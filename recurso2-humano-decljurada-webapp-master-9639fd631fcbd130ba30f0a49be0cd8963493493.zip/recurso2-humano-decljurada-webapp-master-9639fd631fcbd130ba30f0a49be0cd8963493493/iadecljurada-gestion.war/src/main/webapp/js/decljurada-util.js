// =================================================================
// UTILITARIOS
// =================================================================

function mostrarMensajeError(mensaje, callbackFunction){
	bootbox.dialog({
		title: "Error",
		message: "<div class=\"text-danger\"><strong><i class=\"fa fa-exclamation-circle\"></i></strong> " + mensaje + "</div>",
		buttons: {ok: {label: "Aceptar",className: "btn-danger", callback : function(){
			if(callbackFunction!=null)
				callbackFunction();
			}}}});
}

function mostrarMensajeExito(mensaje, callbackFunction){
	bootbox.dialog({
		title: "Mensaje",
		message: "<div class=\"text-success\"><strong><i class=\"fa fa-check-circle\"></i></strong> " + mensaje + "</div>",
		buttons: {ok: {label: "Aceptar",className: "btn-success", callback : function(){
			if(callbackFunction!=null)
				callbackFunction();
			}}}});
}

var confirmarOperacion = function(mensaje, callbackFunction) {
	bootbox.confirm({
		title : "Confirmaci&oacute;n",
		message : mensaje,
		buttons : {
			cancel : {label : '<i class="fa fa-times"></i> No'},
			confirm : {label : '<i class="fa fa-check"></i> S&iacute;'}
		},
		callback : function(result) {
			if(result) 
				callbackFunction();
		}
	});
};

var limpiarMensajesError = function(formElement){
	 var validator = $(formElement).validate();
	 $('[name]',formElement).each(function(){
		$(this).closest('.custom-form-group').removeClass('has-error');
		$(this).closest('div').removeClass('has-error');
	 });
	 validator.resetForm();//remove error class on name elements and clear history
};

var convertirFormAObject = function(formArray) {
	var returnArray = {};
	for (var i = 0; i < formArray.length; i++){
		var cadena = formArray[i]['value'];
		if(cadena!=null)returnArray[formArray[i]['name']] = cadena.toUpperCase();
		else  returnArray[formArray[i]['name']] = formArray[i]['value'];
	}
	return returnArray;
};

var esVacioNulo = function(field){
	return (field == null || $.trim(field) == '');
}

var reemplazaNulo = function(field){
	if(field == null)
		return '';
	else
		return $.trim(field);
}

// =================================================================
// UTILITARIOS
// =================================================================
	
function validarTelefono(numTelef){
	var arrNumTelef = numTelef.split('*');
	var numFormat = arrNumTelef.join('0');
    var numeroPalabras = arrNumTelef.length; 
    mensajeNumTelef = '';
    
    if(!esVacioNulo(numTelef)){
	    if(numeroPalabras<3){
	         if(numTelef.indexOf('*')==0 || numTelef.lastIndexOf('*')==(numTelef.length-1)){
	        	mensajeNumTelef = "No puede haber un * al inicio o fin.";
	         }else if (!esnumero(numFormat)){
	        	mensajeNumTelef = "Ingrese un Número de Teléfono válido.";
	         }
	    }else{
	    	mensajeNumTelef = "Solo se permite a lo más un asterisco (*).";
	    }
    }
    return mensajeNumTelef;
}

function configurarMensajeValidator(method, validator, element, mensaje){
	if(validator.settings.messages[element.name]==null)
		validator.settings.messages[element.name] = {};
	validator.settings.messages[element.name][method] = function () { return mensaje;};
}

function getDoc(frame) {
	
	var doc = null;
	try {
		if (frame.contentWindow) {
			doc = frame.contentWindow.document;	
		}
	} catch(err) {
	}
	if(doc){
		return doc;
	}
	try {
		doc = frame.contentDocument ? frame.contentDocument : frame.document;
	} catch(err) {
		doc = frame.document;
	}
	return doc;
	
}

function calcularEdad(birthDate) {
    var today = new Date();
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}
