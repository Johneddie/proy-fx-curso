// =================================================================
// VALIDATE
// =================================================================

$("#frmRegistrarDeclaracion").validate({
	ignore: false,
	errorElement: 'span',
	errorClass: 'help-block',
	rules: {
		codDocumDer:{
			required: true
		},
		numDocumDer:{
			required: true,
			valNumDocumDer: true 
		},
		
		codPaisEmiDoc:{
			valCodPaisEmiDoc: {depends:true}
		},
		fecNacimientoDer:{
			required: true,
			valFecNacimientoDer:{depends:true}
		},
		apePatDer:{
			valApePatDer:{depends:true}
		},
		nomDer:{
			required: true
		},
		indSexoDer:{
			valIndSexoDer:{depends:true}
		},
		codVinFam:{
			required: true,
			valCodVinFam: true 
		},
		codDocAcreVin:{
			required: true,
			valCodDocAcreVin: true 
		},
		numDocAcreVin:{
			valNumDocAcreVin: true 
		},
		fecInivinc:{
			valFecInivincExi: true,
			valFecInivincMax: true 
		},
		numMesConcep:{
			pattern:"^([0-9]{6})?$",
			valNumMesConcepExi: true,
			valNumMesConcepMax: true
		},
		//baja
		indSituFam:{
			valIndSituFam:true
		},
		fecBaja:{
			valFecBaja: true
		},
		codBaja:{
			valCodBaja: true
		},
		//complementarios
		numRegistro:{
			pattern: "^([a-zA-Z0-9]{4})?$"
		},
		codTelefLarDis:{
			valCodTelefLarDis:{depends:true}
		},
		numTelef:{
			minlength: 6,
			maxlength: 9,
			valNumTelef:{depends:true}
		},
		codCelLarDis:{
			valCodCelLarDis:{depends:true}
		},
		numCelular:{
			valNumCelular:{depends:true},
			pattern:"^([0-9]*)?$"
		},
		desCorreo:{
			valDesCorreo:{depends:true}
		},
		//domicilio actual
		codUbigeoDir2Depa:{
			valCodUbigeoDir2Depa:{depends:true}
		},
		codUbigeoDir2Prov:{
			valCodUbigeoDir2Prov:{depends:true}
		},
		codUbigeoDir2:{
			valCodUbigeoDir2:{depends:true}
		},
		codViaDir2:{
			valCodViaDir2:{depends:true}
		},
		nomViaDir2:{
			valNomViaDir2:{depends:true}
		},
		numViaDir2:{
			valNumViaDir2:{depends:true},
			pattern:"^([0-9]*|sn|SN|Sn|sN)?$"
		},
		numKilomDir2:{
			valNumKilomDir2:{depends:true},
			valNumKilomDir2WithVia:{depends:true}
		},
		desReferDir2:{
			valDesReferDir2:{depends:true}
		},
		//domicilio manual reniec
		codUbigeoDir1Depa:{
			valCodUbigeoDir1Depa:{depends:true}
		},
		codUbigeoDir1Prov:{
			valCodUbigeoDir1Prov:{depends:true}
		},
		codUbigeoDir1:{
			valCodUbigeoDir1:{depends:true}
		},
		codViaDir1:{
			valCodViaDir1:{depends:true}
		},
		nomViaDir1:{
			valNomViaDir1:{depends:true}
		},
		numViaDir1:{
			valNumViaDir1:{depends:true},
			pattern:"^([0-9]*|sn|SN|Sn|sN)?$"
		},
		numKilomDir1:{
			valNumKilomDir1:{depends:true},
			valNumKilomDir1WithVia:{depends:true}
		},
		desReferDir1:{
			valDesReferDir1:{depends:true}
		},
		indDiscapacidad:{
			valIndDiscapacidad:{depends:true},
			valIndDiscapacidadConadis:{depends:true},
		}

    },
    messages: {
    	codDocumDer:{
			required: 'Seleccione el Tipo de Documento.'
		},
    	numDocumDer:{
			required: 'Ingrese el Número de Documento.'
		},
		
		fecNacimientoDer:{
			required: 'Ingrese la Fecha de Nacimiento.'
		},
		nomDer:{
			required: 'Ingrese el Nombre completo.'
		},
		codVinFam:{
			required: 'Seleccione el Tipo de Vínculo Familiar.'
		},
		codDocAcreVin:{
			required: 'Seleccione el Tipo de Documento que Acredite Vínculo.'
		},
		numMesConcep:{
			pattern: "Ingrese correctamente el Mes de Concepción."
		},
		numRegistro:{
			pattern:"Ingrese cuatro (4) caracteres entre números o letras."
		},
		numViaDir2:{
			pattern:"Ingrese número válido."
		},
		numViaDir1:{
			pattern:"Ingrese número válido."
		},
		numTelef:{
			minlength: 'Ingrese un Número de Teléfono válido.',
			maxlength: 'Ingrese un Número de Teléfono válido.'
		},
		numCelular:{
			pattern:"Ingrese caracteres numéricos para el Número de Celular."
		}
	},
	highlight: function (e) {
		if($(e).is("input[tipo^='addon']")||$(e).is("select[tipo^='addon']")) {
			$(e).closest('.custom-form-group').addClass('has-error');
			$(e).addClass('has-error');		
		}else{
			$(e).parent().addClass('has-error');
		}
	},
	success: function (e) {
		$(e).parent().removeClass('has-error');
		$(e).closest('.input-group').removeClass('has-error');
		$(e).remove();
	},
	errorPlacement: function (error, element) {
		if(element.is("input[tipo^='addon']")||element.is("select[tipo^='addon']")) {
			if(element.attr("type") == 'radio')
				error.insertAfter(element.parent().parent());
			else
				error.insertAfter(element.parent());
		}else{
			error.insertAfter(element);	
		}
	},
	submitHandler: function (form) {
		
		var declaracion = convertirFormAObject($("#frmRegistrarDeclaracion").serializeArray());
		declaracion.archivosReferDomicilio = listaArchivosReferDomicilio;
		declaracion.archivosAcredVinculo =  listaArchivosAcredVinculo;
		declaracion.archivosBajaDerechohab =  listaArchivosBajaDerechohab;
		declaracion.archivosSubsidSepelio =  listaArchivosSubsidSepelio;
		declaracion.archivosDiscapacidad =  listaArchivosDiscapacidad;
		declaracion.annDdjj = $("#annDdjj").val();
		declaracion.codPersonal = $("#codPersonal").val();
		declaracion.numDdjj = $("#numDdjj").val();
		declaracion.indEstado = $("#indEstado").val();
		declaracion.indReniec = $("#indReniec").val();
		declaracion.codDocum = $("#codDocum").val();
		declaracion.numDocum = $("#numDocum").val();
		declaracion.indSituFam = $("input[name=indSituFam]:checked").val();
		declaracion.indSubsidSepe = $('#indSubsidSepe').is(":checked")?'1':'0';//baja
		declaracion.indDiscapacidad = $("input[name=indDiscapacidad]:checked").val(); //discapacidad
		declaracion.indEstudiante = $('#indEstudiante').is(":checked")?'1':'0'; // estudiante
		declaracion.codPaisEmiDoc = $("#codPaisEmiDoc").val();
		
		var esReniec = $("#codDocumDer").val()=='01' && $("#indReniec").val()=='1';
		var indEstado = $("#indEstado").val();
		
		if((esReniec && esVacioNulo(indEstado)) || indEstado == 'D' || indEstado == 'A'|| indEstado == 'P'){
			declaracion.codDocumDer = $("#codDocumDer").val();//personales
			declaracion.numDocumDer = $("#numDocumDer").val();
			declaracion.fecNacimientoDer = $("#fecNacimientoDer").val();
			declaracion.indSexoDer = $("input[name=indSexoDer]:checked").val();
			declaracion.nomDer = $("#nomDer").val();
			declaracion.apePatDer = $("#apePatDer").val();
			declaracion.apeMatDer = $("#apeMatDer").val()
			
			declaracion.desDomiciDir1 = $("#desDomiciDir1").val();//domicilio reniec
			declaracion.desUbigeoDir1 = $("#desUbigeoDir1").val();
		}
		
		//elementos no utilizados
		delete declaracion.codUbigeoDir1Depa;
		delete declaracion.codUbigeoDir1Prov;
		delete declaracion.codUbigeoDir2Depa;
		delete declaracion.codUbigeoDir2Prov;
		
		registrarActualizarDeclaracionAjax(declaracion);//nuevo
			
	},
	invalidHandler: function (e,validator) {
		console.log("invalidHandler");
		var idPanelColapsado;
		for (var i=0;i<validator.errorList.length;i++){
			console.log($(validator.errorList[i].element).attr('id'));
			idPanelColapsado = $(validator.errorList[i].element).closest('.panel-collapse.collapse').attr('id');
			break;
		}
		if(!$('#'+idPanelColapsado).hasClass('in'))
			$('#'+idPanelColapsado+'_link').click();
	}
});

// =================================
// Datos generales.
// =================================

//numero de documento
$.validator.addMethod("valNumDocumDer", function(numDocumDer, element) {
	var codDocumDer = $('#codDocumDer').val();
	if (codDocumDer == '01' && numDocumDer.length != 8){ //dni
		configurarMensajeValidator('valNumDocumDer',this, element, 'El tamaño máximo para el Nro. Documento es 8.');
		return false;
	}
	if (codDocumDer == '04' && numDocumDer.length > 11){ //ce
		configurarMensajeValidator('valNumDocumDer',this, element, 'El tamaño máximo para el Nro. Documento es 11.');
		return false;
	}
	if (codDocumDer == '07' && numDocumDer.length > 15){ //pass
		configurarMensajeValidator('valNumDocumDer',this, element, 'El tamaño máximo para el Nro. Documento es 15.');
		return false;
	}
	return true;
}, "Número de Documento no válido.");

//pais emisor de documento
$.validator.addMethod("valCodPaisEmiDoc", function(codPaisEmiDoc, element) {
	var codDocumDer = $('#codDocumDer').val();
	if (codDocumDer == '07' && esVacioNulo(codPaisEmiDoc)) //pasaporte
		return false;
	return true;
}, "Seleccione el País Emisor del Documento.");

//fecha de nacimiento
$.validator.addMethod("valFecNacimientoDer", function(value, element) {
	var fecNacimientoDer = $('#divFecNacimientoDer').data('DateTimePicker').date();
	var today = new Date();
	return fecNacimientoDer <= today;
}, "Ingrese una Fecha de Nacimiento válida, anterior al día de hoy.");

//apellido paterno o materno
$.validator.addMethod("valApePatDer", function(apePatDer, element) {
	var apeMatDer = $('#apeMatDer').val();
	if (esVacioNulo(apePatDer) && esVacioNulo(apeMatDer)) 
		return false;
	return true;
}, "Ingrese al menos un Apellido (paterno o materno).");

//sexo
$.validator.addMethod("valIndSexoDer", function(value, element) {
	return $("#indSexoDerMas").is(':checked') || $("#indSexoDerFem").is(':checked')
}, "Seleccione el Sexo.");

// =================================
// Vínculo familiar
// =================================

$.validator.addMethod("valCodVinFam", function(codVinFam, element) {
	var indSexoDer = $("input[name=indSexoDer]:checked").val();
	if(indSexoDer == '1' && codVinFam == '04')
		return false;
	return true;
},"Un hombre no puede ser Gestante.");

//tipo documento acredita
$.validator.addMethod("valCodDocAcreVin", function(codDocAcreVin, element) {
	var codVinFam = $('#codVinFam').val();
	if(codVinFam == '02' && (codDocAcreVin != '05' && codDocAcreVin != '06' && codDocAcreVin != '07')) //conyugue
		return false;
	if(codVinFam == '03' && (codDocAcreVin != '08' && codDocAcreVin != '09' )) //concubina
		return false;
	if(codVinFam == '04' && (codDocAcreVin != '01' && codDocAcreVin != '02' && codDocAcreVin != '03')) //gestante
		return false;
	if(codVinFam == '06' &&  codDocAcreVin != '04') //incapacitado
		return false;
	if(codVinFam == '05' && (codDocAcreVin != '10' /*&& codDocAcreVin != '04'*/)) //hijo
		return false;
	if(codVinFam == '12' && (codDocAcreVin != '10' /*&& codDocAcreVin != '04'*/)) //tenencia menor
		return false;
	return true;
}, "El Tipo de Documento no corresponde al Vínculo Familiar");

//número de documento acredita
$.validator.addMethod("valNumDocAcreVin", function(numDocAcreVin, element) {
	var codVinFam = $('#codVinFam').val();
	var codDocAcreVin = $('#codDocAcreVin').val();
	if (numDocAcreVin == '' && (codVinFam == '03' || codVinFam == '06' ) && codDocAcreVin != '')
		return false;
	return true;
}, "Ingrese el Número que Acredite el Vínculo.");


//fecha de inicio de vínculo
$.validator.addMethod("valFecInivincExi", function(fecInivinc, element) {
	var codVinFam = $('#codVinFam').val();
	if (fecInivinc == '' && (codVinFam == '02' || codVinFam == '03' )) //conyugue o concubina 
		return false;
	return true;
}, "Ingrese la Fecha de Inicio de Vínculo para Cónyuge o Concubino(a).");

$.validator.addMethod("valFecInivincMax", function(value, element) {
	var codVinFam = $('#codVinFam').val();
	var fecInivinc = $('#divFecInivinc').data('DateTimePicker').date();
	var today = new Date();
	if (!esVacioNulo(fecInivinc) && (codVinFam == '02' || codVinFam == '03' ) && fecInivinc > today)
		return false;
	return true;
}, "Ingrese una Fecha de Inicio de Vínculo menor o igual al día de hoy.");

//mes de concepción
$.validator.addMethod("valNumMesConcepExi", function(numMesConcep, element) {
	var codVinFam = $('#codVinFam').val();
	if (esVacioNulo(numMesConcep) && codVinFam == '04')
		return false;
	return true;
}, "Ingrese el Mes de Concepción.");

$.validator.addMethod("valNumMesConcepMax", function(numMesConcep, element) {
	var codVinFam = $('#codVinFam').val();
	if (!esVacioNulo(numMesConcep) && codVinFam == '04' && parseInt(numMesConcep.substr(0,2)) > 12)
		return false;
	return true;
}, "Ingrese el Mes de Concepción en formato MMAAAA.");

// =================================
// Baja familiar
// =================================
// situación
$.validator.addMethod("valIndSituFam", function(value, element) {
	return $("#indSituFamAct").is(':checked') || $("#indSituFamBaj").is(':checked')
}, "Seleccione la Situación.");

$.validator.addMethod("valFecBaja", function(fecBaja, element) {
	if (fecBaja == '' && $("#indSituFamBaj").is(':checked')) 
		return false;
	return true;
}, "Ingrese la Fecha de Baja.");

$.validator.addMethod("valCodBaja", function(codBaja, element) {
	if (codBaja == '' && $("#indSituFamBaj").is(':checked')) 
		return false;
	return true;
}, "Seleccione el Motivo de Baja.");


// =================================
// Datos complementarios.
// =================================

//número de teléfono
$.validator.addMethod("valCodTelefLarDis", function(codTelefLarDis, element) {
	var numTelef = $('#numTelef').val();
	if(!esVacioNulo(numTelef) && esVacioNulo(codTelefLarDis))
		return false;
	return true;
}, "Seleccione el Código de Ciudad.");

$.validator.addMethod("valNumTelef", function(numTelef, element) {
	var codTelefLarDis = $('#codTelefLarDis').val();
	//sin dato
	if(esVacioNulo(numTelef) && !esVacioNulo(codTelefLarDis)){
		configurarMensajeValidator('valNumTelef',this, element, 'Ingrese el Número de Teléfono.');
		return false;
	}
	//con dato
	var mensajeNumTelef = validarTelefono(numTelef);
	if(!esVacioNulo(mensajeNumTelef)){
		configurarMensajeValidator('valNumTelef',this, element, mensajeNumTelef);
		return false;
	}
	return true;
}, 'Ingrese un Número de Teléfono correcto.');

//número de celular
$.validator.addMethod("valCodCelLarDis", function(codCelLarDis, element) {
	var numCelular = $('#numCelular').val();
	if(!esVacioNulo(numCelular) && esVacioNulo(codCelLarDis))
		return false;
	return true;
}, "Seleccione el Código de Ciudad.");

$.validator.addMethod("valNumCelular", function(numCelular, element) {
	var codCelLarDis = $('#codCelLarDis').val();
	//sin dato
	if(esVacioNulo(numCelular) && !esVacioNulo(codCelLarDis)){
		return false;
	}
	return true;
}, 'Ingrese el Número de Celular.');

//validar correo
$.validator.addMethod("valDesCorreo", function(desCorreo, element) {
	if(!esVacioNulo(desCorreo) && !validacorreo(desCorreo))
		return false;
	return true;
}, "Ingrese un Correo válido.");


//=========================
//domicilio actual - ubigeo
//=========================
$.validator.addMethod("valCodUbigeoDir2Depa", function(codUbigeoDir2Depa, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	if(esDomiActualEditado == '1' && esVacioNulo(codUbigeoDir2Depa))
		return false;
	return true;
}, "Ingrese el Departamento.");
$.validator.addMethod("valCodUbigeoDir2Prov", function(codUbigeoDir2Prov, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	if(esDomiActualEditado == '1' && esVacioNulo(codUbigeoDir2Prov))
		return false;
	return true;
}, "Ingrese la Provincia.");
$.validator.addMethod("valCodUbigeoDir2", function(codUbigeoDir2, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	if(esDomiActualEditado == '1' && esVacioNulo(codUbigeoDir2))
		return false;
	return true;
}, "Ingrese el Distrito.");

$.validator.addMethod("valCodViaDir2", function(codViaDir2, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	if(esDomiActualEditado == '1' && esVacioNulo(codViaDir2))
		return false;
	return true;
}, "Ingrese el Tipo de Vía.");

$.validator.addMethod("valNomViaDir2", function(nomViaDir2, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	if(esDomiActualEditado == '1' && esVacioNulo(nomViaDir2))
		return false;
	return true;
}, "Ingrese el Nombre de la Vía.");

$.validator.addMethod("valNumViaDir2", function(numViaDir2, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	if(esDomiActualEditado == '1' && esVacioNulo(numViaDir2))
		return false;
	return true;
}, "Ingrese Nro. de Vía, si no tiene ingresar \"sn\".");
$.validator.addMethod("valNumKilomDir2", function(numKilomDir2, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	var numManzDir2 = $('#numManzDir2').val();
	var numLoteDir2 = $('#numLoteDir2').val();
	var numViaDir2 = $('#numViaDir2').val().toLowerCase();
	
	if(esDomiActualEditado == '1'){
		if(numViaDir2 == 'sn' && esVacioNulo(numKilomDir2) && esVacioNulo(numManzDir2) && esVacioNulo(numLoteDir2)){
			return false;
		}
	}
	return true;
}, 'Ingrese Nro. de Vía, Manzana, Lote o Kilómetro.');
$.validator.addMethod("valNumKilomDir2WithVia", function(numKilomDir2, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	var numViaDir2 = $('#numViaDir2').val().toLowerCase();
	
	if(esDomiActualEditado == '1'){
		if(!esVacioNulo(numViaDir2) && numViaDir2 != 'sn' && numKilomDir2 != ''){
			return false;
		}
	}
	return true;
}, 'No puede ingresar Kilómetro si ya registró el Nro. de Vía.');


$.validator.addMethod("valDesReferDir2", function(desReferDir2, element) {
	var esDomiActualEditado = $('#esDomiActualEditado').val();
	var numViaDir2 = $('#numViaDir2').val().toLowerCase();
	if(esDomiActualEditado == '1' && numViaDir2 == 'sn' && esVacioNulo(desReferDir2))
		return false;
	return true;
}, "Ingrese una Referencia.");

//=======================
//domicilio manual reniec
//=======================
$.validator.addMethod("valCodUbigeoDir1Depa", function(codUbigeoDir1Depa, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	if(!esReniec && esVacioNulo(codUbigeoDir1Depa))
		return false;
	return true;
}, "Ingrese el Departamento.");
$.validator.addMethod("valCodUbigeoDir1Prov", function(codUbigeoDir1Prov, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	if(!esReniec && esVacioNulo(codUbigeoDir1Prov))
		return false;
	return true;
}, "Ingrese la Provincia.");
$.validator.addMethod("valCodUbigeoDir1", function(codUbigeoDir1, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	if(!esReniec && esVacioNulo(codUbigeoDir1))
		return false;
	return true;
}, "Ingrese el Distrito.");

$.validator.addMethod("valCodViaDir1", function(codViaDir1, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	if(!esReniec && esVacioNulo(codViaDir1))
		return false;
	return true;
}, "Ingrese el Tipo de Vía.");

$.validator.addMethod("valNomViaDir1", function(nomViaDir1, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	if(!esReniec && esVacioNulo(nomViaDir1))
		return false;
	return true;
}, "Ingrese el Nombre de la Vía.");

$.validator.addMethod("valNumViaDir1", function(numViaDir1, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	if(!esReniec && esVacioNulo(numViaDir1))
		return false;
	return true;
}, "Ingrese Nro. de Vía, si no tiene ingresar \"sn\".");
$.validator.addMethod("valNumKilomDir1", function(numKilomDir1, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	var numManzDir1 = $('#numManzDir1').val();
	var numLoteDir1 = $('#numLoteDir1').val();
	var numViaDir1 = $('#numViaDir1').val().toLowerCase();
	
	if(!esReniec){
		if(numViaDir1 == 'sn' && esVacioNulo(numKilomDir1) && esVacioNulo(numManzDir1) && esVacioNulo(numLoteDir1)){
			return false;
		}
	}
	return true;
}, 'Ingrese Nro. de Vía, Manzana, Lote o Kilómetro.');
$.validator.addMethod("valNumKilomDir1WithVia", function(numKilomDir1, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	var numViaDir1 = $('#numViaDir1').val().toLowerCase();
	
	if(!esReniec){
		if(!esVacioNulo(numViaDir1) && numViaDir1 != 'sn' && numKilomDir1 != ''){
			return false;
		}
	}
	return true;
}, 'No puede ingresar Kilómetro si ya registró el Nro. de Vía.');


$.validator.addMethod("valDesReferDir1", function(desReferDir1, element) {
	var esReniec = $('#codDocumDer').val()=='01' && $('#indReniec').val()=='1';
	var numViaDir1 = $('#numViaDir1').val().toLowerCase();
	if(!esReniec && numViaDir1 == 'sn' && esVacioNulo(desReferDir1))
		return false;
	return true;
}, "Ingrese una Referencia.");


//discapacidad
$.validator.addMethod("valIndDiscapacidad", function(value, element) {
	return $("#indDiscapacidadSi").is(':checked') || $("#indDiscapacidadNo").is(':checked')
}, "Indique si posee alguna discapacidad.");

$.validator.addMethod("valIndDiscapacidadConadis", function(value, element) {
	if($("#indDiscapacidadSi").is(':checked')){
		for(var i=0; i<listaArchivosDiscapacidad.length; i++){
			if(listaArchivosDiscapacidad[i].codAccion!='3')
				return true;
		}
		return false
	}
	return true;
}, "Debe adjuntar la resolución del CONADIS.");
