package pe.gob.sunat.recurso2.humano.decljurada.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaborador;
import pe.gob.sunat.recurso2.humano.decljurada.service.CatalogoService;
import pe.gob.sunat.recurso2.humano.decljurada.service.DeclaraColaboradorService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/declaraColaborador")
public class DeclaraColaboradorController {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private DeclaraColaboradorService declaraColaboradorService;
	
	@Autowired
	private CatalogoService catalogoService;
	
	@RequestMapping("/inicio")
	public ModelAndView iniciarDeclaraColaborador(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method iniciarDeclaraColaborador");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map<String,Object> parametros = new HashMap<>();
		//catalogos
		parametros.put("listaDepartamentos", catalogoService.listarDepartamentos());
		parametros.put("listaTiposDocumento", catalogoService.listarTiposDocumento());
		parametros.put("listaNacionalidades", catalogoService.listarNacionalidades());
		parametros.put("listaEstadosCivil", catalogoService.listarEstadosCivil());
		parametros.put("listaCodigosLDN", catalogoService.listarCodigosLDN());
		parametros.put("listaPaisesEmisor", catalogoService.listarPaisesEmisor());
		parametros.put("listaTiposVia", catalogoService.listarTiposVia());
		parametros.put("listaTiposZona", catalogoService.listarTiposZona());
		parametros.put("codPersonal", usuarioBean.getNroRegistro());
		
		return new ModelAndView("colaborador/DeclaraColaborador", parametros);
	}
	
	@RequestMapping(value = "/obtener/{codPersonal}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody
	public DeclaraColaborador obtenerDeclaracion(HttpServletRequest request, @PathVariable("codPersonal") String codPersonal)  {
		log.debug("method obtenerDeclaracion");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		return declaraColaboradorService.obtenerUltimaDeclaracion(usuarioBean.getNroRegistro());
	}
	
	@RequestMapping(value = "/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE}) 
	public @ResponseBody Map<String,Object> registrarDeclaraColaborador(@RequestBody DeclaraColaborador declaraColaborador, HttpServletRequest request) throws Exception {
		if(log.isDebugEnabled()) log.debug("method registrarDeclaraColaborador");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String, String> mapUsuario = new HashMap<>();
		mapUsuario.put("usuario", usuarioBean.getNroRegistro());
		mapUsuario.put("unidad", usuarioBean.getCodUO());
		mapUsuario.put("ticket", usuarioBean.getTicket());
		return declaraColaboradorService.registrarDeclaraColaborador(declaraColaborador, mapUsuario);
	}

}
