package pe.gob.sunat.recurso2.humano.decljurada.web.controller;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohab;
import pe.gob.sunat.recurso2.humano.decljurada.model.Persona;
import pe.gob.sunat.recurso2.humano.decljurada.service.CatalogoService;
import pe.gob.sunat.recurso2.humano.decljurada.service.DeclaraDerechohabService;
import pe.gob.sunat.recurso2.humano.decljurada.util.Utiles;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/declaraDerechohab")
public class DeclaraDerechohabController {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private DeclaraDerechohabService declaraDerechohabService;
	
	@Autowired
	private CatalogoService catalogoService;
	
	@RequestMapping("/inicio")
	public ModelAndView iniciarDeclaraDerechohab(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method iniciarDeclaraDerechohab");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map<String,Object> parametros = new HashMap<>();
		//catalogos
		parametros.put("listaDepartamentos", catalogoService.listarDepartamentos());
		parametros.put("listaTiposDocumento", catalogoService.listarTiposDocumento());
		parametros.put("listaEstadosCivil", catalogoService.listarEstadosCivil());
		parametros.put("listaCodigosLDN", catalogoService.listarCodigosLDN());
		parametros.put("listaPaisesEmisor", catalogoService.listarPaisesEmisor());
		parametros.put("listaTiposVia", catalogoService.listarTiposVia());
		parametros.put("listaTiposZona", catalogoService.listarTiposZona());
		
		parametros.put("listaTiposVinculo", catalogoService.listarTiposVinculo());
		parametros.put("listaMotivosBaja", catalogoService.listarMotivosBaja());
		parametros.put("listaDocumentosVinculo", catalogoService.listarDocumentosVinculo());
		
		parametros.put("esReglSubsidSepe", declaraDerechohabService.esRegimenPermitidoSubsidSepe(usuarioBean.getNroRegistro()));
		
		return new ModelAndView("derechohab/DeclaraDerechohab", parametros);
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/ultimos/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<DeclaraDerechohab> listarUltimasDeclaraciones(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		if(log.isDebugEnabled()) log.debug("method listarUltimasDeclaraciones");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		mapParams.put("codPersonal", usuarioBean.getNroRegistro());
		return declaraDerechohabService.listarUltimasDeclaraciones(usuarioBean.getNroRegistro());
	}
	
	
	@RequestMapping(value = "/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE}) 
	public @ResponseBody Map<String,Object> registrarDeclaraDerechohab(@RequestBody DeclaraDerechohab declaraDerechohab, HttpServletRequest request) throws Exception {
		if(log.isDebugEnabled()) log.debug("method registrarDeclaraDerechohab");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String, String> mapUsuario = new HashMap<>();
		mapUsuario.put("usuario", usuarioBean.getNroRegistro());
		mapUsuario.put("unidad", usuarioBean.getCodUO());
		mapUsuario.put("ticket", usuarioBean.getTicket());
		return declaraDerechohabService.registrarDeclaraDerechohab(declaraDerechohab, mapUsuario);
	}
	
	@RequestMapping(value = "/obtener/{declaracionPK}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody
	public DeclaraDerechohab obtenerDeclaracion(HttpServletRequest request, @PathVariable("declaracionPK") String declaracionPK)  {
		log.debug("method obtenerDeclaracion");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		return declaraDerechohabService.obtenerDeclaracion(usuarioBean.getNroRegistro(), declaracionPK);
	}
	
	@RequestMapping(value = "/derechohabReniec/{numDocumDer}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody
	public DeclaraDerechohab obtenerDerechohabReniec(HttpServletRequest request, @PathVariable("numDocumDer") String numDocumDer)  {
		log.debug("method obtenerDeclaracion");
		return declaraDerechohabService.obtenerDerechohabReniec(numDocumDer);
	}
	
	@RequestMapping(value = "/personal/{numDocumDer}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody
	public Persona obtenerPersonal(HttpServletRequest request, @PathVariable("numDocumDer") String numDocumDer)  {
		log.debug("method obtenerDeclaracion");
		return declaraDerechohabService.obtenerPersonal(numDocumDer);
	}
	
}
