package pe.gob.sunat.recurso2.humano.decljurada.web.controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;
import pe.gob.sunat.recurso2.humano.decljurada.service.CatalogoService;

@Controller
@RequestMapping(value="/catalogo")
public class CatalogoController {
	
	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	private CatalogoService catalogoService;
	
	@RequestMapping(value = "/departamentos/{codDepartamento}/provincias", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarProvincias(@PathVariable("codDepartamento") String codDepartamento)  {
		log.info("Listando provincias....");
		return catalogoService.listarProvincias(codDepartamento);
	}
	
	
	@RequestMapping(value = "/provincias/{codProvincia}/distritos", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarDistritos(@PathVariable("codProvincia") String codProvincia)  {
		log.info("Listando distritos....");
		return catalogoService.listarDistritos(codProvincia);
	}

}
