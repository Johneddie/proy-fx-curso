package pe.gob.sunat.recurso2.humano.decljurada.web.controller;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.humano.decljurada.model.Seguimiento;
import pe.gob.sunat.recurso2.humano.decljurada.service.CatalogoService;
import pe.gob.sunat.recurso2.humano.decljurada.service.SeguimientoService;
import pe.gob.sunat.recurso2.humano.decljurada.util.Utiles;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Controller
@RequestMapping(value="/seguimiento")
public class SeguimientoController {
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private SeguimientoService seguimientoService;
	
	@Autowired
	private CatalogoService catalogoService;
	
	@RequestMapping("/inicio")
	public ModelAndView iniciarBandejaDeclaraciones(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method iniciarDeclaraColaborador");
		Map<String,Object> parametros = new HashMap<>();
		//catalogos
		parametros.put("listaTiposDeclaracion", catalogoService.listarTiposDeclaracion());
		return new ModelAndView("seguimiento/DeclaracionesJuradas", parametros);
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/iniciadas/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Seguimiento> listarIniciadas(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		if(log.isDebugEnabled()) log.debug("method listarIniciadas");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		mapParams.put("codPersonal", usuarioBean.getNroRegistro());
		return seguimientoService.listarDeclaraciones(mapParams);
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/seguimientos/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Seguimiento> listarSeguimientos(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		if(log.isDebugEnabled()) log.debug("method listarSeguimientos");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String, String> mapParams = Utiles.obtenerMapFromParameterMap(request.getParameterMap());
		mapParams.put("codPersonal", usuarioBean.getNroRegistro());
		return seguimientoService.listarSeguimientos(mapParams);
	}
	
}
