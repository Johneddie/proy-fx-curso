package pe.gob.sunat.recurso2.humano.decljurada.util;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DecljuradaUtil {
	
	private static final Log log = LogFactory.getLog("pe.gob.sunat.recurso2.humano.decljurada.util.DecljuradaUtil");
		
		public static String obtenerIndSexo(String strSexo){
			String indSexo = null;
			if(strSexo != null){
			    switch (strSexo) {
		            case "M":
		            	indSexo = "1"; 
		            	break;
		            case "F":
		            	indSexo = "2"; 
		            	break;
		            default: 
		            	indSexo = ""; 
		            	break;
		        }
			}
			return indSexo;
		}
		
		public static String obtenerIndDiscapacidad(String strDiscapacidad){
			String indDiscapacidad = null;
			if(strDiscapacidad != null){
			    switch (strDiscapacidad) {
		            case "S":
		            	indDiscapacidad = "1"; 
		            	break;
		            case "N":
		            	indDiscapacidad = "0"; 
		            	break;
		            default: 
		            	indDiscapacidad = ""; 
		            	break;
		        }
			}
			return indDiscapacidad;
		}

}

