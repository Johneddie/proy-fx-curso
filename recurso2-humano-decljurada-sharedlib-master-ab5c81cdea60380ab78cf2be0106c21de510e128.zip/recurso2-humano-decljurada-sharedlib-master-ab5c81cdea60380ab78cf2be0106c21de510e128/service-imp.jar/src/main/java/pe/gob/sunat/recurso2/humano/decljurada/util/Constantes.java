package pe.gob.sunat.recurso2.humano.decljurada.util;


public class Constantes {
	
	private Constantes(){
	}
	
	public static final String IND_ELIMINAD = "1";
	public static final String IND_NOELIMIN = "0";
	
	public static final String ESTA_CODI_ACTI = "1";
	public static final String ESTA_CODI_INAC = "0";
	
	public static final String TIPO_CODI_CABE = "C";
	public static final String TIPO_CODI_DESC = "D";
	
	public static final String ESTA_DECL_RECH = "R";
	public static final String ESTA_DECL_APRO = "A";
	public static final String ESTA_DECL_SEGU = "S";
	public static final String ESTA_DECL_ENVI = "E";
	public static final String ESTA_DECL_DEVU = "D";
	public static final String ESTA_DECL_PROV = "P";
	
	
	public static final String URL_SERV_RENIEC = "http://api.sunat.peru/v1/tecnologia/arquitectura/externos/pe/reniec/e/dni?arg0=16&arg1=1401&arg2=&arg3=4&arg4=0023&arg5=&arg6=&arg7=SUNAT001&arg8=&arg9={DNI}&arg10=NOIP 0.0.0.0&arg11=8A0000&arg12=1&arg13=2";
	
	public static final String CODI_ERRO_EXCEPCION_RENIEC = "9000";
	public static final String CODI_ERRO_NOT_CODE_200 = "9001";
	public static final String CODI_ERRO_NOT_PROCESS = "9002";
	public static final String CODI_ERRO_EXITO_RENIEC = "0000";
	public static final String CODI_ERRO_EXITO_SUNAT = "1111";
	
	public static final String CODI_ADJU_REFE_DOMI = "1";
	public static final String CODI_ADJU_PERS_DISC = "2";
	public static final String CODI_ADJU_ESTA_CIVI = "3";
	public static final String CODI_ADJU_REFE_DERE = "4";
	public static final String CODI_ADJU_ACRE_VINC = "5";
	public static final String CODI_ADJU_BAJA_DERE = "6";
	public static final String CODI_ADJU_SUBS_SEPE = "7";
	
	public static final String CODI_ACCI_ADJU_NUEV = "1";
	public static final String CODI_ACCI_ADJU_MODI = "2";
	public static final String CODI_ACCI_ADJU_ELIM = "3";
	
	public static final String DIRE_TEMP = "/data0/rtps/upload/";
	
	public static final String NOMB_SECU_DDJJ = "SERTPS";
	
	public static final String CODI_USUR_BATC = "BATCH";
	
	public static final String INDI_SITU_FAMI_ALTA = "1";
	public static final String INDI_SITU_FAMI_BAJA = "2";
	
	// ===========
	// PROPIEDADES
	// ===========
	
	//seguimiento.ind_accionid
	public static final String  CODI_ACCI_SEGU_APRO = "1";
	public static final String  CODI_ACCI_SEGU_RECH = "2";
	public static final String  CODI_ACCI_SEGU_ENVI = "3";
	public static final String  CODI_ACCI_SEGU_DERI = "4";
	public static final String  CODI_ACCI_SEGU_DEVO = "5";
	
	//Tipo de Registro RTPS
	public static final String CODI_TIPO_DDJJ_GENE = "01";
	public static final String CODI_TIPO_DDJJ_FAMI = "02";
	
	public static final String CODI_TABL_UNID_RECE = "204";
	public static final String CODI_TABL_ESTA_DECL = "591";
	public static final String CODI_TABL_TIPO_DECL = "592";
	public static final String CODI_TABL_ESTA_CIVI = "111";
	public static final String CODI_TABL_VINC_FAMI = "205";
	public static final String CODI_TABL_SITU_FAMI = "593";
	public static final String CODI_TABL_TIPO_VINC = "205";
	public static final String CODI_TABL_DOCU_VINC = "208";
	public static final String CODI_TABL_MOTI_BAJA = "209";
	public static final String CODI_TABL_REGL_SUBS = "811";
	public static final String CODI_TABL_EQUI_TIPO_DOCU = "594";
	
	public static final String DESC_TABL_UNID_RECE = "UNIDAD RECEPTORA DDJJS TRABAJ Y DERECHOHABIENTE";
	public static final String DESC_OBSE_SEGU = "REGISTRO ENVIADO POR EL TRABAJADOR";
	
}
