package pe.gob.sunat.recurso2.humano.decljurada.service;


import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;
import pe.gob.sunat.recurso2.humano.decljurada.model.CodigoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamContribuyenteDAO;
import pe.gob.sunat.recurso2.humano.decljurada.util.Constantes;



@Service("catalogoService")
public class CatalogoServiceImpl implements CatalogoService{

	public final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private CodigoDAO codigoDAO;
	
	@Autowired
	private ParamContribuyenteDAO paramContribuyenteDAO;
	
	@Override
	public List<Parametro> listarDepartamentos() {
		return paramContribuyenteDAO.listarDepartamentos();
	}

	
	@Override
	public List<Parametro> listarProvincias(String codDepartamento) {
		return paramContribuyenteDAO.listarProvincias(codDepartamento);
	}

	@Override
	public List<Parametro> listarDistritos(String codProvincia) {
		return paramContribuyenteDAO.listarDistritos(codProvincia);
	}
	
	@Override
	public List<Parametro> listarEstadosCivil() {
		return listarCodigosByTabla(Constantes.CODI_TABL_ESTA_CIVI);
	}
	
	@Override
	public List<Parametro> listarTiposDeclaracion() {
		return listarCodigosByTabla(Constantes.CODI_TABL_TIPO_DECL);
	}
	
	@Override
	public List<Parametro> listarTiposVinculo() {
		return listarCodigosByTablaNoEstado(Constantes.CODI_TABL_TIPO_VINC);
	}
	
	@Override
	public List<Parametro> listarDocumentosVinculo() {
		String[] arrCodigos = {"01","02","03","04","05","08","09","10"};
		CodigoExample ce = new CodigoExample();
		CodigoExample.Criteria cc = ce.createCriteria();
		cc.andT99codTabEqualTo(Constantes.CODI_TABL_DOCU_VINC);
		cc.andT99tipDescEqualTo(Constantes.TIPO_CODI_DESC);
		cc.andT99codigoIn(Arrays.asList(arrCodigos));
		return codigoDAO.selectByExampleBasic(ce);
		
	}
	
	@Override
	public List<Parametro> listarMotivosBaja() {
		String[] arrCodigos = {"02","03","04","05","06"};
		CodigoExample ce = new CodigoExample();
		CodigoExample.Criteria cc = ce.createCriteria();
		cc.andT99codTabEqualTo(Constantes.CODI_TABL_MOTI_BAJA);
		cc.andT99tipDescEqualTo(Constantes.TIPO_CODI_DESC);
		cc.andT99codigoIn(Arrays.asList(arrCodigos));
		return codigoDAO.selectByExampleBasic(ce);
	}
	
	
	
	private List<Parametro> listarCodigosByTabla(String codTabla){
		CodigoExample ce = new CodigoExample();
		CodigoExample.Criteria cc = ce.createCriteria();
		cc.andT99codTabEqualTo(codTabla);
		cc.andT99estadoEqualTo(Constantes.ESTA_CODI_ACTI);
		cc.andT99tipDescEqualTo(Constantes.TIPO_CODI_DESC);
		return codigoDAO.selectByExampleBasic(ce);
	}
	
	private List<Parametro> listarCodigosByTablaNoEstado(String codTabla){
		CodigoExample ce = new CodigoExample();
		CodigoExample.Criteria cc = ce.createCriteria();
		cc.andT99codTabEqualTo(codTabla);
		cc.andT99tipDescEqualTo(Constantes.TIPO_CODI_DESC);
		return codigoDAO.selectByExampleBasic(ce);
	}

	@Override
	public List<Parametro> listarCodigosLDN() {
		return paramContribuyenteDAO.listarCodigosLDN();
	}	
	
	@Override
	public List<Parametro> listarTiposDocumento() {
		return paramContribuyenteDAO.listarTiposDocumento();
	}	
	
	@Override
	public List<Parametro> listarNacionalidades() {
		return paramContribuyenteDAO.listarNacionalidades();
	}
	
	@Override
	public List<Parametro> listarTiposVia() {
		return paramContribuyenteDAO.listarTiposVia();
	}	
	
	@Override
	public List<Parametro> listarTiposZona() {
		return paramContribuyenteDAO.listarTiposZona();
	}
	
	@Override
	public List<Parametro> listarPaisesEmisor() {
		return paramContribuyenteDAO.listarPaisesEmisor();
	}
}
