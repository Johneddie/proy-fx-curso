package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.recurso2.humano.decljurada.bean.PersonaReniec;
import pe.gob.sunat.recurso2.humano.decljurada.model.Codigo;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohab;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.Documento;
import pe.gob.sunat.recurso2.humano.decljurada.model.DocumentoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.Persona;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ArchivoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraDerechohabDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DocumentoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamContribuyenteDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamRrhhDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaDAO;
import pe.gob.sunat.recurso2.humano.decljurada.util.Constantes;
import pe.gob.sunat.recurso2.humano.decljurada.util.DecljuradaUtil;
import pe.gob.sunat.recurso2.humano.decljurada.util.FechasUtil;

@Service("declaraDerechohabService")
public class DeclaraDerechohabServiceImpl implements DeclaraDerechohabService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	DeclaraDerechohabDAO declaraDerechohabDAO;
	
	@Autowired
	private CodigoDAO codigoDAO;
	
	@Autowired
	private DocumentoDAO documentoDAO;
	
	@Autowired
	private ParamContribuyenteDAO paramContribuyenteDAO;
	
	@Autowired
	private ParamRrhhDAO paramRrhhDAO;
	
    @Autowired
    SequenceDAO sequenceDAO;
    
    @Autowired
    ArchivoService archivoService;
    
    @Autowired
    SeguimientoService seguimientoService;
    
    @Autowired
    PersonaReniecService personaReniecService;
    
	@Autowired
	private ArchivoDAO archivoDAO;
	
	@Autowired
	private PersonaDAO personaDAO;
	
	@Override
	public List<DeclaraDerechohab> listarUltimasDeclaraciones (String codPersonal){
		if(log.isDebugEnabled()) 
			log.debug("method obtenerUltimasDeclaraciones");
		List<DeclaraDerechohab> lstDeclaraciones = new ArrayList<>();
		
		try{
			DeclaraDerechohab params = new DeclaraDerechohab();
			params.setCodPersonal(codPersonal);
			lstDeclaraciones = declaraDerechohabDAO.listarUltimasDeclaraciones(params);
			for(DeclaraDerechohab d:lstDeclaraciones){
				d.setDesVinFam(codigoDAO.obtenerParametro(Constantes.CODI_TABL_VINC_FAMI, d.getCodVinFam()).getT99descrip());
				d.setDesIndEstado(codigoDAO.obtenerParametro(Constantes.CODI_TABL_ESTA_DECL, d.getIndEstado()).getT99descrip());
				d.setDesSituFam(codigoDAO.obtenerParametro(Constantes.CODI_TABL_SITU_FAMI, d.getIndSituFam()).getT99descrip());
			}
		}catch(Exception e){
			log.error("Ha ocurrido un error en listarUltimasDeclaraciones: " + e.getMessage(), e);
		}
		return lstDeclaraciones;
	}
	
	@Override
	public DeclaraDerechohab obtenerDeclaracion(String codPersonal, String declaracionPK){
		if(log.isDebugEnabled()) 
			log.debug("method obtenerDeclaracion");
		DeclaraDerechohab declaracion = null;
		String indEstado = null;
		String annDdjj = null;
		Integer numDdjj = null;
		try{
			//datos pk
			String[] arrDeclaracionPK = declaracionPK.split("-");
			if(arrDeclaracionPK.length == 3){
				annDdjj = arrDeclaracionPK[0];
				numDdjj = Integer.parseInt(arrDeclaracionPK[1]);
				indEstado = arrDeclaracionPK[2];
			}
			
			if(numDdjj == null){
				declaracion = new DeclaraDerechohab();
				declaracion.setCodPersonal(codPersonal);
				declaracion.setDesIndEstado("NUEVO");
				
				//obtener documento
				Documento documento = documentoDAO.obtenerDocumento(codPersonal);
				Codigo codigoTipDocum = codigoDAO.obtenerParametroBySigla(Constantes.CODI_TABL_EQUI_TIPO_DOCU, documento.getT07codDcto());
				declaracion.setCodDocum(codigoTipDocum.getT99codigo().trim());
				declaracion.setNumDocum(documento.getT07nroDcto());
			}else{
				DeclaraDerechohabKey dk = new DeclaraDerechohabKey();
				dk.setAnnDdjj(annDdjj);
				dk.setNumDdjj(numDdjj);
				dk.setIndEstado(indEstado);
				declaracion = declaraDerechohabDAO.selectByPrimaryKey(dk);
				
				//domicilio reniec
				if(!Constantes.ESTA_DECL_ENVI.equals(declaracion.getIndEstado())){
					Map<String, Object> mapPersonaReniec = personaReniecService.obtenerPersonaReniec(declaracion.getNumDocumDer());
					String codErrorReniec = (String)mapPersonaReniec.get("codError");
					PersonaReniec personaReniec = (PersonaReniec)mapPersonaReniec.get("persona");
					if(Constantes.CODI_ERRO_EXITO_RENIEC.equals(codErrorReniec) || Constantes.CODI_ERRO_EXITO_SUNAT.equals(codErrorReniec)) {
						//domicilio
						String codUbigeoDirSunat = paramContribuyenteDAO.obtenerUbigeoSunat(personaReniec.getCodDistrito());
						declaracion.setDesUbigeoDir1(paramRrhhDAO.obtenerDesUbigeoSunat(codUbigeoDirSunat));
						declaracion.setDesDomiciDir1(personaReniec.getDesDomiciPnat());
						declaracion.setIndReniec("1");
						
						//datos personales
						declaracion.setCodDocumDer("01");
						declaracion.setNumDocumDer(personaReniec.getNumDocidePnat());
						
						//datos principales
						declaracion.setApePatDer(personaReniec.getDesApepatPnat());
						declaracion.setApeMatDer(personaReniec.getDesApematPnat());
						declaracion.setNomDer(personaReniec.getDesNombrePnat());
						declaracion.setFecNacimientoDer(FechasUtil.getDateFromStringDDMMYY(personaReniec.getFecNacPnat()));
						declaracion.setIndSexoDer(DecljuradaUtil.obtenerIndSexo(personaReniec.getDesSexoPnat()));
					}
				}
				
				//ubigeo domicilio
				if(!esVacioNulo(declaracion.getCodUbigeoDir1())){
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoSunat(declaracion.getCodUbigeoDir1()));
				}
				if(!esVacioNulo(declaracion.getCodUbigeoDir2())){
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoSunat(declaracion.getCodUbigeoDir2()));
				}
				
				//listado de adjuntos
				declaracion.setArchivosReferDomicilio(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_REFE_DERE));
				declaracion.setArchivosAcredVinculo(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_ACRE_VINC));
				declaracion.setArchivosBajaDerechohab(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_BAJA_DERE));
				declaracion.setArchivosSubsidSepelio(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_SUBS_SEPE));
				declaracion.setArchivosDiscapacidad(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_PERS_DISC));
				
				declaracion.setDesIndEstado(codigoDAO.obtenerParametro(Constantes.CODI_TABL_ESTA_DECL, declaracion.getIndEstado()).getT99descrip());
				
				//parche temporal
				if(!Constantes.ESTA_DECL_ENVI.equals(declaracion.getIndEstado())){
					
				}
				
			}
		}catch(Exception e){
			log.error("Ha ocurrido un error en listarUltimasDeclaraciones: " + e.getMessage(), e);
		}
		return declaracion;
	}
	
	@Override
	public DeclaraDerechohab obtenerDerechohabReniec(String numDocDer){
		if(log.isDebugEnabled()) 
			log.debug("method obtenerDerechohabReniec");
		DeclaraDerechohab declaracion = new DeclaraDerechohab();
		try{
			Map<String, Object> mapPersonaReniec = personaReniecService.obtenerPersonaReniec(numDocDer);
			String codErrorReniec = (String)mapPersonaReniec.get("codError");
			PersonaReniec personaReniec = (PersonaReniec)mapPersonaReniec.get("persona");
			if(Constantes.CODI_ERRO_EXITO_RENIEC.equals(codErrorReniec) || Constantes.CODI_ERRO_EXITO_SUNAT.equals(codErrorReniec)) {

				String codUbigeoDirSunat = paramContribuyenteDAO.obtenerUbigeoSunat(personaReniec.getCodDistrito());
				declaracion.setDesUbigeoDir1(paramRrhhDAO.obtenerDesUbigeoSunat(codUbigeoDirSunat));
				declaracion.setDesDomiciDir1(personaReniec.getDesDomiciPnat());
				declaracion.setIndReniec("1");
				
				//datos personales
				declaracion.setCodDocum("01");
				declaracion.setNumDocum(personaReniec.getNumDocidePnat());
				
				declaracion.setApePatDer(personaReniec.getDesApepatPnat());
				declaracion.setApeMatDer(personaReniec.getDesApematPnat());
				declaracion.setNomDer(personaReniec.getDesNombrePnat());
				declaracion.setFecNacimientoDer(FechasUtil.getDateFromStringDDMMYY(personaReniec.getFecNacPnat()));
				declaracion.setIndSexoDer(DecljuradaUtil.obtenerIndSexo(personaReniec.getDesSexoPnat()));
				
			}else{
				declaracion.setNumDocum(numDocDer);
				declaracion.setIndReniec("0");
			}

		}catch(Exception e){
			log.error("Ha ocurrido un error en obtenerDerechohabReniec: " + e.getMessage(), e);
		}
		return declaracion;
	}
	
	@Override
	public Map<String, Object> registrarDeclaraDerechohab(DeclaraDerechohab declaracion, Map<String, String> mapUsuario) throws Exception{
		if(log.isDebugEnabled()) 
			log.debug("method registrarAccionCapacita");
		Map<String, Object> hmResult = new HashMap<>();
		Calendar calendar = Calendar.getInstance();
		hmResult.put("codError", 1);
		String usuario = mapUsuario.get("usuario");
		String unidad = mapUsuario.get("unidad");
		
		try{
		
			DataSourceContextHolder.setKeyDataSource("g");
			String indEstado = declaracion.getIndEstado();
			
			//verifica existencia
			if(esVacioNulo(indEstado)){
				DeclaraDerechohab params = new DeclaraDerechohab();
				params.setCodPersonal(declaracion.getCodPersonal());
				params.setCodDocumDer(declaracion.getCodDocumDer());
				params.setNumDocumDer(declaracion.getNumDocumDer());
				List<DeclaraDerechohab> lstDeclaraciones = declaraDerechohabDAO.listarUltimasDeclaraciones(params);
				if(!lstDeclaraciones.isEmpty()){
					hmResult.put("desError", "Ya existe un derechohabiente registrado con dichos datos, si desea actualizarlo utilizar la �ltima declaraci�n APROBADA para dicho derechohabiente.");
					return hmResult;
				}
			}
				
			// nuevo o aprobado
			if(esVacioNulo(indEstado) || Constantes.ESTA_DECL_APRO.equals(indEstado)){
				declaracion.setFecCreacion(calendar.getTime());
				declaracion.setCodUsucrea(usuario);
				declaracion.setFecModif(calendar.getTime());
				declaracion.setCodUsumodif(usuario);
				declaracion.setCodUorgan(unidad);
				declaracion.setIndDel(Constantes.IND_NOELIMIN);
				declaracion.setIndEstado(Constantes.ESTA_DECL_ENVI);
				if(!esVacioNulo(declaracion.getCodUbigeoDir1()))
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir1()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir2()))
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir2()));

				//secuencia
				Integer numDdjjOld = declaracion.getNumDdjj();
				int secuencia = sequenceDAO.getNextSequence(Constantes.NOMB_SECU_DDJJ).intValue();
				declaracion.setNumDdjj(secuencia);
	
				declaracion.setAnnDdjj(String.valueOf(calendar.get(Calendar.YEAR)));
				declaracion.setCodPersonal(usuario);
				declaraDerechohabDAO.insertSelective(declaracion);
				
				//si es aprobado 
				if(Constantes.ESTA_DECL_APRO.equals(indEstado)){
					archivoService.migrarArchivosDerechohab((DeclaraDerechohabKey)declaracion, numDdjjOld, usuario, calendar);
				}
				
				//archivos
				archivoService.registrarArchivos(declaracion.getArchivosReferDomicilio(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosAcredVinculo(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosBajaDerechohab(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosSubsidSepelio(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosDiscapacidad(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				
				seguimientoService.registrarSeguimiento((DeclaraDerechohabKey)declaracion, usuario, unidad, mapUsuario, Constantes.CODI_TIPO_DDJJ_FAMI);
				
			}else if(Constantes.ESTA_DECL_PROV.equals(indEstado)){//provisional
				//baja 
				DeclaraDerechohab dt = new DeclaraDerechohab();
				dt.setCodUsumodif(usuario);
				dt.setFecModif(calendar.getTime());
				dt.setIndDel(Constantes.IND_ELIMINAD);
				dt.setAnnDdjj(declaracion.getAnnDdjj());
				dt.setNumDdjj(declaracion.getNumDdjj());
				dt.setIndEstado(declaracion.getIndEstado());
				declaraDerechohabDAO.updateByPrimaryKeySelective(dt);
				
				declaracion.setFecCreacion(calendar.getTime());
				declaracion.setCodUsucrea(usuario);
				declaracion.setFecModif(calendar.getTime());
				declaracion.setCodUsumodif(usuario);
				declaracion.setCodUorgan(unidad);
				declaracion.setIndDel(Constantes.IND_NOELIMIN);
				declaracion.setIndEstado(Constantes.ESTA_DECL_ENVI);
				if(!esVacioNulo(declaracion.getCodUbigeoDir1()))
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir1()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir2()))
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir2()));

				//secuencia
				declaracion.setAnnDdjj(String.valueOf(calendar.get(Calendar.YEAR)));
				declaracion.setCodPersonal(usuario);
				declaraDerechohabDAO.insertSelective(declaracion);
				
				//archivos
				archivoService.registrarArchivos(declaracion.getArchivosReferDomicilio(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosAcredVinculo(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosBajaDerechohab(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosSubsidSepelio(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosDiscapacidad(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				
				seguimientoService.registrarSeguimiento((DeclaraDerechohabKey)declaracion, usuario, unidad, mapUsuario, Constantes.CODI_TIPO_DDJJ_FAMI);
				
			} else{//modificar
				declaracion.setFecModif(calendar.getTime());
				declaracion.setCodUsumodif(usuario);
				declaracion.setCodUorgan(unidad);
				declaracion.setIndDel(Constantes.IND_NOELIMIN);
				declaracion.setIndEstado(Constantes.ESTA_DECL_ENVI);
				if(!esVacioNulo(declaracion.getCodUbigeoDir1()))
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir1()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir2()))
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir2()));
				declaraDerechohabDAO.updateByPrimaryKeySelective(declaracion);
				
				//archivos
				archivoService.registrarArchivos(declaracion.getArchivosReferDomicilio(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosAcredVinculo(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosBajaDerechohab(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosSubsidSepelio(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosDiscapacidad(), calendar, (DeclaraDerechohabKey)declaracion, mapUsuario);
				
				seguimientoService.registrarSeguimiento((DeclaraDerechohabKey)declaracion, usuario, unidad, mapUsuario, Constantes.CODI_TIPO_DDJJ_FAMI);
			}
			
			hmResult.put("declaraDerechohab", (DeclaraDerechohabKey)declaracion);
			hmResult.put("codError", 0);
			
		}catch(Exception e){
			log.error("Ha ocurrido un error en registrarDeclaraColaborador" + e.getMessage(), e);
			throw new Exception();
		}
			
		return hmResult;
	}
	
	@Override
	public String esRegimenPermitidoSubsidSepe(String codPersonal){
		//persona
		Persona p = personaDAO.selectByPrimaryKey(codPersonal);
		
		//regimen para subsidio sepelio
		String indReglSubsidSepe = "0";
		String strReglSubsidSepe = codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_REGL_SUBS, "01");
		if(strReglSubsidSepe != null && strReglSubsidSepe.contains(p.getT02codRegl()))
			indReglSubsidSepe = "1";
		return indReglSubsidSepe;
	}
	
	
	@Override
	public Persona obtenerPersonal(String documento){
		if(log.isDebugEnabled()) 
			log.debug("method obtenerPersonal");
		String numDocumDer = null;
		String codDocumDer = null;
		Persona persona = new Persona();
		try{
			//datos pk
			String[] arrDeclaracionPK = documento.split("-");
			if(arrDeclaracionPK.length == 2){
				codDocumDer = arrDeclaracionPK[0];
				numDocumDer = arrDeclaracionPK[1];
				
				//tipo de documento
				Codigo codigoTipDocumDer = codigoDAO.obtenerParametro(Constantes.CODI_TABL_EQUI_TIPO_DOCU, codDocumDer);
				
				DocumentoExample de = new DocumentoExample();
				DocumentoExample.Criteria dc = de.createCriteria();
				dc.andT07codDctoEqualTo(codigoTipDocumDer.getT99siglas());
				dc.andT07nroDctoEqualTo(numDocumDer);
				List<Documento> lstDocumentos = documentoDAO.selectByExample(de);
				
				Persona p = null;
				for(Documento d : lstDocumentos){
					Persona tmp = personaDAO.selectByPrimaryKey(d.getT07codPers());
					if(Constantes.ESTA_CODI_ACTI.equals(tmp.getT02codStat())){
						p = tmp;
						break;
					}
				}
				
				if(p!=null){
					persona.setT02nombres(p.getT02nombres());
					persona.setT02apMate(p.getT02apMate());
					persona.setT02apPate(p.getT02apPate());
					persona.setT02codPers(p.getT02codPers());
				}
			}
		}catch(Exception e){
			log.error("Ha ocurrido un error en ");
		}
		return persona;
	}
	
	private boolean esVacioNulo(String dato){
		return dato==null || "".equals(dato.trim());
	}
	
}
