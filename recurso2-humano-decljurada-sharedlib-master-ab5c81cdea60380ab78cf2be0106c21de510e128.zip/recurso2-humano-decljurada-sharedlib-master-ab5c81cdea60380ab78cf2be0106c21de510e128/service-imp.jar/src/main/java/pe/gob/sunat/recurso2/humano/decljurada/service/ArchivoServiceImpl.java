package pe.gob.sunat.recurso2.humano.decljurada.service;


import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.decljurada.bean.DeclaracionJuradaKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.Archivo;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ArchivoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.util.Constantes;


@Service("archivoService")
public class ArchivoServiceImpl implements ArchivoService{

	public final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private ArchivoDAO archivoDAO;
	
	@Override
	public Archivo obtenerArchivo(ArchivoKey archivoKey) {
		return archivoDAO.selectByPrimaryKey(archivoKey);
	}
	
	public void migrarArchivosDerechohab(DeclaraDerechohabKey declaraKey, Integer numDdjjOld, String usuario, Calendar calendar){
		//referencia domicilio
		ArchivoExample ae = new ArchivoExample();
		ArchivoExample.Criteria ac = ae.createCriteria();
		List<String> lstTiposArchivo = new ArrayList<>();
		lstTiposArchivo.add(Constantes.CODI_ADJU_REFE_DERE);
		lstTiposArchivo.add(Constantes.CODI_ADJU_ACRE_VINC);
		lstTiposArchivo.add(Constantes.CODI_ADJU_BAJA_DERE);
		lstTiposArchivo.add(Constantes.CODI_ADJU_SUBS_SEPE);
		lstTiposArchivo.add(Constantes.CODI_ADJU_PERS_DISC);
		
		for(String tipoArchivo:lstTiposArchivo){
			ae = new ArchivoExample();
			ac = ae.createCriteria();
			ac.andAnnDdjjEqualTo(declaraKey.getAnnDdjj());
			ac.andNumDdjjEqualTo(numDdjjOld);
			ac.andCodTipEqualTo(tipoArchivo);
			List<Archivo> lstArchivos = archivoDAO.selectByExampleWithBLOBs(ae);
			for(Archivo a:lstArchivos){
				a.setNumDdjj(declaraKey.getNumDdjj());
				a.setCodUsucrea(usuario);
				a.setFecCreacion(calendar.getTime());
				a.setCodUsumodif(usuario);
				a.setFecModif(calendar.getTime());
				archivoDAO.insert(a);
			}
		}
		
	}
	
	public void migrarArchivosColaborador(DeclaraColaboradorKey declaraKey, Integer numDdjjOld, String usuario, Calendar calendar){
		//estado civil
		ArchivoExample ae = new ArchivoExample();
		ArchivoExample.Criteria ac = ae.createCriteria();
		List<String> lstTiposArchivo = new ArrayList<>();
		lstTiposArchivo.add(Constantes.CODI_ADJU_ESTA_CIVI);
		lstTiposArchivo.add(Constantes.CODI_ADJU_REFE_DOMI);
		lstTiposArchivo.add(Constantes.CODI_ADJU_PERS_DISC);
		
		for(String tipoArchivo:lstTiposArchivo){
			ae = new ArchivoExample();
			ac = ae.createCriteria();
			ac.andAnnDdjjEqualTo(declaraKey.getAnnDdjj());
			ac.andNumDdjjEqualTo(numDdjjOld);
			ac.andCodTipEqualTo(tipoArchivo);
			List<Archivo> lstArchivos = archivoDAO.selectByExampleWithBLOBs(ae);
			for(Archivo a:lstArchivos){
				a.setNumDdjj(declaraKey.getNumDdjj());
				a.setCodUsucrea(usuario);
				a.setFecCreacion(calendar.getTime());
				a.setCodUsumodif(usuario);
				a.setFecModif(calendar.getTime());
				archivoDAO.insert(a);
			}
		}
		
	}
	
	public void registrarArchivos(List<Archivo> lstArchivos, Calendar calendar, DeclaracionJuradaKey declaraKey, Map<String, String> mapUsuario) throws Exception{
		String usuario = mapUsuario.get("usuario");
		String ticket = mapUsuario.get("ticket");
		
		Short indCorrel = obtenerMaxIndCorrel(lstArchivos);
		for(Archivo a:lstArchivos){
			String codAccion = a.getCodAccion();
			Archivo archivoModif = new Archivo();
			archivoModif.setAnnDdjj(a.getAnnDdjj());
			archivoModif.setNumDdjj(declaraKey.getNumDdjj());
			archivoModif.setIndCorrel(a.getIndCorrel());
			archivoModif.setCodTip(a.getCodTip());
			
			if(Constantes.CODI_ACCI_ADJU_NUEV.equals(codAccion)){
				indCorrel = (short)(indCorrel.intValue() + 1);
				InputStream is = (InputStream) new FileInputStream(Constantes.DIRE_TEMP + ticket + a.getDesNombre());
				a.setAnnDdjj(declaraKey.getAnnDdjj());
				a.setNumDdjj(declaraKey.getNumDdjj());
				a.setFecCreacion(calendar.getTime());
				a.setCodUsucrea(usuario);
				a.setIndCorrel(indCorrel);
				a.setArcDdjj(IOUtils.toByteArray(is));
				archivoDAO.insertSelective(a);
				is.close();
			}else if(Constantes.CODI_ACCI_ADJU_MODI.equals(codAccion)){
				archivoModif.setDesComentario(a.getDesComentario());
				archivoModif.setFecModif(calendar.getTime());
				archivoModif.setCodUsumodif(usuario);
				archivoDAO.updateByPrimaryKeySelective(archivoModif);
			}else if(Constantes.CODI_ACCI_ADJU_ELIM.equals(codAccion)){
				archivoDAO.deleteByPrimaryKey(archivoModif);
			}
		}
	}
	
	private Short obtenerMaxIndCorrel(List<Archivo> lista){
		Short indCorrel = new Short("0");
		for(Archivo a:lista){
			if(a.getIndCorrel() != null && indCorrel.compareTo(a.getIndCorrel()) == -1)
				indCorrel = a.getIndCorrel();
		}
		return indCorrel;
	}
}
