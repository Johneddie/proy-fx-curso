package pe.gob.sunat.recurso2.humano.decljurada.util;

import java.util.HashMap;
import java.util.Map;

public class Utiles{
	
	private Utiles(){
		
	}
	public static Map<String, String> obtenerMapFromParameterMap(Map<String, String[]> arrayMap){
		  Map<String, String> r = new HashMap<>();
		  for (Map.Entry<String, String[]> entry: arrayMap.entrySet()){
		    String[] value = entry.getValue();
		    if (value !=null && value .length>0) 
		    	r.put(entry.getKey(), value[0]);
		  }
		  return r;
	}
	
	

}
