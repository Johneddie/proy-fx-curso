package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.recurso2.humano.decljurada.bean.PersonaReniec;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaborador;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.Persona;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ArchivoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraColaboradorDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamContribuyenteDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamRrhhDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaDAO;
import pe.gob.sunat.recurso2.humano.decljurada.util.Constantes;
import pe.gob.sunat.recurso2.humano.decljurada.util.DecljuradaUtil;
import pe.gob.sunat.recurso2.humano.decljurada.util.FechasUtil;


@Service("declaraColaboradorService")
public class DeclaraColaboradorServiceImpl implements DeclaraColaboradorService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	DeclaraColaboradorDAO declaraColaboradorDAO;
	
	@Autowired
	private ParamRrhhDAO paramRrhhDAO;
	
	@Autowired
	private ParamContribuyenteDAO paramContribuyenteDAO;
	
	@Autowired
	private PersonaDAO personaDAO;
	
	@Autowired
	private ArchivoDAO archivoDAO;
	
    @Autowired
    SequenceDAO sequenceDAO;
    
	@Autowired
	private CodigoDAO codigoDAO;
	
    @Autowired
    ArchivoService archivoService;
    
    @Autowired
    SeguimientoService seguimientoService;
    
    @Autowired
    PersonaReniecService personaReniecService;
	
	public DeclaraColaborador obtenerUltimaDeclaracion (String codPersonal){
		if(log.isDebugEnabled()) 
			log.debug("method obtenerUltimaDeclaracion");
		DeclaraColaborador declaracion = null;
		
		try{
			
			//declaracion provisinal
			DeclaraColaboradorExample de = new DeclaraColaboradorExample();
			DeclaraColaboradorExample.Criteria dc = de.createCriteria();
			dc.andIndDelEqualTo(Constantes.IND_NOELIMIN);
			dc.andCodPersonalEqualTo(codPersonal);
			dc.andIndEstadoEqualTo(Constantes.ESTA_DECL_PROV);
			List<DeclaraColaborador> lstDeclaraciones = declaraColaboradorDAO.selectByExample(de);
			
			//ultima declaracion
			if(lstDeclaraciones.isEmpty()){
				DeclaraColaborador d = new DeclaraColaborador();
				d.setCodPersonal(codPersonal);
				d.setIndDel(Constantes.IND_NOELIMIN);
				declaracion = declaraColaboradorDAO.obtenerUltimaDeclaracion(d);
			}else{
				declaracion = lstDeclaraciones.get(0);
			}
			
			if(declaracion != null){ //modificaci�n
				
				if(declaracion.getCodUbigeoNac()!=null)
					declaracion.setCodUbigeoNac(paramContribuyenteDAO.obtenerUbigeoSunat(declaracion.getCodUbigeoNac()));
				
				//domicilio reniec
				if(!Constantes.ESTA_DECL_ENVI.equals(declaracion.getIndEstado())){
					Map<String, Object> mapPersonaReniec = personaReniecService.obtenerPersonaReniec(declaracion.getNumDocum());
					String codErrorReniec = (String)mapPersonaReniec.get("codError");
					PersonaReniec personaReniec = (PersonaReniec)mapPersonaReniec.get("persona");
					if(Constantes.CODI_ERRO_EXITO_RENIEC.equals(codErrorReniec) || Constantes.CODI_ERRO_EXITO_SUNAT.equals(codErrorReniec)) {
						//domicilio
						String codUbigeoDirSunat = paramContribuyenteDAO.obtenerUbigeoSunat(personaReniec.getCodDistrito());
						declaracion.setDesUbigeoDir1(paramRrhhDAO.obtenerDesUbigeoSunat(codUbigeoDirSunat));
						declaracion.setDesDomiciDir1(personaReniec.getDesDomiciPnat());
						declaracion.setIndReniec("1");
						
						//datos personales
						declaracion.setCodDocum("01");
						declaracion.setNumDocum(personaReniec.getNumDocidePnat());
						declaracion.setCodNacionalidad("9589");
						
						//datos principales
						declaracion.setApePat(personaReniec.getDesApepatPnat());
						declaracion.setApeMat(personaReniec.getDesApematPnat());
						declaracion.setNomPersonal(personaReniec.getDesNombrePnat());
						declaracion.setFecNacimiento(FechasUtil.getDateFromStringDDMMYY(personaReniec.getFecNacPnat()));
						declaracion.setIndSexo(DecljuradaUtil.obtenerIndSexo(personaReniec.getDesSexoPnat()));
					}
				}
				
				//ubigeo domicilio
				if(!esVacioNulo(declaracion.getCodUbigeoDir1())){
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoSunat(declaracion.getCodUbigeoDir1()));
				}
				if(!esVacioNulo(declaracion.getCodUbigeoDir2())){
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoSunat(declaracion.getCodUbigeoDir2()));
				}
				
				//listado de adjuntos
				declaracion.setArchivosReferDomicilio(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_REFE_DOMI));
				declaracion.setArchivosEstadoCivil(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_ESTA_CIVI));
				declaracion.setArchivosDiscapacidad(archivoDAO.listarArchivosByTipo(declaracion.getAnnDdjj(), declaracion.getNumDdjj(), Constantes.CODI_ADJU_PERS_DISC));
				
				declaracion.setDesIndEstado(codigoDAO.obtenerParametro(Constantes.CODI_TABL_ESTA_DECL, declaracion.getIndEstado()).getT99descrip());
				
			}else{//nuevo
				
				declaracion = new DeclaraColaborador();
				
				Persona persona = personaDAO.selectByPrimaryKey(codPersonal);
				String codEstado = persona.getT02codStat();
				if(Constantes.ESTA_CODI_ACTI.equals(codEstado)){
					//domicilio reniec
					Map<String, Object> mapPersonaReniec = personaReniecService.obtenerPersonaReniec(persona.getT02libElec());
					String codErrorReniec = (String)mapPersonaReniec.get("codError");
					PersonaReniec personaReniec = (PersonaReniec)mapPersonaReniec.get("persona");
					if(Constantes.CODI_ERRO_EXITO_RENIEC.equals(codErrorReniec) || Constantes.CODI_ERRO_EXITO_SUNAT.equals(codErrorReniec)) {
	
						String codUbigeoDirSunat = paramContribuyenteDAO.obtenerUbigeoSunat(personaReniec.getCodDistrito());
						declaracion.setDesUbigeoDir1(paramRrhhDAO.obtenerDesUbigeoSunat(codUbigeoDirSunat));
						declaracion.setDesDomiciDir1(personaReniec.getDesDomiciPnat());
						declaracion.setIndReniec("1");
						
						//datos personales
						declaracion.setCodDocum("01");
						declaracion.setNumDocum(personaReniec.getNumDocidePnat());
						declaracion.setCodNacionalidad("9589");
						
						declaracion.setApePat(personaReniec.getDesApepatPnat());
						declaracion.setApeMat(personaReniec.getDesApematPnat());
						declaracion.setNomPersonal(personaReniec.getDesNombrePnat());
						declaracion.setFecNacimiento(FechasUtil.getDateFromStringDDMMYY(personaReniec.getFecNacPnat()));
						declaracion.setIndSexo(DecljuradaUtil.obtenerIndSexo(personaReniec.getDesSexoPnat()));
						
					}else{
						declaracion.setNumDocum(persona.getT02libElec());
						declaracion.setIndReniec("0");
					}
					
					declaracion.setCodPaisUbiNac("9589");
					declaracion.setDesIndEstado("NUEVO");
					declaracion.setCodPersonal(codPersonal);
					
					
				}else{
					log.error("El registro que tiene asignado en la INTRANET esta INACTIVO. Favor coordinar con la Divisi�n de Atenci�n a Usuarios a fin de actualizarlo.");
				}
					
			}
		}catch(Exception e){
			log.error("Ha ocurrido un error en obtenerUltimaDeclaracion: " + e.getMessage(), e);
		}
		return declaracion;
	}
	
	
	public Map<String, Object> registrarDeclaraColaborador(DeclaraColaborador declaracion, Map<String, String> mapUsuario) throws Exception{
		if(log.isDebugEnabled()) 
			log.debug("method registrarAccionCapacita");
		Map<String, Object> hmResult = new HashMap<>();
		Calendar calendar = Calendar.getInstance();
		hmResult.put("codError", 1);
		String usuario = mapUsuario.get("usuario");
		String unidad = mapUsuario.get("unidad");
		
		try{
		
			DataSourceContextHolder.setKeyDataSource("g");
			String indEstado = declaracion.getIndEstado();
			
			if(esVacioNulo(indEstado) || Constantes.ESTA_DECL_APRO.equals(indEstado)){//registrar
				declaracion.setFecCreacion(calendar.getTime());
				declaracion.setCodUsucrea(usuario);
				declaracion.setFecModif(calendar.getTime());
				declaracion.setCodUsumodif(usuario);
				declaracion.setCodUorgan(unidad);
				declaracion.setIndDel(Constantes.IND_NOELIMIN);
				declaracion.setIndEstado(Constantes.ESTA_DECL_ENVI);
				if(!esVacioNulo(declaracion.getCodUbigeoNac()))
					declaracion.setCodUbigeoNac(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoNac()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir1()))
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir1()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir2()))
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir2()));

				//secuencia
				Integer numDdjjOld = declaracion.getNumDdjj();
				int secuencia = sequenceDAO.getNextSequence(Constantes.NOMB_SECU_DDJJ).intValue();
				declaracion.setNumDdjj(secuencia);
	
				declaracion.setAnnDdjj(String.valueOf(calendar.get(Calendar.YEAR)));
				declaracion.setCodPersonal(usuario);
				declaraColaboradorDAO.insertSelective(declaracion);
				
				//si es aprobado 
				if(Constantes.ESTA_DECL_APRO.equals(indEstado)){
					archivoService.migrarArchivosColaborador((DeclaraColaboradorKey)declaracion, numDdjjOld, usuario, calendar);
				}
				
				//archivos
				archivoService.registrarArchivos(declaracion.getArchivosEstadoCivil(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosReferDomicilio(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosDiscapacidad(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				
				seguimientoService.registrarSeguimiento((DeclaraColaboradorKey)declaracion, usuario, unidad, mapUsuario, Constantes.CODI_TIPO_DDJJ_GENE);
				
			}else if(Constantes.ESTA_DECL_PROV.equals(indEstado)){//provisional
				DeclaraColaborador dt = new DeclaraColaborador();
				dt.setCodUsumodif(usuario);
				dt.setCodUorgan(unidad);
				dt.setIndDel(Constantes.IND_ELIMINAD);
				dt.setAnnDdjj(declaracion.getAnnDdjj());
				dt.setNumDdjj(declaracion.getNumDdjj());
				dt.setIndEstado(declaracion.getIndEstado());
				declaraColaboradorDAO.updateByPrimaryKeySelective(dt);
				
				declaracion.setFecCreacion(calendar.getTime());
				declaracion.setCodUsucrea(usuario);
				declaracion.setFecModif(calendar.getTime());
				declaracion.setCodUsumodif(usuario);
				declaracion.setCodUorgan(unidad);
				declaracion.setIndDel(Constantes.IND_NOELIMIN);
				declaracion.setIndEstado(Constantes.ESTA_DECL_ENVI);
				if(!esVacioNulo(declaracion.getCodUbigeoNac()))
					declaracion.setCodUbigeoNac(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoNac()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir1()))
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir1()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir2()))
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir2()));

				//secuencia
				declaracion.setAnnDdjj(String.valueOf(calendar.get(Calendar.YEAR)));
				declaracion.setCodPersonal(usuario);
				declaraColaboradorDAO.insertSelective(declaracion);
				
				//archivos
				archivoService.registrarArchivos(declaracion.getArchivosEstadoCivil(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosReferDomicilio(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosDiscapacidad(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				
				seguimientoService.registrarSeguimiento((DeclaraColaboradorKey)declaracion, usuario, unidad, mapUsuario, Constantes.CODI_TIPO_DDJJ_GENE);
				
			} else{//modificar
				declaracion.setFecModif(calendar.getTime());
				declaracion.setCodUsumodif(usuario);
				declaracion.setCodUorgan(unidad);
				declaracion.setIndDel(Constantes.IND_NOELIMIN);
				declaracion.setIndEstado(Constantes.ESTA_DECL_ENVI);
				if(!esVacioNulo(declaracion.getCodUbigeoNac()))
					declaracion.setCodUbigeoNac(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoNac()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir1()))
					declaracion.setCodUbigeoDir1(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir1()));
				if(!esVacioNulo(declaracion.getCodUbigeoDir2()))
					declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(declaracion.getCodUbigeoDir2()));
				declaraColaboradorDAO.updateByPrimaryKeySelective(declaracion);
				
				//archivos
				archivoService.registrarArchivos(declaracion.getArchivosEstadoCivil(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosReferDomicilio(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				archivoService.registrarArchivos(declaracion.getArchivosDiscapacidad(), calendar, (DeclaraColaboradorKey)declaracion, mapUsuario);
				
				seguimientoService.registrarSeguimiento((DeclaraColaboradorKey)declaracion, usuario, unidad, mapUsuario, Constantes.CODI_TIPO_DDJJ_GENE);
			}
			
			hmResult.put("declaraColaborador", (DeclaraColaboradorKey)declaracion);
			hmResult.put("codError", 0);
			
		}catch(Exception e){
			log.error("Ha ocurrido un error en registrarDeclaraColaborador" + e.getMessage(), e);
			throw new Exception();
		}
			
		return hmResult;
	}
	
	
	private boolean esVacioNulo(String dato){
		return dato==null || "".equals(dato.trim());
	}

}
