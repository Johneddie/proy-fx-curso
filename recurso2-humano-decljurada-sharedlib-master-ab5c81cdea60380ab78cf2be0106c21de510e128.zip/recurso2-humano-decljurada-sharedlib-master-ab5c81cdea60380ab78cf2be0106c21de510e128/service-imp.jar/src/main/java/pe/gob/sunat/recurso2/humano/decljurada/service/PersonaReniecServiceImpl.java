package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import pe.gob.sunat.recurso2.humano.decljurada.bean.PersonaReniec;
import pe.gob.sunat.recurso2.humano.decljurada.util.Constantes;


@Service("personaReniecService")
public class PersonaReniecServiceImpl implements PersonaReniecService{

	public final Log log = LogFactory.getLog(getClass());

	public Map<String,Object> obtenerPersonaReniec(String numDoc) {
		if(log.isDebugEnabled()) 
			log.debug("method obtenerPersonaReniec");
		Map<String,Object> mensaje = new HashMap<>();
		mensaje.put("codError", Constantes.CODI_ERRO_NOT_PROCESS);
		
		String url = Constantes.URL_SERV_RENIEC.replace("{DNI}", numDoc);//Consultamos al servicio RENIEC
		RestTemplate restTemplate = new RestTemplate();
		
		try {
			ResponseEntity<String> response= restTemplate.getForEntity(url, String.class);
			log.info("C�digo de respuesta del servicio:"+response.getStatusCode());
			if(HttpStatus.OK.equals(response.getStatusCode())) {
				try {
					String jsonRespuesta = response.getBody();
					ObjectMapper mapper = new ObjectMapper();
					JsonNode responseNode = mapper.readTree(jsonRespuesta);
					
					mensaje.put("codError",omitirNulo(responseNode.findValue("cod_error")));
					mensaje.put("desError",omitirNulo(responseNode.findValue("des_error")));
					
					
					JsonNode datosPersona = responseNode.findValue("t733PerNatBean");
					if(datosPersona!=null){
						PersonaReniec persona = new PersonaReniec();
						persona.setDesApematPnat(omitirNulo(datosPersona.get("des_apemat_pnat")));
						persona.setDesApepatPnat(omitirNulo(datosPersona.get("des_apepat_pnat")));
						persona.setDesNombrePnat(omitirNulo(datosPersona.get("des_nombre_pnat")));
						persona.setFecNacPnat(omitirNulo(datosPersona.get("fec_nac_pnat")));
						persona.setCodDepartamento(omitirNulo(datosPersona.get("cod_departamento")));
						persona.setCodDistrito(omitirNulo(datosPersona.get("cod_distrito")));
						persona.setCodProvincia(omitirNulo(datosPersona.get("cod_provincia")));
						persona.setDesDepartamento(omitirNulo(datosPersona.get("des_departamento")));
						persona.setDesProvincia(omitirNulo(datosPersona.get("des_provincia")));
						persona.setDesDistrito(omitirNulo(datosPersona.get("des_distrito")));
						persona.setDesDomiciPnat(omitirNulo(datosPersona.get("des_domici_pnat")));
						persona.setDesEstcivPnat(omitirNulo(datosPersona.get("des_estciv_pnat")));
						persona.setNumDocidePnat(omitirNulo(datosPersona.get("num_docide_pnat")));
						persona.setDesSexoPnat(omitirNulo(datosPersona.get("des_sexo_pnat")));
						mensaje.put("persona",persona);
					}
					
				}catch(Exception e) {
					mensaje.put("codError",Constantes.CODI_ERRO_EXCEPCION_RENIEC);
					log.info("Ocurri� un error al procesar el mensaje en reniec",e);
				}
			}else {
				mensaje.put("codError",Constantes.CODI_ERRO_NOT_CODE_200);
			}
			
		}catch(Exception e) {
			mensaje.put("codError",Constantes.CODI_ERRO_EXCEPCION_RENIEC);
			log.info("Ocurri� un error al procesar el mensaje en reniec",e);
		}
		
		return mensaje;
	}
	
	private String omitirNulo(JsonNode jsonNode) {
		if(jsonNode!=null)return jsonNode.asText();
		return "-";
	}
}
