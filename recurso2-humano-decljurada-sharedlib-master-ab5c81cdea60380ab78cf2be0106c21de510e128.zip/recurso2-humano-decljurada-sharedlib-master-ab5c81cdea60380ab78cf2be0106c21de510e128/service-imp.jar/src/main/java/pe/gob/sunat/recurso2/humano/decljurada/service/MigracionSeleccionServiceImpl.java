package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.framework.spring.util.jdbc.datasource.lookup.DataSourceContextHolder;
import pe.gob.sunat.recurso2.humano.decljurada.bean.PersonaReniec;
import pe.gob.sunat.recurso2.humano.decljurada.model.Codigo;
import pe.gob.sunat.recurso2.humano.decljurada.model.CodigoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaborador;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohab;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSel;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSelExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.Documento;
import pe.gob.sunat.recurso2.humano.decljurada.model.FichaHistorico;
import pe.gob.sunat.recurso2.humano.decljurada.model.Persona;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaSiga;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaSigaExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraColaboradorDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraDerechohabDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DerechohabSelDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DocumentoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.FichaHistoricoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamContribuyenteDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamRrhhDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaSigaDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.TipoDocumSigaDAO;
import pe.gob.sunat.recurso2.humano.decljurada.util.Constantes;
import pe.gob.sunat.recurso2.humano.decljurada.util.DecljuradaUtil;
import pe.gob.sunat.recurso2.humano.decljurada.util.FechasUtil;


@Service("migracionSeleccionService")
public class MigracionSeleccionServiceImpl implements MigracionSeleccionService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	DeclaraColaboradorDAO declaraColaboradorDAO;
	
	@Autowired
	private PersonaDAO personaDAO;
	
    @Autowired
    SequenceDAO sequenceDAO;
	
	@Autowired
	private DocumentoDAO documentoDAO;
	
	@Autowired
	private FichaHistoricoDAO fichaHistoricoDAO;
	
	@Autowired
	private ParamRrhhDAO paramRrhhDAO;
	
	@Autowired
	private ParamContribuyenteDAO paramContribuyenteDAO;
	
	@Autowired
	private PersonaSigaDAO personaSigaDAO;
	
	@Autowired
	private TipoDocumSigaDAO tipoDocumSigaDAO;
	
	@Autowired
	private CodigoDAO codigoDAO;
	
	@Autowired
	private DerechohabSelDAO derechohabSelDAO;
	
	@Autowired
	DeclaraDerechohabDAO declaraDerechohabDAO;
	
    @Autowired
    PersonaReniecService personaReniecService;
	
	@Override
	public void migrarDatosPersonales() {
		if(log.isDebugEnabled()) 
			log.debug("method procesarDatosPersonales");
		Calendar calHoy = Calendar.getInstance();
		
		try{
			DataSourceContextHolder.setKeyDataSource("g");
			//listar nuevos
			PersonaExample pe = new PersonaExample();
			PersonaExample.Criteria pc = pe.createCriteria();
			pc.andT02codStatEqualTo(Constantes.ESTA_CODI_ACTI);
			pc.andT02fIngsunEqualTo(calHoy.getTime());
			List<Persona> lstPersonasNueva = personaDAO.selectByExample(pe);
			for(Persona p:lstPersonasNueva){
				
				try{
					String codPersonal = p.getT02codPers();
					
					//provisional
					DeclaraColaboradorExample de = new DeclaraColaboradorExample();
					DeclaraColaboradorExample.Criteria dc = de.createCriteria();
					dc.andCodPersonalEqualTo(codPersonal);
					dc.andIndEstadoEqualTo(Constantes.ESTA_DECL_PROV);
					dc.andIndDelEqualTo(Constantes.IND_NOELIMIN);
					List<DeclaraColaborador> lstDeclaraciones = declaraColaboradorDAO.selectByExample(de);
					
					if(lstDeclaraciones.isEmpty()){
						//obtener documento
						Documento documento = documentoDAO.obtenerDocumento(codPersonal);
						Codigo codigoTipDocum = codigoDAO.obtenerParametroBySigla(Constantes.CODI_TABL_EQUI_TIPO_DOCU, documento.getT07codDcto());
						
						//obtener ficha
						FichaHistorico ficha = new FichaHistorico();
						ficha.setCodTipoDoc(codigoTipDocum.getT99codigo().trim());
						ficha.setNumDocId(documento.getT07nroDcto());
						ficha = fichaHistoricoDAO.obtenerFichaHistoricoByDocumento(ficha);
						
						//copiar campos seleccion
						if(ficha != null){
							DeclaraColaborador declaracion = new DeclaraColaborador();
							int secuencia = sequenceDAO.getNextSequence(Constantes.NOMB_SECU_DDJJ).intValue();
							declaracion.setNumDdjj(secuencia);//constantes
							declaracion.setAnnDdjj(String.valueOf(calHoy.get(Calendar.YEAR)));
							declaracion.setCodPersonal(codPersonal);
							declaracion.setFecCreacion(calHoy.getTime());
							declaracion.setCodUsucrea(Constantes.CODI_USUR_BATC);
							declaracion.setFecModif(calHoy.getTime());
							declaracion.setCodUsumodif(Constantes.CODI_USUR_BATC);
							declaracion.setCodUorgan(p.getT02codUorg());
							declaracion.setIndDel(Constantes.IND_NOELIMIN);
							declaracion.setIndEstado(Constantes.ESTA_DECL_PROV);
							declaracion.setIndReniec(Constantes.ESTA_CODI_INAC);
							declaracion.setCodDocum(ficha.getCodTipoDoc()); //recuperados
							declaracion.setNumDocum(ficha.getNumDocId());
							declaracion.setNomPersonal(ficha.getNomPostulante());
							declaracion.setApePat(ficha.getApePaterno());
							declaracion.setApeMat(ficha.getApeMaterno());
							declaracion.setFecNacimiento(ficha.getFecNacimiento());
							declaracion.setIndSexo(DecljuradaUtil.obtenerIndSexo(ficha.getIndSexo()));
							declaracion.setIndDiscapacidad(DecljuradaUtil.obtenerIndDiscapacidad(ficha.getIndDiscapacitado()));
							//declaracion.setCodPaisUbiNac(ficha.getCodPaisnac());
							declaracion.setCodUbigeoNac(paramContribuyenteDAO.obtenerUbigeoReniec(ficha.getCodUbigeonac()));
							declaracion.setIndEstCivil(ficha.getCodEstcivil());
							declaracion.setDesCorreo(ficha.getNomEmail());
							declaracion.setNumTelef(ficha.getNumTelcasa());
							declaracion.setNumCelular(ficha.getNumTelcelular());
							declaracion.setCodViaDir2(ficha.getCodTipvia());//domicilio actual
							declaracion.setNumViaDir2(ficha.getNumDom());
							declaracion.setNomViaDir2(ficha.getNomVia());
							declaracion.setNumDepaDir2(ficha.getNumDepaDir());
							declaracion.setNumInteriorDir2(ficha.getNumInteriorDir());
							declaracion.setNumManzDir2(ficha.getNumManzDir());
							declaracion.setNumLoteDir2(ficha.getNumLoteDir());
							declaracion.setNumKilomDir2(ficha.getNumKilomDir());
							declaracion.setNumBlockDir2(ficha.getNumBlockDir());
							declaracion.setNumEtapaDir2(ficha.getNumEtapaDir());
							declaracion.setCodZonaDir2(ficha.getCodTipzona());
							declaracion.setNomZonaDir2(ficha.getNomZona());
							declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(ficha.getCodUbigeodom()));
							declaracion.setDesReferDir2(ficha.getDesReferDir());
							
							if("01".equals(documento.getT07codDcto())){ //dni
								
								//domicilio reniec
								Map<String, Object> mapPersonaReniec = personaReniecService.obtenerPersonaReniec(declaracion.getNumDocum());
								String codErrorReniec = (String)mapPersonaReniec.get("codError");
								PersonaReniec personaReniec = (PersonaReniec)mapPersonaReniec.get("persona");
								if(Constantes.CODI_ERRO_EXITO_RENIEC.equals(codErrorReniec) || Constantes.CODI_ERRO_EXITO_SUNAT.equals(codErrorReniec)) {
									//domicilio
									String codUbigeoDirSunat = paramContribuyenteDAO.obtenerUbigeoSunat(personaReniec.getCodDistrito());
									declaracion.setDesUbigeoDir1(paramRrhhDAO.obtenerDesUbigeoSunat(codUbigeoDirSunat));
									declaracion.setDesDomiciDir1(personaReniec.getDesDomiciPnat());
									declaracion.setIndReniec(Constantes.ESTA_CODI_ACTI);
									
									//datos personales
									declaracion.setCodDocum("01");
									declaracion.setNumDocum(personaReniec.getNumDocidePnat());
									declaracion.setCodNacionalidad("9589");
									
									//datos principales
									declaracion.setApePat(personaReniec.getDesApepatPnat());
									declaracion.setApeMat(personaReniec.getDesApematPnat());
									declaracion.setNomPersonal(personaReniec.getDesNombrePnat());
									declaracion.setFecNacimiento(FechasUtil.getDateFromStringDDMMYY(personaReniec.getFecNacPnat()));
									declaracion.setIndSexo(DecljuradaUtil.obtenerIndSexo(personaReniec.getDesSexoPnat()));
								}
							}
							
							declaraColaboradorDAO.insertSelective(declaracion);
							
						}else{
							
							PersonaSigaExample pse = new PersonaSigaExample();
							PersonaSigaExample.Criteria psc = pse.createCriteria();
							psc.andNumeroRegistroAlternoEqualTo(codPersonal);
							List<PersonaSiga> lstPersonaSiga = personaSigaDAO.selectByExample(pse);
							
							//copiar campos siga
							if(!lstPersonaSiga.isEmpty()){
								PersonaSiga personaSiga = lstPersonaSiga.get(0);
								
								DeclaraColaborador declaracion = new DeclaraColaborador();
								int secuencia = sequenceDAO.getNextSequence(Constantes.NOMB_SECU_DDJJ).intValue();
								declaracion.setNumDdjj(secuencia);//constantes
								declaracion.setAnnDdjj(String.valueOf(calHoy.get(Calendar.YEAR)));
								declaracion.setCodPersonal(codPersonal);
								declaracion.setFecCreacion(calHoy.getTime());
								declaracion.setCodUsucrea(Constantes.CODI_USUR_BATC);
								declaracion.setFecModif(calHoy.getTime());
								declaracion.setCodUsumodif(Constantes.CODI_USUR_BATC);
								declaracion.setCodUorgan(p.getT02codUorg());
								declaracion.setIndDel(Constantes.IND_NOELIMIN);
								declaracion.setIndEstado(Constantes.ESTA_DECL_PROV);
								declaracion.setIndReniec(Constantes.ESTA_CODI_INAC);
								declaracion.setCodDocum(tipoDocumSigaDAO.selectByPrimaryKey(personaSiga.getTipoDocuPer()).getCodReniec());//recuperados
								declaracion.setNumDocum(personaSiga.getLibrElecPer());
								declaracion.setNomPersonal(personaSiga.getNomEmpPer());
								declaracion.setApePat(personaSiga.getApePatPer());
								declaracion.setApeMat(personaSiga.getApeMatPer());
								declaracion.setFecNacimiento(personaSiga.getFecNacPer());
								declaracion.setIndSexo(DecljuradaUtil.obtenerIndSexo(personaSiga.getSexEmpPer()));
								declaracion.setIndEstCivil(obtenerIndEstCivil(personaSiga.getEstCivPer()));
								declaracion.setCodUbigeoDir2(paramContribuyenteDAO.obtenerUbigeoReniec(personaSiga.getCodiDepaDpt() + personaSiga.getCodiProvTpr() + personaSiga.getCodiDistTdi()));
								declaracion.setDesReferDir2(personaSiga.getDomicilioReferencia());
								
								if("01".equals(documento.getT07codDcto())){ //dni
									
									//domicilio reniec
									Map<String, Object> mapPersonaReniec = personaReniecService.obtenerPersonaReniec(declaracion.getNumDocum());
									String codErrorReniec = (String)mapPersonaReniec.get("codError");
									PersonaReniec personaReniec = (PersonaReniec)mapPersonaReniec.get("persona");
									if(Constantes.CODI_ERRO_EXITO_RENIEC.equals(codErrorReniec) || Constantes.CODI_ERRO_EXITO_SUNAT.equals(codErrorReniec)) {
										//domicilio
										String codUbigeoDirSunat = paramContribuyenteDAO.obtenerUbigeoSunat(personaReniec.getCodDistrito());
										declaracion.setDesUbigeoDir1(paramRrhhDAO.obtenerDesUbigeoSunat(codUbigeoDirSunat));
										declaracion.setDesDomiciDir1(personaReniec.getDesDomiciPnat());
										declaracion.setIndReniec(Constantes.ESTA_CODI_ACTI);
										
										//datos personales
										declaracion.setCodDocum("01");
										declaracion.setNumDocum(personaReniec.getNumDocidePnat());
										declaracion.setCodNacionalidad("9589");
										
										//datos principales
										declaracion.setApePat(personaReniec.getDesApepatPnat());
										declaracion.setApeMat(personaReniec.getDesApematPnat());
										declaracion.setNomPersonal(personaReniec.getDesNombrePnat());
										declaracion.setFecNacimiento(FechasUtil.getDateFromStringDDMMYY(personaReniec.getFecNacPnat()));
										declaracion.setIndSexo(DecljuradaUtil.obtenerIndSexo(personaReniec.getDesSexoPnat()));
									}
								}
								
								declaraColaboradorDAO.insertSelective(declaracion);
							}
						}
					}
				
				}catch(Exception e){
					log.error("Ha ocurrido un error al procesar al personal: Registro:"+ p.getT02codPers() + ", " + e.getMessage(), e);
				}
			}
			
	    }catch(Exception e){
			log.error("Ha ocurrido un error en procesarDatosPersonales: " + e.getMessage(), e);
		}finally{
			log.debug("fin procesarDatosPersonales");
		}
	}
	
	private String obtenerIndEstCivil(String numDoc) {
		String indEstCivil=null;
		CodigoExample example = new CodigoExample();
		CodigoExample.Criteria criterio = example.createCriteria();
		criterio.andT99codTabEqualTo(Constantes.CODI_TABL_ESTA_CIVI);
		criterio.andT99estadoEqualTo("1");
		criterio.andT99tipDescEqualTo("D");
		criterio.andCodClasif1EqualTo(numDoc);
		List<Codigo> lstParametros = codigoDAO.selectByExample(example);
		if(!lstParametros.isEmpty())
			indEstCivil = lstParametros.get(0).getT99codigo();
		return indEstCivil;
	}
	
	
	@Override
	public void migrarDatosFamiliares() {
		if(log.isDebugEnabled()) 
			log.debug("method migrarDatosFamiliares");
		Calendar calHoy = Calendar.getInstance();
		
		try{
			DataSourceContextHolder.setKeyDataSource("g");
			//listar nuevos
			PersonaExample pe = new PersonaExample();
			PersonaExample.Criteria pc = pe.createCriteria();
			pc.andT02codStatEqualTo(Constantes.ESTA_CODI_ACTI);
			pc.andT02fIngsunEqualTo(calHoy.getTime());
			List<Persona> lstPersonasNueva = personaDAO.selectByExample(pe);
			for(Persona p:lstPersonasNueva){
				
				try{
				
					String codPersonal = p.getT02codPers();
					
					//obtener documento
					Documento documento = documentoDAO.obtenerDocumento(codPersonal);
					Codigo codigoTipDocum = codigoDAO.obtenerParametroBySigla(Constantes.CODI_TABL_EQUI_TIPO_DOCU, documento.getT07codDcto());
					
					//obtener ficha
					FichaHistorico ficha = new FichaHistorico();
					ficha.setCodTipoDoc(codigoTipDocum.getT99codigo().trim());
					ficha.setNumDocId(documento.getT07nroDcto());
					ficha.setIndDerechohab(Constantes.ESTA_CODI_ACTI);
					ficha = fichaHistoricoDAO.obtenerFichaHistoricoByDocumento(ficha);
					
					if(ficha != null){
						
						//recuperar familiares 
						DerechohabSelExample dse = new DerechohabSelExample();
						DerechohabSelExample.Criteria dsc = dse.createCriteria();
						dsc.andCodCatEqualTo(ficha.getCodCat());
						dsc.andNumPostulanteEqualTo(ficha.getNumPostulante());
						dsc.andIndDelEqualTo(Constantes.IND_NOELIMIN);
						List<DerechohabSel> lstDerechohabSel = derechohabSelDAO.selectByExample(dse);
						
						for(DerechohabSel dh:lstDerechohabSel){
							
							try{
								//1. provisional
								DeclaraDerechohabExample de = new DeclaraDerechohabExample();
								DeclaraDerechohabExample.Criteria dc = de.createCriteria();
								dc.andCodPersonalEqualTo(codPersonal);
								dc.andIndEstadoEqualTo(Constantes.ESTA_DECL_PROV);
								dc.andIndDelEqualTo(Constantes.IND_NOELIMIN);
								dc.andCodDocumDerEqualTo(dh.getCodDocumDer());
								dc.andNumDocumDerEqualTo(dh.getNumDocumDer());
								List<DeclaraDerechohab> lstDeclaraciones = declaraDerechohabDAO.selectByExample(de);
								if(lstDeclaraciones.isEmpty()){
									DeclaraDerechohab declaracion = new DeclaraDerechohab();
									int secuencia = sequenceDAO.getNextSequence(Constantes.NOMB_SECU_DDJJ).intValue();
									declaracion.setNumDdjj(secuencia);//constantes
									declaracion.setAnnDdjj(String.valueOf(calHoy.get(Calendar.YEAR)));
									declaracion.setCodPersonal(codPersonal);
									declaracion.setFecCreacion(calHoy.getTime());
									declaracion.setCodUsucrea(Constantes.CODI_USUR_BATC);
									declaracion.setFecModif(calHoy.getTime());
									declaracion.setCodUsumodif(Constantes.CODI_USUR_BATC);
									declaracion.setCodUorgan(p.getT02codUorg());
									declaracion.setIndDel(Constantes.IND_NOELIMIN);
									declaracion.setIndEstado(Constantes.ESTA_DECL_PROV);
									declaracion.setIndSituFam(Constantes.INDI_SITU_FAMI_ALTA);
									
									declaracion.setCodDocum(documento.getT07codDcto()); //recuperado     
									declaracion.setNumDocum(documento.getT07nroDcto());            
									declaracion.setCodDocumDer(dh.getCodDocumDer());        
									declaracion.setNumDocumDer(dh.getNumDocumDer());        
									declaracion.setCodPaisEmiDoc(dh.getCodPaisEmiDoc());     
									declaracion.setFecNacimientoDer(dh.getFecNacimientoDer());   
									declaracion.setApePatDer(dh.getApePatDer());          
									declaracion.setApeMatDer(dh.getApeMatDer());          
									declaracion.setNomDer(dh.getNomDer());              
									declaracion.setIndSexoDer(dh.getIndSexoDer());         
									declaracion.setCodVinFam(dh.getCodVinFam());          
									declaracion.setCodDocAcreVin(dh.getCodDocAcreVin());     
									declaracion.setNumDocAcreVin(dh.getNumDocAcreVin());     
									declaracion.setNumMesConcep(dh.getNumMesConcep());       
									declaracion.setIndTrabSunat(dh.getIndTrabSunat());       
									declaracion.setNumRegistro(dh.getNumRegistro()); 
									
									declaracion.setCodViaDir1(dh.getCodViaDir1());  //direccion reniec       
									declaracion.setNomViaDir1(dh.getNomViaDir1());         
									declaracion.setNumViaDir1(dh.getNumViaDir1());         
									declaracion.setNumDepaDir1(dh.getNumDepaDir1());        
									declaracion.setNumInteriorDir1(dh.getNumInteriorDir1());    
									declaracion.setNumManzDir1(dh.getNumManzDir1());        
									declaracion.setNumLoteDir1(dh.getNumLoteDir1());        
									declaracion.setNumKilomDir1(dh.getNumKilomDir1());       
									declaracion.setNumBlockDir1(dh.getNumBlockDir1());       
									declaracion.setNumEtapaDir1(dh.getNumEtapaDir1());       
									declaracion.setCodZonaDir1(dh.getCodZonaDir1());        
									declaracion.setNomZonaDir1(dh.getNomZonaDir1());        
									declaracion.setDesReferDir1(dh.getDesReferDir1());       
									declaracion.setCodUbigeoDir1(dh.getCodUbigeoDir1());  
									
									declaracion.setCodViaDir2(dh.getCodViaDir2());  //direccion actual       
									declaracion.setNomViaDir2(dh.getNomViaDir2());         
									declaracion.setNumViaDir2(dh.getNumViaDir2());         
									declaracion.setNumDepaDir2(dh.getNumDepaDir2());        
									declaracion.setNumInteriorDir2(dh.getNumInteriorDir2());    
									declaracion.setNumManzDir2(dh.getNumManzDir2());        
									declaracion.setNumLoteDir2(dh.getNumLoteDir2());        
									declaracion.setNumKilomDir2(dh.getNumKilomDir2());       
									declaracion.setNumBlockDir2(dh.getNumBlockDir2());       
									declaracion.setNumEtapaDir2(dh.getNumEtapaDir2());       
									declaracion.setCodZonaDir2(dh.getCodZonaDir2());        
									declaracion.setNomZonaDir2(dh.getNomZonaDir2());        
									declaracion.setDesReferDir2(dh.getDesRef());              
									declaracion.setCodUbigeoDir2(dh.getCodUbigeoDir2());  
									
									declaracion.setCodTelefLarDis(dh.getCodTelef());  //recuperado           
									declaracion.setNumTelef(dh.getNumTelef());              
									declaracion.setCodCelLarDis(dh.getCodCel());                
									declaracion.setNumCelular(dh.getNumCelular());            
									declaracion.setDesCorreo(dh.getDesCorreo());             
									declaracion.setDesDomiciDir1(dh.getDesDomiciDir1());        
									declaracion.setDesUbigeoDir1(dh.getDesUbigeoDir1());        
									declaracion.setIndReniec(dh.getIndReniec());             
									declaracion.setFecInivinc(dh.getFecInivinc());            
									declaracion.setIndCentAsis(dh.getIndCentAsis());    
									declaracion.setIndEstudiante(dh.getIndEstudio());  
									
									if("01".equals(dh.getCodDocumDer())){ //dni
										
										//domicilio reniec
										Map<String, Object> mapPersonaReniec = personaReniecService.obtenerPersonaReniec(dh.getNumDocumDer());
										String codErrorReniec = (String)mapPersonaReniec.get("codError");
										PersonaReniec personaReniec = (PersonaReniec)mapPersonaReniec.get("persona");
										if(Constantes.CODI_ERRO_EXITO_RENIEC.equals(codErrorReniec) || Constantes.CODI_ERRO_EXITO_SUNAT.equals(codErrorReniec)) {
											//domicilio
											String codUbigeoDirSunat = paramContribuyenteDAO.obtenerUbigeoSunat(personaReniec.getCodDistrito());
											declaracion.setDesUbigeoDir1(paramRrhhDAO.obtenerDesUbigeoSunat(codUbigeoDirSunat));
											declaracion.setDesDomiciDir1(personaReniec.getDesDomiciPnat());
											declaracion.setIndReniec(Constantes.ESTA_CODI_ACTI);
											
											//datos personales
											declaracion.setCodDocumDer("01");
											declaracion.setNumDocumDer(personaReniec.getNumDocidePnat());
											
											//datos principales
											declaracion.setApePatDer(personaReniec.getDesApepatPnat());
											declaracion.setApeMatDer(personaReniec.getDesApematPnat());
											declaracion.setNomDer(personaReniec.getDesNombrePnat());
											declaracion.setFecNacimientoDer(FechasUtil.getDateFromStringDDMMYY(personaReniec.getFecNacPnat()));
											declaracion.setIndSexoDer(DecljuradaUtil.obtenerIndSexo(personaReniec.getDesSexoPnat()));
										}
									}
									declaraDerechohabDAO.insertSelective(declaracion);
								}
							
							}catch(Exception e){
								log.error("Ha ocurrido un error al procesar al derechohabiente: Documento:"+ dh.getNumDocumDer() + ", " + e.getMessage(), e);
							}
							
						}
						
					}
				
				}catch(Exception e){
					log.error("Ha ocurrido un error al procesar al personal: Documento:"+ p.getT02codPers() + ", " + e.getMessage(), e);
				}
				
			}
			
	    }catch(Exception e){
			log.error("Ha ocurrido un error en migrarDatosFamiliares: " + e.getMessage(), e);
		}finally{
			log.debug("fin migrarDatosFamiliares");
		}
	}

}
