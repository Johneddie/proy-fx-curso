package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import pe.gob.sunat.framework.spring.util.dao.SequenceDAO;
import pe.gob.sunat.recurso2.humano.decljurada.bean.DeclaracionJuradaKey;
import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;
import pe.gob.sunat.recurso2.humano.decljurada.model.CodigoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaborador;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohab;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.Persona;
import pe.gob.sunat.recurso2.humano.decljurada.model.Seguimiento;
import pe.gob.sunat.recurso2.humano.decljurada.model.SeguimientoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.UnidadOrg;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.CodigoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraColaboradorDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraDerechohabDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.SeguimientoDAO;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.UnidadOrgDAO;
import pe.gob.sunat.recurso2.humano.decljurada.util.Constantes;
import pe.gob.sunat.recurso2.humano.decljurada.util.FechasUtil;


@Service("seguimientoService")
public class SeguimientoServiceImpl implements SeguimientoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	DeclaraColaboradorDAO declaraColaboradorDAO;
	
	@Autowired
	private PersonaDAO personaDAO;
	
    @Autowired
    SequenceDAO sequenceDAO;
    
	@Autowired
	private SeguimientoDAO seguimientoDAO;
	
	@Autowired
	private CodigoDAO codigoDAO;
	
	@Autowired
	private UnidadOrgDAO unidadOrgDAO;
	
	@Autowired
	DeclaraDerechohabDAO declaraDerechohabDAO;
	
	@Override
	public List<Seguimiento> listarDeclaraciones(Map<String, String> params) throws ParseException {
		if(log.isDebugEnabled()) 
			log.debug("method listarDeclaraciones");
		
		List<Seguimiento> lstDeclaracionesRpt = new ArrayList<>();
		
		try{
			String tipDdjj = !esVacioNulo(params.get("tipDdjj"))?params.get("tipDdjj"):null;
			Date fecCreacionIni = FechasUtil.getDateFromStringDDMMYY(params.get("fecCreacionIni")) ;
			Date fecCreacionFin = FechasUtil.getDateFromStringDDMMYY(params.get("fecCreacionFin")) ;
			if(fecCreacionFin!=null)
				fecCreacionFin = FechasUtil.obtenerFinalDia(fecCreacionFin);
			
			Map<String, Object> mapDeclaraciones = new HashMap<>();
			mapDeclaraciones.put("tipDdjj", tipDdjj);
			mapDeclaraciones.put("fecCreacionIni", fecCreacionIni);
			mapDeclaraciones.put("fecCreacionFin", fecCreacionFin);
			mapDeclaraciones.put("codPersonal", params.get("codPersonal"));
			
			List<Seguimiento> lstDeclaraciones = seguimientoDAO.listarSeguimientos(mapDeclaraciones);
			for(Seguimiento s:lstDeclaraciones){
				s.setDesTipDdjj(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_TIPO_DECL, s.getTipDdjj()));
				
				//nombres
				if(Constantes.CODI_TIPO_DDJJ_GENE.equals(s.getTipDdjj())){
					DeclaraColaboradorKey dk = new DeclaraColaboradorKey();
					dk.setAnnDdjj(s.getAnnDdjj());
					dk.setNumDdjj(s.getNumDdjj());
					dk.setIndEstado(s.getIndEstadoid());
					DeclaraColaborador d = declaraColaboradorDAO.selectByPrimaryKey(dk);
					if(d != null){
						s.setDesNombres(d.getApePat() + " " + d.getApeMat() + ", " + d.getNomPersonal());
						lstDeclaracionesRpt.add(s);
					}
				}else if(Constantes.CODI_TIPO_DDJJ_FAMI.equals(s.getTipDdjj())){
					DeclaraDerechohabKey dk = new DeclaraDerechohabKey();
					dk.setAnnDdjj(s.getAnnDdjj());
					dk.setNumDdjj(s.getNumDdjj());
					dk.setIndEstado(s.getIndEstadoid());
					DeclaraDerechohab d = declaraDerechohabDAO.selectByPrimaryKey(dk);
					if(d != null){
						s.setDesNombres(d.getApePatDer() + " " + d.getApeMatDer() + ", " + d.getNomDer());
						lstDeclaracionesRpt.add(s);
					}
				}
				
				//estado
				s.setDesIndEstadoid(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_ESTA_DECL, s.getIndEstadoid()));
				
				//responsable
				Persona p = personaDAO.selectByPrimaryKey(s.getCodUserdest());
				s.setDesNombresResp(p.getT02apMate() + " " + p.getT02apPate() + ", " + p.getT02nombres());
			}
		}catch(Exception e){
			log.error("Ha ocurrido un error en listarDeclaraciones: " + e.getMessage(), e);
		}
		return lstDeclaracionesRpt;
	}
	
	@Override
	public List<Seguimiento> listarSeguimientos(Map<String, String> params) {
		if(log.isDebugEnabled()) 
			log.debug("method listarSeguimientos");
		
		SeguimientoExample se = new SeguimientoExample();
		SeguimientoExample.Criteria sc = se.createCriteria();
		sc.andAnnDdjjEqualTo(params.get("annDdjj"));
		sc.andNumDdjjEqualTo(Integer.parseInt(params.get("numDdjj")));
		sc.andCodPersonalEqualTo(params.get("codPersonal"));
		se.setOrderByClause("num_seguim desc");
		List<Seguimiento> lstDeclaraciones = seguimientoDAO.selectByExample(se);
		
		for(Seguimiento s:lstDeclaraciones){
			s.setDesIndEstadoid(codigoDAO.obtenerDescripcion(Constantes.CODI_TABL_ESTA_DECL, s.getIndEstadoid()));
			//responsable
			Persona p = personaDAO.selectByPrimaryKey(s.getCodUserdest());
			s.setDesNombresResp(p.getT02apMate() + " " + p.getT02apPate() + ", " + p.getT02nombres());
		}
		
		return lstDeclaraciones;
	}
	
	public void registrarSeguimiento(DeclaracionJuradaKey declaracion, String codPersonal, String codUorgan, Map<String, String> mapUsuario, String tipDdjj){
		Calendar calendar = Calendar.getInstance();
		String usuario = mapUsuario.get("usuario");
		String indEstado = declaracion.getIndEstado();
		String annDdjj = declaracion.getAnnDdjj();
		Integer numDdjj = declaracion.getNumDdjj();
		String numSeguim = "-1";
		
		//n�mero seguimiento
		SeguimientoExample se = new SeguimientoExample();
		SeguimientoExample.Criteria sc = se.createCriteria();
		sc.andAnnDdjjEqualTo(annDdjj);
		sc.andNumDdjjEqualTo(numDdjj);
		sc.andCodPersonalEqualTo(codPersonal);
		se.setOrderByClause("num_seguim desc");
		Seguimiento seguimAnterior = seguimientoDAO.selectByExampleFirst(se);
		
		//unidad destino
		CodigoExample ce = new CodigoExample();
		CodigoExample.Criteria cc = ce.createCriteria();
		cc.andT99codTabEqualTo(Constantes.CODI_TABL_UNID_RECE);
		cc.andT99descripEqualTo(Constantes.DESC_TABL_UNID_RECE);
		cc.andT99tipDescEqualTo(Constantes.TIPO_CODI_DESC);
		List<Parametro> lstParamUnidades = codigoDAO.selectByExampleBasic(ce);
		
		//jefe o encargado
		UnidadOrg unidadJefe = unidadOrgDAO.selectByPrimaryKey(lstParamUnidades.get(0).getCodParametro());
		String codJefeEncarg =  unidadJefe.getT12codEncar();
		if(esVacioNulo(codJefeEncarg))
			codJefeEncarg = unidadJefe.getT12codJefat();
		
		//anterior seguimiento
		if(seguimAnterior != null){
			seguimAnterior.setFecModif(calendar.getTime());
			seguimAnterior.setCodUsumodif(usuario);
			seguimAnterior.setIndUltSeg(Constantes.ESTA_CODI_INAC);
			seguimientoDAO.updateByPrimaryKeySelective(seguimAnterior);
			numSeguim = seguimAnterior.getNumSeguim();
		}
		
		if(Constantes.ESTA_DECL_ENVI.equals(indEstado)){
			Seguimiento s = new Seguimiento();
			s.setAnnDdjj(annDdjj);
			s.setNumDdjj(numDdjj);
			s.setCodPersonal(codPersonal);
			s.setCodUorgan(codUorgan);
			s.setNumSeguim(Integer.toString(Integer.parseInt(numSeguim)+1));
			s.setIndAccionid(Constantes.CODI_ACCI_SEGU_ENVI);
			s.setIndEstadoid(declaracion.getIndEstado());
			s.setFecRecep(calendar.getTime());
			s.setFecDeriv(calendar.getTime());
			s.setCodUserorig(codPersonal);
			s.setCodUserdest(codJefeEncarg);
			s.setObsSeg(Constantes.DESC_OBSE_SEGU);
			s.setTipDdjj(tipDdjj);
			s.setFecCreacion(calendar.getTime());
			s.setCodUsucrea(usuario);
			s.setFecModif(calendar.getTime());
			s.setCodUsumodif(usuario);
			seguimientoDAO.insertSelective(s);
		}
	}
	
	private boolean esVacioNulo(String dato){
		return dato==null || "".equals(dato.trim());
	}

}
