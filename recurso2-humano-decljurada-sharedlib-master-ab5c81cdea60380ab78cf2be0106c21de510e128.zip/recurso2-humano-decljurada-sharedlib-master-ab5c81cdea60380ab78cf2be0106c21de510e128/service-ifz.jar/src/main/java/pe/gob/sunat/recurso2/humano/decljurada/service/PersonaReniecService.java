package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.Calendar;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.decljurada.bean.DeclaracionJuradaKey;
import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;
import pe.gob.sunat.recurso2.humano.decljurada.model.Archivo;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabKey;


public interface PersonaReniecService {


	public Map<String,Object> obtenerPersonaReniec(String numDoc);
	
}
