package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.Map;

import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaborador;

public interface DeclaraColaboradorService {
	public DeclaraColaborador obtenerUltimaDeclaracion (String codPersonal);
	public Map<String, Object> registrarDeclaraColaborador(DeclaraColaborador declaraColaborador, Map<String, String> mapUsuario) throws Exception;
}
