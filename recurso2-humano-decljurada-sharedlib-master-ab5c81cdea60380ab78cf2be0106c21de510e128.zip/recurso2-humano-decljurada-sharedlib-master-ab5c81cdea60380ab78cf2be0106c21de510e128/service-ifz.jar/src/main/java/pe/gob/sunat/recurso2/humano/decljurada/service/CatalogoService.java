package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.List;

import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;


public interface CatalogoService {

	List<Parametro> listarDepartamentos();
	List<Parametro> listarProvincias(String codDepartamento);
	List<Parametro> listarDistritos(String codProvincia);
	
//	Parametro getUbigeo(String codUbigeo);
//	
//	List<Parametro> listarZonasDomiciliarias();
//	List<Parametro> listarViasDomiciliarias();
//	
//	List<Parametro> listarGradosAcademicos();
//	List<Parametro> listarProfesiones();
//	List<Parametro> listarCentrosEstudio();
//	
//	List<Parametro> listarIndicadoresPuesto();
//	
//	List<Parametro> listarTiposExperiencia();
//	List<Parametro> listarContratosPrivados();
//	List<Parametro> listarContratosPublicos();
//	List<Parametro> listarMotivosCese();
//	List<Parametro> listarNivelesExpLab();
//	
//	List<Parametro> listarTiposBrevete();
//	
//	List<Parametro> listarTiposEstudio();
//	List<Parametro> listarNivelEstudio(String codTipoEstudio);
//	List<Parametro> listarCiclos(String codTipoEstudio, String codNivelEstudio);
//	
//	List<Parametro> listarCarreras(String codTipoEstudio);	
//	List<Parametro> listaTipoConocimiento( String codTipoConocimiento);	
//	
//	Parametro getMensajeInicio();
//	
//	List<Parametro> listarPaises() ;
//	List<Parametro> listarCondicionesColegiatura();
//	List<Parametro> listarTiposDiscapacidad();
//	List<Parametro>  selectVinculoFamiliar();
//	List<Parametro> selectDocAgredita();
	List<Parametro> listarCodigosLDN();
	List<Parametro> listarTiposDocumento();
	List<Parametro> listarNacionalidades();
	List<Parametro> listarTiposVia();
	List<Parametro> listarTiposZona();
	
	public List<Parametro> listarMotivosBaja();
//	String selectUbigeoDni(String codigo);
//	String selectUbigeoRuc(String codigo);
//	String descripcionDocPariente(String codigo);
//	String descripcionVinculoFamiliar(String codigo);
//	String selectZona(String codigo);
//	List<ModalidadSeccion> selectSeccionModalidad(String codModalidad);
//	int selectGanadoresPorModalidad(DetalleFase objetc);
//	int selectGanadoresFechaFin(Integer numPostulante);
//	int deleteArchivoPorModalidad(SustentoVinculoFamiliar object) ;
//	
//	List<Parametro> listarParentescos();
//	int updateFichaPracticaCero(Integer numPostulante);
//	int updateFichaPractica(String numIdAcadem);
//	String especialidadPadre(String codigo);
//	List<Parametro> listarNivelPorT99codigo(List<String> incluir);
//	List<Parametro> listarContratosPrivadosEx(List<String> excluir);
//	List<Parametro> listarContratosPublicosEx(List<String> excluir);
//	int countFormacionAcademica(Integer numPostulante);
//	int countExperienciaLaboral(Integer numPostulante);
//	int countCertificacion(Integer numPostulante);
//	int countProgramaEspecializacion(Integer numPostulante);
//	Ficha fichaObject(Integer numPostulante);
//	RucNumDocumento countDocRuc(RucNumDocumento object);
//	RucNumDocumento rucDocIntidad(RucNumDocumento object);
//	String tipoDocEquivalencia(String tipoDoc);
//	String habilitaObligatoriedadRuc();
//	boolean permiteRegistroManualCuentaUsuario();
//	int countExisteExperienciaEspecifico(Short codCat);
	
	
	public List<Parametro> listarEstadosCivil();
	
	public List<Parametro> listarPaisesEmisor();
	
	public List<Parametro> listarTiposDeclaracion();
	
	public List<Parametro> listarTiposVinculo();
	
	public List<Parametro> listarDocumentosVinculo();
	
}
