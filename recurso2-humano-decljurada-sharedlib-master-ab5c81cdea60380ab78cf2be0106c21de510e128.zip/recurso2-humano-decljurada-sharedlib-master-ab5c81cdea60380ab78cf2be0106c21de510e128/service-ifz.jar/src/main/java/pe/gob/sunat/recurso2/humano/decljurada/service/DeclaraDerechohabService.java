package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohab;
import pe.gob.sunat.recurso2.humano.decljurada.model.Persona;

public interface DeclaraDerechohabService {
	
	
	public List<DeclaraDerechohab> listarUltimasDeclaraciones (String codPersonal);
	
	public DeclaraDerechohab obtenerDeclaracion(String codPersonal, String declaracionPK);
	
	public DeclaraDerechohab obtenerDerechohabReniec(String numDocDer);
	
	public Map<String, Object> registrarDeclaraDerechohab(DeclaraDerechohab declaracion, Map<String, String> mapUsuario) throws Exception;
	
	public String esRegimenPermitidoSubsidSepe(String codPersonal);
	
	public Persona obtenerPersonal(String documento);

}
