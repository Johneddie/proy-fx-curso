package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.util.Calendar;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.decljurada.bean.DeclaracionJuradaKey;
import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;
import pe.gob.sunat.recurso2.humano.decljurada.model.Archivo;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabKey;


public interface ArchivoService {

	public Archivo obtenerArchivo(ArchivoKey archivoKey);
	
	public void migrarArchivosDerechohab(DeclaraDerechohabKey declaraKey, Integer numDdjjOld, String usuario, Calendar calendar);
	
	public void migrarArchivosColaborador(DeclaraColaboradorKey declaraKey, Integer numDdjjOld, String usuario, Calendar calendar);
	
	public void registrarArchivos(List<Archivo> lstArchivos, Calendar calendar, DeclaracionJuradaKey declaraKey, Map<String, String> mapUsuario) throws Exception;
	
}
