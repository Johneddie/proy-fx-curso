package pe.gob.sunat.recurso2.humano.decljurada.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.decljurada.bean.DeclaracionJuradaKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.Seguimiento;

public interface SeguimientoService {
	public List<Seguimiento> listarDeclaraciones(Map<String, String> params) throws ParseException;
	public List<Seguimiento> listarSeguimientos(Map<String, String> params);
	public void registrarSeguimiento(DeclaracionJuradaKey declaracion, String codPersonal, String codUorgan, Map<String, String> mapUsuario, String tipDdjj);
}
