package pe.gob.sunat.recurso2.humano.decljurada.service;


public interface MigracionSeleccionService {
	
	public void migrarDatosPersonales();
	
	public void migrarDatosFamiliares();
}
