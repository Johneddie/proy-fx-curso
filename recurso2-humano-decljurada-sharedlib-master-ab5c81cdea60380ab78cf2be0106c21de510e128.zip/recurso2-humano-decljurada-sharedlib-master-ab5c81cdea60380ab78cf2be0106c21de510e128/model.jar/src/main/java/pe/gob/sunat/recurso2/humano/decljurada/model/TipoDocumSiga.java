package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class TipoDocumSiga {
    private String tipoDocuIde;

    private String nombDocuIde;

    private Short longDocuIde;

    private String codigoMef;

    private String userCrea;

    private Date fechCrea;

    private String userModi;

    private Date fechModi;

    private String codReniec;

    private String desReniec;

    private String codSirh;

    private String codDds;

    public String getTipoDocuIde() {
        return tipoDocuIde;
    }

    public void setTipoDocuIde(String tipoDocuIde) {
        this.tipoDocuIde = tipoDocuIde == null ? null : tipoDocuIde.trim();
    }

    public String getNombDocuIde() {
        return nombDocuIde;
    }

    public void setNombDocuIde(String nombDocuIde) {
        this.nombDocuIde = nombDocuIde == null ? null : nombDocuIde.trim();
    }

    public Short getLongDocuIde() {
        return longDocuIde;
    }

    public void setLongDocuIde(Short longDocuIde) {
        this.longDocuIde = longDocuIde;
    }

    public String getCodigoMef() {
        return codigoMef;
    }

    public void setCodigoMef(String codigoMef) {
        this.codigoMef = codigoMef == null ? null : codigoMef.trim();
    }

    public String getUserCrea() {
        return userCrea;
    }

    public void setUserCrea(String userCrea) {
        this.userCrea = userCrea == null ? null : userCrea.trim();
    }

    public Date getFechCrea() {
        return fechCrea;
    }

    public void setFechCrea(Date fechCrea) {
        this.fechCrea = fechCrea;
    }

    public String getUserModi() {
        return userModi;
    }

    public void setUserModi(String userModi) {
        this.userModi = userModi == null ? null : userModi.trim();
    }

    public Date getFechModi() {
        return fechModi;
    }

    public void setFechModi(Date fechModi) {
        this.fechModi = fechModi;
    }

    public String getCodReniec() {
        return codReniec;
    }

    public void setCodReniec(String codReniec) {
        this.codReniec = codReniec == null ? null : codReniec.trim();
    }

    public String getDesReniec() {
        return desReniec;
    }

    public void setDesReniec(String desReniec) {
        this.desReniec = desReniec == null ? null : desReniec.trim();
    }

    public String getCodSirh() {
        return codSirh;
    }

    public void setCodSirh(String codSirh) {
        this.codSirh = codSirh == null ? null : codSirh.trim();
    }

    public String getCodDds() {
        return codDds;
    }

    public void setCodDds(String codDds) {
        this.codDds = codDds == null ? null : codDds.trim();
    }
}