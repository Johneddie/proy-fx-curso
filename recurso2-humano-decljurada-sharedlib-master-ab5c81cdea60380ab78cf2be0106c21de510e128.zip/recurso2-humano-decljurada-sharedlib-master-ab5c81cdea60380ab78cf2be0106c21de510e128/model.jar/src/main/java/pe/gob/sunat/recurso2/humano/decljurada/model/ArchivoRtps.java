package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class ArchivoRtps {
    private Date fecProceso;

    private String indArchTrab;

    private String indArchDerhab;

    private String indExitoProc;

    private Date fecCreacion;

    private String codUsucrea;

    private Date fecModif;

    private String codUsumodif;

    private String indArchTrabAlta;

    private String indArchTrabBaja;

    private String indArchTrabMod;

    private String indArchDerhabAlta;

    private String indArchDerhabBaja;

    public Date getFecProceso() {
        return fecProceso;
    }

    public void setFecProceso(Date fecProceso) {
        this.fecProceso = fecProceso;
    }

    public String getIndArchTrab() {
        return indArchTrab;
    }

    public void setIndArchTrab(String indArchTrab) {
        this.indArchTrab = indArchTrab == null ? null : indArchTrab.trim();
    }

    public String getIndArchDerhab() {
        return indArchDerhab;
    }

    public void setIndArchDerhab(String indArchDerhab) {
        this.indArchDerhab = indArchDerhab == null ? null : indArchDerhab.trim();
    }

    public String getIndExitoProc() {
        return indExitoProc;
    }

    public void setIndExitoProc(String indExitoProc) {
        this.indExitoProc = indExitoProc == null ? null : indExitoProc.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public String getIndArchTrabAlta() {
        return indArchTrabAlta;
    }

    public void setIndArchTrabAlta(String indArchTrabAlta) {
        this.indArchTrabAlta = indArchTrabAlta == null ? null : indArchTrabAlta.trim();
    }

    public String getIndArchTrabBaja() {
        return indArchTrabBaja;
    }

    public void setIndArchTrabBaja(String indArchTrabBaja) {
        this.indArchTrabBaja = indArchTrabBaja == null ? null : indArchTrabBaja.trim();
    }

    public String getIndArchTrabMod() {
        return indArchTrabMod;
    }

    public void setIndArchTrabMod(String indArchTrabMod) {
        this.indArchTrabMod = indArchTrabMod == null ? null : indArchTrabMod.trim();
    }

    public String getIndArchDerhabAlta() {
        return indArchDerhabAlta;
    }

    public void setIndArchDerhabAlta(String indArchDerhabAlta) {
        this.indArchDerhabAlta = indArchDerhabAlta == null ? null : indArchDerhabAlta.trim();
    }

    public String getIndArchDerhabBaja() {
        return indArchDerhabBaja;
    }

    public void setIndArchDerhabBaja(String indArchDerhabBaja) {
        this.indArchDerhabBaja = indArchDerhabBaja == null ? null : indArchDerhabBaja.trim();
    }
}