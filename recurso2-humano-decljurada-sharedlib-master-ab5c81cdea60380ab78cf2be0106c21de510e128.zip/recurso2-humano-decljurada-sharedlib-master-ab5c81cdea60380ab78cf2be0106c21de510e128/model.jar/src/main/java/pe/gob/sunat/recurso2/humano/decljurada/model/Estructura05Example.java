package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Estructura05Example {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public Estructura05Example() {
        oredCriteria = new ArrayList<>();
    }

    protected Estructura05Example(Estructura05Example example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andFecProcesoIsNull() {
            addCriterion("fec_proceso is null");
            return this;
        }

        public Criteria andFecProcesoIsNotNull() {
            addCriterion("fec_proceso is not null");
            return this;
        }

        public Criteria andFecProcesoEqualTo(Date value) {
            addCriterion("fec_proceso =", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotEqualTo(Date value) {
            addCriterion("fec_proceso <>", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThan(Date value) {
            addCriterion("fec_proceso >", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_proceso >=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThan(Date value) {
            addCriterion("fec_proceso <", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThanOrEqualTo(Date value) {
            addCriterion("fec_proceso <=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoIn(List<Date> values) {
            addCriterion("fec_proceso in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotIn(List<Date> values) {
            addCriterion("fec_proceso not in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoBetween(Date value1, Date value2) {
            addCriterion("fec_proceso between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotBetween(Date value1, Date value2) {
            addCriterion("fec_proceso not between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodRegLabIsNull() {
            addCriterion("cod_reg_lab is null");
            return this;
        }

        public Criteria andCodRegLabIsNotNull() {
            addCriterion("cod_reg_lab is not null");
            return this;
        }

        public Criteria andCodRegLabEqualTo(String value) {
            addCriterion("cod_reg_lab =", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabNotEqualTo(String value) {
            addCriterion("cod_reg_lab <>", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabGreaterThan(String value) {
            addCriterion("cod_reg_lab >", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabGreaterThanOrEqualTo(String value) {
            addCriterion("cod_reg_lab >=", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabLessThan(String value) {
            addCriterion("cod_reg_lab <", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabLessThanOrEqualTo(String value) {
            addCriterion("cod_reg_lab <=", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabLike(String value) {
            addCriterion("cod_reg_lab like", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabNotLike(String value) {
            addCriterion("cod_reg_lab not like", value, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabIn(List<String> values) {
            addCriterion("cod_reg_lab in", values, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabNotIn(List<String> values) {
            addCriterion("cod_reg_lab not in", values, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabBetween(String value1, String value2) {
            addCriterion("cod_reg_lab between", value1, value2, "codRegLab");
            return this;
        }

        public Criteria andCodRegLabNotBetween(String value1, String value2) {
            addCriterion("cod_reg_lab not between", value1, value2, "codRegLab");
            return this;
        }

        public Criteria andCodNvlEduIsNull() {
            addCriterion("cod_nvl_edu is null");
            return this;
        }

        public Criteria andCodNvlEduIsNotNull() {
            addCriterion("cod_nvl_edu is not null");
            return this;
        }

        public Criteria andCodNvlEduEqualTo(String value) {
            addCriterion("cod_nvl_edu =", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduNotEqualTo(String value) {
            addCriterion("cod_nvl_edu <>", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduGreaterThan(String value) {
            addCriterion("cod_nvl_edu >", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduGreaterThanOrEqualTo(String value) {
            addCriterion("cod_nvl_edu >=", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduLessThan(String value) {
            addCriterion("cod_nvl_edu <", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduLessThanOrEqualTo(String value) {
            addCriterion("cod_nvl_edu <=", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduLike(String value) {
            addCriterion("cod_nvl_edu like", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduNotLike(String value) {
            addCriterion("cod_nvl_edu not like", value, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduIn(List<String> values) {
            addCriterion("cod_nvl_edu in", values, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduNotIn(List<String> values) {
            addCriterion("cod_nvl_edu not in", values, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduBetween(String value1, String value2) {
            addCriterion("cod_nvl_edu between", value1, value2, "codNvlEdu");
            return this;
        }

        public Criteria andCodNvlEduNotBetween(String value1, String value2) {
            addCriterion("cod_nvl_edu not between", value1, value2, "codNvlEdu");
            return this;
        }

        public Criteria andCodOcupIsNull() {
            addCriterion("cod_ocup is null");
            return this;
        }

        public Criteria andCodOcupIsNotNull() {
            addCriterion("cod_ocup is not null");
            return this;
        }

        public Criteria andCodOcupEqualTo(String value) {
            addCriterion("cod_ocup =", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupNotEqualTo(String value) {
            addCriterion("cod_ocup <>", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupGreaterThan(String value) {
            addCriterion("cod_ocup >", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ocup >=", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupLessThan(String value) {
            addCriterion("cod_ocup <", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupLessThanOrEqualTo(String value) {
            addCriterion("cod_ocup <=", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupLike(String value) {
            addCriterion("cod_ocup like", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupNotLike(String value) {
            addCriterion("cod_ocup not like", value, "codOcup");
            return this;
        }

        public Criteria andCodOcupIn(List<String> values) {
            addCriterion("cod_ocup in", values, "codOcup");
            return this;
        }

        public Criteria andCodOcupNotIn(List<String> values) {
            addCriterion("cod_ocup not in", values, "codOcup");
            return this;
        }

        public Criteria andCodOcupBetween(String value1, String value2) {
            addCriterion("cod_ocup between", value1, value2, "codOcup");
            return this;
        }

        public Criteria andCodOcupNotBetween(String value1, String value2) {
            addCriterion("cod_ocup not between", value1, value2, "codOcup");
            return this;
        }

        public Criteria andIndDiscapacidadIsNull() {
            addCriterion("ind_discapacidad is null");
            return this;
        }

        public Criteria andIndDiscapacidadIsNotNull() {
            addCriterion("ind_discapacidad is not null");
            return this;
        }

        public Criteria andIndDiscapacidadEqualTo(String value) {
            addCriterion("ind_discapacidad =", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotEqualTo(String value) {
            addCriterion("ind_discapacidad <>", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadGreaterThan(String value) {
            addCriterion("ind_discapacidad >", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadGreaterThanOrEqualTo(String value) {
            addCriterion("ind_discapacidad >=", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLessThan(String value) {
            addCriterion("ind_discapacidad <", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLessThanOrEqualTo(String value) {
            addCriterion("ind_discapacidad <=", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLike(String value) {
            addCriterion("ind_discapacidad like", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotLike(String value) {
            addCriterion("ind_discapacidad not like", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadIn(List<String> values) {
            addCriterion("ind_discapacidad in", values, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotIn(List<String> values) {
            addCriterion("ind_discapacidad not in", values, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadBetween(String value1, String value2) {
            addCriterion("ind_discapacidad between", value1, value2, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotBetween(String value1, String value2) {
            addCriterion("ind_discapacidad not between", value1, value2, "indDiscapacidad");
            return this;
        }

        public Criteria andDesCusspIsNull() {
            addCriterion("des_cussp is null");
            return this;
        }

        public Criteria andDesCusspIsNotNull() {
            addCriterion("des_cussp is not null");
            return this;
        }

        public Criteria andDesCusspEqualTo(String value) {
            addCriterion("des_cussp =", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspNotEqualTo(String value) {
            addCriterion("des_cussp <>", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspGreaterThan(String value) {
            addCriterion("des_cussp >", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspGreaterThanOrEqualTo(String value) {
            addCriterion("des_cussp >=", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspLessThan(String value) {
            addCriterion("des_cussp <", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspLessThanOrEqualTo(String value) {
            addCriterion("des_cussp <=", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspLike(String value) {
            addCriterion("des_cussp like", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspNotLike(String value) {
            addCriterion("des_cussp not like", value, "desCussp");
            return this;
        }

        public Criteria andDesCusspIn(List<String> values) {
            addCriterion("des_cussp in", values, "desCussp");
            return this;
        }

        public Criteria andDesCusspNotIn(List<String> values) {
            addCriterion("des_cussp not in", values, "desCussp");
            return this;
        }

        public Criteria andDesCusspBetween(String value1, String value2) {
            addCriterion("des_cussp between", value1, value2, "desCussp");
            return this;
        }

        public Criteria andDesCusspNotBetween(String value1, String value2) {
            addCriterion("des_cussp not between", value1, value2, "desCussp");
            return this;
        }

        public Criteria andIndSctrIsNull() {
            addCriterion("ind_sctr is null");
            return this;
        }

        public Criteria andIndSctrIsNotNull() {
            addCriterion("ind_sctr is not null");
            return this;
        }

        public Criteria andIndSctrEqualTo(String value) {
            addCriterion("ind_sctr =", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrNotEqualTo(String value) {
            addCriterion("ind_sctr <>", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrGreaterThan(String value) {
            addCriterion("ind_sctr >", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sctr >=", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrLessThan(String value) {
            addCriterion("ind_sctr <", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrLessThanOrEqualTo(String value) {
            addCriterion("ind_sctr <=", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrLike(String value) {
            addCriterion("ind_sctr like", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrNotLike(String value) {
            addCriterion("ind_sctr not like", value, "indSctr");
            return this;
        }

        public Criteria andIndSctrIn(List<String> values) {
            addCriterion("ind_sctr in", values, "indSctr");
            return this;
        }

        public Criteria andIndSctrNotIn(List<String> values) {
            addCriterion("ind_sctr not in", values, "indSctr");
            return this;
        }

        public Criteria andIndSctrBetween(String value1, String value2) {
            addCriterion("ind_sctr between", value1, value2, "indSctr");
            return this;
        }

        public Criteria andIndSctrNotBetween(String value1, String value2) {
            addCriterion("ind_sctr not between", value1, value2, "indSctr");
            return this;
        }

        public Criteria andCodTipContratoIsNull() {
            addCriterion("cod_tip_contrato is null");
            return this;
        }

        public Criteria andCodTipContratoIsNotNull() {
            addCriterion("cod_tip_contrato is not null");
            return this;
        }

        public Criteria andCodTipContratoEqualTo(String value) {
            addCriterion("cod_tip_contrato =", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoNotEqualTo(String value) {
            addCriterion("cod_tip_contrato <>", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoGreaterThan(String value) {
            addCriterion("cod_tip_contrato >", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip_contrato >=", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoLessThan(String value) {
            addCriterion("cod_tip_contrato <", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoLessThanOrEqualTo(String value) {
            addCriterion("cod_tip_contrato <=", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoLike(String value) {
            addCriterion("cod_tip_contrato like", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoNotLike(String value) {
            addCriterion("cod_tip_contrato not like", value, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoIn(List<String> values) {
            addCriterion("cod_tip_contrato in", values, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoNotIn(List<String> values) {
            addCriterion("cod_tip_contrato not in", values, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoBetween(String value1, String value2) {
            addCriterion("cod_tip_contrato between", value1, value2, "codTipContrato");
            return this;
        }

        public Criteria andCodTipContratoNotBetween(String value1, String value2) {
            addCriterion("cod_tip_contrato not between", value1, value2, "codTipContrato");
            return this;
        }

        public Criteria andIndRegIsNull() {
            addCriterion("ind_reg is null");
            return this;
        }

        public Criteria andIndRegIsNotNull() {
            addCriterion("ind_reg is not null");
            return this;
        }

        public Criteria andIndRegEqualTo(String value) {
            addCriterion("ind_reg =", value, "indReg");
            return this;
        }

        public Criteria andIndRegNotEqualTo(String value) {
            addCriterion("ind_reg <>", value, "indReg");
            return this;
        }

        public Criteria andIndRegGreaterThan(String value) {
            addCriterion("ind_reg >", value, "indReg");
            return this;
        }

        public Criteria andIndRegGreaterThanOrEqualTo(String value) {
            addCriterion("ind_reg >=", value, "indReg");
            return this;
        }

        public Criteria andIndRegLessThan(String value) {
            addCriterion("ind_reg <", value, "indReg");
            return this;
        }

        public Criteria andIndRegLessThanOrEqualTo(String value) {
            addCriterion("ind_reg <=", value, "indReg");
            return this;
        }

        public Criteria andIndRegLike(String value) {
            addCriterion("ind_reg like", value, "indReg");
            return this;
        }

        public Criteria andIndRegNotLike(String value) {
            addCriterion("ind_reg not like", value, "indReg");
            return this;
        }

        public Criteria andIndRegIn(List<String> values) {
            addCriterion("ind_reg in", values, "indReg");
            return this;
        }

        public Criteria andIndRegNotIn(List<String> values) {
            addCriterion("ind_reg not in", values, "indReg");
            return this;
        }

        public Criteria andIndRegBetween(String value1, String value2) {
            addCriterion("ind_reg between", value1, value2, "indReg");
            return this;
        }

        public Criteria andIndRegNotBetween(String value1, String value2) {
            addCriterion("ind_reg not between", value1, value2, "indReg");
            return this;
        }

        public Criteria andIndJorTraMaxIsNull() {
            addCriterion("ind_jor_tra_max is null");
            return this;
        }

        public Criteria andIndJorTraMaxIsNotNull() {
            addCriterion("ind_jor_tra_max is not null");
            return this;
        }

        public Criteria andIndJorTraMaxEqualTo(String value) {
            addCriterion("ind_jor_tra_max =", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxNotEqualTo(String value) {
            addCriterion("ind_jor_tra_max <>", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxGreaterThan(String value) {
            addCriterion("ind_jor_tra_max >", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxGreaterThanOrEqualTo(String value) {
            addCriterion("ind_jor_tra_max >=", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxLessThan(String value) {
            addCriterion("ind_jor_tra_max <", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxLessThanOrEqualTo(String value) {
            addCriterion("ind_jor_tra_max <=", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxLike(String value) {
            addCriterion("ind_jor_tra_max like", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxNotLike(String value) {
            addCriterion("ind_jor_tra_max not like", value, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxIn(List<String> values) {
            addCriterion("ind_jor_tra_max in", values, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxNotIn(List<String> values) {
            addCriterion("ind_jor_tra_max not in", values, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxBetween(String value1, String value2) {
            addCriterion("ind_jor_tra_max between", value1, value2, "indJorTraMax");
            return this;
        }

        public Criteria andIndJorTraMaxNotBetween(String value1, String value2) {
            addCriterion("ind_jor_tra_max not between", value1, value2, "indJorTraMax");
            return this;
        }

        public Criteria andIndHorNoctIsNull() {
            addCriterion("ind_hor_noct is null");
            return this;
        }

        public Criteria andIndHorNoctIsNotNull() {
            addCriterion("ind_hor_noct is not null");
            return this;
        }

        public Criteria andIndHorNoctEqualTo(String value) {
            addCriterion("ind_hor_noct =", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctNotEqualTo(String value) {
            addCriterion("ind_hor_noct <>", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctGreaterThan(String value) {
            addCriterion("ind_hor_noct >", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctGreaterThanOrEqualTo(String value) {
            addCriterion("ind_hor_noct >=", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctLessThan(String value) {
            addCriterion("ind_hor_noct <", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctLessThanOrEqualTo(String value) {
            addCriterion("ind_hor_noct <=", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctLike(String value) {
            addCriterion("ind_hor_noct like", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctNotLike(String value) {
            addCriterion("ind_hor_noct not like", value, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctIn(List<String> values) {
            addCriterion("ind_hor_noct in", values, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctNotIn(List<String> values) {
            addCriterion("ind_hor_noct not in", values, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctBetween(String value1, String value2) {
            addCriterion("ind_hor_noct between", value1, value2, "indHorNoct");
            return this;
        }

        public Criteria andIndHorNoctNotBetween(String value1, String value2) {
            addCriterion("ind_hor_noct not between", value1, value2, "indHorNoct");
            return this;
        }

        public Criteria andIndSindicalIsNull() {
            addCriterion("ind_sindical is null");
            return this;
        }

        public Criteria andIndSindicalIsNotNull() {
            addCriterion("ind_sindical is not null");
            return this;
        }

        public Criteria andIndSindicalEqualTo(String value) {
            addCriterion("ind_sindical =", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalNotEqualTo(String value) {
            addCriterion("ind_sindical <>", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalGreaterThan(String value) {
            addCriterion("ind_sindical >", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sindical >=", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalLessThan(String value) {
            addCriterion("ind_sindical <", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalLessThanOrEqualTo(String value) {
            addCriterion("ind_sindical <=", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalLike(String value) {
            addCriterion("ind_sindical like", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalNotLike(String value) {
            addCriterion("ind_sindical not like", value, "indSindical");
            return this;
        }

        public Criteria andIndSindicalIn(List<String> values) {
            addCriterion("ind_sindical in", values, "indSindical");
            return this;
        }

        public Criteria andIndSindicalNotIn(List<String> values) {
            addCriterion("ind_sindical not in", values, "indSindical");
            return this;
        }

        public Criteria andIndSindicalBetween(String value1, String value2) {
            addCriterion("ind_sindical between", value1, value2, "indSindical");
            return this;
        }

        public Criteria andIndSindicalNotBetween(String value1, String value2) {
            addCriterion("ind_sindical not between", value1, value2, "indSindical");
            return this;
        }

        public Criteria andIndPeriodicidadIsNull() {
            addCriterion("ind_periodicidad is null");
            return this;
        }

        public Criteria andIndPeriodicidadIsNotNull() {
            addCriterion("ind_periodicidad is not null");
            return this;
        }

        public Criteria andIndPeriodicidadEqualTo(String value) {
            addCriterion("ind_periodicidad =", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadNotEqualTo(String value) {
            addCriterion("ind_periodicidad <>", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadGreaterThan(String value) {
            addCriterion("ind_periodicidad >", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadGreaterThanOrEqualTo(String value) {
            addCriterion("ind_periodicidad >=", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadLessThan(String value) {
            addCriterion("ind_periodicidad <", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadLessThanOrEqualTo(String value) {
            addCriterion("ind_periodicidad <=", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadLike(String value) {
            addCriterion("ind_periodicidad like", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadNotLike(String value) {
            addCriterion("ind_periodicidad not like", value, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadIn(List<String> values) {
            addCriterion("ind_periodicidad in", values, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadNotIn(List<String> values) {
            addCriterion("ind_periodicidad not in", values, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadBetween(String value1, String value2) {
            addCriterion("ind_periodicidad between", value1, value2, "indPeriodicidad");
            return this;
        }

        public Criteria andIndPeriodicidadNotBetween(String value1, String value2) {
            addCriterion("ind_periodicidad not between", value1, value2, "indPeriodicidad");
            return this;
        }

        public Criteria andNumMontoRemIsNull() {
            addCriterion("num_monto_rem is null");
            return this;
        }

        public Criteria andNumMontoRemIsNotNull() {
            addCriterion("num_monto_rem is not null");
            return this;
        }

        public Criteria andNumMontoRemEqualTo(BigDecimal value) {
            addCriterion("num_monto_rem =", value, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemNotEqualTo(BigDecimal value) {
            addCriterion("num_monto_rem <>", value, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemGreaterThan(BigDecimal value) {
            addCriterion("num_monto_rem >", value, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("num_monto_rem >=", value, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemLessThan(BigDecimal value) {
            addCriterion("num_monto_rem <", value, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemLessThanOrEqualTo(BigDecimal value) {
            addCriterion("num_monto_rem <=", value, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemIn(List<BigDecimal> values) {
            addCriterion("num_monto_rem in", values, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemNotIn(List<BigDecimal> values) {
            addCriterion("num_monto_rem not in", values, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_monto_rem between", value1, value2, "numMontoRem");
            return this;
        }

        public Criteria andNumMontoRemNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_monto_rem not between", value1, value2, "numMontoRem");
            return this;
        }

        public Criteria andCodSituIsNull() {
            addCriterion("cod_situ is null");
            return this;
        }

        public Criteria andCodSituIsNotNull() {
            addCriterion("cod_situ is not null");
            return this;
        }

        public Criteria andCodSituEqualTo(String value) {
            addCriterion("cod_situ =", value, "codSitu");
            return this;
        }

        public Criteria andCodSituNotEqualTo(String value) {
            addCriterion("cod_situ <>", value, "codSitu");
            return this;
        }

        public Criteria andCodSituGreaterThan(String value) {
            addCriterion("cod_situ >", value, "codSitu");
            return this;
        }

        public Criteria andCodSituGreaterThanOrEqualTo(String value) {
            addCriterion("cod_situ >=", value, "codSitu");
            return this;
        }

        public Criteria andCodSituLessThan(String value) {
            addCriterion("cod_situ <", value, "codSitu");
            return this;
        }

        public Criteria andCodSituLessThanOrEqualTo(String value) {
            addCriterion("cod_situ <=", value, "codSitu");
            return this;
        }

        public Criteria andCodSituLike(String value) {
            addCriterion("cod_situ like", value, "codSitu");
            return this;
        }

        public Criteria andCodSituNotLike(String value) {
            addCriterion("cod_situ not like", value, "codSitu");
            return this;
        }

        public Criteria andCodSituIn(List<String> values) {
            addCriterion("cod_situ in", values, "codSitu");
            return this;
        }

        public Criteria andCodSituNotIn(List<String> values) {
            addCriterion("cod_situ not in", values, "codSitu");
            return this;
        }

        public Criteria andCodSituBetween(String value1, String value2) {
            addCriterion("cod_situ between", value1, value2, "codSitu");
            return this;
        }

        public Criteria andCodSituNotBetween(String value1, String value2) {
            addCriterion("cod_situ not between", value1, value2, "codSitu");
            return this;
        }

        public Criteria andIndRentQuintaIsNull() {
            addCriterion("ind_rent_quinta is null");
            return this;
        }

        public Criteria andIndRentQuintaIsNotNull() {
            addCriterion("ind_rent_quinta is not null");
            return this;
        }

        public Criteria andIndRentQuintaEqualTo(String value) {
            addCriterion("ind_rent_quinta =", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaNotEqualTo(String value) {
            addCriterion("ind_rent_quinta <>", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaGreaterThan(String value) {
            addCriterion("ind_rent_quinta >", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_rent_quinta >=", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaLessThan(String value) {
            addCriterion("ind_rent_quinta <", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaLessThanOrEqualTo(String value) {
            addCriterion("ind_rent_quinta <=", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaLike(String value) {
            addCriterion("ind_rent_quinta like", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaNotLike(String value) {
            addCriterion("ind_rent_quinta not like", value, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaIn(List<String> values) {
            addCriterion("ind_rent_quinta in", values, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaNotIn(List<String> values) {
            addCriterion("ind_rent_quinta not in", values, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaBetween(String value1, String value2) {
            addCriterion("ind_rent_quinta between", value1, value2, "indRentQuinta");
            return this;
        }

        public Criteria andIndRentQuintaNotBetween(String value1, String value2) {
            addCriterion("ind_rent_quinta not between", value1, value2, "indRentQuinta");
            return this;
        }

        public Criteria andIndSituEspTraIsNull() {
            addCriterion("ind_situ_esp_tra is null");
            return this;
        }

        public Criteria andIndSituEspTraIsNotNull() {
            addCriterion("ind_situ_esp_tra is not null");
            return this;
        }

        public Criteria andIndSituEspTraEqualTo(String value) {
            addCriterion("ind_situ_esp_tra =", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraNotEqualTo(String value) {
            addCriterion("ind_situ_esp_tra <>", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraGreaterThan(String value) {
            addCriterion("ind_situ_esp_tra >", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraGreaterThanOrEqualTo(String value) {
            addCriterion("ind_situ_esp_tra >=", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraLessThan(String value) {
            addCriterion("ind_situ_esp_tra <", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraLessThanOrEqualTo(String value) {
            addCriterion("ind_situ_esp_tra <=", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraLike(String value) {
            addCriterion("ind_situ_esp_tra like", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraNotLike(String value) {
            addCriterion("ind_situ_esp_tra not like", value, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraIn(List<String> values) {
            addCriterion("ind_situ_esp_tra in", values, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraNotIn(List<String> values) {
            addCriterion("ind_situ_esp_tra not in", values, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraBetween(String value1, String value2) {
            addCriterion("ind_situ_esp_tra between", value1, value2, "indSituEspTra");
            return this;
        }

        public Criteria andIndSituEspTraNotBetween(String value1, String value2) {
            addCriterion("ind_situ_esp_tra not between", value1, value2, "indSituEspTra");
            return this;
        }

        public Criteria andIndTipPagoIsNull() {
            addCriterion("ind_tip_pago is null");
            return this;
        }

        public Criteria andIndTipPagoIsNotNull() {
            addCriterion("ind_tip_pago is not null");
            return this;
        }

        public Criteria andIndTipPagoEqualTo(String value) {
            addCriterion("ind_tip_pago =", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoNotEqualTo(String value) {
            addCriterion("ind_tip_pago <>", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoGreaterThan(String value) {
            addCriterion("ind_tip_pago >", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_tip_pago >=", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoLessThan(String value) {
            addCriterion("ind_tip_pago <", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoLessThanOrEqualTo(String value) {
            addCriterion("ind_tip_pago <=", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoLike(String value) {
            addCriterion("ind_tip_pago like", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoNotLike(String value) {
            addCriterion("ind_tip_pago not like", value, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoIn(List<String> values) {
            addCriterion("ind_tip_pago in", values, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoNotIn(List<String> values) {
            addCriterion("ind_tip_pago not in", values, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoBetween(String value1, String value2) {
            addCriterion("ind_tip_pago between", value1, value2, "indTipPago");
            return this;
        }

        public Criteria andIndTipPagoNotBetween(String value1, String value2) {
            addCriterion("ind_tip_pago not between", value1, value2, "indTipPago");
            return this;
        }

        public Criteria andCodCatOcupIsNull() {
            addCriterion("cod_cat_ocup is null");
            return this;
        }

        public Criteria andCodCatOcupIsNotNull() {
            addCriterion("cod_cat_ocup is not null");
            return this;
        }

        public Criteria andCodCatOcupEqualTo(String value) {
            addCriterion("cod_cat_ocup =", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupNotEqualTo(String value) {
            addCriterion("cod_cat_ocup <>", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupGreaterThan(String value) {
            addCriterion("cod_cat_ocup >", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupGreaterThanOrEqualTo(String value) {
            addCriterion("cod_cat_ocup >=", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupLessThan(String value) {
            addCriterion("cod_cat_ocup <", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupLessThanOrEqualTo(String value) {
            addCriterion("cod_cat_ocup <=", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupLike(String value) {
            addCriterion("cod_cat_ocup like", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupNotLike(String value) {
            addCriterion("cod_cat_ocup not like", value, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupIn(List<String> values) {
            addCriterion("cod_cat_ocup in", values, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupNotIn(List<String> values) {
            addCriterion("cod_cat_ocup not in", values, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupBetween(String value1, String value2) {
            addCriterion("cod_cat_ocup between", value1, value2, "codCatOcup");
            return this;
        }

        public Criteria andCodCatOcupNotBetween(String value1, String value2) {
            addCriterion("cod_cat_ocup not between", value1, value2, "codCatOcup");
            return this;
        }

        public Criteria andIndConvIsNull() {
            addCriterion("ind_conv is null");
            return this;
        }

        public Criteria andIndConvIsNotNull() {
            addCriterion("ind_conv is not null");
            return this;
        }

        public Criteria andIndConvEqualTo(String value) {
            addCriterion("ind_conv =", value, "indConv");
            return this;
        }

        public Criteria andIndConvNotEqualTo(String value) {
            addCriterion("ind_conv <>", value, "indConv");
            return this;
        }

        public Criteria andIndConvGreaterThan(String value) {
            addCriterion("ind_conv >", value, "indConv");
            return this;
        }

        public Criteria andIndConvGreaterThanOrEqualTo(String value) {
            addCriterion("ind_conv >=", value, "indConv");
            return this;
        }

        public Criteria andIndConvLessThan(String value) {
            addCriterion("ind_conv <", value, "indConv");
            return this;
        }

        public Criteria andIndConvLessThanOrEqualTo(String value) {
            addCriterion("ind_conv <=", value, "indConv");
            return this;
        }

        public Criteria andIndConvLike(String value) {
            addCriterion("ind_conv like", value, "indConv");
            return this;
        }

        public Criteria andIndConvNotLike(String value) {
            addCriterion("ind_conv not like", value, "indConv");
            return this;
        }

        public Criteria andIndConvIn(List<String> values) {
            addCriterion("ind_conv in", values, "indConv");
            return this;
        }

        public Criteria andIndConvNotIn(List<String> values) {
            addCriterion("ind_conv not in", values, "indConv");
            return this;
        }

        public Criteria andIndConvBetween(String value1, String value2) {
            addCriterion("ind_conv between", value1, value2, "indConv");
            return this;
        }

        public Criteria andIndConvNotBetween(String value1, String value2) {
            addCriterion("ind_conv not between", value1, value2, "indConv");
            return this;
        }

        public Criteria andNumRucIsNull() {
            addCriterion("num_ruc is null");
            return this;
        }

        public Criteria andNumRucIsNotNull() {
            addCriterion("num_ruc is not null");
            return this;
        }

        public Criteria andNumRucEqualTo(String value) {
            addCriterion("num_ruc =", value, "numRuc");
            return this;
        }

        public Criteria andNumRucNotEqualTo(String value) {
            addCriterion("num_ruc <>", value, "numRuc");
            return this;
        }

        public Criteria andNumRucGreaterThan(String value) {
            addCriterion("num_ruc >", value, "numRuc");
            return this;
        }

        public Criteria andNumRucGreaterThanOrEqualTo(String value) {
            addCriterion("num_ruc >=", value, "numRuc");
            return this;
        }

        public Criteria andNumRucLessThan(String value) {
            addCriterion("num_ruc <", value, "numRuc");
            return this;
        }

        public Criteria andNumRucLessThanOrEqualTo(String value) {
            addCriterion("num_ruc <=", value, "numRuc");
            return this;
        }

        public Criteria andNumRucLike(String value) {
            addCriterion("num_ruc like", value, "numRuc");
            return this;
        }

        public Criteria andNumRucNotLike(String value) {
            addCriterion("num_ruc not like", value, "numRuc");
            return this;
        }

        public Criteria andNumRucIn(List<String> values) {
            addCriterion("num_ruc in", values, "numRuc");
            return this;
        }

        public Criteria andNumRucNotIn(List<String> values) {
            addCriterion("num_ruc not in", values, "numRuc");
            return this;
        }

        public Criteria andNumRucBetween(String value1, String value2) {
            addCriterion("num_ruc between", value1, value2, "numRuc");
            return this;
        }

        public Criteria andNumRucNotBetween(String value1, String value2) {
            addCriterion("num_ruc not between", value1, value2, "numRuc");
            return this;
        }

        public Criteria andEstProcesoIsNull() {
            addCriterion("est_proceso is null");
            return this;
        }

        public Criteria andEstProcesoIsNotNull() {
            addCriterion("est_proceso is not null");
            return this;
        }

        public Criteria andEstProcesoEqualTo(String value) {
            addCriterion("est_proceso =", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotEqualTo(String value) {
            addCriterion("est_proceso <>", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThan(String value) {
            addCriterion("est_proceso >", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThanOrEqualTo(String value) {
            addCriterion("est_proceso >=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThan(String value) {
            addCriterion("est_proceso <", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThanOrEqualTo(String value) {
            addCriterion("est_proceso <=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLike(String value) {
            addCriterion("est_proceso like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotLike(String value) {
            addCriterion("est_proceso not like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoIn(List<String> values) {
            addCriterion("est_proceso in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotIn(List<String> values) {
            addCriterion("est_proceso not in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoBetween(String value1, String value2) {
            addCriterion("est_proceso between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotBetween(String value1, String value2) {
            addCriterion("est_proceso not between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andAccCreacionIsNull() {
            addCriterion("acc_creacion is null");
            return this;
        }

        public Criteria andAccCreacionIsNotNull() {
            addCriterion("acc_creacion is not null");
            return this;
        }

        public Criteria andAccCreacionEqualTo(String value) {
            addCriterion("acc_creacion =", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotEqualTo(String value) {
            addCriterion("acc_creacion <>", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThan(String value) {
            addCriterion("acc_creacion >", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThanOrEqualTo(String value) {
            addCriterion("acc_creacion >=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThan(String value) {
            addCriterion("acc_creacion <", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThanOrEqualTo(String value) {
            addCriterion("acc_creacion <=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLike(String value) {
            addCriterion("acc_creacion like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotLike(String value) {
            addCriterion("acc_creacion not like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionIn(List<String> values) {
            addCriterion("acc_creacion in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotIn(List<String> values) {
            addCriterion("acc_creacion not in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionBetween(String value1, String value2) {
            addCriterion("acc_creacion between", value1, value2, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotBetween(String value1, String value2) {
            addCriterion("acc_creacion not between", value1, value2, "accCreacion");
            return this;
        }
    }
}