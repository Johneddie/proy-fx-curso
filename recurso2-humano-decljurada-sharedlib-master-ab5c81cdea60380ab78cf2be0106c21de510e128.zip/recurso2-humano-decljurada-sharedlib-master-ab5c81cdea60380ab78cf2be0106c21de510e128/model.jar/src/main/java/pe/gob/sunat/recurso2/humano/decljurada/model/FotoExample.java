package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FotoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public FotoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected FotoExample(FotoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andT02codPersIsNull() {
            addCriterion("t02cod_pers is null");
            return this;
        }

        public Criteria andT02codPersIsNotNull() {
            addCriterion("t02cod_pers is not null");
            return this;
        }

        public Criteria andT02codPersEqualTo(String value) {
            addCriterion("t02cod_pers =", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotEqualTo(String value) {
            addCriterion("t02cod_pers <>", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersGreaterThan(String value) {
            addCriterion("t02cod_pers >", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_pers >=", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersLessThan(String value) {
            addCriterion("t02cod_pers <", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersLessThanOrEqualTo(String value) {
            addCriterion("t02cod_pers <=", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersLike(String value) {
            addCriterion("t02cod_pers like", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotLike(String value) {
            addCriterion("t02cod_pers not like", value, "t02codPers");
            return this;
        }

        public Criteria andT02codPersIn(List<String> values) {
            addCriterion("t02cod_pers in", values, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotIn(List<String> values) {
            addCriterion("t02cod_pers not in", values, "t02codPers");
            return this;
        }

        public Criteria andT02codPersBetween(String value1, String value2) {
            addCriterion("t02cod_pers between", value1, value2, "t02codPers");
            return this;
        }

        public Criteria andT02codPersNotBetween(String value1, String value2) {
            addCriterion("t02cod_pers not between", value1, value2, "t02codPers");
            return this;
        }

        public Criteria andT02fGrabaIsNull() {
            addCriterion("t02f_graba is null");
            return this;
        }

        public Criteria andT02fGrabaIsNotNull() {
            addCriterion("t02f_graba is not null");
            return this;
        }

        public Criteria andT02fGrabaEqualTo(Date value) {
            addCriterion("t02f_graba =", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaNotEqualTo(Date value) {
            addCriterion("t02f_graba <>", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaGreaterThan(Date value) {
            addCriterion("t02f_graba >", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t02f_graba >=", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaLessThan(Date value) {
            addCriterion("t02f_graba <", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t02f_graba <=", value, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaIn(List<Date> values) {
            addCriterion("t02f_graba in", values, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaNotIn(List<Date> values) {
            addCriterion("t02f_graba not in", values, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaBetween(Date value1, Date value2) {
            addCriterion("t02f_graba between", value1, value2, "t02fGraba");
            return this;
        }

        public Criteria andT02fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t02f_graba not between", value1, value2, "t02fGraba");
            return this;
        }

        public Criteria andT02codUserIsNull() {
            addCriterion("t02cod_user is null");
            return this;
        }

        public Criteria andT02codUserIsNotNull() {
            addCriterion("t02cod_user is not null");
            return this;
        }

        public Criteria andT02codUserEqualTo(String value) {
            addCriterion("t02cod_user =", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotEqualTo(String value) {
            addCriterion("t02cod_user <>", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserGreaterThan(String value) {
            addCriterion("t02cod_user >", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t02cod_user >=", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserLessThan(String value) {
            addCriterion("t02cod_user <", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserLessThanOrEqualTo(String value) {
            addCriterion("t02cod_user <=", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserLike(String value) {
            addCriterion("t02cod_user like", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotLike(String value) {
            addCriterion("t02cod_user not like", value, "t02codUser");
            return this;
        }

        public Criteria andT02codUserIn(List<String> values) {
            addCriterion("t02cod_user in", values, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotIn(List<String> values) {
            addCriterion("t02cod_user not in", values, "t02codUser");
            return this;
        }

        public Criteria andT02codUserBetween(String value1, String value2) {
            addCriterion("t02cod_user between", value1, value2, "t02codUser");
            return this;
        }

        public Criteria andT02codUserNotBetween(String value1, String value2) {
            addCriterion("t02cod_user not between", value1, value2, "t02codUser");
            return this;
        }
    }
}