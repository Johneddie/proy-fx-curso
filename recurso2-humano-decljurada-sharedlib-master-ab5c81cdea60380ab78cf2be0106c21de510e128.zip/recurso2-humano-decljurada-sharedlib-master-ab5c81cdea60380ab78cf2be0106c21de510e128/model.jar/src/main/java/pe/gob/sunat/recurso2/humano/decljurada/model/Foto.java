package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Foto {
    private String t02codPers;

    private Date t02fGraba;

    private String t02codUser;

    private byte[] t02foto;

    public String getT02codPers() {
        return t02codPers;
    }

    public void setT02codPers(String t02codPers) {
        this.t02codPers = t02codPers == null ? null : t02codPers.trim();
    }

    public Date getT02fGraba() {
        return t02fGraba;
    }

    public void setT02fGraba(Date t02fGraba) {
        this.t02fGraba = t02fGraba;
    }

    public String getT02codUser() {
        return t02codUser;
    }

    public void setT02codUser(String t02codUser) {
        this.t02codUser = t02codUser == null ? null : t02codUser.trim();
    }

    public byte[] getT02foto() {
        return t02foto;
    }

    public void setT02foto(byte[] t02foto) {
        this.t02foto = t02foto;
    }
}