package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocalRtpsExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public LocalRtpsExample() {
        oredCriteria = new ArrayList<>();
    }

    protected LocalRtpsExample(LocalRtpsExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andSprCorrelIsNull() {
            addCriterion("spr_correl is null");
            return this;
        }

        public Criteria andSprCorrelIsNotNull() {
            addCriterion("spr_correl is not null");
            return this;
        }

        public Criteria andSprCorrelEqualTo(Short value) {
            addCriterion("spr_correl =", value, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelNotEqualTo(Short value) {
            addCriterion("spr_correl <>", value, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelGreaterThan(Short value) {
            addCriterion("spr_correl >", value, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelGreaterThanOrEqualTo(Short value) {
            addCriterion("spr_correl >=", value, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelLessThan(Short value) {
            addCriterion("spr_correl <", value, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelLessThanOrEqualTo(Short value) {
            addCriterion("spr_correl <=", value, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelIn(List<Short> values) {
            addCriterion("spr_correl in", values, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelNotIn(List<Short> values) {
            addCriterion("spr_correl not in", values, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelBetween(Short value1, Short value2) {
            addCriterion("spr_correl between", value1, value2, "sprCorrel");
            return this;
        }

        public Criteria andSprCorrelNotBetween(Short value1, Short value2) {
            addCriterion("spr_correl not between", value1, value2, "sprCorrel");
            return this;
        }

        public Criteria andSprNumrucIsNull() {
            addCriterion("spr_numruc is null");
            return this;
        }

        public Criteria andSprNumrucIsNotNull() {
            addCriterion("spr_numruc is not null");
            return this;
        }

        public Criteria andSprNumrucEqualTo(String value) {
            addCriterion("spr_numruc =", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucNotEqualTo(String value) {
            addCriterion("spr_numruc <>", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucGreaterThan(String value) {
            addCriterion("spr_numruc >", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucGreaterThanOrEqualTo(String value) {
            addCriterion("spr_numruc >=", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucLessThan(String value) {
            addCriterion("spr_numruc <", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucLessThanOrEqualTo(String value) {
            addCriterion("spr_numruc <=", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucLike(String value) {
            addCriterion("spr_numruc like", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucNotLike(String value) {
            addCriterion("spr_numruc not like", value, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucIn(List<String> values) {
            addCriterion("spr_numruc in", values, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucNotIn(List<String> values) {
            addCriterion("spr_numruc not in", values, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucBetween(String value1, String value2) {
            addCriterion("spr_numruc between", value1, value2, "sprNumruc");
            return this;
        }

        public Criteria andSprNumrucNotBetween(String value1, String value2) {
            addCriterion("spr_numruc not between", value1, value2, "sprNumruc");
            return this;
        }

        public Criteria andSprUbigeoIsNull() {
            addCriterion("spr_ubigeo is null");
            return this;
        }

        public Criteria andSprUbigeoIsNotNull() {
            addCriterion("spr_ubigeo is not null");
            return this;
        }

        public Criteria andSprUbigeoEqualTo(String value) {
            addCriterion("spr_ubigeo =", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoNotEqualTo(String value) {
            addCriterion("spr_ubigeo <>", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoGreaterThan(String value) {
            addCriterion("spr_ubigeo >", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoGreaterThanOrEqualTo(String value) {
            addCriterion("spr_ubigeo >=", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoLessThan(String value) {
            addCriterion("spr_ubigeo <", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoLessThanOrEqualTo(String value) {
            addCriterion("spr_ubigeo <=", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoLike(String value) {
            addCriterion("spr_ubigeo like", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoNotLike(String value) {
            addCriterion("spr_ubigeo not like", value, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoIn(List<String> values) {
            addCriterion("spr_ubigeo in", values, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoNotIn(List<String> values) {
            addCriterion("spr_ubigeo not in", values, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoBetween(String value1, String value2) {
            addCriterion("spr_ubigeo between", value1, value2, "sprUbigeo");
            return this;
        }

        public Criteria andSprUbigeoNotBetween(String value1, String value2) {
            addCriterion("spr_ubigeo not between", value1, value2, "sprUbigeo");
            return this;
        }

        public Criteria andSprNomviaIsNull() {
            addCriterion("spr_nomvia is null");
            return this;
        }

        public Criteria andSprNomviaIsNotNull() {
            addCriterion("spr_nomvia is not null");
            return this;
        }

        public Criteria andSprNomviaEqualTo(String value) {
            addCriterion("spr_nomvia =", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaNotEqualTo(String value) {
            addCriterion("spr_nomvia <>", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaGreaterThan(String value) {
            addCriterion("spr_nomvia >", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaGreaterThanOrEqualTo(String value) {
            addCriterion("spr_nomvia >=", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaLessThan(String value) {
            addCriterion("spr_nomvia <", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaLessThanOrEqualTo(String value) {
            addCriterion("spr_nomvia <=", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaLike(String value) {
            addCriterion("spr_nomvia like", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaNotLike(String value) {
            addCriterion("spr_nomvia not like", value, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaIn(List<String> values) {
            addCriterion("spr_nomvia in", values, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaNotIn(List<String> values) {
            addCriterion("spr_nomvia not in", values, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaBetween(String value1, String value2) {
            addCriterion("spr_nomvia between", value1, value2, "sprNomvia");
            return this;
        }

        public Criteria andSprNomviaNotBetween(String value1, String value2) {
            addCriterion("spr_nomvia not between", value1, value2, "sprNomvia");
            return this;
        }

        public Criteria andSprNumer1IsNull() {
            addCriterion("spr_numer1 is null");
            return this;
        }

        public Criteria andSprNumer1IsNotNull() {
            addCriterion("spr_numer1 is not null");
            return this;
        }

        public Criteria andSprNumer1EqualTo(String value) {
            addCriterion("spr_numer1 =", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1NotEqualTo(String value) {
            addCriterion("spr_numer1 <>", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1GreaterThan(String value) {
            addCriterion("spr_numer1 >", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1GreaterThanOrEqualTo(String value) {
            addCriterion("spr_numer1 >=", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1LessThan(String value) {
            addCriterion("spr_numer1 <", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1LessThanOrEqualTo(String value) {
            addCriterion("spr_numer1 <=", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1Like(String value) {
            addCriterion("spr_numer1 like", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1NotLike(String value) {
            addCriterion("spr_numer1 not like", value, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1In(List<String> values) {
            addCriterion("spr_numer1 in", values, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1NotIn(List<String> values) {
            addCriterion("spr_numer1 not in", values, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1Between(String value1, String value2) {
            addCriterion("spr_numer1 between", value1, value2, "sprNumer1");
            return this;
        }

        public Criteria andSprNumer1NotBetween(String value1, String value2) {
            addCriterion("spr_numer1 not between", value1, value2, "sprNumer1");
            return this;
        }

        public Criteria andSprInter1IsNull() {
            addCriterion("spr_inter1 is null");
            return this;
        }

        public Criteria andSprInter1IsNotNull() {
            addCriterion("spr_inter1 is not null");
            return this;
        }

        public Criteria andSprInter1EqualTo(String value) {
            addCriterion("spr_inter1 =", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1NotEqualTo(String value) {
            addCriterion("spr_inter1 <>", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1GreaterThan(String value) {
            addCriterion("spr_inter1 >", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1GreaterThanOrEqualTo(String value) {
            addCriterion("spr_inter1 >=", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1LessThan(String value) {
            addCriterion("spr_inter1 <", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1LessThanOrEqualTo(String value) {
            addCriterion("spr_inter1 <=", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1Like(String value) {
            addCriterion("spr_inter1 like", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1NotLike(String value) {
            addCriterion("spr_inter1 not like", value, "sprInter1");
            return this;
        }

        public Criteria andSprInter1In(List<String> values) {
            addCriterion("spr_inter1 in", values, "sprInter1");
            return this;
        }

        public Criteria andSprInter1NotIn(List<String> values) {
            addCriterion("spr_inter1 not in", values, "sprInter1");
            return this;
        }

        public Criteria andSprInter1Between(String value1, String value2) {
            addCriterion("spr_inter1 between", value1, value2, "sprInter1");
            return this;
        }

        public Criteria andSprInter1NotBetween(String value1, String value2) {
            addCriterion("spr_inter1 not between", value1, value2, "sprInter1");
            return this;
        }

        public Criteria andSprNomzonIsNull() {
            addCriterion("spr_nomzon is null");
            return this;
        }

        public Criteria andSprNomzonIsNotNull() {
            addCriterion("spr_nomzon is not null");
            return this;
        }

        public Criteria andSprNomzonEqualTo(String value) {
            addCriterion("spr_nomzon =", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonNotEqualTo(String value) {
            addCriterion("spr_nomzon <>", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonGreaterThan(String value) {
            addCriterion("spr_nomzon >", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonGreaterThanOrEqualTo(String value) {
            addCriterion("spr_nomzon >=", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonLessThan(String value) {
            addCriterion("spr_nomzon <", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonLessThanOrEqualTo(String value) {
            addCriterion("spr_nomzon <=", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonLike(String value) {
            addCriterion("spr_nomzon like", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonNotLike(String value) {
            addCriterion("spr_nomzon not like", value, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonIn(List<String> values) {
            addCriterion("spr_nomzon in", values, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonNotIn(List<String> values) {
            addCriterion("spr_nomzon not in", values, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonBetween(String value1, String value2) {
            addCriterion("spr_nomzon between", value1, value2, "sprNomzon");
            return this;
        }

        public Criteria andSprNomzonNotBetween(String value1, String value2) {
            addCriterion("spr_nomzon not between", value1, value2, "sprNomzon");
            return this;
        }

        public Criteria andSprRefer1IsNull() {
            addCriterion("spr_refer1 is null");
            return this;
        }

        public Criteria andSprRefer1IsNotNull() {
            addCriterion("spr_refer1 is not null");
            return this;
        }

        public Criteria andSprRefer1EqualTo(String value) {
            addCriterion("spr_refer1 =", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1NotEqualTo(String value) {
            addCriterion("spr_refer1 <>", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1GreaterThan(String value) {
            addCriterion("spr_refer1 >", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1GreaterThanOrEqualTo(String value) {
            addCriterion("spr_refer1 >=", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1LessThan(String value) {
            addCriterion("spr_refer1 <", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1LessThanOrEqualTo(String value) {
            addCriterion("spr_refer1 <=", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1Like(String value) {
            addCriterion("spr_refer1 like", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1NotLike(String value) {
            addCriterion("spr_refer1 not like", value, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1In(List<String> values) {
            addCriterion("spr_refer1 in", values, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1NotIn(List<String> values) {
            addCriterion("spr_refer1 not in", values, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1Between(String value1, String value2) {
            addCriterion("spr_refer1 between", value1, value2, "sprRefer1");
            return this;
        }

        public Criteria andSprRefer1NotBetween(String value1, String value2) {
            addCriterion("spr_refer1 not between", value1, value2, "sprRefer1");
            return this;
        }

        public Criteria andSprNombreIsNull() {
            addCriterion("spr_nombre is null");
            return this;
        }

        public Criteria andSprNombreIsNotNull() {
            addCriterion("spr_nombre is not null");
            return this;
        }

        public Criteria andSprNombreEqualTo(String value) {
            addCriterion("spr_nombre =", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreNotEqualTo(String value) {
            addCriterion("spr_nombre <>", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreGreaterThan(String value) {
            addCriterion("spr_nombre >", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreGreaterThanOrEqualTo(String value) {
            addCriterion("spr_nombre >=", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreLessThan(String value) {
            addCriterion("spr_nombre <", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreLessThanOrEqualTo(String value) {
            addCriterion("spr_nombre <=", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreLike(String value) {
            addCriterion("spr_nombre like", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreNotLike(String value) {
            addCriterion("spr_nombre not like", value, "sprNombre");
            return this;
        }

        public Criteria andSprNombreIn(List<String> values) {
            addCriterion("spr_nombre in", values, "sprNombre");
            return this;
        }

        public Criteria andSprNombreNotIn(List<String> values) {
            addCriterion("spr_nombre not in", values, "sprNombre");
            return this;
        }

        public Criteria andSprNombreBetween(String value1, String value2) {
            addCriterion("spr_nombre between", value1, value2, "sprNombre");
            return this;
        }

        public Criteria andSprNombreNotBetween(String value1, String value2) {
            addCriterion("spr_nombre not between", value1, value2, "sprNombre");
            return this;
        }

        public Criteria andSprTipestIsNull() {
            addCriterion("spr_tipest is null");
            return this;
        }

        public Criteria andSprTipestIsNotNull() {
            addCriterion("spr_tipest is not null");
            return this;
        }

        public Criteria andSprTipestEqualTo(String value) {
            addCriterion("spr_tipest =", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestNotEqualTo(String value) {
            addCriterion("spr_tipest <>", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestGreaterThan(String value) {
            addCriterion("spr_tipest >", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestGreaterThanOrEqualTo(String value) {
            addCriterion("spr_tipest >=", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestLessThan(String value) {
            addCriterion("spr_tipest <", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestLessThanOrEqualTo(String value) {
            addCriterion("spr_tipest <=", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestLike(String value) {
            addCriterion("spr_tipest like", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestNotLike(String value) {
            addCriterion("spr_tipest not like", value, "sprTipest");
            return this;
        }

        public Criteria andSprTipestIn(List<String> values) {
            addCriterion("spr_tipest in", values, "sprTipest");
            return this;
        }

        public Criteria andSprTipestNotIn(List<String> values) {
            addCriterion("spr_tipest not in", values, "sprTipest");
            return this;
        }

        public Criteria andSprTipestBetween(String value1, String value2) {
            addCriterion("spr_tipest between", value1, value2, "sprTipest");
            return this;
        }

        public Criteria andSprTipestNotBetween(String value1, String value2) {
            addCriterion("spr_tipest not between", value1, value2, "sprTipest");
            return this;
        }

        public Criteria andSprLicencIsNull() {
            addCriterion("spr_licenc is null");
            return this;
        }

        public Criteria andSprLicencIsNotNull() {
            addCriterion("spr_licenc is not null");
            return this;
        }

        public Criteria andSprLicencEqualTo(String value) {
            addCriterion("spr_licenc =", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencNotEqualTo(String value) {
            addCriterion("spr_licenc <>", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencGreaterThan(String value) {
            addCriterion("spr_licenc >", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencGreaterThanOrEqualTo(String value) {
            addCriterion("spr_licenc >=", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencLessThan(String value) {
            addCriterion("spr_licenc <", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencLessThanOrEqualTo(String value) {
            addCriterion("spr_licenc <=", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencLike(String value) {
            addCriterion("spr_licenc like", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencNotLike(String value) {
            addCriterion("spr_licenc not like", value, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencIn(List<String> values) {
            addCriterion("spr_licenc in", values, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencNotIn(List<String> values) {
            addCriterion("spr_licenc not in", values, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencBetween(String value1, String value2) {
            addCriterion("spr_licenc between", value1, value2, "sprLicenc");
            return this;
        }

        public Criteria andSprLicencNotBetween(String value1, String value2) {
            addCriterion("spr_licenc not between", value1, value2, "sprLicenc");
            return this;
        }

        public Criteria andSprTipviaIsNull() {
            addCriterion("spr_tipvia is null");
            return this;
        }

        public Criteria andSprTipviaIsNotNull() {
            addCriterion("spr_tipvia is not null");
            return this;
        }

        public Criteria andSprTipviaEqualTo(String value) {
            addCriterion("spr_tipvia =", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaNotEqualTo(String value) {
            addCriterion("spr_tipvia <>", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaGreaterThan(String value) {
            addCriterion("spr_tipvia >", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaGreaterThanOrEqualTo(String value) {
            addCriterion("spr_tipvia >=", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaLessThan(String value) {
            addCriterion("spr_tipvia <", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaLessThanOrEqualTo(String value) {
            addCriterion("spr_tipvia <=", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaLike(String value) {
            addCriterion("spr_tipvia like", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaNotLike(String value) {
            addCriterion("spr_tipvia not like", value, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaIn(List<String> values) {
            addCriterion("spr_tipvia in", values, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaNotIn(List<String> values) {
            addCriterion("spr_tipvia not in", values, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaBetween(String value1, String value2) {
            addCriterion("spr_tipvia between", value1, value2, "sprTipvia");
            return this;
        }

        public Criteria andSprTipviaNotBetween(String value1, String value2) {
            addCriterion("spr_tipvia not between", value1, value2, "sprTipvia");
            return this;
        }

        public Criteria andSprTipzonIsNull() {
            addCriterion("spr_tipzon is null");
            return this;
        }

        public Criteria andSprTipzonIsNotNull() {
            addCriterion("spr_tipzon is not null");
            return this;
        }

        public Criteria andSprTipzonEqualTo(String value) {
            addCriterion("spr_tipzon =", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonNotEqualTo(String value) {
            addCriterion("spr_tipzon <>", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonGreaterThan(String value) {
            addCriterion("spr_tipzon >", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonGreaterThanOrEqualTo(String value) {
            addCriterion("spr_tipzon >=", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonLessThan(String value) {
            addCriterion("spr_tipzon <", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonLessThanOrEqualTo(String value) {
            addCriterion("spr_tipzon <=", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonLike(String value) {
            addCriterion("spr_tipzon like", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonNotLike(String value) {
            addCriterion("spr_tipzon not like", value, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonIn(List<String> values) {
            addCriterion("spr_tipzon in", values, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonNotIn(List<String> values) {
            addCriterion("spr_tipzon not in", values, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonBetween(String value1, String value2) {
            addCriterion("spr_tipzon between", value1, value2, "sprTipzon");
            return this;
        }

        public Criteria andSprTipzonNotBetween(String value1, String value2) {
            addCriterion("spr_tipzon not between", value1, value2, "sprTipzon");
            return this;
        }

        public Criteria andSprIndmaqIsNull() {
            addCriterion("spr_indmaq is null");
            return this;
        }

        public Criteria andSprIndmaqIsNotNull() {
            addCriterion("spr_indmaq is not null");
            return this;
        }

        public Criteria andSprIndmaqEqualTo(String value) {
            addCriterion("spr_indmaq =", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqNotEqualTo(String value) {
            addCriterion("spr_indmaq <>", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqGreaterThan(String value) {
            addCriterion("spr_indmaq >", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqGreaterThanOrEqualTo(String value) {
            addCriterion("spr_indmaq >=", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqLessThan(String value) {
            addCriterion("spr_indmaq <", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqLessThanOrEqualTo(String value) {
            addCriterion("spr_indmaq <=", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqLike(String value) {
            addCriterion("spr_indmaq like", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqNotLike(String value) {
            addCriterion("spr_indmaq not like", value, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqIn(List<String> values) {
            addCriterion("spr_indmaq in", values, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqNotIn(List<String> values) {
            addCriterion("spr_indmaq not in", values, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqBetween(String value1, String value2) {
            addCriterion("spr_indmaq between", value1, value2, "sprIndmaq");
            return this;
        }

        public Criteria andSprIndmaqNotBetween(String value1, String value2) {
            addCriterion("spr_indmaq not between", value1, value2, "sprIndmaq");
            return this;
        }

        public Criteria andSprUsernaIsNull() {
            addCriterion("spr_userna is null");
            return this;
        }

        public Criteria andSprUsernaIsNotNull() {
            addCriterion("spr_userna is not null");
            return this;
        }

        public Criteria andSprUsernaEqualTo(String value) {
            addCriterion("spr_userna =", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaNotEqualTo(String value) {
            addCriterion("spr_userna <>", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaGreaterThan(String value) {
            addCriterion("spr_userna >", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaGreaterThanOrEqualTo(String value) {
            addCriterion("spr_userna >=", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaLessThan(String value) {
            addCriterion("spr_userna <", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaLessThanOrEqualTo(String value) {
            addCriterion("spr_userna <=", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaLike(String value) {
            addCriterion("spr_userna like", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaNotLike(String value) {
            addCriterion("spr_userna not like", value, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaIn(List<String> values) {
            addCriterion("spr_userna in", values, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaNotIn(List<String> values) {
            addCriterion("spr_userna not in", values, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaBetween(String value1, String value2) {
            addCriterion("spr_userna between", value1, value2, "sprUserna");
            return this;
        }

        public Criteria andSprUsernaNotBetween(String value1, String value2) {
            addCriterion("spr_userna not between", value1, value2, "sprUserna");
            return this;
        }

        public Criteria andSprFecactIsNull() {
            addCriterion("spr_fecact is null");
            return this;
        }

        public Criteria andSprFecactIsNotNull() {
            addCriterion("spr_fecact is not null");
            return this;
        }

        public Criteria andSprFecactEqualTo(Date value) {
            addCriterion("spr_fecact =", value, "sprFecact");
            return this;
        }

        public Criteria andSprFecactNotEqualTo(Date value) {
            addCriterion("spr_fecact <>", value, "sprFecact");
            return this;
        }

        public Criteria andSprFecactGreaterThan(Date value) {
            addCriterion("spr_fecact >", value, "sprFecact");
            return this;
        }

        public Criteria andSprFecactGreaterThanOrEqualTo(Date value) {
            addCriterion("spr_fecact >=", value, "sprFecact");
            return this;
        }

        public Criteria andSprFecactLessThan(Date value) {
            addCriterion("spr_fecact <", value, "sprFecact");
            return this;
        }

        public Criteria andSprFecactLessThanOrEqualTo(Date value) {
            addCriterion("spr_fecact <=", value, "sprFecact");
            return this;
        }

        public Criteria andSprFecactIn(List<Date> values) {
            addCriterion("spr_fecact in", values, "sprFecact");
            return this;
        }

        public Criteria andSprFecactNotIn(List<Date> values) {
            addCriterion("spr_fecact not in", values, "sprFecact");
            return this;
        }

        public Criteria andSprFecactBetween(Date value1, Date value2) {
            addCriterion("spr_fecact between", value1, value2, "sprFecact");
            return this;
        }

        public Criteria andSprFecactNotBetween(Date value1, Date value2) {
            addCriterion("spr_fecact not between", value1, value2, "sprFecact");
            return this;
        }
    }
}