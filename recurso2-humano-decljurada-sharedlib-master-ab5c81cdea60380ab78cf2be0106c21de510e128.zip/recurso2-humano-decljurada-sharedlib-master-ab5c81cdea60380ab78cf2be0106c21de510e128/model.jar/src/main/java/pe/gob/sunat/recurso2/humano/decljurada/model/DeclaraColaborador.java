package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DeclaraColaborador extends DeclaraColaboradorKey {
    private String codPersonal;

    private String codUorgan;

    private String codDocum;

    private String numDocum;

    private String codPaisEmiDoc;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy",timezone="GMT-5:00")
    private Date fecNacimiento;

    private String apePat;

    private String apeMat;

    private String nomPersonal;

    private String indSexo;

    private String codNacionalidad;

    private String codUbigeoNac;

    private String indEstCivil;

    private String codSedeLab;

    private String codTelefLarDis;

    private String numTelef;

    private String codCelLarDis;

    private String numCelular;

    private String desCorreo;

    private String codViaDir1;

    private String nomViaDir1;

    private String numViaDir1;

    private String numDepaDir1;

    private String numInteriorDir1;

    private String numManzDir1;

    private String numLoteDir1;

    private String numKilomDir1;

    private String numBlockDir1;

    private String numEtapaDir1;

    private String codZonaDir1;

    private String nomZonaDir1;

    private String desReferDir1;

    private String codUbigeoDir1;

    private String codViaDir2;

    private String nomViaDir2;

    private String numViaDir2;

    private String numDepaDir2;

    private String numInteriorDir2;

    private String numManzDir2;

    private String numLoteDir2;

    private String numKilomDir2;

    private String numBlockDir2;

    private String numEtapaDir2;

    private String codZonaDir2;

    private String nomZonaDir2;

    private String desReferDir2;

    private String codUbigeoDir2;

    private String indCentAsis;

    private String desCtaHaberes;

    private String numCtaHaberes;

    private String codGrupoSan;

    private String indDiscapacidad;

    private String codDiscapacidad;

    private String indDel;

    private String codUsucrea;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss",timezone="GMT-5:00")
    private Date fecCreacion;

    private String codUsumodif;

    private Date fecModif;

    private String indNivEduc;

    private String numCuspp;

    private String desDomiciDir1;

    private String desUbigeoDir1;

    private String indReniec;

    private String codPaisUbiNac;
    
    
    private List<Archivo> archivosReferDomicilio;
    
    private List<Archivo> archivosEstadoCivil;
    
    private List<Archivo> archivosDiscapacidad;
    
    private String desIndEstado;

    public String getCodPersonal() {
        return codPersonal;
    }

    public void setCodPersonal(String codPersonal) {
        this.codPersonal = codPersonal == null ? null : codPersonal.trim();
    }

    public String getCodUorgan() {
        return codUorgan;
    }

    public void setCodUorgan(String codUorgan) {
        this.codUorgan = codUorgan == null ? null : codUorgan.trim();
    }

    public String getCodDocum() {
        return codDocum;
    }

    public void setCodDocum(String codDocum) {
        this.codDocum = codDocum == null ? null : codDocum.trim();
    }

    public String getNumDocum() {
        return numDocum;
    }

    public void setNumDocum(String numDocum) {
        this.numDocum = numDocum == null ? null : numDocum.trim();
    }

    public String getCodPaisEmiDoc() {
        return codPaisEmiDoc;
    }

    public void setCodPaisEmiDoc(String codPaisEmiDoc) {
        this.codPaisEmiDoc = codPaisEmiDoc == null ? null : codPaisEmiDoc.trim();
    }

    public Date getFecNacimiento() {
        return fecNacimiento;
    }

    public void setFecNacimiento(Date fecNacimiento) {
        this.fecNacimiento = fecNacimiento;
    }

    public String getApePat() {
        return apePat;
    }

    public void setApePat(String apePat) {
        this.apePat = apePat == null ? null : apePat.trim();
    }

    public String getApeMat() {
        return apeMat;
    }

    public void setApeMat(String apeMat) {
        this.apeMat = apeMat == null ? null : apeMat.trim();
    }

    public String getNomPersonal() {
        return nomPersonal;
    }

    public void setNomPersonal(String nomPersonal) {
        this.nomPersonal = nomPersonal == null ? null : nomPersonal.trim();
    }

    public String getIndSexo() {
        return indSexo;
    }

    public void setIndSexo(String indSexo) {
        this.indSexo = indSexo == null ? null : indSexo.trim();
    }

    public String getCodNacionalidad() {
        return codNacionalidad;
    }

    public void setCodNacionalidad(String codNacionalidad) {
        this.codNacionalidad = codNacionalidad == null ? null : codNacionalidad.trim();
    }

    public String getCodUbigeoNac() {
        return codUbigeoNac;
    }

    public void setCodUbigeoNac(String codUbigeoNac) {
        this.codUbigeoNac = codUbigeoNac == null ? null : codUbigeoNac.trim();
    }

    public String getIndEstCivil() {
        return indEstCivil;
    }

    public void setIndEstCivil(String indEstCivil) {
        this.indEstCivil = indEstCivil == null ? null : indEstCivil.trim();
    }

    public String getCodSedeLab() {
        return codSedeLab;
    }

    public void setCodSedeLab(String codSedeLab) {
        this.codSedeLab = codSedeLab == null ? null : codSedeLab.trim();
    }

    public String getCodTelefLarDis() {
        return codTelefLarDis;
    }

    public void setCodTelefLarDis(String codTelefLarDis) {
        this.codTelefLarDis = codTelefLarDis == null ? null : codTelefLarDis.trim();
    }

    public String getNumTelef() {
        return numTelef;
    }

    public void setNumTelef(String numTelef) {
        this.numTelef = numTelef == null ? null : numTelef.trim();
    }

    public String getCodCelLarDis() {
        return codCelLarDis;
    }

    public void setCodCelLarDis(String codCelLarDis) {
        this.codCelLarDis = codCelLarDis == null ? null : codCelLarDis.trim();
    }

    public String getNumCelular() {
        return numCelular;
    }

    public void setNumCelular(String numCelular) {
        this.numCelular = numCelular == null ? null : numCelular.trim();
    }

    public String getDesCorreo() {
        return desCorreo;
    }

    public void setDesCorreo(String desCorreo) {
        this.desCorreo = desCorreo == null ? null : desCorreo.trim();
    }

    public String getCodViaDir1() {
        return codViaDir1;
    }

    public void setCodViaDir1(String codViaDir1) {
        this.codViaDir1 = codViaDir1 == null ? null : codViaDir1.trim();
    }

    public String getNomViaDir1() {
        return nomViaDir1;
    }

    public void setNomViaDir1(String nomViaDir1) {
        this.nomViaDir1 = nomViaDir1 == null ? null : nomViaDir1.trim();
    }

    public String getNumViaDir1() {
        return numViaDir1;
    }

    public void setNumViaDir1(String numViaDir1) {
        this.numViaDir1 = numViaDir1 == null ? null : numViaDir1.trim();
    }

    public String getNumDepaDir1() {
        return numDepaDir1;
    }

    public void setNumDepaDir1(String numDepaDir1) {
        this.numDepaDir1 = numDepaDir1 == null ? null : numDepaDir1.trim();
    }

    public String getNumInteriorDir1() {
        return numInteriorDir1;
    }

    public void setNumInteriorDir1(String numInteriorDir1) {
        this.numInteriorDir1 = numInteriorDir1 == null ? null : numInteriorDir1.trim();
    }

    public String getNumManzDir1() {
        return numManzDir1;
    }

    public void setNumManzDir1(String numManzDir1) {
        this.numManzDir1 = numManzDir1 == null ? null : numManzDir1.trim();
    }

    public String getNumLoteDir1() {
        return numLoteDir1;
    }

    public void setNumLoteDir1(String numLoteDir1) {
        this.numLoteDir1 = numLoteDir1 == null ? null : numLoteDir1.trim();
    }

    public String getNumKilomDir1() {
        return numKilomDir1;
    }

    public void setNumKilomDir1(String numKilomDir1) {
        this.numKilomDir1 = numKilomDir1 == null ? null : numKilomDir1.trim();
    }

    public String getNumBlockDir1() {
        return numBlockDir1;
    }

    public void setNumBlockDir1(String numBlockDir1) {
        this.numBlockDir1 = numBlockDir1 == null ? null : numBlockDir1.trim();
    }

    public String getNumEtapaDir1() {
        return numEtapaDir1;
    }

    public void setNumEtapaDir1(String numEtapaDir1) {
        this.numEtapaDir1 = numEtapaDir1 == null ? null : numEtapaDir1.trim();
    }

    public String getCodZonaDir1() {
        return codZonaDir1;
    }

    public void setCodZonaDir1(String codZonaDir1) {
        this.codZonaDir1 = codZonaDir1 == null ? null : codZonaDir1.trim();
    }

    public String getNomZonaDir1() {
        return nomZonaDir1;
    }

    public void setNomZonaDir1(String nomZonaDir1) {
        this.nomZonaDir1 = nomZonaDir1 == null ? null : nomZonaDir1.trim();
    }

    public String getDesReferDir1() {
        return desReferDir1;
    }

    public void setDesReferDir1(String desReferDir1) {
        this.desReferDir1 = desReferDir1 == null ? null : desReferDir1.trim();
    }

    public String getCodUbigeoDir1() {
        return codUbigeoDir1;
    }

    public void setCodUbigeoDir1(String codUbigeoDir1) {
        this.codUbigeoDir1 = codUbigeoDir1 == null ? null : codUbigeoDir1.trim();
    }

    public String getCodViaDir2() {
        return codViaDir2;
    }

    public void setCodViaDir2(String codViaDir2) {
        this.codViaDir2 = codViaDir2 == null ? null : codViaDir2.trim();
    }

    public String getNomViaDir2() {
        return nomViaDir2;
    }

    public void setNomViaDir2(String nomViaDir2) {
        this.nomViaDir2 = nomViaDir2 == null ? null : nomViaDir2.trim();
    }

    public String getNumViaDir2() {
        return numViaDir2;
    }

    public void setNumViaDir2(String numViaDir2) {
        this.numViaDir2 = numViaDir2 == null ? null : numViaDir2.trim();
    }

    public String getNumDepaDir2() {
        return numDepaDir2;
    }

    public void setNumDepaDir2(String numDepaDir2) {
        this.numDepaDir2 = numDepaDir2 == null ? null : numDepaDir2.trim();
    }

    public String getNumInteriorDir2() {
        return numInteriorDir2;
    }

    public void setNumInteriorDir2(String numInteriorDir2) {
        this.numInteriorDir2 = numInteriorDir2 == null ? null : numInteriorDir2.trim();
    }

    public String getNumManzDir2() {
        return numManzDir2;
    }

    public void setNumManzDir2(String numManzDir2) {
        this.numManzDir2 = numManzDir2 == null ? null : numManzDir2.trim();
    }

    public String getNumLoteDir2() {
        return numLoteDir2;
    }

    public void setNumLoteDir2(String numLoteDir2) {
        this.numLoteDir2 = numLoteDir2 == null ? null : numLoteDir2.trim();
    }

    public String getNumKilomDir2() {
        return numKilomDir2;
    }

    public void setNumKilomDir2(String numKilomDir2) {
        this.numKilomDir2 = numKilomDir2 == null ? null : numKilomDir2.trim();
    }

    public String getNumBlockDir2() {
        return numBlockDir2;
    }

    public void setNumBlockDir2(String numBlockDir2) {
        this.numBlockDir2 = numBlockDir2 == null ? null : numBlockDir2.trim();
    }

    public String getNumEtapaDir2() {
        return numEtapaDir2;
    }

    public void setNumEtapaDir2(String numEtapaDir2) {
        this.numEtapaDir2 = numEtapaDir2 == null ? null : numEtapaDir2.trim();
    }

    public String getCodZonaDir2() {
        return codZonaDir2;
    }

    public void setCodZonaDir2(String codZonaDir2) {
        this.codZonaDir2 = codZonaDir2 == null ? null : codZonaDir2.trim();
    }

    public String getNomZonaDir2() {
        return nomZonaDir2;
    }

    public void setNomZonaDir2(String nomZonaDir2) {
        this.nomZonaDir2 = nomZonaDir2 == null ? null : nomZonaDir2.trim();
    }

    public String getDesReferDir2() {
        return desReferDir2;
    }

    public void setDesReferDir2(String desReferDir2) {
        this.desReferDir2 = desReferDir2 == null ? null : desReferDir2.trim();
    }

    public String getCodUbigeoDir2() {
        return codUbigeoDir2;
    }

    public void setCodUbigeoDir2(String codUbigeoDir2) {
        this.codUbigeoDir2 = codUbigeoDir2 == null ? null : codUbigeoDir2.trim();
    }

    public String getIndCentAsis() {
        return indCentAsis;
    }

    public void setIndCentAsis(String indCentAsis) {
        this.indCentAsis = indCentAsis == null ? null : indCentAsis.trim();
    }

    public String getDesCtaHaberes() {
        return desCtaHaberes;
    }

    public void setDesCtaHaberes(String desCtaHaberes) {
        this.desCtaHaberes = desCtaHaberes == null ? null : desCtaHaberes.trim();
    }

    public String getNumCtaHaberes() {
        return numCtaHaberes;
    }

    public void setNumCtaHaberes(String numCtaHaberes) {
        this.numCtaHaberes = numCtaHaberes == null ? null : numCtaHaberes.trim();
    }

    public String getCodGrupoSan() {
        return codGrupoSan;
    }

    public void setCodGrupoSan(String codGrupoSan) {
        this.codGrupoSan = codGrupoSan == null ? null : codGrupoSan.trim();
    }

    public String getIndDiscapacidad() {
        return indDiscapacidad;
    }

    public void setIndDiscapacidad(String indDiscapacidad) {
        this.indDiscapacidad = indDiscapacidad == null ? null : indDiscapacidad.trim();
    }

    public String getCodDiscapacidad() {
        return codDiscapacidad;
    }

    public void setCodDiscapacidad(String codDiscapacidad) {
        this.codDiscapacidad = codDiscapacidad == null ? null : codDiscapacidad.trim();
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getIndNivEduc() {
        return indNivEduc;
    }

    public void setIndNivEduc(String indNivEduc) {
        this.indNivEduc = indNivEduc == null ? null : indNivEduc.trim();
    }

    public String getNumCuspp() {
        return numCuspp;
    }

    public void setNumCuspp(String numCuspp) {
        this.numCuspp = numCuspp == null ? null : numCuspp.trim();
    }

    public String getDesDomiciDir1() {
        return desDomiciDir1;
    }

    public void setDesDomiciDir1(String desDomiciDir1) {
        this.desDomiciDir1 = desDomiciDir1 == null ? null : desDomiciDir1.trim();
    }

    public String getDesUbigeoDir1() {
        return desUbigeoDir1;
    }

    public void setDesUbigeoDir1(String desUbigeoDir1) {
        this.desUbigeoDir1 = desUbigeoDir1 == null ? null : desUbigeoDir1.trim();
    }

    public String getIndReniec() {
        return indReniec;
    }

    public void setIndReniec(String indReniec) {
        this.indReniec = indReniec == null ? null : indReniec.trim();
    }

    public String getCodPaisUbiNac() {
        return codPaisUbiNac;
    }

    public void setCodPaisUbiNac(String codPaisUbiNac) {
        this.codPaisUbiNac = codPaisUbiNac == null ? null : codPaisUbiNac.trim();
    }

	public List<Archivo> getArchivosReferDomicilio() {
		return archivosReferDomicilio;
	}

	public void setArchivosReferDomicilio(List<Archivo> archivosReferDomicilio) {
		this.archivosReferDomicilio = archivosReferDomicilio;
	}

	public List<Archivo> getArchivosEstadoCivil() {
		return archivosEstadoCivil;
	}

	public void setArchivosEstadoCivil(List<Archivo> archivosEstadoCivil) {
		this.archivosEstadoCivil = archivosEstadoCivil;
	}

	public String getDesIndEstado() {
		return desIndEstado;
	}

	public void setDesIndEstado(String desIndEstado) {
		this.desIndEstado = desIndEstado;
	}

	public List<Archivo> getArchivosDiscapacidad() {
		return archivosDiscapacidad;
	}

	public void setArchivosDiscapacidad(List<Archivo> archivosDiscapacidad) {
		this.archivosDiscapacidad = archivosDiscapacidad;
	}
    
}