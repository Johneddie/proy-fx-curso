package pe.gob.sunat.recurso2.humano.decljurada.model;

public class TelefonoEmpl extends TelefonoEmplKey {
    private String codUorgan;

    private String codLocal;

    private String piso;

    public String getCodUorgan() {
        return codUorgan;
    }

    public void setCodUorgan(String codUorgan) {
        this.codUorgan = codUorgan == null ? null : codUorgan.trim();
    }

    public String getCodLocal() {
        return codLocal;
    }

    public void setCodLocal(String codLocal) {
        this.codLocal = codLocal == null ? null : codLocal.trim();
    }

    public String getPiso() {
        return piso;
    }

    public void setPiso(String piso) {
        this.piso = piso == null ? null : piso.trim();
    }
}