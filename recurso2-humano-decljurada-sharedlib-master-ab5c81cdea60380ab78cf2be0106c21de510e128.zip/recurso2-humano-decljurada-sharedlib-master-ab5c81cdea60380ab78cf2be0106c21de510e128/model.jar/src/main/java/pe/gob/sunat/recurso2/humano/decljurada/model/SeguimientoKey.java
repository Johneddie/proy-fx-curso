package pe.gob.sunat.recurso2.humano.decljurada.model;

public class SeguimientoKey {
    private String annDdjj;

    private String codPersonal;

    private Integer numDdjj;

    private String numSeguim;

    public String getAnnDdjj() {
        return annDdjj;
    }

    public void setAnnDdjj(String annDdjj) {
        this.annDdjj = annDdjj == null ? null : annDdjj.trim();
    }

    public String getCodPersonal() {
        return codPersonal;
    }

    public void setCodPersonal(String codPersonal) {
        this.codPersonal = codPersonal == null ? null : codPersonal.trim();
    }

    public Integer getNumDdjj() {
        return numDdjj;
    }

    public void setNumDdjj(Integer numDdjj) {
        this.numDdjj = numDdjj;
    }

    public String getNumSeguim() {
        return numSeguim;
    }

    public void setNumSeguim(String numSeguim) {
        this.numSeguim = numSeguim == null ? null : numSeguim.trim();
    }
}