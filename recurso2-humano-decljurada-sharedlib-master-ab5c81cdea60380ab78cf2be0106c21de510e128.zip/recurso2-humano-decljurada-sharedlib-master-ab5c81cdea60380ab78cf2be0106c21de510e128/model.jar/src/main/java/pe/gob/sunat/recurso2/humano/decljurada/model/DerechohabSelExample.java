package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DerechohabSelExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public DerechohabSelExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected DerechohabSelExample(DerechohabSelExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andNumCorrelIsNull() {
            addCriterion("num_correl is null");
            return this;
        }

        public Criteria andNumCorrelIsNotNull() {
            addCriterion("num_correl is not null");
            return this;
        }

        public Criteria andNumCorrelEqualTo(Short value) {
            addCriterion("num_correl =", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotEqualTo(Short value) {
            addCriterion("num_correl <>", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelGreaterThan(Short value) {
            addCriterion("num_correl >", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelGreaterThanOrEqualTo(Short value) {
            addCriterion("num_correl >=", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelLessThan(Short value) {
            addCriterion("num_correl <", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelLessThanOrEqualTo(Short value) {
            addCriterion("num_correl <=", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelIn(List<Short> values) {
            addCriterion("num_correl in", values, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotIn(List<Short> values) {
            addCriterion("num_correl not in", values, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelBetween(Short value1, Short value2) {
            addCriterion("num_correl between", value1, value2, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotBetween(Short value1, Short value2) {
            addCriterion("num_correl not between", value1, value2, "numCorrel");
            return this;
        }

        public Criteria andNumPostulanteIsNull() {
            addCriterion("num_postulante is null");
            return this;
        }

        public Criteria andNumPostulanteIsNotNull() {
            addCriterion("num_postulante is not null");
            return this;
        }

        public Criteria andNumPostulanteEqualTo(Integer value) {
            addCriterion("num_postulante =", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteNotEqualTo(Integer value) {
            addCriterion("num_postulante <>", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteGreaterThan(Integer value) {
            addCriterion("num_postulante >", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_postulante >=", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteLessThan(Integer value) {
            addCriterion("num_postulante <", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteLessThanOrEqualTo(Integer value) {
            addCriterion("num_postulante <=", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteIn(List<Integer> values) {
            addCriterion("num_postulante in", values, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteNotIn(List<Integer> values) {
            addCriterion("num_postulante not in", values, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteBetween(Integer value1, Integer value2) {
            addCriterion("num_postulante between", value1, value2, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteNotBetween(Integer value1, Integer value2) {
            addCriterion("num_postulante not between", value1, value2, "numPostulante");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodDocumDerIsNull() {
            addCriterion("cod_docum_der is null");
            return this;
        }

        public Criteria andCodDocumDerIsNotNull() {
            addCriterion("cod_docum_der is not null");
            return this;
        }

        public Criteria andCodDocumDerEqualTo(String value) {
            addCriterion("cod_docum_der =", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotEqualTo(String value) {
            addCriterion("cod_docum_der <>", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerGreaterThan(String value) {
            addCriterion("cod_docum_der >", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum_der >=", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLessThan(String value) {
            addCriterion("cod_docum_der <", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLessThanOrEqualTo(String value) {
            addCriterion("cod_docum_der <=", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLike(String value) {
            addCriterion("cod_docum_der like", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotLike(String value) {
            addCriterion("cod_docum_der not like", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerIn(List<String> values) {
            addCriterion("cod_docum_der in", values, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotIn(List<String> values) {
            addCriterion("cod_docum_der not in", values, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerBetween(String value1, String value2) {
            addCriterion("cod_docum_der between", value1, value2, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotBetween(String value1, String value2) {
            addCriterion("cod_docum_der not between", value1, value2, "codDocumDer");
            return this;
        }

        public Criteria andNumDocumDerIsNull() {
            addCriterion("num_docum_der is null");
            return this;
        }

        public Criteria andNumDocumDerIsNotNull() {
            addCriterion("num_docum_der is not null");
            return this;
        }

        public Criteria andNumDocumDerEqualTo(String value) {
            addCriterion("num_docum_der =", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotEqualTo(String value) {
            addCriterion("num_docum_der <>", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerGreaterThan(String value) {
            addCriterion("num_docum_der >", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum_der >=", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLessThan(String value) {
            addCriterion("num_docum_der <", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLessThanOrEqualTo(String value) {
            addCriterion("num_docum_der <=", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLike(String value) {
            addCriterion("num_docum_der like", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotLike(String value) {
            addCriterion("num_docum_der not like", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerIn(List<String> values) {
            addCriterion("num_docum_der in", values, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotIn(List<String> values) {
            addCriterion("num_docum_der not in", values, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerBetween(String value1, String value2) {
            addCriterion("num_docum_der between", value1, value2, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotBetween(String value1, String value2) {
            addCriterion("num_docum_der not between", value1, value2, "numDocumDer");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andFecNacimientoDerIsNull() {
            addCriterion("fec_nacimiento_der is null");
            return this;
        }

        public Criteria andFecNacimientoDerIsNotNull() {
            addCriterion("fec_nacimiento_der is not null");
            return this;
        }

        public Criteria andFecNacimientoDerEqualTo(Date value) {
            addCriterion("fec_nacimiento_der =", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotEqualTo(Date value) {
            addCriterion("fec_nacimiento_der <>", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerGreaterThan(Date value) {
            addCriterion("fec_nacimiento_der >", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_nacimiento_der >=", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerLessThan(Date value) {
            addCriterion("fec_nacimiento_der <", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerLessThanOrEqualTo(Date value) {
            addCriterion("fec_nacimiento_der <=", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerIn(List<Date> values) {
            addCriterion("fec_nacimiento_der in", values, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotIn(List<Date> values) {
            addCriterion("fec_nacimiento_der not in", values, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerBetween(Date value1, Date value2) {
            addCriterion("fec_nacimiento_der between", value1, value2, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotBetween(Date value1, Date value2) {
            addCriterion("fec_nacimiento_der not between", value1, value2, "fecNacimientoDer");
            return this;
        }

        public Criteria andApePatDerIsNull() {
            addCriterion("ape_pat_der is null");
            return this;
        }

        public Criteria andApePatDerIsNotNull() {
            addCriterion("ape_pat_der is not null");
            return this;
        }

        public Criteria andApePatDerEqualTo(String value) {
            addCriterion("ape_pat_der =", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotEqualTo(String value) {
            addCriterion("ape_pat_der <>", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerGreaterThan(String value) {
            addCriterion("ape_pat_der >", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerGreaterThanOrEqualTo(String value) {
            addCriterion("ape_pat_der >=", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLessThan(String value) {
            addCriterion("ape_pat_der <", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLessThanOrEqualTo(String value) {
            addCriterion("ape_pat_der <=", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLike(String value) {
            addCriterion("ape_pat_der like", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotLike(String value) {
            addCriterion("ape_pat_der not like", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerIn(List<String> values) {
            addCriterion("ape_pat_der in", values, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotIn(List<String> values) {
            addCriterion("ape_pat_der not in", values, "apePatDer");
            return this;
        }

        public Criteria andApePatDerBetween(String value1, String value2) {
            addCriterion("ape_pat_der between", value1, value2, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotBetween(String value1, String value2) {
            addCriterion("ape_pat_der not between", value1, value2, "apePatDer");
            return this;
        }

        public Criteria andApeMatDerIsNull() {
            addCriterion("ape_mat_der is null");
            return this;
        }

        public Criteria andApeMatDerIsNotNull() {
            addCriterion("ape_mat_der is not null");
            return this;
        }

        public Criteria andApeMatDerEqualTo(String value) {
            addCriterion("ape_mat_der =", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotEqualTo(String value) {
            addCriterion("ape_mat_der <>", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerGreaterThan(String value) {
            addCriterion("ape_mat_der >", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerGreaterThanOrEqualTo(String value) {
            addCriterion("ape_mat_der >=", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLessThan(String value) {
            addCriterion("ape_mat_der <", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLessThanOrEqualTo(String value) {
            addCriterion("ape_mat_der <=", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLike(String value) {
            addCriterion("ape_mat_der like", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotLike(String value) {
            addCriterion("ape_mat_der not like", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerIn(List<String> values) {
            addCriterion("ape_mat_der in", values, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotIn(List<String> values) {
            addCriterion("ape_mat_der not in", values, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerBetween(String value1, String value2) {
            addCriterion("ape_mat_der between", value1, value2, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotBetween(String value1, String value2) {
            addCriterion("ape_mat_der not between", value1, value2, "apeMatDer");
            return this;
        }

        public Criteria andNomDerIsNull() {
            addCriterion("nom_der is null");
            return this;
        }

        public Criteria andNomDerIsNotNull() {
            addCriterion("nom_der is not null");
            return this;
        }

        public Criteria andNomDerEqualTo(String value) {
            addCriterion("nom_der =", value, "nomDer");
            return this;
        }

        public Criteria andNomDerNotEqualTo(String value) {
            addCriterion("nom_der <>", value, "nomDer");
            return this;
        }

        public Criteria andNomDerGreaterThan(String value) {
            addCriterion("nom_der >", value, "nomDer");
            return this;
        }

        public Criteria andNomDerGreaterThanOrEqualTo(String value) {
            addCriterion("nom_der >=", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLessThan(String value) {
            addCriterion("nom_der <", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLessThanOrEqualTo(String value) {
            addCriterion("nom_der <=", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLike(String value) {
            addCriterion("nom_der like", value, "nomDer");
            return this;
        }

        public Criteria andNomDerNotLike(String value) {
            addCriterion("nom_der not like", value, "nomDer");
            return this;
        }

        public Criteria andNomDerIn(List<String> values) {
            addCriterion("nom_der in", values, "nomDer");
            return this;
        }

        public Criteria andNomDerNotIn(List<String> values) {
            addCriterion("nom_der not in", values, "nomDer");
            return this;
        }

        public Criteria andNomDerBetween(String value1, String value2) {
            addCriterion("nom_der between", value1, value2, "nomDer");
            return this;
        }

        public Criteria andNomDerNotBetween(String value1, String value2) {
            addCriterion("nom_der not between", value1, value2, "nomDer");
            return this;
        }

        public Criteria andIndSexoDerIsNull() {
            addCriterion("ind_sexo_der is null");
            return this;
        }

        public Criteria andIndSexoDerIsNotNull() {
            addCriterion("ind_sexo_der is not null");
            return this;
        }

        public Criteria andIndSexoDerEqualTo(String value) {
            addCriterion("ind_sexo_der =", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotEqualTo(String value) {
            addCriterion("ind_sexo_der <>", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerGreaterThan(String value) {
            addCriterion("ind_sexo_der >", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sexo_der >=", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerLessThan(String value) {
            addCriterion("ind_sexo_der <", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerLessThanOrEqualTo(String value) {
            addCriterion("ind_sexo_der <=", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerLike(String value) {
            addCriterion("ind_sexo_der like", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotLike(String value) {
            addCriterion("ind_sexo_der not like", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerIn(List<String> values) {
            addCriterion("ind_sexo_der in", values, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotIn(List<String> values) {
            addCriterion("ind_sexo_der not in", values, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerBetween(String value1, String value2) {
            addCriterion("ind_sexo_der between", value1, value2, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotBetween(String value1, String value2) {
            addCriterion("ind_sexo_der not between", value1, value2, "indSexoDer");
            return this;
        }

        public Criteria andCodVinFamIsNull() {
            addCriterion("cod_vin_fam is null");
            return this;
        }

        public Criteria andCodVinFamIsNotNull() {
            addCriterion("cod_vin_fam is not null");
            return this;
        }

        public Criteria andCodVinFamEqualTo(String value) {
            addCriterion("cod_vin_fam =", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotEqualTo(String value) {
            addCriterion("cod_vin_fam <>", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamGreaterThan(String value) {
            addCriterion("cod_vin_fam >", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamGreaterThanOrEqualTo(String value) {
            addCriterion("cod_vin_fam >=", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLessThan(String value) {
            addCriterion("cod_vin_fam <", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLessThanOrEqualTo(String value) {
            addCriterion("cod_vin_fam <=", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLike(String value) {
            addCriterion("cod_vin_fam like", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotLike(String value) {
            addCriterion("cod_vin_fam not like", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamIn(List<String> values) {
            addCriterion("cod_vin_fam in", values, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotIn(List<String> values) {
            addCriterion("cod_vin_fam not in", values, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamBetween(String value1, String value2) {
            addCriterion("cod_vin_fam between", value1, value2, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotBetween(String value1, String value2) {
            addCriterion("cod_vin_fam not between", value1, value2, "codVinFam");
            return this;
        }

        public Criteria andCodDocAcreVinIsNull() {
            addCriterion("cod_doc_acre_vin is null");
            return this;
        }

        public Criteria andCodDocAcreVinIsNotNull() {
            addCriterion("cod_doc_acre_vin is not null");
            return this;
        }

        public Criteria andCodDocAcreVinEqualTo(String value) {
            addCriterion("cod_doc_acre_vin =", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotEqualTo(String value) {
            addCriterion("cod_doc_acre_vin <>", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinGreaterThan(String value) {
            addCriterion("cod_doc_acre_vin >", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinGreaterThanOrEqualTo(String value) {
            addCriterion("cod_doc_acre_vin >=", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinLessThan(String value) {
            addCriterion("cod_doc_acre_vin <", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinLessThanOrEqualTo(String value) {
            addCriterion("cod_doc_acre_vin <=", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinLike(String value) {
            addCriterion("cod_doc_acre_vin like", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotLike(String value) {
            addCriterion("cod_doc_acre_vin not like", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinIn(List<String> values) {
            addCriterion("cod_doc_acre_vin in", values, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotIn(List<String> values) {
            addCriterion("cod_doc_acre_vin not in", values, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinBetween(String value1, String value2) {
            addCriterion("cod_doc_acre_vin between", value1, value2, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotBetween(String value1, String value2) {
            addCriterion("cod_doc_acre_vin not between", value1, value2, "codDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinIsNull() {
            addCriterion("num_doc_acre_vin is null");
            return this;
        }

        public Criteria andNumDocAcreVinIsNotNull() {
            addCriterion("num_doc_acre_vin is not null");
            return this;
        }

        public Criteria andNumDocAcreVinEqualTo(String value) {
            addCriterion("num_doc_acre_vin =", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotEqualTo(String value) {
            addCriterion("num_doc_acre_vin <>", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinGreaterThan(String value) {
            addCriterion("num_doc_acre_vin >", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinGreaterThanOrEqualTo(String value) {
            addCriterion("num_doc_acre_vin >=", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinLessThan(String value) {
            addCriterion("num_doc_acre_vin <", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinLessThanOrEqualTo(String value) {
            addCriterion("num_doc_acre_vin <=", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinLike(String value) {
            addCriterion("num_doc_acre_vin like", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotLike(String value) {
            addCriterion("num_doc_acre_vin not like", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinIn(List<String> values) {
            addCriterion("num_doc_acre_vin in", values, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotIn(List<String> values) {
            addCriterion("num_doc_acre_vin not in", values, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinBetween(String value1, String value2) {
            addCriterion("num_doc_acre_vin between", value1, value2, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotBetween(String value1, String value2) {
            addCriterion("num_doc_acre_vin not between", value1, value2, "numDocAcreVin");
            return this;
        }

        public Criteria andNumMesConcepIsNull() {
            addCriterion("num_mes_concep is null");
            return this;
        }

        public Criteria andNumMesConcepIsNotNull() {
            addCriterion("num_mes_concep is not null");
            return this;
        }

        public Criteria andNumMesConcepEqualTo(String value) {
            addCriterion("num_mes_concep =", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotEqualTo(String value) {
            addCriterion("num_mes_concep <>", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepGreaterThan(String value) {
            addCriterion("num_mes_concep >", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepGreaterThanOrEqualTo(String value) {
            addCriterion("num_mes_concep >=", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepLessThan(String value) {
            addCriterion("num_mes_concep <", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepLessThanOrEqualTo(String value) {
            addCriterion("num_mes_concep <=", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepLike(String value) {
            addCriterion("num_mes_concep like", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotLike(String value) {
            addCriterion("num_mes_concep not like", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepIn(List<String> values) {
            addCriterion("num_mes_concep in", values, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotIn(List<String> values) {
            addCriterion("num_mes_concep not in", values, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepBetween(String value1, String value2) {
            addCriterion("num_mes_concep between", value1, value2, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotBetween(String value1, String value2) {
            addCriterion("num_mes_concep not between", value1, value2, "numMesConcep");
            return this;
        }

        public Criteria andIndTrabSunatIsNull() {
            addCriterion("ind_trab_sunat is null");
            return this;
        }

        public Criteria andIndTrabSunatIsNotNull() {
            addCriterion("ind_trab_sunat is not null");
            return this;
        }

        public Criteria andIndTrabSunatEqualTo(String value) {
            addCriterion("ind_trab_sunat =", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotEqualTo(String value) {
            addCriterion("ind_trab_sunat <>", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatGreaterThan(String value) {
            addCriterion("ind_trab_sunat >", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatGreaterThanOrEqualTo(String value) {
            addCriterion("ind_trab_sunat >=", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatLessThan(String value) {
            addCriterion("ind_trab_sunat <", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatLessThanOrEqualTo(String value) {
            addCriterion("ind_trab_sunat <=", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatLike(String value) {
            addCriterion("ind_trab_sunat like", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotLike(String value) {
            addCriterion("ind_trab_sunat not like", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatIn(List<String> values) {
            addCriterion("ind_trab_sunat in", values, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotIn(List<String> values) {
            addCriterion("ind_trab_sunat not in", values, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatBetween(String value1, String value2) {
            addCriterion("ind_trab_sunat between", value1, value2, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotBetween(String value1, String value2) {
            addCriterion("ind_trab_sunat not between", value1, value2, "indTrabSunat");
            return this;
        }

        public Criteria andNumRegistroIsNull() {
            addCriterion("num_registro is null");
            return this;
        }

        public Criteria andNumRegistroIsNotNull() {
            addCriterion("num_registro is not null");
            return this;
        }

        public Criteria andNumRegistroEqualTo(String value) {
            addCriterion("num_registro =", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotEqualTo(String value) {
            addCriterion("num_registro <>", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroGreaterThan(String value) {
            addCriterion("num_registro >", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroGreaterThanOrEqualTo(String value) {
            addCriterion("num_registro >=", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroLessThan(String value) {
            addCriterion("num_registro <", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroLessThanOrEqualTo(String value) {
            addCriterion("num_registro <=", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroLike(String value) {
            addCriterion("num_registro like", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotLike(String value) {
            addCriterion("num_registro not like", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroIn(List<String> values) {
            addCriterion("num_registro in", values, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotIn(List<String> values) {
            addCriterion("num_registro not in", values, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroBetween(String value1, String value2) {
            addCriterion("num_registro between", value1, value2, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotBetween(String value1, String value2) {
            addCriterion("num_registro not between", value1, value2, "numRegistro");
            return this;
        }

        public Criteria andCodViaDir1IsNull() {
            addCriterion("cod_via_dir1 is null");
            return this;
        }

        public Criteria andCodViaDir1IsNotNull() {
            addCriterion("cod_via_dir1 is not null");
            return this;
        }

        public Criteria andCodViaDir1EqualTo(String value) {
            addCriterion("cod_via_dir1 =", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotEqualTo(String value) {
            addCriterion("cod_via_dir1 <>", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThan(String value) {
            addCriterion("cod_via_dir1 >", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 >=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThan(String value) {
            addCriterion("cod_via_dir1 <", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 <=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Like(String value) {
            addCriterion("cod_via_dir1 like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotLike(String value) {
            addCriterion("cod_via_dir1 not like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1In(List<String> values) {
            addCriterion("cod_via_dir1 in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotIn(List<String> values) {
            addCriterion("cod_via_dir1 not in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Between(String value1, String value2) {
            addCriterion("cod_via_dir1 between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir1 not between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andNomViaDir1IsNull() {
            addCriterion("nom_via_dir1 is null");
            return this;
        }

        public Criteria andNomViaDir1IsNotNull() {
            addCriterion("nom_via_dir1 is not null");
            return this;
        }

        public Criteria andNomViaDir1EqualTo(String value) {
            addCriterion("nom_via_dir1 =", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotEqualTo(String value) {
            addCriterion("nom_via_dir1 <>", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThan(String value) {
            addCriterion("nom_via_dir1 >", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 >=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThan(String value) {
            addCriterion("nom_via_dir1 <", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 <=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Like(String value) {
            addCriterion("nom_via_dir1 like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotLike(String value) {
            addCriterion("nom_via_dir1 not like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1In(List<String> values) {
            addCriterion("nom_via_dir1 in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotIn(List<String> values) {
            addCriterion("nom_via_dir1 not in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Between(String value1, String value2) {
            addCriterion("nom_via_dir1 between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir1 not between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNumViaDir1IsNull() {
            addCriterion("num_via_dir1 is null");
            return this;
        }

        public Criteria andNumViaDir1IsNotNull() {
            addCriterion("num_via_dir1 is not null");
            return this;
        }

        public Criteria andNumViaDir1EqualTo(String value) {
            addCriterion("num_via_dir1 =", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotEqualTo(String value) {
            addCriterion("num_via_dir1 <>", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThan(String value) {
            addCriterion("num_via_dir1 >", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 >=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThan(String value) {
            addCriterion("num_via_dir1 <", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 <=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Like(String value) {
            addCriterion("num_via_dir1 like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotLike(String value) {
            addCriterion("num_via_dir1 not like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1In(List<String> values) {
            addCriterion("num_via_dir1 in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotIn(List<String> values) {
            addCriterion("num_via_dir1 not in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Between(String value1, String value2) {
            addCriterion("num_via_dir1 between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotBetween(String value1, String value2) {
            addCriterion("num_via_dir1 not between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumDepaDir1IsNull() {
            addCriterion("num_depa_dir1 is null");
            return this;
        }

        public Criteria andNumDepaDir1IsNotNull() {
            addCriterion("num_depa_dir1 is not null");
            return this;
        }

        public Criteria andNumDepaDir1EqualTo(String value) {
            addCriterion("num_depa_dir1 =", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotEqualTo(String value) {
            addCriterion("num_depa_dir1 <>", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThan(String value) {
            addCriterion("num_depa_dir1 >", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 >=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThan(String value) {
            addCriterion("num_depa_dir1 <", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 <=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Like(String value) {
            addCriterion("num_depa_dir1 like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotLike(String value) {
            addCriterion("num_depa_dir1 not like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1In(List<String> values) {
            addCriterion("num_depa_dir1 in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotIn(List<String> values) {
            addCriterion("num_depa_dir1 not in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Between(String value1, String value2) {
            addCriterion("num_depa_dir1 between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir1 not between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumInteriorDir1IsNull() {
            addCriterion("num_interior_dir1 is null");
            return this;
        }

        public Criteria andNumInteriorDir1IsNotNull() {
            addCriterion("num_interior_dir1 is not null");
            return this;
        }

        public Criteria andNumInteriorDir1EqualTo(String value) {
            addCriterion("num_interior_dir1 =", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotEqualTo(String value) {
            addCriterion("num_interior_dir1 <>", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThan(String value) {
            addCriterion("num_interior_dir1 >", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 >=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThan(String value) {
            addCriterion("num_interior_dir1 <", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 <=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Like(String value) {
            addCriterion("num_interior_dir1 like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotLike(String value) {
            addCriterion("num_interior_dir1 not like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1In(List<String> values) {
            addCriterion("num_interior_dir1 in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotIn(List<String> values) {
            addCriterion("num_interior_dir1 not in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Between(String value1, String value2) {
            addCriterion("num_interior_dir1 between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir1 not between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumManzDir1IsNull() {
            addCriterion("num_manz_dir1 is null");
            return this;
        }

        public Criteria andNumManzDir1IsNotNull() {
            addCriterion("num_manz_dir1 is not null");
            return this;
        }

        public Criteria andNumManzDir1EqualTo(String value) {
            addCriterion("num_manz_dir1 =", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotEqualTo(String value) {
            addCriterion("num_manz_dir1 <>", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThan(String value) {
            addCriterion("num_manz_dir1 >", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 >=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThan(String value) {
            addCriterion("num_manz_dir1 <", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 <=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Like(String value) {
            addCriterion("num_manz_dir1 like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotLike(String value) {
            addCriterion("num_manz_dir1 not like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1In(List<String> values) {
            addCriterion("num_manz_dir1 in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotIn(List<String> values) {
            addCriterion("num_manz_dir1 not in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Between(String value1, String value2) {
            addCriterion("num_manz_dir1 between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir1 not between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumLoteDir1IsNull() {
            addCriterion("num_lote_dir1 is null");
            return this;
        }

        public Criteria andNumLoteDir1IsNotNull() {
            addCriterion("num_lote_dir1 is not null");
            return this;
        }

        public Criteria andNumLoteDir1EqualTo(String value) {
            addCriterion("num_lote_dir1 =", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotEqualTo(String value) {
            addCriterion("num_lote_dir1 <>", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThan(String value) {
            addCriterion("num_lote_dir1 >", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 >=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThan(String value) {
            addCriterion("num_lote_dir1 <", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 <=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Like(String value) {
            addCriterion("num_lote_dir1 like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotLike(String value) {
            addCriterion("num_lote_dir1 not like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1In(List<String> values) {
            addCriterion("num_lote_dir1 in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotIn(List<String> values) {
            addCriterion("num_lote_dir1 not in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Between(String value1, String value2) {
            addCriterion("num_lote_dir1 between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir1 not between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumKilomDir1IsNull() {
            addCriterion("num_kilom_dir1 is null");
            return this;
        }

        public Criteria andNumKilomDir1IsNotNull() {
            addCriterion("num_kilom_dir1 is not null");
            return this;
        }

        public Criteria andNumKilomDir1EqualTo(String value) {
            addCriterion("num_kilom_dir1 =", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotEqualTo(String value) {
            addCriterion("num_kilom_dir1 <>", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThan(String value) {
            addCriterion("num_kilom_dir1 >", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 >=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThan(String value) {
            addCriterion("num_kilom_dir1 <", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 <=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Like(String value) {
            addCriterion("num_kilom_dir1 like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotLike(String value) {
            addCriterion("num_kilom_dir1 not like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1In(List<String> values) {
            addCriterion("num_kilom_dir1 in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotIn(List<String> values) {
            addCriterion("num_kilom_dir1 not in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Between(String value1, String value2) {
            addCriterion("num_kilom_dir1 between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir1 not between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumBlockDir1IsNull() {
            addCriterion("num_block_dir1 is null");
            return this;
        }

        public Criteria andNumBlockDir1IsNotNull() {
            addCriterion("num_block_dir1 is not null");
            return this;
        }

        public Criteria andNumBlockDir1EqualTo(String value) {
            addCriterion("num_block_dir1 =", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotEqualTo(String value) {
            addCriterion("num_block_dir1 <>", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThan(String value) {
            addCriterion("num_block_dir1 >", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 >=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThan(String value) {
            addCriterion("num_block_dir1 <", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 <=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Like(String value) {
            addCriterion("num_block_dir1 like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotLike(String value) {
            addCriterion("num_block_dir1 not like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1In(List<String> values) {
            addCriterion("num_block_dir1 in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotIn(List<String> values) {
            addCriterion("num_block_dir1 not in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Between(String value1, String value2) {
            addCriterion("num_block_dir1 between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotBetween(String value1, String value2) {
            addCriterion("num_block_dir1 not between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumEtapaDir1IsNull() {
            addCriterion("num_etapa_dir1 is null");
            return this;
        }

        public Criteria andNumEtapaDir1IsNotNull() {
            addCriterion("num_etapa_dir1 is not null");
            return this;
        }

        public Criteria andNumEtapaDir1EqualTo(String value) {
            addCriterion("num_etapa_dir1 =", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotEqualTo(String value) {
            addCriterion("num_etapa_dir1 <>", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThan(String value) {
            addCriterion("num_etapa_dir1 >", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 >=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThan(String value) {
            addCriterion("num_etapa_dir1 <", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 <=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Like(String value) {
            addCriterion("num_etapa_dir1 like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotLike(String value) {
            addCriterion("num_etapa_dir1 not like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1In(List<String> values) {
            addCriterion("num_etapa_dir1 in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotIn(List<String> values) {
            addCriterion("num_etapa_dir1 not in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Between(String value1, String value2) {
            addCriterion("num_etapa_dir1 between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir1 not between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andCodZonaDir1IsNull() {
            addCriterion("cod_zona_dir1 is null");
            return this;
        }

        public Criteria andCodZonaDir1IsNotNull() {
            addCriterion("cod_zona_dir1 is not null");
            return this;
        }

        public Criteria andCodZonaDir1EqualTo(String value) {
            addCriterion("cod_zona_dir1 =", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotEqualTo(String value) {
            addCriterion("cod_zona_dir1 <>", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThan(String value) {
            addCriterion("cod_zona_dir1 >", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 >=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThan(String value) {
            addCriterion("cod_zona_dir1 <", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 <=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Like(String value) {
            addCriterion("cod_zona_dir1 like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotLike(String value) {
            addCriterion("cod_zona_dir1 not like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1In(List<String> values) {
            addCriterion("cod_zona_dir1 in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotIn(List<String> values) {
            addCriterion("cod_zona_dir1 not in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Between(String value1, String value2) {
            addCriterion("cod_zona_dir1 between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir1 not between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1IsNull() {
            addCriterion("nom_zona_dir1 is null");
            return this;
        }

        public Criteria andNomZonaDir1IsNotNull() {
            addCriterion("nom_zona_dir1 is not null");
            return this;
        }

        public Criteria andNomZonaDir1EqualTo(String value) {
            addCriterion("nom_zona_dir1 =", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotEqualTo(String value) {
            addCriterion("nom_zona_dir1 <>", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThan(String value) {
            addCriterion("nom_zona_dir1 >", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 >=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThan(String value) {
            addCriterion("nom_zona_dir1 <", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 <=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Like(String value) {
            addCriterion("nom_zona_dir1 like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotLike(String value) {
            addCriterion("nom_zona_dir1 not like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1In(List<String> values) {
            addCriterion("nom_zona_dir1 in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotIn(List<String> values) {
            addCriterion("nom_zona_dir1 not in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Between(String value1, String value2) {
            addCriterion("nom_zona_dir1 between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir1 not between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andDesReferDir1IsNull() {
            addCriterion("des_refer_dir1 is null");
            return this;
        }

        public Criteria andDesReferDir1IsNotNull() {
            addCriterion("des_refer_dir1 is not null");
            return this;
        }

        public Criteria andDesReferDir1EqualTo(String value) {
            addCriterion("des_refer_dir1 =", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotEqualTo(String value) {
            addCriterion("des_refer_dir1 <>", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThan(String value) {
            addCriterion("des_refer_dir1 >", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 >=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThan(String value) {
            addCriterion("des_refer_dir1 <", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 <=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Like(String value) {
            addCriterion("des_refer_dir1 like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotLike(String value) {
            addCriterion("des_refer_dir1 not like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1In(List<String> values) {
            addCriterion("des_refer_dir1 in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotIn(List<String> values) {
            addCriterion("des_refer_dir1 not in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Between(String value1, String value2) {
            addCriterion("des_refer_dir1 between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotBetween(String value1, String value2) {
            addCriterion("des_refer_dir1 not between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNull() {
            addCriterion("cod_ubigeo_dir1 is null");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNotNull() {
            addCriterion("cod_ubigeo_dir1 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir1EqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 =", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <>", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir1 >", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 >=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThan(String value) {
            addCriterion("cod_ubigeo_dir1 <", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Like(String value) {
            addCriterion("cod_ubigeo_dir1 like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotLike(String value) {
            addCriterion("cod_ubigeo_dir1 not like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1In(List<String> values) {
            addCriterion("cod_ubigeo_dir1 in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir1 not in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 not between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodViaDir2IsNull() {
            addCriterion("cod_via_dir2 is null");
            return this;
        }

        public Criteria andCodViaDir2IsNotNull() {
            addCriterion("cod_via_dir2 is not null");
            return this;
        }

        public Criteria andCodViaDir2EqualTo(String value) {
            addCriterion("cod_via_dir2 =", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotEqualTo(String value) {
            addCriterion("cod_via_dir2 <>", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThan(String value) {
            addCriterion("cod_via_dir2 >", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 >=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThan(String value) {
            addCriterion("cod_via_dir2 <", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 <=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Like(String value) {
            addCriterion("cod_via_dir2 like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotLike(String value) {
            addCriterion("cod_via_dir2 not like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2In(List<String> values) {
            addCriterion("cod_via_dir2 in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotIn(List<String> values) {
            addCriterion("cod_via_dir2 not in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Between(String value1, String value2) {
            addCriterion("cod_via_dir2 between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir2 not between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andNomViaDir2IsNull() {
            addCriterion("nom_via_dir2 is null");
            return this;
        }

        public Criteria andNomViaDir2IsNotNull() {
            addCriterion("nom_via_dir2 is not null");
            return this;
        }

        public Criteria andNomViaDir2EqualTo(String value) {
            addCriterion("nom_via_dir2 =", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotEqualTo(String value) {
            addCriterion("nom_via_dir2 <>", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThan(String value) {
            addCriterion("nom_via_dir2 >", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 >=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThan(String value) {
            addCriterion("nom_via_dir2 <", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 <=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Like(String value) {
            addCriterion("nom_via_dir2 like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotLike(String value) {
            addCriterion("nom_via_dir2 not like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2In(List<String> values) {
            addCriterion("nom_via_dir2 in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotIn(List<String> values) {
            addCriterion("nom_via_dir2 not in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Between(String value1, String value2) {
            addCriterion("nom_via_dir2 between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir2 not between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNumViaDir2IsNull() {
            addCriterion("num_via_dir2 is null");
            return this;
        }

        public Criteria andNumViaDir2IsNotNull() {
            addCriterion("num_via_dir2 is not null");
            return this;
        }

        public Criteria andNumViaDir2EqualTo(String value) {
            addCriterion("num_via_dir2 =", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotEqualTo(String value) {
            addCriterion("num_via_dir2 <>", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThan(String value) {
            addCriterion("num_via_dir2 >", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 >=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThan(String value) {
            addCriterion("num_via_dir2 <", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 <=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Like(String value) {
            addCriterion("num_via_dir2 like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotLike(String value) {
            addCriterion("num_via_dir2 not like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2In(List<String> values) {
            addCriterion("num_via_dir2 in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotIn(List<String> values) {
            addCriterion("num_via_dir2 not in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Between(String value1, String value2) {
            addCriterion("num_via_dir2 between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotBetween(String value1, String value2) {
            addCriterion("num_via_dir2 not between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumDepaDir2IsNull() {
            addCriterion("num_depa_dir2 is null");
            return this;
        }

        public Criteria andNumDepaDir2IsNotNull() {
            addCriterion("num_depa_dir2 is not null");
            return this;
        }

        public Criteria andNumDepaDir2EqualTo(String value) {
            addCriterion("num_depa_dir2 =", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotEqualTo(String value) {
            addCriterion("num_depa_dir2 <>", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThan(String value) {
            addCriterion("num_depa_dir2 >", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 >=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThan(String value) {
            addCriterion("num_depa_dir2 <", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 <=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Like(String value) {
            addCriterion("num_depa_dir2 like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotLike(String value) {
            addCriterion("num_depa_dir2 not like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2In(List<String> values) {
            addCriterion("num_depa_dir2 in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotIn(List<String> values) {
            addCriterion("num_depa_dir2 not in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Between(String value1, String value2) {
            addCriterion("num_depa_dir2 between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir2 not between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumInteriorDir2IsNull() {
            addCriterion("num_interior_dir2 is null");
            return this;
        }

        public Criteria andNumInteriorDir2IsNotNull() {
            addCriterion("num_interior_dir2 is not null");
            return this;
        }

        public Criteria andNumInteriorDir2EqualTo(String value) {
            addCriterion("num_interior_dir2 =", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotEqualTo(String value) {
            addCriterion("num_interior_dir2 <>", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThan(String value) {
            addCriterion("num_interior_dir2 >", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 >=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThan(String value) {
            addCriterion("num_interior_dir2 <", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 <=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Like(String value) {
            addCriterion("num_interior_dir2 like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotLike(String value) {
            addCriterion("num_interior_dir2 not like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2In(List<String> values) {
            addCriterion("num_interior_dir2 in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotIn(List<String> values) {
            addCriterion("num_interior_dir2 not in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Between(String value1, String value2) {
            addCriterion("num_interior_dir2 between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir2 not between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumManzDir2IsNull() {
            addCriterion("num_manz_dir2 is null");
            return this;
        }

        public Criteria andNumManzDir2IsNotNull() {
            addCriterion("num_manz_dir2 is not null");
            return this;
        }

        public Criteria andNumManzDir2EqualTo(String value) {
            addCriterion("num_manz_dir2 =", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotEqualTo(String value) {
            addCriterion("num_manz_dir2 <>", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThan(String value) {
            addCriterion("num_manz_dir2 >", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 >=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThan(String value) {
            addCriterion("num_manz_dir2 <", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 <=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Like(String value) {
            addCriterion("num_manz_dir2 like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotLike(String value) {
            addCriterion("num_manz_dir2 not like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2In(List<String> values) {
            addCriterion("num_manz_dir2 in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotIn(List<String> values) {
            addCriterion("num_manz_dir2 not in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Between(String value1, String value2) {
            addCriterion("num_manz_dir2 between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir2 not between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumLoteDir2IsNull() {
            addCriterion("num_lote_dir2 is null");
            return this;
        }

        public Criteria andNumLoteDir2IsNotNull() {
            addCriterion("num_lote_dir2 is not null");
            return this;
        }

        public Criteria andNumLoteDir2EqualTo(String value) {
            addCriterion("num_lote_dir2 =", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotEqualTo(String value) {
            addCriterion("num_lote_dir2 <>", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThan(String value) {
            addCriterion("num_lote_dir2 >", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 >=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThan(String value) {
            addCriterion("num_lote_dir2 <", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 <=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Like(String value) {
            addCriterion("num_lote_dir2 like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotLike(String value) {
            addCriterion("num_lote_dir2 not like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2In(List<String> values) {
            addCriterion("num_lote_dir2 in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotIn(List<String> values) {
            addCriterion("num_lote_dir2 not in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Between(String value1, String value2) {
            addCriterion("num_lote_dir2 between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir2 not between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumKilomDir2IsNull() {
            addCriterion("num_kilom_dir2 is null");
            return this;
        }

        public Criteria andNumKilomDir2IsNotNull() {
            addCriterion("num_kilom_dir2 is not null");
            return this;
        }

        public Criteria andNumKilomDir2EqualTo(String value) {
            addCriterion("num_kilom_dir2 =", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotEqualTo(String value) {
            addCriterion("num_kilom_dir2 <>", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThan(String value) {
            addCriterion("num_kilom_dir2 >", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 >=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThan(String value) {
            addCriterion("num_kilom_dir2 <", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 <=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Like(String value) {
            addCriterion("num_kilom_dir2 like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotLike(String value) {
            addCriterion("num_kilom_dir2 not like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2In(List<String> values) {
            addCriterion("num_kilom_dir2 in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotIn(List<String> values) {
            addCriterion("num_kilom_dir2 not in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Between(String value1, String value2) {
            addCriterion("num_kilom_dir2 between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir2 not between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumBlockDir2IsNull() {
            addCriterion("num_block_dir2 is null");
            return this;
        }

        public Criteria andNumBlockDir2IsNotNull() {
            addCriterion("num_block_dir2 is not null");
            return this;
        }

        public Criteria andNumBlockDir2EqualTo(String value) {
            addCriterion("num_block_dir2 =", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotEqualTo(String value) {
            addCriterion("num_block_dir2 <>", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThan(String value) {
            addCriterion("num_block_dir2 >", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 >=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThan(String value) {
            addCriterion("num_block_dir2 <", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 <=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Like(String value) {
            addCriterion("num_block_dir2 like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotLike(String value) {
            addCriterion("num_block_dir2 not like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2In(List<String> values) {
            addCriterion("num_block_dir2 in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotIn(List<String> values) {
            addCriterion("num_block_dir2 not in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Between(String value1, String value2) {
            addCriterion("num_block_dir2 between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotBetween(String value1, String value2) {
            addCriterion("num_block_dir2 not between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumEtapaDir2IsNull() {
            addCriterion("num_etapa_dir2 is null");
            return this;
        }

        public Criteria andNumEtapaDir2IsNotNull() {
            addCriterion("num_etapa_dir2 is not null");
            return this;
        }

        public Criteria andNumEtapaDir2EqualTo(String value) {
            addCriterion("num_etapa_dir2 =", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotEqualTo(String value) {
            addCriterion("num_etapa_dir2 <>", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThan(String value) {
            addCriterion("num_etapa_dir2 >", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 >=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThan(String value) {
            addCriterion("num_etapa_dir2 <", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 <=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Like(String value) {
            addCriterion("num_etapa_dir2 like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotLike(String value) {
            addCriterion("num_etapa_dir2 not like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2In(List<String> values) {
            addCriterion("num_etapa_dir2 in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotIn(List<String> values) {
            addCriterion("num_etapa_dir2 not in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Between(String value1, String value2) {
            addCriterion("num_etapa_dir2 between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir2 not between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andCodZonaDir2IsNull() {
            addCriterion("cod_zona_dir2 is null");
            return this;
        }

        public Criteria andCodZonaDir2IsNotNull() {
            addCriterion("cod_zona_dir2 is not null");
            return this;
        }

        public Criteria andCodZonaDir2EqualTo(String value) {
            addCriterion("cod_zona_dir2 =", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotEqualTo(String value) {
            addCriterion("cod_zona_dir2 <>", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThan(String value) {
            addCriterion("cod_zona_dir2 >", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 >=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThan(String value) {
            addCriterion("cod_zona_dir2 <", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 <=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Like(String value) {
            addCriterion("cod_zona_dir2 like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotLike(String value) {
            addCriterion("cod_zona_dir2 not like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2In(List<String> values) {
            addCriterion("cod_zona_dir2 in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotIn(List<String> values) {
            addCriterion("cod_zona_dir2 not in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Between(String value1, String value2) {
            addCriterion("cod_zona_dir2 between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir2 not between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2IsNull() {
            addCriterion("nom_zona_dir2 is null");
            return this;
        }

        public Criteria andNomZonaDir2IsNotNull() {
            addCriterion("nom_zona_dir2 is not null");
            return this;
        }

        public Criteria andNomZonaDir2EqualTo(String value) {
            addCriterion("nom_zona_dir2 =", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotEqualTo(String value) {
            addCriterion("nom_zona_dir2 <>", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThan(String value) {
            addCriterion("nom_zona_dir2 >", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 >=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThan(String value) {
            addCriterion("nom_zona_dir2 <", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 <=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Like(String value) {
            addCriterion("nom_zona_dir2 like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotLike(String value) {
            addCriterion("nom_zona_dir2 not like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2In(List<String> values) {
            addCriterion("nom_zona_dir2 in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotIn(List<String> values) {
            addCriterion("nom_zona_dir2 not in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Between(String value1, String value2) {
            addCriterion("nom_zona_dir2 between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir2 not between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andDesRefIsNull() {
            addCriterion("des_ref is null");
            return this;
        }

        public Criteria andDesRefIsNotNull() {
            addCriterion("des_ref is not null");
            return this;
        }

        public Criteria andDesRefEqualTo(String value) {
            addCriterion("des_ref =", value, "desRef");
            return this;
        }

        public Criteria andDesRefNotEqualTo(String value) {
            addCriterion("des_ref <>", value, "desRef");
            return this;
        }

        public Criteria andDesRefGreaterThan(String value) {
            addCriterion("des_ref >", value, "desRef");
            return this;
        }

        public Criteria andDesRefGreaterThanOrEqualTo(String value) {
            addCriterion("des_ref >=", value, "desRef");
            return this;
        }

        public Criteria andDesRefLessThan(String value) {
            addCriterion("des_ref <", value, "desRef");
            return this;
        }

        public Criteria andDesRefLessThanOrEqualTo(String value) {
            addCriterion("des_ref <=", value, "desRef");
            return this;
        }

        public Criteria andDesRefLike(String value) {
            addCriterion("des_ref like", value, "desRef");
            return this;
        }

        public Criteria andDesRefNotLike(String value) {
            addCriterion("des_ref not like", value, "desRef");
            return this;
        }

        public Criteria andDesRefIn(List<String> values) {
            addCriterion("des_ref in", values, "desRef");
            return this;
        }

        public Criteria andDesRefNotIn(List<String> values) {
            addCriterion("des_ref not in", values, "desRef");
            return this;
        }

        public Criteria andDesRefBetween(String value1, String value2) {
            addCriterion("des_ref between", value1, value2, "desRef");
            return this;
        }

        public Criteria andDesRefNotBetween(String value1, String value2) {
            addCriterion("des_ref not between", value1, value2, "desRef");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNull() {
            addCriterion("cod_ubigeo_dir2 is null");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNotNull() {
            addCriterion("cod_ubigeo_dir2 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir2EqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 =", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <>", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir2 >", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 >=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThan(String value) {
            addCriterion("cod_ubigeo_dir2 <", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Like(String value) {
            addCriterion("cod_ubigeo_dir2 like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotLike(String value) {
            addCriterion("cod_ubigeo_dir2 not like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2In(List<String> values) {
            addCriterion("cod_ubigeo_dir2 in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir2 not in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 not between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodTelefIsNull() {
            addCriterion("cod_telef is null");
            return this;
        }

        public Criteria andCodTelefIsNotNull() {
            addCriterion("cod_telef is not null");
            return this;
        }

        public Criteria andCodTelefEqualTo(String value) {
            addCriterion("cod_telef =", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefNotEqualTo(String value) {
            addCriterion("cod_telef <>", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefGreaterThan(String value) {
            addCriterion("cod_telef >", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefGreaterThanOrEqualTo(String value) {
            addCriterion("cod_telef >=", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefLessThan(String value) {
            addCriterion("cod_telef <", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefLessThanOrEqualTo(String value) {
            addCriterion("cod_telef <=", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefLike(String value) {
            addCriterion("cod_telef like", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefNotLike(String value) {
            addCriterion("cod_telef not like", value, "codTelef");
            return this;
        }

        public Criteria andCodTelefIn(List<String> values) {
            addCriterion("cod_telef in", values, "codTelef");
            return this;
        }

        public Criteria andCodTelefNotIn(List<String> values) {
            addCriterion("cod_telef not in", values, "codTelef");
            return this;
        }

        public Criteria andCodTelefBetween(String value1, String value2) {
            addCriterion("cod_telef between", value1, value2, "codTelef");
            return this;
        }

        public Criteria andCodTelefNotBetween(String value1, String value2) {
            addCriterion("cod_telef not between", value1, value2, "codTelef");
            return this;
        }

        public Criteria andNumTelefIsNull() {
            addCriterion("num_telef is null");
            return this;
        }

        public Criteria andNumTelefIsNotNull() {
            addCriterion("num_telef is not null");
            return this;
        }

        public Criteria andNumTelefEqualTo(String value) {
            addCriterion("num_telef =", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotEqualTo(String value) {
            addCriterion("num_telef <>", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThan(String value) {
            addCriterion("num_telef >", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThanOrEqualTo(String value) {
            addCriterion("num_telef >=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThan(String value) {
            addCriterion("num_telef <", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThanOrEqualTo(String value) {
            addCriterion("num_telef <=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLike(String value) {
            addCriterion("num_telef like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotLike(String value) {
            addCriterion("num_telef not like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefIn(List<String> values) {
            addCriterion("num_telef in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotIn(List<String> values) {
            addCriterion("num_telef not in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefBetween(String value1, String value2) {
            addCriterion("num_telef between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotBetween(String value1, String value2) {
            addCriterion("num_telef not between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andCodCelIsNull() {
            addCriterion("cod_cel is null");
            return this;
        }

        public Criteria andCodCelIsNotNull() {
            addCriterion("cod_cel is not null");
            return this;
        }

        public Criteria andCodCelEqualTo(String value) {
            addCriterion("cod_cel =", value, "codCel");
            return this;
        }

        public Criteria andCodCelNotEqualTo(String value) {
            addCriterion("cod_cel <>", value, "codCel");
            return this;
        }

        public Criteria andCodCelGreaterThan(String value) {
            addCriterion("cod_cel >", value, "codCel");
            return this;
        }

        public Criteria andCodCelGreaterThanOrEqualTo(String value) {
            addCriterion("cod_cel >=", value, "codCel");
            return this;
        }

        public Criteria andCodCelLessThan(String value) {
            addCriterion("cod_cel <", value, "codCel");
            return this;
        }

        public Criteria andCodCelLessThanOrEqualTo(String value) {
            addCriterion("cod_cel <=", value, "codCel");
            return this;
        }

        public Criteria andCodCelLike(String value) {
            addCriterion("cod_cel like", value, "codCel");
            return this;
        }

        public Criteria andCodCelNotLike(String value) {
            addCriterion("cod_cel not like", value, "codCel");
            return this;
        }

        public Criteria andCodCelIn(List<String> values) {
            addCriterion("cod_cel in", values, "codCel");
            return this;
        }

        public Criteria andCodCelNotIn(List<String> values) {
            addCriterion("cod_cel not in", values, "codCel");
            return this;
        }

        public Criteria andCodCelBetween(String value1, String value2) {
            addCriterion("cod_cel between", value1, value2, "codCel");
            return this;
        }

        public Criteria andCodCelNotBetween(String value1, String value2) {
            addCriterion("cod_cel not between", value1, value2, "codCel");
            return this;
        }

        public Criteria andNumCelularIsNull() {
            addCriterion("num_celular is null");
            return this;
        }

        public Criteria andNumCelularIsNotNull() {
            addCriterion("num_celular is not null");
            return this;
        }

        public Criteria andNumCelularEqualTo(String value) {
            addCriterion("num_celular =", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotEqualTo(String value) {
            addCriterion("num_celular <>", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularGreaterThan(String value) {
            addCriterion("num_celular >", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularGreaterThanOrEqualTo(String value) {
            addCriterion("num_celular >=", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLessThan(String value) {
            addCriterion("num_celular <", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLessThanOrEqualTo(String value) {
            addCriterion("num_celular <=", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLike(String value) {
            addCriterion("num_celular like", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotLike(String value) {
            addCriterion("num_celular not like", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularIn(List<String> values) {
            addCriterion("num_celular in", values, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotIn(List<String> values) {
            addCriterion("num_celular not in", values, "numCelular");
            return this;
        }

        public Criteria andNumCelularBetween(String value1, String value2) {
            addCriterion("num_celular between", value1, value2, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotBetween(String value1, String value2) {
            addCriterion("num_celular not between", value1, value2, "numCelular");
            return this;
        }

        public Criteria andDesCorreoIsNull() {
            addCriterion("des_correo is null");
            return this;
        }

        public Criteria andDesCorreoIsNotNull() {
            addCriterion("des_correo is not null");
            return this;
        }

        public Criteria andDesCorreoEqualTo(String value) {
            addCriterion("des_correo =", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotEqualTo(String value) {
            addCriterion("des_correo <>", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThan(String value) {
            addCriterion("des_correo >", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThanOrEqualTo(String value) {
            addCriterion("des_correo >=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThan(String value) {
            addCriterion("des_correo <", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThanOrEqualTo(String value) {
            addCriterion("des_correo <=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLike(String value) {
            addCriterion("des_correo like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotLike(String value) {
            addCriterion("des_correo not like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoIn(List<String> values) {
            addCriterion("des_correo in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotIn(List<String> values) {
            addCriterion("des_correo not in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoBetween(String value1, String value2) {
            addCriterion("des_correo between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotBetween(String value1, String value2) {
            addCriterion("des_correo not between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesDomiciDir1IsNull() {
            addCriterion("des_domici_dir1 is null");
            return this;
        }

        public Criteria andDesDomiciDir1IsNotNull() {
            addCriterion("des_domici_dir1 is not null");
            return this;
        }

        public Criteria andDesDomiciDir1EqualTo(String value) {
            addCriterion("des_domici_dir1 =", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotEqualTo(String value) {
            addCriterion("des_domici_dir1 <>", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1GreaterThan(String value) {
            addCriterion("des_domici_dir1 >", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_domici_dir1 >=", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1LessThan(String value) {
            addCriterion("des_domici_dir1 <", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1LessThanOrEqualTo(String value) {
            addCriterion("des_domici_dir1 <=", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1Like(String value) {
            addCriterion("des_domici_dir1 like", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotLike(String value) {
            addCriterion("des_domici_dir1 not like", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1In(List<String> values) {
            addCriterion("des_domici_dir1 in", values, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotIn(List<String> values) {
            addCriterion("des_domici_dir1 not in", values, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1Between(String value1, String value2) {
            addCriterion("des_domici_dir1 between", value1, value2, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotBetween(String value1, String value2) {
            addCriterion("des_domici_dir1 not between", value1, value2, "desDomiciDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1IsNull() {
            addCriterion("des_ubigeo_dir1 is null");
            return this;
        }

        public Criteria andDesUbigeoDir1IsNotNull() {
            addCriterion("des_ubigeo_dir1 is not null");
            return this;
        }

        public Criteria andDesUbigeoDir1EqualTo(String value) {
            addCriterion("des_ubigeo_dir1 =", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 <>", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1GreaterThan(String value) {
            addCriterion("des_ubigeo_dir1 >", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 >=", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1LessThan(String value) {
            addCriterion("des_ubigeo_dir1 <", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1LessThanOrEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 <=", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1Like(String value) {
            addCriterion("des_ubigeo_dir1 like", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotLike(String value) {
            addCriterion("des_ubigeo_dir1 not like", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1In(List<String> values) {
            addCriterion("des_ubigeo_dir1 in", values, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotIn(List<String> values) {
            addCriterion("des_ubigeo_dir1 not in", values, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1Between(String value1, String value2) {
            addCriterion("des_ubigeo_dir1 between", value1, value2, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotBetween(String value1, String value2) {
            addCriterion("des_ubigeo_dir1 not between", value1, value2, "desUbigeoDir1");
            return this;
        }

        public Criteria andIndReniecIsNull() {
            addCriterion("ind_reniec is null");
            return this;
        }

        public Criteria andIndReniecIsNotNull() {
            addCriterion("ind_reniec is not null");
            return this;
        }

        public Criteria andIndReniecEqualTo(String value) {
            addCriterion("ind_reniec =", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotEqualTo(String value) {
            addCriterion("ind_reniec <>", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecGreaterThan(String value) {
            addCriterion("ind_reniec >", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecGreaterThanOrEqualTo(String value) {
            addCriterion("ind_reniec >=", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLessThan(String value) {
            addCriterion("ind_reniec <", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLessThanOrEqualTo(String value) {
            addCriterion("ind_reniec <=", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLike(String value) {
            addCriterion("ind_reniec like", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotLike(String value) {
            addCriterion("ind_reniec not like", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecIn(List<String> values) {
            addCriterion("ind_reniec in", values, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotIn(List<String> values) {
            addCriterion("ind_reniec not in", values, "indReniec");
            return this;
        }

        public Criteria andIndReniecBetween(String value1, String value2) {
            addCriterion("ind_reniec between", value1, value2, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotBetween(String value1, String value2) {
            addCriterion("ind_reniec not between", value1, value2, "indReniec");
            return this;
        }

        public Criteria andFecInivincIsNull() {
            addCriterion("fec_inivinc is null");
            return this;
        }

        public Criteria andFecInivincIsNotNull() {
            addCriterion("fec_inivinc is not null");
            return this;
        }

        public Criteria andFecInivincEqualTo(Date value) {
            addCriterion("fec_inivinc =", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincNotEqualTo(Date value) {
            addCriterion("fec_inivinc <>", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincGreaterThan(Date value) {
            addCriterion("fec_inivinc >", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_inivinc >=", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincLessThan(Date value) {
            addCriterion("fec_inivinc <", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincLessThanOrEqualTo(Date value) {
            addCriterion("fec_inivinc <=", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincIn(List<Date> values) {
            addCriterion("fec_inivinc in", values, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincNotIn(List<Date> values) {
            addCriterion("fec_inivinc not in", values, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincBetween(Date value1, Date value2) {
            addCriterion("fec_inivinc between", value1, value2, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincNotBetween(Date value1, Date value2) {
            addCriterion("fec_inivinc not between", value1, value2, "fecInivinc");
            return this;
        }

        public Criteria andIndCentAsisIsNull() {
            addCriterion("ind_cent_asis is null");
            return this;
        }

        public Criteria andIndCentAsisIsNotNull() {
            addCriterion("ind_cent_asis is not null");
            return this;
        }

        public Criteria andIndCentAsisEqualTo(String value) {
            addCriterion("ind_cent_asis =", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotEqualTo(String value) {
            addCriterion("ind_cent_asis <>", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThan(String value) {
            addCriterion("ind_cent_asis >", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis >=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThan(String value) {
            addCriterion("ind_cent_asis <", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis <=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLike(String value) {
            addCriterion("ind_cent_asis like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotLike(String value) {
            addCriterion("ind_cent_asis not like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisIn(List<String> values) {
            addCriterion("ind_cent_asis in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotIn(List<String> values) {
            addCriterion("ind_cent_asis not in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisBetween(String value1, String value2) {
            addCriterion("ind_cent_asis between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotBetween(String value1, String value2) {
            addCriterion("ind_cent_asis not between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodCatIsNull() {
            addCriterion("cod_cat is null");
            return this;
        }

        public Criteria andCodCatIsNotNull() {
            addCriterion("cod_cat is not null");
            return this;
        }

        public Criteria andCodCatEqualTo(Short value) {
            addCriterion("cod_cat =", value, "codCat");
            return this;
        }

        public Criteria andCodCatNotEqualTo(Short value) {
            addCriterion("cod_cat <>", value, "codCat");
            return this;
        }

        public Criteria andCodCatGreaterThan(Short value) {
            addCriterion("cod_cat >", value, "codCat");
            return this;
        }

        public Criteria andCodCatGreaterThanOrEqualTo(Short value) {
            addCriterion("cod_cat >=", value, "codCat");
            return this;
        }

        public Criteria andCodCatLessThan(Short value) {
            addCriterion("cod_cat <", value, "codCat");
            return this;
        }

        public Criteria andCodCatLessThanOrEqualTo(Short value) {
            addCriterion("cod_cat <=", value, "codCat");
            return this;
        }

        public Criteria andCodCatIn(List<Short> values) {
            addCriterion("cod_cat in", values, "codCat");
            return this;
        }

        public Criteria andCodCatNotIn(List<Short> values) {
            addCriterion("cod_cat not in", values, "codCat");
            return this;
        }

        public Criteria andCodCatBetween(Short value1, Short value2) {
            addCriterion("cod_cat between", value1, value2, "codCat");
            return this;
        }

        public Criteria andCodCatNotBetween(Short value1, Short value2) {
            addCriterion("cod_cat not between", value1, value2, "codCat");
            return this;
        }

        public Criteria andCodFaseIsNull() {
            addCriterion("cod_fase is null");
            return this;
        }

        public Criteria andCodFaseIsNotNull() {
            addCriterion("cod_fase is not null");
            return this;
        }

        public Criteria andCodFaseEqualTo(String value) {
            addCriterion("cod_fase =", value, "codFase");
            return this;
        }

        public Criteria andCodFaseNotEqualTo(String value) {
            addCriterion("cod_fase <>", value, "codFase");
            return this;
        }

        public Criteria andCodFaseGreaterThan(String value) {
            addCriterion("cod_fase >", value, "codFase");
            return this;
        }

        public Criteria andCodFaseGreaterThanOrEqualTo(String value) {
            addCriterion("cod_fase >=", value, "codFase");
            return this;
        }

        public Criteria andCodFaseLessThan(String value) {
            addCriterion("cod_fase <", value, "codFase");
            return this;
        }

        public Criteria andCodFaseLessThanOrEqualTo(String value) {
            addCriterion("cod_fase <=", value, "codFase");
            return this;
        }

        public Criteria andCodFaseLike(String value) {
            addCriterion("cod_fase like", value, "codFase");
            return this;
        }

        public Criteria andCodFaseNotLike(String value) {
            addCriterion("cod_fase not like", value, "codFase");
            return this;
        }

        public Criteria andCodFaseIn(List<String> values) {
            addCriterion("cod_fase in", values, "codFase");
            return this;
        }

        public Criteria andCodFaseNotIn(List<String> values) {
            addCriterion("cod_fase not in", values, "codFase");
            return this;
        }

        public Criteria andCodFaseBetween(String value1, String value2) {
            addCriterion("cod_fase between", value1, value2, "codFase");
            return this;
        }

        public Criteria andCodFaseNotBetween(String value1, String value2) {
            addCriterion("cod_fase not between", value1, value2, "codFase");
            return this;
        }

        public Criteria andIndEstudioIsNull() {
            addCriterion("ind_estudio is null");
            return this;
        }

        public Criteria andIndEstudioIsNotNull() {
            addCriterion("ind_estudio is not null");
            return this;
        }

        public Criteria andIndEstudioEqualTo(String value) {
            addCriterion("ind_estudio =", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioNotEqualTo(String value) {
            addCriterion("ind_estudio <>", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioGreaterThan(String value) {
            addCriterion("ind_estudio >", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioGreaterThanOrEqualTo(String value) {
            addCriterion("ind_estudio >=", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioLessThan(String value) {
            addCriterion("ind_estudio <", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioLessThanOrEqualTo(String value) {
            addCriterion("ind_estudio <=", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioLike(String value) {
            addCriterion("ind_estudio like", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioNotLike(String value) {
            addCriterion("ind_estudio not like", value, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioIn(List<String> values) {
            addCriterion("ind_estudio in", values, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioNotIn(List<String> values) {
            addCriterion("ind_estudio not in", values, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioBetween(String value1, String value2) {
            addCriterion("ind_estudio between", value1, value2, "indEstudio");
            return this;
        }

        public Criteria andIndEstudioNotBetween(String value1, String value2) {
            addCriterion("ind_estudio not between", value1, value2, "indEstudio");
            return this;
        }

        public Criteria andDesEdadIsNull() {
            addCriterion("des_edad is null");
            return this;
        }

        public Criteria andDesEdadIsNotNull() {
            addCriterion("des_edad is not null");
            return this;
        }

        public Criteria andDesEdadEqualTo(String value) {
            addCriterion("des_edad =", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadNotEqualTo(String value) {
            addCriterion("des_edad <>", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadGreaterThan(String value) {
            addCriterion("des_edad >", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadGreaterThanOrEqualTo(String value) {
            addCriterion("des_edad >=", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadLessThan(String value) {
            addCriterion("des_edad <", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadLessThanOrEqualTo(String value) {
            addCriterion("des_edad <=", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadLike(String value) {
            addCriterion("des_edad like", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadNotLike(String value) {
            addCriterion("des_edad not like", value, "desEdad");
            return this;
        }

        public Criteria andDesEdadIn(List<String> values) {
            addCriterion("des_edad in", values, "desEdad");
            return this;
        }

        public Criteria andDesEdadNotIn(List<String> values) {
            addCriterion("des_edad not in", values, "desEdad");
            return this;
        }

        public Criteria andDesEdadBetween(String value1, String value2) {
            addCriterion("des_edad between", value1, value2, "desEdad");
            return this;
        }

        public Criteria andDesEdadNotBetween(String value1, String value2) {
            addCriterion("des_edad not between", value1, value2, "desEdad");
            return this;
        }

        public Criteria andIndEstadoIsNull() {
            addCriterion("ind_estado is null");
            return this;
        }

        public Criteria andIndEstadoIsNotNull() {
            addCriterion("ind_estado is not null");
            return this;
        }

        public Criteria andIndEstadoEqualTo(String value) {
            addCriterion("ind_estado =", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotEqualTo(String value) {
            addCriterion("ind_estado <>", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoGreaterThan(String value) {
            addCriterion("ind_estado >", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_estado >=", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLessThan(String value) {
            addCriterion("ind_estado <", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLessThanOrEqualTo(String value) {
            addCriterion("ind_estado <=", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLike(String value) {
            addCriterion("ind_estado like", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotLike(String value) {
            addCriterion("ind_estado not like", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoIn(List<String> values) {
            addCriterion("ind_estado in", values, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotIn(List<String> values) {
            addCriterion("ind_estado not in", values, "indEstado");
            return this;
        }

        public Criteria andIndEstadoBetween(String value1, String value2) {
            addCriterion("ind_estado between", value1, value2, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotBetween(String value1, String value2) {
            addCriterion("ind_estado not between", value1, value2, "indEstado");
            return this;
        }
    }
}