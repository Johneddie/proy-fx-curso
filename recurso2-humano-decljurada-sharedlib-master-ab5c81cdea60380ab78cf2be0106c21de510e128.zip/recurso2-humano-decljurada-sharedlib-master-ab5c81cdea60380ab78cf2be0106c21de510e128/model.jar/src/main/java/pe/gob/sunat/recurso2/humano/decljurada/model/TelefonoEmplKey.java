package pe.gob.sunat.recurso2.humano.decljurada.model;

public class TelefonoEmplKey {
    private String codPers;

    private String numero;

    private String tipLinea;

    public String getCodPers() {
        return codPers;
    }

    public void setCodPers(String codPers) {
        this.codPers = codPers == null ? null : codPers.trim();
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero == null ? null : numero.trim();
    }

    public String getTipLinea() {
        return tipLinea;
    }

    public void setTipLinea(String tipLinea) {
        this.tipLinea = tipLinea == null ? null : tipLinea.trim();
    }
}