package pe.gob.sunat.recurso2.humano.decljurada.model;

public class FichaHistoricoKey {
    private Short codCat;

    private String codPuesto;

    private Integer numPostulante;

    public Short getCodCat() {
        return codCat;
    }

    public void setCodCat(Short codCat) {
        this.codCat = codCat;
    }

    public String getCodPuesto() {
        return codPuesto;
    }

    public void setCodPuesto(String codPuesto) {
        this.codPuesto = codPuesto == null ? null : codPuesto.trim();
    }

    public Integer getNumPostulante() {
        return numPostulante;
    }

    public void setNumPostulante(Integer numPostulante) {
        this.numPostulante = numPostulante;
    }
}