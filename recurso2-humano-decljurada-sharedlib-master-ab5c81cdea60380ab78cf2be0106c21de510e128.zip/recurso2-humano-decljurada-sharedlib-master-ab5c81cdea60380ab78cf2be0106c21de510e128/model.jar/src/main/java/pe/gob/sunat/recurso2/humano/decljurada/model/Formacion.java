package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.math.BigDecimal;
import java.util.Date;

public class Formacion {
    private String t29codPers;

    private String t29codGrado;

    private String t29codUni;

    private String t29codEsp;

    private String t29numCole;

    private String t29finGrado;

    private String t29sustento;

    private String t29observa;

    private String t29desGrado;

    private String tituVerif;

    private Date t29fGraba;

    private String t29codUser;

    private BigDecimal numHoras;

    private String indOrigen;

    private Date fecPresenta;

    public String getT29codPers() {
        return t29codPers;
    }

    public void setT29codPers(String t29codPers) {
        this.t29codPers = t29codPers == null ? null : t29codPers.trim();
    }

    public String getT29codGrado() {
        return t29codGrado;
    }

    public void setT29codGrado(String t29codGrado) {
        this.t29codGrado = t29codGrado == null ? null : t29codGrado.trim();
    }

    public String getT29codUni() {
        return t29codUni;
    }

    public void setT29codUni(String t29codUni) {
        this.t29codUni = t29codUni == null ? null : t29codUni.trim();
    }

    public String getT29codEsp() {
        return t29codEsp;
    }

    public void setT29codEsp(String t29codEsp) {
        this.t29codEsp = t29codEsp == null ? null : t29codEsp.trim();
    }

    public String getT29numCole() {
        return t29numCole;
    }

    public void setT29numCole(String t29numCole) {
        this.t29numCole = t29numCole == null ? null : t29numCole.trim();
    }

    public String getT29finGrado() {
        return t29finGrado;
    }

    public void setT29finGrado(String t29finGrado) {
        this.t29finGrado = t29finGrado == null ? null : t29finGrado.trim();
    }

    public String getT29sustento() {
        return t29sustento;
    }

    public void setT29sustento(String t29sustento) {
        this.t29sustento = t29sustento == null ? null : t29sustento.trim();
    }

    public String getT29observa() {
        return t29observa;
    }

    public void setT29observa(String t29observa) {
        this.t29observa = t29observa == null ? null : t29observa.trim();
    }

    public String getT29desGrado() {
        return t29desGrado;
    }

    public void setT29desGrado(String t29desGrado) {
        this.t29desGrado = t29desGrado == null ? null : t29desGrado.trim();
    }

    public String getTituVerif() {
        return tituVerif;
    }

    public void setTituVerif(String tituVerif) {
        this.tituVerif = tituVerif == null ? null : tituVerif.trim();
    }

    public Date getT29fGraba() {
        return t29fGraba;
    }

    public void setT29fGraba(Date t29fGraba) {
        this.t29fGraba = t29fGraba;
    }

    public String getT29codUser() {
        return t29codUser;
    }

    public void setT29codUser(String t29codUser) {
        this.t29codUser = t29codUser == null ? null : t29codUser.trim();
    }

    public BigDecimal getNumHoras() {
        return numHoras;
    }

    public void setNumHoras(BigDecimal numHoras) {
        this.numHoras = numHoras;
    }

    public String getIndOrigen() {
        return indOrigen;
    }

    public void setIndOrigen(String indOrigen) {
        this.indOrigen = indOrigen == null ? null : indOrigen.trim();
    }

    public Date getFecPresenta() {
        return fecPresenta;
    }

    public void setFecPresenta(Date fecPresenta) {
        this.fecPresenta = fecPresenta;
    }
}