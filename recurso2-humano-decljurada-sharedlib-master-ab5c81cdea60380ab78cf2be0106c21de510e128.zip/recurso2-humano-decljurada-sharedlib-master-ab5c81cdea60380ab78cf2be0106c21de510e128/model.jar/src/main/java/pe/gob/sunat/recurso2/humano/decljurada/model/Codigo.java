package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Codigo {
    private String t99codTab;

    private String t99tipDesc;

    private String t99codigo;

    private String t99descrip;

    private String t99abrev;

    private String t99siglas;

    private String t99tipo;

    private String t99estado;

    private String t99codUser;

    private Date t99Factual;

    private String t99Modulo;

    private String codClasif1;

    private String codClasif2;

    public String getT99codTab() {
        return t99codTab;
    }

    public void setT99codTab(String t99codTab) {
        this.t99codTab = t99codTab == null ? null : t99codTab.trim();
    }

    public String getT99tipDesc() {
        return t99tipDesc;
    }

    public void setT99tipDesc(String t99tipDesc) {
        this.t99tipDesc = t99tipDesc == null ? null : t99tipDesc.trim();
    }

    public String getT99codigo() {
        return t99codigo;
    }

    public void setT99codigo(String t99codigo) {
        this.t99codigo = t99codigo == null ? null : t99codigo.trim();
    }

    public String getT99descrip() {
        return t99descrip;
    }

    public void setT99descrip(String t99descrip) {
        this.t99descrip = t99descrip == null ? null : t99descrip.trim();
    }

    public String getT99abrev() {
        return t99abrev;
    }

    public void setT99abrev(String t99abrev) {
        this.t99abrev = t99abrev == null ? null : t99abrev.trim();
    }

    public String getT99siglas() {
        return t99siglas;
    }

    public void setT99siglas(String t99siglas) {
        this.t99siglas = t99siglas == null ? null : t99siglas.trim();
    }

    public String getT99tipo() {
        return t99tipo;
    }

    public void setT99tipo(String t99tipo) {
        this.t99tipo = t99tipo == null ? null : t99tipo.trim();
    }

    public String getT99estado() {
        return t99estado;
    }

    public void setT99estado(String t99estado) {
        this.t99estado = t99estado == null ? null : t99estado.trim();
    }

    public String getT99codUser() {
        return t99codUser;
    }

    public void setT99codUser(String t99codUser) {
        this.t99codUser = t99codUser == null ? null : t99codUser.trim();
    }

    public Date getT99Factual() {
        return t99Factual;
    }

    public void setT99Factual(Date t99Factual) {
        this.t99Factual = t99Factual;
    }

    public String getT99Modulo() {
        return t99Modulo;
    }

    public void setT99Modulo(String t99Modulo) {
        this.t99Modulo = t99Modulo == null ? null : t99Modulo.trim();
    }

    public String getCodClasif1() {
        return codClasif1;
    }

    public void setCodClasif1(String codClasif1) {
        this.codClasif1 = codClasif1 == null ? null : codClasif1.trim();
    }

    public String getCodClasif2() {
        return codClasif2;
    }

    public void setCodClasif2(String codClasif2) {
        this.codClasif2 = codClasif2 == null ? null : codClasif2.trim();
    }
}