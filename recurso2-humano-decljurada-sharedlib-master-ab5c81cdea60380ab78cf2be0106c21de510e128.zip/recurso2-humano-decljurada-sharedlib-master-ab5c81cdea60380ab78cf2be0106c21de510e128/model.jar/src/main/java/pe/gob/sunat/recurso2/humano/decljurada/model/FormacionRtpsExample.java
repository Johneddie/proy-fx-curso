package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FormacionRtpsExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public FormacionRtpsExample() {
        oredCriteria = new ArrayList<>();
    }

    protected FormacionRtpsExample(FormacionRtpsExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andAnnDdjjIsNull() {
            addCriterion("ann_ddjj is null");
            return this;
        }

        public Criteria andAnnDdjjIsNotNull() {
            addCriterion("ann_ddjj is not null");
            return this;
        }

        public Criteria andAnnDdjjEqualTo(String value) {
            addCriterion("ann_ddjj =", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotEqualTo(String value) {
            addCriterion("ann_ddjj <>", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThan(String value) {
            addCriterion("ann_ddjj >", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThanOrEqualTo(String value) {
            addCriterion("ann_ddjj >=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThan(String value) {
            addCriterion("ann_ddjj <", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThanOrEqualTo(String value) {
            addCriterion("ann_ddjj <=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLike(String value) {
            addCriterion("ann_ddjj like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotLike(String value) {
            addCriterion("ann_ddjj not like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjIn(List<String> values) {
            addCriterion("ann_ddjj in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotIn(List<String> values) {
            addCriterion("ann_ddjj not in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjBetween(String value1, String value2) {
            addCriterion("ann_ddjj between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotBetween(String value1, String value2) {
            addCriterion("ann_ddjj not between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andNumCorrelIsNull() {
            addCriterion("num_correl is null");
            return this;
        }

        public Criteria andNumCorrelIsNotNull() {
            addCriterion("num_correl is not null");
            return this;
        }

        public Criteria andNumCorrelEqualTo(Short value) {
            addCriterion("num_correl =", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotEqualTo(Short value) {
            addCriterion("num_correl <>", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelGreaterThan(Short value) {
            addCriterion("num_correl >", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelGreaterThanOrEqualTo(Short value) {
            addCriterion("num_correl >=", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelLessThan(Short value) {
            addCriterion("num_correl <", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelLessThanOrEqualTo(Short value) {
            addCriterion("num_correl <=", value, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelIn(List<Short> values) {
            addCriterion("num_correl in", values, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotIn(List<Short> values) {
            addCriterion("num_correl not in", values, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelBetween(Short value1, Short value2) {
            addCriterion("num_correl between", value1, value2, "numCorrel");
            return this;
        }

        public Criteria andNumCorrelNotBetween(Short value1, Short value2) {
            addCriterion("num_correl not between", value1, value2, "numCorrel");
            return this;
        }

        public Criteria andNumDdjjIsNull() {
            addCriterion("num_ddjj is null");
            return this;
        }

        public Criteria andNumDdjjIsNotNull() {
            addCriterion("num_ddjj is not null");
            return this;
        }

        public Criteria andNumDdjjEqualTo(Integer value) {
            addCriterion("num_ddjj =", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotEqualTo(Integer value) {
            addCriterion("num_ddjj <>", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThan(Integer value) {
            addCriterion("num_ddjj >", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj >=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThan(Integer value) {
            addCriterion("num_ddjj <", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj <=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjIn(List<Integer> values) {
            addCriterion("num_ddjj in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotIn(List<Integer> values) {
            addCriterion("num_ddjj not in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj not between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andCodGraAcaIsNull() {
            addCriterion("cod_gra_aca is null");
            return this;
        }

        public Criteria andCodGraAcaIsNotNull() {
            addCriterion("cod_gra_aca is not null");
            return this;
        }

        public Criteria andCodGraAcaEqualTo(String value) {
            addCriterion("cod_gra_aca =", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaNotEqualTo(String value) {
            addCriterion("cod_gra_aca <>", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaGreaterThan(String value) {
            addCriterion("cod_gra_aca >", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_gra_aca >=", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaLessThan(String value) {
            addCriterion("cod_gra_aca <", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaLessThanOrEqualTo(String value) {
            addCriterion("cod_gra_aca <=", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaLike(String value) {
            addCriterion("cod_gra_aca like", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaNotLike(String value) {
            addCriterion("cod_gra_aca not like", value, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaIn(List<String> values) {
            addCriterion("cod_gra_aca in", values, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaNotIn(List<String> values) {
            addCriterion("cod_gra_aca not in", values, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaBetween(String value1, String value2) {
            addCriterion("cod_gra_aca between", value1, value2, "codGraAca");
            return this;
        }

        public Criteria andCodGraAcaNotBetween(String value1, String value2) {
            addCriterion("cod_gra_aca not between", value1, value2, "codGraAca");
            return this;
        }

        public Criteria andCodInstIsNull() {
            addCriterion("cod_inst is null");
            return this;
        }

        public Criteria andCodInstIsNotNull() {
            addCriterion("cod_inst is not null");
            return this;
        }

        public Criteria andCodInstEqualTo(String value) {
            addCriterion("cod_inst =", value, "codInst");
            return this;
        }

        public Criteria andCodInstNotEqualTo(String value) {
            addCriterion("cod_inst <>", value, "codInst");
            return this;
        }

        public Criteria andCodInstGreaterThan(String value) {
            addCriterion("cod_inst >", value, "codInst");
            return this;
        }

        public Criteria andCodInstGreaterThanOrEqualTo(String value) {
            addCriterion("cod_inst >=", value, "codInst");
            return this;
        }

        public Criteria andCodInstLessThan(String value) {
            addCriterion("cod_inst <", value, "codInst");
            return this;
        }

        public Criteria andCodInstLessThanOrEqualTo(String value) {
            addCriterion("cod_inst <=", value, "codInst");
            return this;
        }

        public Criteria andCodInstLike(String value) {
            addCriterion("cod_inst like", value, "codInst");
            return this;
        }

        public Criteria andCodInstNotLike(String value) {
            addCriterion("cod_inst not like", value, "codInst");
            return this;
        }

        public Criteria andCodInstIn(List<String> values) {
            addCriterion("cod_inst in", values, "codInst");
            return this;
        }

        public Criteria andCodInstNotIn(List<String> values) {
            addCriterion("cod_inst not in", values, "codInst");
            return this;
        }

        public Criteria andCodInstBetween(String value1, String value2) {
            addCriterion("cod_inst between", value1, value2, "codInst");
            return this;
        }

        public Criteria andCodInstNotBetween(String value1, String value2) {
            addCriterion("cod_inst not between", value1, value2, "codInst");
            return this;
        }

        public Criteria andCodEspeIsNull() {
            addCriterion("cod_espe is null");
            return this;
        }

        public Criteria andCodEspeIsNotNull() {
            addCriterion("cod_espe is not null");
            return this;
        }

        public Criteria andCodEspeEqualTo(String value) {
            addCriterion("cod_espe =", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeNotEqualTo(String value) {
            addCriterion("cod_espe <>", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeGreaterThan(String value) {
            addCriterion("cod_espe >", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeGreaterThanOrEqualTo(String value) {
            addCriterion("cod_espe >=", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeLessThan(String value) {
            addCriterion("cod_espe <", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeLessThanOrEqualTo(String value) {
            addCriterion("cod_espe <=", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeLike(String value) {
            addCriterion("cod_espe like", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeNotLike(String value) {
            addCriterion("cod_espe not like", value, "codEspe");
            return this;
        }

        public Criteria andCodEspeIn(List<String> values) {
            addCriterion("cod_espe in", values, "codEspe");
            return this;
        }

        public Criteria andCodEspeNotIn(List<String> values) {
            addCriterion("cod_espe not in", values, "codEspe");
            return this;
        }

        public Criteria andCodEspeBetween(String value1, String value2) {
            addCriterion("cod_espe between", value1, value2, "codEspe");
            return this;
        }

        public Criteria andCodEspeNotBetween(String value1, String value2) {
            addCriterion("cod_espe not between", value1, value2, "codEspe");
            return this;
        }

        public Criteria andCodOrdMerIsNull() {
            addCriterion("cod_ord_mer is null");
            return this;
        }

        public Criteria andCodOrdMerIsNotNull() {
            addCriterion("cod_ord_mer is not null");
            return this;
        }

        public Criteria andCodOrdMerEqualTo(String value) {
            addCriterion("cod_ord_mer =", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerNotEqualTo(String value) {
            addCriterion("cod_ord_mer <>", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerGreaterThan(String value) {
            addCriterion("cod_ord_mer >", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ord_mer >=", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerLessThan(String value) {
            addCriterion("cod_ord_mer <", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerLessThanOrEqualTo(String value) {
            addCriterion("cod_ord_mer <=", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerLike(String value) {
            addCriterion("cod_ord_mer like", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerNotLike(String value) {
            addCriterion("cod_ord_mer not like", value, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerIn(List<String> values) {
            addCriterion("cod_ord_mer in", values, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerNotIn(List<String> values) {
            addCriterion("cod_ord_mer not in", values, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerBetween(String value1, String value2) {
            addCriterion("cod_ord_mer between", value1, value2, "codOrdMer");
            return this;
        }

        public Criteria andCodOrdMerNotBetween(String value1, String value2) {
            addCriterion("cod_ord_mer not between", value1, value2, "codOrdMer");
            return this;
        }

        public Criteria andFecIniIsNull() {
            addCriterion("fec_ini is null");
            return this;
        }

        public Criteria andFecIniIsNotNull() {
            addCriterion("fec_ini is not null");
            return this;
        }

        public Criteria andFecIniEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini =", value, "fecIni");
            return this;
        }

        public Criteria andFecIniNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini <>", value, "fecIni");
            return this;
        }

        public Criteria andFecIniGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_ini >", value, "fecIni");
            return this;
        }

        public Criteria andFecIniGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini >=", value, "fecIni");
            return this;
        }

        public Criteria andFecIniLessThan(Date value) {
            addCriterionForJDBCDate("fec_ini <", value, "fecIni");
            return this;
        }

        public Criteria andFecIniLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini <=", value, "fecIni");
            return this;
        }

        public Criteria andFecIniIn(List<Date> values) {
            addCriterionForJDBCDate("fec_ini in", values, "fecIni");
            return this;
        }

        public Criteria andFecIniNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_ini not in", values, "fecIni");
            return this;
        }

        public Criteria andFecIniBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_ini between", value1, value2, "fecIni");
            return this;
        }

        public Criteria andFecIniNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_ini not between", value1, value2, "fecIni");
            return this;
        }

        public Criteria andFecFinIsNull() {
            addCriterion("fec_fin is null");
            return this;
        }

        public Criteria andFecFinIsNotNull() {
            addCriterion("fec_fin is not null");
            return this;
        }

        public Criteria andFecFinEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin =", value, "fecFin");
            return this;
        }

        public Criteria andFecFinNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin <>", value, "fecFin");
            return this;
        }

        public Criteria andFecFinGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_fin >", value, "fecFin");
            return this;
        }

        public Criteria andFecFinGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin >=", value, "fecFin");
            return this;
        }

        public Criteria andFecFinLessThan(Date value) {
            addCriterionForJDBCDate("fec_fin <", value, "fecFin");
            return this;
        }

        public Criteria andFecFinLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin <=", value, "fecFin");
            return this;
        }

        public Criteria andFecFinIn(List<Date> values) {
            addCriterionForJDBCDate("fec_fin in", values, "fecFin");
            return this;
        }

        public Criteria andFecFinNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_fin not in", values, "fecFin");
            return this;
        }

        public Criteria andFecFinBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_fin between", value1, value2, "fecFin");
            return this;
        }

        public Criteria andFecFinNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_fin not between", value1, value2, "fecFin");
            return this;
        }

        public Criteria andDesNotaIsNull() {
            addCriterion("des_nota is null");
            return this;
        }

        public Criteria andDesNotaIsNotNull() {
            addCriterion("des_nota is not null");
            return this;
        }

        public Criteria andDesNotaEqualTo(String value) {
            addCriterion("des_nota =", value, "desNota");
            return this;
        }

        public Criteria andDesNotaNotEqualTo(String value) {
            addCriterion("des_nota <>", value, "desNota");
            return this;
        }

        public Criteria andDesNotaGreaterThan(String value) {
            addCriterion("des_nota >", value, "desNota");
            return this;
        }

        public Criteria andDesNotaGreaterThanOrEqualTo(String value) {
            addCriterion("des_nota >=", value, "desNota");
            return this;
        }

        public Criteria andDesNotaLessThan(String value) {
            addCriterion("des_nota <", value, "desNota");
            return this;
        }

        public Criteria andDesNotaLessThanOrEqualTo(String value) {
            addCriterion("des_nota <=", value, "desNota");
            return this;
        }

        public Criteria andDesNotaLike(String value) {
            addCriterion("des_nota like", value, "desNota");
            return this;
        }

        public Criteria andDesNotaNotLike(String value) {
            addCriterion("des_nota not like", value, "desNota");
            return this;
        }

        public Criteria andDesNotaIn(List<String> values) {
            addCriterion("des_nota in", values, "desNota");
            return this;
        }

        public Criteria andDesNotaNotIn(List<String> values) {
            addCriterion("des_nota not in", values, "desNota");
            return this;
        }

        public Criteria andDesNotaBetween(String value1, String value2) {
            addCriterion("des_nota between", value1, value2, "desNota");
            return this;
        }

        public Criteria andDesNotaNotBetween(String value1, String value2) {
            addCriterion("des_nota not between", value1, value2, "desNota");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }
    }
}