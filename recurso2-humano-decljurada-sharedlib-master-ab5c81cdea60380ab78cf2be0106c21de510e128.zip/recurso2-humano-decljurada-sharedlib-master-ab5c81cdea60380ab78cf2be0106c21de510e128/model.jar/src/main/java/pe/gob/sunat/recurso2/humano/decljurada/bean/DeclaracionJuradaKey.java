package pe.gob.sunat.recurso2.humano.decljurada.bean;

public interface DeclaracionJuradaKey {


    public String getAnnDdjj();

    public void setAnnDdjj(String annDdjj);

    public String getIndEstado();

    public void setIndEstado(String indEstado);

    public Integer getNumDdjj();

    public void setNumDdjj(Integer numDdjj);
}