package pe.gob.sunat.recurso2.humano.decljurada.bean;

public class PersonaReniec {

	private String codDepartamento;
	private String codDistrito;
	private String codProvincia;
	private String desApematPnat;
	private String desApepatPnat;
	private String desDepartamento;
	private String desDistrito;
	private String desDomiciPnat;
	private String desEstcivPnat;
	private String desNombrePnat;
	private String desProvincia;
	private String desRestriccion;
	private String desSexoPnat;
	private String fecNacPnat;
	private String numDocidePnat;
	private String codUbigeoPnat;
	
	public String getCodDepartamento() {
		return codDepartamento;
	}
	public void setCodDepartamento(String codDepartamento) {
		this.codDepartamento = codDepartamento;
	}
	public String getCodDistrito() {
		return codDistrito;
	}
	public void setCodDistrito(String codDistrito) {
		this.codDistrito = codDistrito;
	}
	public String getCodProvincia() {
		return codProvincia;
	}
	public void setCodProvincia(String codProvincia) {
		this.codProvincia = codProvincia;
	}
	public String getDesApematPnat() {
		return desApematPnat;
	}
	public void setDesApematPnat(String desApematPnat) {
		this.desApematPnat = desApematPnat;
	}
	public String getDesApepatPnat() {
		return desApepatPnat;
	}
	public void setDesApepatPnat(String desApepatPnat) {
		this.desApepatPnat = desApepatPnat;
	}
	public String getDesDepartamento() {
		return desDepartamento;
	}
	public void setDesDepartamento(String desDepartamento) {
		this.desDepartamento = desDepartamento;
	}
	public String getDesDistrito() {
		return desDistrito;
	}
	public void setDesDistrito(String desDistrito) {
		this.desDistrito = desDistrito;
	}
	public String getDesDomiciPnat() {
		return desDomiciPnat;
	}
	public void setDesDomiciPnat(String desDomiciPnat) {
		this.desDomiciPnat = desDomiciPnat;
	}
	public String getDesEstcivPnat() {
		return desEstcivPnat;
	}
	public void setDesEstcivPnat(String desEstcivPnat) {
		this.desEstcivPnat = desEstcivPnat;
	}
	public String getDesNombrePnat() {
		return desNombrePnat;
	}
	public void setDesNombrePnat(String desNombrePnat) {
		this.desNombrePnat = desNombrePnat;
	}
	public String getDesProvincia() {
		return desProvincia;
	}
	public void setDesProvincia(String desProvincia) {
		this.desProvincia = desProvincia;
	}
	public String getDesRestriccion() {
		return desRestriccion;
	}
	public void setDesRestriccion(String desRestriccion) {
		this.desRestriccion = desRestriccion;
	}
	public String getDesSexoPnat() {
		return desSexoPnat;
	}
	public void setDesSexoPnat(String desSexoPnat) {
		this.desSexoPnat = desSexoPnat;
	}
	public String getFecNacPnat() {
		return fecNacPnat;
	}
	public void setFecNacPnat(String fecNacPnat) {
		this.fecNacPnat = fecNacPnat;
	}
	public String getNumDocidePnat() {
		return numDocidePnat;
	}
	public void setNumDocidePnat(String numDocidePnat) {
		this.numDocidePnat = numDocidePnat;
	}
	public String getCodUbigeoPnat() {
		return codUbigeoPnat;
	}
	public void setCodUbigeoPnat(String codUbigeoPnat) {
		this.codUbigeoPnat = codUbigeoPnat;
	}
	
}
