package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Archivo extends ArchivoKey {
    private String codUsucrea;

    private Date fecCreacion;

    private String codUsumodif;

    private Date fecModif;

    private String desNombre;

    private String desComentario;

    private byte[] arcDdjj;
    
    private String codAccion; //1:nuevo 2:modificar

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getDesNombre() {
        return desNombre;
    }

    public void setDesNombre(String desNombre) {
        this.desNombre = desNombre == null ? null : desNombre.trim();
    }

    public String getDesComentario() {
        return desComentario;
    }

    public void setDesComentario(String desComentario) {
        this.desComentario = desComentario == null ? null : desComentario.trim();
    }

    public byte[] getArcDdjj() {
        return arcDdjj;
    }

    public void setArcDdjj(byte[] arcDdjj) {
        this.arcDdjj = arcDdjj;
    }

	public String getCodAccion() {
		return codAccion;
	}

	public void setCodAccion(String codAccion) {
		this.codAccion = codAccion;
	}
    
}