package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CorreoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public CorreoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected CorreoExample(CorreoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodPersIsNull() {
            addCriterion("cod_pers is null");
            return this;
        }

        public Criteria andCodPersIsNotNull() {
            addCriterion("cod_pers is not null");
            return this;
        }

        public Criteria andCodPersEqualTo(String value) {
            addCriterion("cod_pers =", value, "codPers");
            return this;
        }

        public Criteria andCodPersNotEqualTo(String value) {
            addCriterion("cod_pers <>", value, "codPers");
            return this;
        }

        public Criteria andCodPersGreaterThan(String value) {
            addCriterion("cod_pers >", value, "codPers");
            return this;
        }

        public Criteria andCodPersGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pers >=", value, "codPers");
            return this;
        }

        public Criteria andCodPersLessThan(String value) {
            addCriterion("cod_pers <", value, "codPers");
            return this;
        }

        public Criteria andCodPersLessThanOrEqualTo(String value) {
            addCriterion("cod_pers <=", value, "codPers");
            return this;
        }

        public Criteria andCodPersLike(String value) {
            addCriterion("cod_pers like", value, "codPers");
            return this;
        }

        public Criteria andCodPersNotLike(String value) {
            addCriterion("cod_pers not like", value, "codPers");
            return this;
        }

        public Criteria andCodPersIn(List<String> values) {
            addCriterion("cod_pers in", values, "codPers");
            return this;
        }

        public Criteria andCodPersNotIn(List<String> values) {
            addCriterion("cod_pers not in", values, "codPers");
            return this;
        }

        public Criteria andCodPersBetween(String value1, String value2) {
            addCriterion("cod_pers between", value1, value2, "codPers");
            return this;
        }

        public Criteria andCodPersNotBetween(String value1, String value2) {
            addCriterion("cod_pers not between", value1, value2, "codPers");
            return this;
        }

        public Criteria andSmtpIsNull() {
            addCriterion("smtp is null");
            return this;
        }

        public Criteria andSmtpIsNotNull() {
            addCriterion("smtp is not null");
            return this;
        }

        public Criteria andSmtpEqualTo(String value) {
            addCriterion("smtp =", value, "smtp");
            return this;
        }

        public Criteria andSmtpNotEqualTo(String value) {
            addCriterion("smtp <>", value, "smtp");
            return this;
        }

        public Criteria andSmtpGreaterThan(String value) {
            addCriterion("smtp >", value, "smtp");
            return this;
        }

        public Criteria andSmtpGreaterThanOrEqualTo(String value) {
            addCriterion("smtp >=", value, "smtp");
            return this;
        }

        public Criteria andSmtpLessThan(String value) {
            addCriterion("smtp <", value, "smtp");
            return this;
        }

        public Criteria andSmtpLessThanOrEqualTo(String value) {
            addCriterion("smtp <=", value, "smtp");
            return this;
        }

        public Criteria andSmtpLike(String value) {
            addCriterion("smtp like", value, "smtp");
            return this;
        }

        public Criteria andSmtpNotLike(String value) {
            addCriterion("smtp not like", value, "smtp");
            return this;
        }

        public Criteria andSmtpIn(List<String> values) {
            addCriterion("smtp in", values, "smtp");
            return this;
        }

        public Criteria andSmtpNotIn(List<String> values) {
            addCriterion("smtp not in", values, "smtp");
            return this;
        }

        public Criteria andSmtpBetween(String value1, String value2) {
            addCriterion("smtp between", value1, value2, "smtp");
            return this;
        }

        public Criteria andSmtpNotBetween(String value1, String value2) {
            addCriterion("smtp not between", value1, value2, "smtp");
            return this;
        }

        public Criteria andAliasIsNull() {
            addCriterion("alias is null");
            return this;
        }

        public Criteria andAliasIsNotNull() {
            addCriterion("alias is not null");
            return this;
        }

        public Criteria andAliasEqualTo(String value) {
            addCriterion("alias =", value, "alias");
            return this;
        }

        public Criteria andAliasNotEqualTo(String value) {
            addCriterion("alias <>", value, "alias");
            return this;
        }

        public Criteria andAliasGreaterThan(String value) {
            addCriterion("alias >", value, "alias");
            return this;
        }

        public Criteria andAliasGreaterThanOrEqualTo(String value) {
            addCriterion("alias >=", value, "alias");
            return this;
        }

        public Criteria andAliasLessThan(String value) {
            addCriterion("alias <", value, "alias");
            return this;
        }

        public Criteria andAliasLessThanOrEqualTo(String value) {
            addCriterion("alias <=", value, "alias");
            return this;
        }

        public Criteria andAliasLike(String value) {
            addCriterion("alias like", value, "alias");
            return this;
        }

        public Criteria andAliasNotLike(String value) {
            addCriterion("alias not like", value, "alias");
            return this;
        }

        public Criteria andAliasIn(List<String> values) {
            addCriterion("alias in", values, "alias");
            return this;
        }

        public Criteria andAliasNotIn(List<String> values) {
            addCriterion("alias not in", values, "alias");
            return this;
        }

        public Criteria andAliasBetween(String value1, String value2) {
            addCriterion("alias between", value1, value2, "alias");
            return this;
        }

        public Criteria andAliasNotBetween(String value1, String value2) {
            addCriterion("alias not between", value1, value2, "alias");
            return this;
        }
    }
}