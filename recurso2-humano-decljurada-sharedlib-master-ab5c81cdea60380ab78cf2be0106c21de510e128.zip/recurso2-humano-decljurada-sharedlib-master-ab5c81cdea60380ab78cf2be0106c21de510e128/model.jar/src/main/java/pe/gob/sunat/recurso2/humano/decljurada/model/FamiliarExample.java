package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FamiliarExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public FamiliarExample() {
        oredCriteria = new ArrayList<>();
    }

    protected FamiliarExample(FamiliarExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andT09codPersIsNull() {
            addCriterion("t09cod_pers is null");
            return this;
        }

        public Criteria andT09codPersIsNotNull() {
            addCriterion("t09cod_pers is not null");
            return this;
        }

        public Criteria andT09codPersEqualTo(String value) {
            addCriterion("t09cod_pers =", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersNotEqualTo(String value) {
            addCriterion("t09cod_pers <>", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersGreaterThan(String value) {
            addCriterion("t09cod_pers >", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersGreaterThanOrEqualTo(String value) {
            addCriterion("t09cod_pers >=", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersLessThan(String value) {
            addCriterion("t09cod_pers <", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersLessThanOrEqualTo(String value) {
            addCriterion("t09cod_pers <=", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersLike(String value) {
            addCriterion("t09cod_pers like", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersNotLike(String value) {
            addCriterion("t09cod_pers not like", value, "t09codPers");
            return this;
        }

        public Criteria andT09codPersIn(List<String> values) {
            addCriterion("t09cod_pers in", values, "t09codPers");
            return this;
        }

        public Criteria andT09codPersNotIn(List<String> values) {
            addCriterion("t09cod_pers not in", values, "t09codPers");
            return this;
        }

        public Criteria andT09codPersBetween(String value1, String value2) {
            addCriterion("t09cod_pers between", value1, value2, "t09codPers");
            return this;
        }

        public Criteria andT09codPersNotBetween(String value1, String value2) {
            addCriterion("t09cod_pers not between", value1, value2, "t09codPers");
            return this;
        }

        public Criteria andT09codFamiIsNull() {
            addCriterion("t09cod_fami is null");
            return this;
        }

        public Criteria andT09codFamiIsNotNull() {
            addCriterion("t09cod_fami is not null");
            return this;
        }

        public Criteria andT09codFamiEqualTo(String value) {
            addCriterion("t09cod_fami =", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiNotEqualTo(String value) {
            addCriterion("t09cod_fami <>", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiGreaterThan(String value) {
            addCriterion("t09cod_fami >", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiGreaterThanOrEqualTo(String value) {
            addCriterion("t09cod_fami >=", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiLessThan(String value) {
            addCriterion("t09cod_fami <", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiLessThanOrEqualTo(String value) {
            addCriterion("t09cod_fami <=", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiLike(String value) {
            addCriterion("t09cod_fami like", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiNotLike(String value) {
            addCriterion("t09cod_fami not like", value, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiIn(List<String> values) {
            addCriterion("t09cod_fami in", values, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiNotIn(List<String> values) {
            addCriterion("t09cod_fami not in", values, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiBetween(String value1, String value2) {
            addCriterion("t09cod_fami between", value1, value2, "t09codFami");
            return this;
        }

        public Criteria andT09codFamiNotBetween(String value1, String value2) {
            addCriterion("t09cod_fami not between", value1, value2, "t09codFami");
            return this;
        }

        public Criteria andT09correlIsNull() {
            addCriterion("t09correl is null");
            return this;
        }

        public Criteria andT09correlIsNotNull() {
            addCriterion("t09correl is not null");
            return this;
        }

        public Criteria andT09correlEqualTo(String value) {
            addCriterion("t09correl =", value, "t09correl");
            return this;
        }

        public Criteria andT09correlNotEqualTo(String value) {
            addCriterion("t09correl <>", value, "t09correl");
            return this;
        }

        public Criteria andT09correlGreaterThan(String value) {
            addCriterion("t09correl >", value, "t09correl");
            return this;
        }

        public Criteria andT09correlGreaterThanOrEqualTo(String value) {
            addCriterion("t09correl >=", value, "t09correl");
            return this;
        }

        public Criteria andT09correlLessThan(String value) {
            addCriterion("t09correl <", value, "t09correl");
            return this;
        }

        public Criteria andT09correlLessThanOrEqualTo(String value) {
            addCriterion("t09correl <=", value, "t09correl");
            return this;
        }

        public Criteria andT09correlLike(String value) {
            addCriterion("t09correl like", value, "t09correl");
            return this;
        }

        public Criteria andT09correlNotLike(String value) {
            addCriterion("t09correl not like", value, "t09correl");
            return this;
        }

        public Criteria andT09correlIn(List<String> values) {
            addCriterion("t09correl in", values, "t09correl");
            return this;
        }

        public Criteria andT09correlNotIn(List<String> values) {
            addCriterion("t09correl not in", values, "t09correl");
            return this;
        }

        public Criteria andT09correlBetween(String value1, String value2) {
            addCriterion("t09correl between", value1, value2, "t09correl");
            return this;
        }

        public Criteria andT09correlNotBetween(String value1, String value2) {
            addCriterion("t09correl not between", value1, value2, "t09correl");
            return this;
        }

        public Criteria andT09apPfamiIsNull() {
            addCriterion("t09ap_pfami is null");
            return this;
        }

        public Criteria andT09apPfamiIsNotNull() {
            addCriterion("t09ap_pfami is not null");
            return this;
        }

        public Criteria andT09apPfamiEqualTo(String value) {
            addCriterion("t09ap_pfami =", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiNotEqualTo(String value) {
            addCriterion("t09ap_pfami <>", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiGreaterThan(String value) {
            addCriterion("t09ap_pfami >", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiGreaterThanOrEqualTo(String value) {
            addCriterion("t09ap_pfami >=", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiLessThan(String value) {
            addCriterion("t09ap_pfami <", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiLessThanOrEqualTo(String value) {
            addCriterion("t09ap_pfami <=", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiLike(String value) {
            addCriterion("t09ap_pfami like", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiNotLike(String value) {
            addCriterion("t09ap_pfami not like", value, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiIn(List<String> values) {
            addCriterion("t09ap_pfami in", values, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiNotIn(List<String> values) {
            addCriterion("t09ap_pfami not in", values, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiBetween(String value1, String value2) {
            addCriterion("t09ap_pfami between", value1, value2, "t09apPfami");
            return this;
        }

        public Criteria andT09apPfamiNotBetween(String value1, String value2) {
            addCriterion("t09ap_pfami not between", value1, value2, "t09apPfami");
            return this;
        }

        public Criteria andT09apMfamiIsNull() {
            addCriterion("t09ap_mfami is null");
            return this;
        }

        public Criteria andT09apMfamiIsNotNull() {
            addCriterion("t09ap_mfami is not null");
            return this;
        }

        public Criteria andT09apMfamiEqualTo(String value) {
            addCriterion("t09ap_mfami =", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiNotEqualTo(String value) {
            addCriterion("t09ap_mfami <>", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiGreaterThan(String value) {
            addCriterion("t09ap_mfami >", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiGreaterThanOrEqualTo(String value) {
            addCriterion("t09ap_mfami >=", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiLessThan(String value) {
            addCriterion("t09ap_mfami <", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiLessThanOrEqualTo(String value) {
            addCriterion("t09ap_mfami <=", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiLike(String value) {
            addCriterion("t09ap_mfami like", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiNotLike(String value) {
            addCriterion("t09ap_mfami not like", value, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiIn(List<String> values) {
            addCriterion("t09ap_mfami in", values, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiNotIn(List<String> values) {
            addCriterion("t09ap_mfami not in", values, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiBetween(String value1, String value2) {
            addCriterion("t09ap_mfami between", value1, value2, "t09apMfami");
            return this;
        }

        public Criteria andT09apMfamiNotBetween(String value1, String value2) {
            addCriterion("t09ap_mfami not between", value1, value2, "t09apMfami");
            return this;
        }

        public Criteria andT09nombFaIsNull() {
            addCriterion("t09nomb_fa is null");
            return this;
        }

        public Criteria andT09nombFaIsNotNull() {
            addCriterion("t09nomb_fa is not null");
            return this;
        }

        public Criteria andT09nombFaEqualTo(String value) {
            addCriterion("t09nomb_fa =", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaNotEqualTo(String value) {
            addCriterion("t09nomb_fa <>", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaGreaterThan(String value) {
            addCriterion("t09nomb_fa >", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaGreaterThanOrEqualTo(String value) {
            addCriterion("t09nomb_fa >=", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaLessThan(String value) {
            addCriterion("t09nomb_fa <", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaLessThanOrEqualTo(String value) {
            addCriterion("t09nomb_fa <=", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaLike(String value) {
            addCriterion("t09nomb_fa like", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaNotLike(String value) {
            addCriterion("t09nomb_fa not like", value, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaIn(List<String> values) {
            addCriterion("t09nomb_fa in", values, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaNotIn(List<String> values) {
            addCriterion("t09nomb_fa not in", values, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaBetween(String value1, String value2) {
            addCriterion("t09nomb_fa between", value1, value2, "t09nombFa");
            return this;
        }

        public Criteria andT09nombFaNotBetween(String value1, String value2) {
            addCriterion("t09nomb_fa not between", value1, value2, "t09nombFa");
            return this;
        }

        public Criteria andT09codDctoIsNull() {
            addCriterion("t09cod_dcto is null");
            return this;
        }

        public Criteria andT09codDctoIsNotNull() {
            addCriterion("t09cod_dcto is not null");
            return this;
        }

        public Criteria andT09codDctoEqualTo(String value) {
            addCriterion("t09cod_dcto =", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoNotEqualTo(String value) {
            addCriterion("t09cod_dcto <>", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoGreaterThan(String value) {
            addCriterion("t09cod_dcto >", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoGreaterThanOrEqualTo(String value) {
            addCriterion("t09cod_dcto >=", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoLessThan(String value) {
            addCriterion("t09cod_dcto <", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoLessThanOrEqualTo(String value) {
            addCriterion("t09cod_dcto <=", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoLike(String value) {
            addCriterion("t09cod_dcto like", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoNotLike(String value) {
            addCriterion("t09cod_dcto not like", value, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoIn(List<String> values) {
            addCriterion("t09cod_dcto in", values, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoNotIn(List<String> values) {
            addCriterion("t09cod_dcto not in", values, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoBetween(String value1, String value2) {
            addCriterion("t09cod_dcto between", value1, value2, "t09codDcto");
            return this;
        }

        public Criteria andT09codDctoNotBetween(String value1, String value2) {
            addCriterion("t09cod_dcto not between", value1, value2, "t09codDcto");
            return this;
        }

        public Criteria andT09nroDctoIsNull() {
            addCriterion("t09nro_dcto is null");
            return this;
        }

        public Criteria andT09nroDctoIsNotNull() {
            addCriterion("t09nro_dcto is not null");
            return this;
        }

        public Criteria andT09nroDctoEqualTo(String value) {
            addCriterion("t09nro_dcto =", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoNotEqualTo(String value) {
            addCriterion("t09nro_dcto <>", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoGreaterThan(String value) {
            addCriterion("t09nro_dcto >", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoGreaterThanOrEqualTo(String value) {
            addCriterion("t09nro_dcto >=", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoLessThan(String value) {
            addCriterion("t09nro_dcto <", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoLessThanOrEqualTo(String value) {
            addCriterion("t09nro_dcto <=", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoLike(String value) {
            addCriterion("t09nro_dcto like", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoNotLike(String value) {
            addCriterion("t09nro_dcto not like", value, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoIn(List<String> values) {
            addCriterion("t09nro_dcto in", values, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoNotIn(List<String> values) {
            addCriterion("t09nro_dcto not in", values, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoBetween(String value1, String value2) {
            addCriterion("t09nro_dcto between", value1, value2, "t09nroDcto");
            return this;
        }

        public Criteria andT09nroDctoNotBetween(String value1, String value2) {
            addCriterion("t09nro_dcto not between", value1, value2, "t09nroDcto");
            return this;
        }

        public Criteria andT09estadoIsNull() {
            addCriterion("t09estado is null");
            return this;
        }

        public Criteria andT09estadoIsNotNull() {
            addCriterion("t09estado is not null");
            return this;
        }

        public Criteria andT09estadoEqualTo(String value) {
            addCriterion("t09estado =", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoNotEqualTo(String value) {
            addCriterion("t09estado <>", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoGreaterThan(String value) {
            addCriterion("t09estado >", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoGreaterThanOrEqualTo(String value) {
            addCriterion("t09estado >=", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoLessThan(String value) {
            addCriterion("t09estado <", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoLessThanOrEqualTo(String value) {
            addCriterion("t09estado <=", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoLike(String value) {
            addCriterion("t09estado like", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoNotLike(String value) {
            addCriterion("t09estado not like", value, "t09estado");
            return this;
        }

        public Criteria andT09estadoIn(List<String> values) {
            addCriterion("t09estado in", values, "t09estado");
            return this;
        }

        public Criteria andT09estadoNotIn(List<String> values) {
            addCriterion("t09estado not in", values, "t09estado");
            return this;
        }

        public Criteria andT09estadoBetween(String value1, String value2) {
            addCriterion("t09estado between", value1, value2, "t09estado");
            return this;
        }

        public Criteria andT09estadoNotBetween(String value1, String value2) {
            addCriterion("t09estado not between", value1, value2, "t09estado");
            return this;
        }

        public Criteria andT09fNacfaIsNull() {
            addCriterion("t09f_nacfa is null");
            return this;
        }

        public Criteria andT09fNacfaIsNotNull() {
            addCriterion("t09f_nacfa is not null");
            return this;
        }

        public Criteria andT09fNacfaEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_nacfa =", value, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaNotEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_nacfa <>", value, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaGreaterThan(Date value) {
            addCriterionForJDBCDate("t09f_nacfa >", value, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_nacfa >=", value, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaLessThan(Date value) {
            addCriterionForJDBCDate("t09f_nacfa <", value, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_nacfa <=", value, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaIn(List<Date> values) {
            addCriterionForJDBCDate("t09f_nacfa in", values, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaNotIn(List<Date> values) {
            addCriterionForJDBCDate("t09f_nacfa not in", values, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t09f_nacfa between", value1, value2, "t09fNacfa");
            return this;
        }

        public Criteria andT09fNacfaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t09f_nacfa not between", value1, value2, "t09fNacfa");
            return this;
        }

        public Criteria andT09fMatriIsNull() {
            addCriterion("t09f_matri is null");
            return this;
        }

        public Criteria andT09fMatriIsNotNull() {
            addCriterion("t09f_matri is not null");
            return this;
        }

        public Criteria andT09fMatriEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_matri =", value, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriNotEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_matri <>", value, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriGreaterThan(Date value) {
            addCriterionForJDBCDate("t09f_matri >", value, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_matri >=", value, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriLessThan(Date value) {
            addCriterionForJDBCDate("t09f_matri <", value, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("t09f_matri <=", value, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriIn(List<Date> values) {
            addCriterionForJDBCDate("t09f_matri in", values, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriNotIn(List<Date> values) {
            addCriterionForJDBCDate("t09f_matri not in", values, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t09f_matri between", value1, value2, "t09fMatri");
            return this;
        }

        public Criteria andT09fMatriNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("t09f_matri not between", value1, value2, "t09fMatri");
            return this;
        }

        public Criteria andT09trabFamiIsNull() {
            addCriterion("t09trab_fami is null");
            return this;
        }

        public Criteria andT09trabFamiIsNotNull() {
            addCriterion("t09trab_fami is not null");
            return this;
        }

        public Criteria andT09trabFamiEqualTo(String value) {
            addCriterion("t09trab_fami =", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiNotEqualTo(String value) {
            addCriterion("t09trab_fami <>", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiGreaterThan(String value) {
            addCriterion("t09trab_fami >", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiGreaterThanOrEqualTo(String value) {
            addCriterion("t09trab_fami >=", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiLessThan(String value) {
            addCriterion("t09trab_fami <", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiLessThanOrEqualTo(String value) {
            addCriterion("t09trab_fami <=", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiLike(String value) {
            addCriterion("t09trab_fami like", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiNotLike(String value) {
            addCriterion("t09trab_fami not like", value, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiIn(List<String> values) {
            addCriterion("t09trab_fami in", values, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiNotIn(List<String> values) {
            addCriterion("t09trab_fami not in", values, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiBetween(String value1, String value2) {
            addCriterion("t09trab_fami between", value1, value2, "t09trabFami");
            return this;
        }

        public Criteria andT09trabFamiNotBetween(String value1, String value2) {
            addCriterion("t09trab_fami not between", value1, value2, "t09trabFami");
            return this;
        }

        public Criteria andT09telfFamiIsNull() {
            addCriterion("t09telf_fami is null");
            return this;
        }

        public Criteria andT09telfFamiIsNotNull() {
            addCriterion("t09telf_fami is not null");
            return this;
        }

        public Criteria andT09telfFamiEqualTo(String value) {
            addCriterion("t09telf_fami =", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiNotEqualTo(String value) {
            addCriterion("t09telf_fami <>", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiGreaterThan(String value) {
            addCriterion("t09telf_fami >", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiGreaterThanOrEqualTo(String value) {
            addCriterion("t09telf_fami >=", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiLessThan(String value) {
            addCriterion("t09telf_fami <", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiLessThanOrEqualTo(String value) {
            addCriterion("t09telf_fami <=", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiLike(String value) {
            addCriterion("t09telf_fami like", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiNotLike(String value) {
            addCriterion("t09telf_fami not like", value, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiIn(List<String> values) {
            addCriterion("t09telf_fami in", values, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiNotIn(List<String> values) {
            addCriterion("t09telf_fami not in", values, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiBetween(String value1, String value2) {
            addCriterion("t09telf_fami between", value1, value2, "t09telfFami");
            return this;
        }

        public Criteria andT09telfFamiNotBetween(String value1, String value2) {
            addCriterion("t09telf_fami not between", value1, value2, "t09telfFami");
            return this;
        }

        public Criteria andT09pamfIsNull() {
            addCriterion("t09pamf is null");
            return this;
        }

        public Criteria andT09pamfIsNotNull() {
            addCriterion("t09pamf is not null");
            return this;
        }

        public Criteria andT09pamfEqualTo(String value) {
            addCriterion("t09pamf =", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfNotEqualTo(String value) {
            addCriterion("t09pamf <>", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfGreaterThan(String value) {
            addCriterion("t09pamf >", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfGreaterThanOrEqualTo(String value) {
            addCriterion("t09pamf >=", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfLessThan(String value) {
            addCriterion("t09pamf <", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfLessThanOrEqualTo(String value) {
            addCriterion("t09pamf <=", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfLike(String value) {
            addCriterion("t09pamf like", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfNotLike(String value) {
            addCriterion("t09pamf not like", value, "t09pamf");
            return this;
        }

        public Criteria andT09pamfIn(List<String> values) {
            addCriterion("t09pamf in", values, "t09pamf");
            return this;
        }

        public Criteria andT09pamfNotIn(List<String> values) {
            addCriterion("t09pamf not in", values, "t09pamf");
            return this;
        }

        public Criteria andT09pamfBetween(String value1, String value2) {
            addCriterion("t09pamf between", value1, value2, "t09pamf");
            return this;
        }

        public Criteria andT09pamfNotBetween(String value1, String value2) {
            addCriterion("t09pamf not between", value1, value2, "t09pamf");
            return this;
        }

        public Criteria andT09enSunatIsNull() {
            addCriterion("t09en_sunat is null");
            return this;
        }

        public Criteria andT09enSunatIsNotNull() {
            addCriterion("t09en_sunat is not null");
            return this;
        }

        public Criteria andT09enSunatEqualTo(String value) {
            addCriterion("t09en_sunat =", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatNotEqualTo(String value) {
            addCriterion("t09en_sunat <>", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatGreaterThan(String value) {
            addCriterion("t09en_sunat >", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatGreaterThanOrEqualTo(String value) {
            addCriterion("t09en_sunat >=", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatLessThan(String value) {
            addCriterion("t09en_sunat <", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatLessThanOrEqualTo(String value) {
            addCriterion("t09en_sunat <=", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatLike(String value) {
            addCriterion("t09en_sunat like", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatNotLike(String value) {
            addCriterion("t09en_sunat not like", value, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatIn(List<String> values) {
            addCriterion("t09en_sunat in", values, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatNotIn(List<String> values) {
            addCriterion("t09en_sunat not in", values, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatBetween(String value1, String value2) {
            addCriterion("t09en_sunat between", value1, value2, "t09enSunat");
            return this;
        }

        public Criteria andT09enSunatNotBetween(String value1, String value2) {
            addCriterion("t09en_sunat not between", value1, value2, "t09enSunat");
            return this;
        }

        public Criteria andT09codPersfIsNull() {
            addCriterion("t09cod_persf is null");
            return this;
        }

        public Criteria andT09codPersfIsNotNull() {
            addCriterion("t09cod_persf is not null");
            return this;
        }

        public Criteria andT09codPersfEqualTo(String value) {
            addCriterion("t09cod_persf =", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfNotEqualTo(String value) {
            addCriterion("t09cod_persf <>", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfGreaterThan(String value) {
            addCriterion("t09cod_persf >", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfGreaterThanOrEqualTo(String value) {
            addCriterion("t09cod_persf >=", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfLessThan(String value) {
            addCriterion("t09cod_persf <", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfLessThanOrEqualTo(String value) {
            addCriterion("t09cod_persf <=", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfLike(String value) {
            addCriterion("t09cod_persf like", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfNotLike(String value) {
            addCriterion("t09cod_persf not like", value, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfIn(List<String> values) {
            addCriterion("t09cod_persf in", values, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfNotIn(List<String> values) {
            addCriterion("t09cod_persf not in", values, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfBetween(String value1, String value2) {
            addCriterion("t09cod_persf between", value1, value2, "t09codPersf");
            return this;
        }

        public Criteria andT09codPersfNotBetween(String value1, String value2) {
            addCriterion("t09cod_persf not between", value1, value2, "t09codPersf");
            return this;
        }

        public Criteria andT09direccionIsNull() {
            addCriterion("t09direccion is null");
            return this;
        }

        public Criteria andT09direccionIsNotNull() {
            addCriterion("t09direccion is not null");
            return this;
        }

        public Criteria andT09direccionEqualTo(String value) {
            addCriterion("t09direccion =", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionNotEqualTo(String value) {
            addCriterion("t09direccion <>", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionGreaterThan(String value) {
            addCriterion("t09direccion >", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionGreaterThanOrEqualTo(String value) {
            addCriterion("t09direccion >=", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionLessThan(String value) {
            addCriterion("t09direccion <", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionLessThanOrEqualTo(String value) {
            addCriterion("t09direccion <=", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionLike(String value) {
            addCriterion("t09direccion like", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionNotLike(String value) {
            addCriterion("t09direccion not like", value, "t09direccion");
            return this;
        }

        public Criteria andT09direccionIn(List<String> values) {
            addCriterion("t09direccion in", values, "t09direccion");
            return this;
        }

        public Criteria andT09direccionNotIn(List<String> values) {
            addCriterion("t09direccion not in", values, "t09direccion");
            return this;
        }

        public Criteria andT09direccionBetween(String value1, String value2) {
            addCriterion("t09direccion between", value1, value2, "t09direccion");
            return this;
        }

        public Criteria andT09direccionNotBetween(String value1, String value2) {
            addCriterion("t09direccion not between", value1, value2, "t09direccion");
            return this;
        }

        public Criteria andT09referIsNull() {
            addCriterion("t09refer is null");
            return this;
        }

        public Criteria andT09referIsNotNull() {
            addCriterion("t09refer is not null");
            return this;
        }

        public Criteria andT09referEqualTo(String value) {
            addCriterion("t09refer =", value, "t09refer");
            return this;
        }

        public Criteria andT09referNotEqualTo(String value) {
            addCriterion("t09refer <>", value, "t09refer");
            return this;
        }

        public Criteria andT09referGreaterThan(String value) {
            addCriterion("t09refer >", value, "t09refer");
            return this;
        }

        public Criteria andT09referGreaterThanOrEqualTo(String value) {
            addCriterion("t09refer >=", value, "t09refer");
            return this;
        }

        public Criteria andT09referLessThan(String value) {
            addCriterion("t09refer <", value, "t09refer");
            return this;
        }

        public Criteria andT09referLessThanOrEqualTo(String value) {
            addCriterion("t09refer <=", value, "t09refer");
            return this;
        }

        public Criteria andT09referLike(String value) {
            addCriterion("t09refer like", value, "t09refer");
            return this;
        }

        public Criteria andT09referNotLike(String value) {
            addCriterion("t09refer not like", value, "t09refer");
            return this;
        }

        public Criteria andT09referIn(List<String> values) {
            addCriterion("t09refer in", values, "t09refer");
            return this;
        }

        public Criteria andT09referNotIn(List<String> values) {
            addCriterion("t09refer not in", values, "t09refer");
            return this;
        }

        public Criteria andT09referBetween(String value1, String value2) {
            addCriterion("t09refer between", value1, value2, "t09refer");
            return this;
        }

        public Criteria andT09referNotBetween(String value1, String value2) {
            addCriterion("t09refer not between", value1, value2, "t09refer");
            return this;
        }

        public Criteria andT09fGrabaIsNull() {
            addCriterion("t09f_graba is null");
            return this;
        }

        public Criteria andT09fGrabaIsNotNull() {
            addCriterion("t09f_graba is not null");
            return this;
        }

        public Criteria andT09fGrabaEqualTo(Date value) {
            addCriterion("t09f_graba =", value, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaNotEqualTo(Date value) {
            addCriterion("t09f_graba <>", value, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaGreaterThan(Date value) {
            addCriterion("t09f_graba >", value, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t09f_graba >=", value, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaLessThan(Date value) {
            addCriterion("t09f_graba <", value, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t09f_graba <=", value, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaIn(List<Date> values) {
            addCriterion("t09f_graba in", values, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaNotIn(List<Date> values) {
            addCriterion("t09f_graba not in", values, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaBetween(Date value1, Date value2) {
            addCriterion("t09f_graba between", value1, value2, "t09fGraba");
            return this;
        }

        public Criteria andT09fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t09f_graba not between", value1, value2, "t09fGraba");
            return this;
        }

        public Criteria andT09codUserIsNull() {
            addCriterion("t09cod_user is null");
            return this;
        }

        public Criteria andT09codUserIsNotNull() {
            addCriterion("t09cod_user is not null");
            return this;
        }

        public Criteria andT09codUserEqualTo(String value) {
            addCriterion("t09cod_user =", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserNotEqualTo(String value) {
            addCriterion("t09cod_user <>", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserGreaterThan(String value) {
            addCriterion("t09cod_user >", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t09cod_user >=", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserLessThan(String value) {
            addCriterion("t09cod_user <", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserLessThanOrEqualTo(String value) {
            addCriterion("t09cod_user <=", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserLike(String value) {
            addCriterion("t09cod_user like", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserNotLike(String value) {
            addCriterion("t09cod_user not like", value, "t09codUser");
            return this;
        }

        public Criteria andT09codUserIn(List<String> values) {
            addCriterion("t09cod_user in", values, "t09codUser");
            return this;
        }

        public Criteria andT09codUserNotIn(List<String> values) {
            addCriterion("t09cod_user not in", values, "t09codUser");
            return this;
        }

        public Criteria andT09codUserBetween(String value1, String value2) {
            addCriterion("t09cod_user between", value1, value2, "t09codUser");
            return this;
        }

        public Criteria andT09codUserNotBetween(String value1, String value2) {
            addCriterion("t09cod_user not between", value1, value2, "t09codUser");
            return this;
        }

        public Criteria andT09indDelIsNull() {
            addCriterion("t09ind_del is null");
            return this;
        }

        public Criteria andT09indDelIsNotNull() {
            addCriterion("t09ind_del is not null");
            return this;
        }

        public Criteria andT09indDelEqualTo(String value) {
            addCriterion("t09ind_del =", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelNotEqualTo(String value) {
            addCriterion("t09ind_del <>", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelGreaterThan(String value) {
            addCriterion("t09ind_del >", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelGreaterThanOrEqualTo(String value) {
            addCriterion("t09ind_del >=", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelLessThan(String value) {
            addCriterion("t09ind_del <", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelLessThanOrEqualTo(String value) {
            addCriterion("t09ind_del <=", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelLike(String value) {
            addCriterion("t09ind_del like", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelNotLike(String value) {
            addCriterion("t09ind_del not like", value, "t09indDel");
            return this;
        }

        public Criteria andT09indDelIn(List<String> values) {
            addCriterion("t09ind_del in", values, "t09indDel");
            return this;
        }

        public Criteria andT09indDelNotIn(List<String> values) {
            addCriterion("t09ind_del not in", values, "t09indDel");
            return this;
        }

        public Criteria andT09indDelBetween(String value1, String value2) {
            addCriterion("t09ind_del between", value1, value2, "t09indDel");
            return this;
        }

        public Criteria andT09indDelNotBetween(String value1, String value2) {
            addCriterion("t09ind_del not between", value1, value2, "t09indDel");
            return this;
        }
    }
}