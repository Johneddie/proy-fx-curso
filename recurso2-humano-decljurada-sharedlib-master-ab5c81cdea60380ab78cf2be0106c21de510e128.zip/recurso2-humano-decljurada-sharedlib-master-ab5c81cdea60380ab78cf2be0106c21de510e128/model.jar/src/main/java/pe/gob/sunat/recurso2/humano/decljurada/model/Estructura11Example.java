package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Estructura11Example {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public Estructura11Example() {
        oredCriteria = new ArrayList<>();
    }

    protected Estructura11Example(Estructura11Example example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andFecProcesoIsNull() {
            addCriterion("fec_proceso is null");
            return this;
        }

        public Criteria andFecProcesoIsNotNull() {
            addCriterion("fec_proceso is not null");
            return this;
        }

        public Criteria andFecProcesoEqualTo(Date value) {
            addCriterion("fec_proceso =", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotEqualTo(Date value) {
            addCriterion("fec_proceso <>", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThan(Date value) {
            addCriterion("fec_proceso >", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_proceso >=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThan(Date value) {
            addCriterion("fec_proceso <", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThanOrEqualTo(Date value) {
            addCriterion("fec_proceso <=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoIn(List<Date> values) {
            addCriterion("fec_proceso in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotIn(List<Date> values) {
            addCriterion("fec_proceso not in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoBetween(Date value1, Date value2) {
            addCriterion("fec_proceso between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotBetween(Date value1, Date value2) {
            addCriterion("fec_proceso not between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodCateIsNull() {
            addCriterion("cod_cate is null");
            return this;
        }

        public Criteria andCodCateIsNotNull() {
            addCriterion("cod_cate is not null");
            return this;
        }

        public Criteria andCodCateEqualTo(String value) {
            addCriterion("cod_cate =", value, "codCate");
            return this;
        }

        public Criteria andCodCateNotEqualTo(String value) {
            addCriterion("cod_cate <>", value, "codCate");
            return this;
        }

        public Criteria andCodCateGreaterThan(String value) {
            addCriterion("cod_cate >", value, "codCate");
            return this;
        }

        public Criteria andCodCateGreaterThanOrEqualTo(String value) {
            addCriterion("cod_cate >=", value, "codCate");
            return this;
        }

        public Criteria andCodCateLessThan(String value) {
            addCriterion("cod_cate <", value, "codCate");
            return this;
        }

        public Criteria andCodCateLessThanOrEqualTo(String value) {
            addCriterion("cod_cate <=", value, "codCate");
            return this;
        }

        public Criteria andCodCateLike(String value) {
            addCriterion("cod_cate like", value, "codCate");
            return this;
        }

        public Criteria andCodCateNotLike(String value) {
            addCriterion("cod_cate not like", value, "codCate");
            return this;
        }

        public Criteria andCodCateIn(List<String> values) {
            addCriterion("cod_cate in", values, "codCate");
            return this;
        }

        public Criteria andCodCateNotIn(List<String> values) {
            addCriterion("cod_cate not in", values, "codCate");
            return this;
        }

        public Criteria andCodCateBetween(String value1, String value2) {
            addCriterion("cod_cate between", value1, value2, "codCate");
            return this;
        }

        public Criteria andCodCateNotBetween(String value1, String value2) {
            addCriterion("cod_cate not between", value1, value2, "codCate");
            return this;
        }

        public Criteria andCodTipRegIsNull() {
            addCriterion("cod_tip_reg is null");
            return this;
        }

        public Criteria andCodTipRegIsNotNull() {
            addCriterion("cod_tip_reg is not null");
            return this;
        }

        public Criteria andCodTipRegEqualTo(String value) {
            addCriterion("cod_tip_reg =", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegNotEqualTo(String value) {
            addCriterion("cod_tip_reg <>", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegGreaterThan(String value) {
            addCriterion("cod_tip_reg >", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip_reg >=", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegLessThan(String value) {
            addCriterion("cod_tip_reg <", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegLessThanOrEqualTo(String value) {
            addCriterion("cod_tip_reg <=", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegLike(String value) {
            addCriterion("cod_tip_reg like", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegNotLike(String value) {
            addCriterion("cod_tip_reg not like", value, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegIn(List<String> values) {
            addCriterion("cod_tip_reg in", values, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegNotIn(List<String> values) {
            addCriterion("cod_tip_reg not in", values, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegBetween(String value1, String value2) {
            addCriterion("cod_tip_reg between", value1, value2, "codTipReg");
            return this;
        }

        public Criteria andCodTipRegNotBetween(String value1, String value2) {
            addCriterion("cod_tip_reg not between", value1, value2, "codTipReg");
            return this;
        }

        public Criteria andFecIniIsNull() {
            addCriterion("fec_ini is null");
            return this;
        }

        public Criteria andFecIniIsNotNull() {
            addCriterion("fec_ini is not null");
            return this;
        }

        public Criteria andFecIniEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini =", value, "fecIni");
            return this;
        }

        public Criteria andFecIniNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini <>", value, "fecIni");
            return this;
        }

        public Criteria andFecIniGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_ini >", value, "fecIni");
            return this;
        }

        public Criteria andFecIniGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini >=", value, "fecIni");
            return this;
        }

        public Criteria andFecIniLessThan(Date value) {
            addCriterionForJDBCDate("fec_ini <", value, "fecIni");
            return this;
        }

        public Criteria andFecIniLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_ini <=", value, "fecIni");
            return this;
        }

        public Criteria andFecIniIn(List<Date> values) {
            addCriterionForJDBCDate("fec_ini in", values, "fecIni");
            return this;
        }

        public Criteria andFecIniNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_ini not in", values, "fecIni");
            return this;
        }

        public Criteria andFecIniBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_ini between", value1, value2, "fecIni");
            return this;
        }

        public Criteria andFecIniNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_ini not between", value1, value2, "fecIni");
            return this;
        }

        public Criteria andFecFinIsNull() {
            addCriterion("fec_fin is null");
            return this;
        }

        public Criteria andFecFinIsNotNull() {
            addCriterion("fec_fin is not null");
            return this;
        }

        public Criteria andFecFinEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin =", value, "fecFin");
            return this;
        }

        public Criteria andFecFinNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin <>", value, "fecFin");
            return this;
        }

        public Criteria andFecFinGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_fin >", value, "fecFin");
            return this;
        }

        public Criteria andFecFinGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin >=", value, "fecFin");
            return this;
        }

        public Criteria andFecFinLessThan(Date value) {
            addCriterionForJDBCDate("fec_fin <", value, "fecFin");
            return this;
        }

        public Criteria andFecFinLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fin <=", value, "fecFin");
            return this;
        }

        public Criteria andFecFinIn(List<Date> values) {
            addCriterionForJDBCDate("fec_fin in", values, "fecFin");
            return this;
        }

        public Criteria andFecFinNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_fin not in", values, "fecFin");
            return this;
        }

        public Criteria andFecFinBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_fin between", value1, value2, "fecFin");
            return this;
        }

        public Criteria andFecFinNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_fin not between", value1, value2, "fecFin");
            return this;
        }

        public Criteria andCodIndTipRegIsNull() {
            addCriterion("cod_ind_tip_reg is null");
            return this;
        }

        public Criteria andCodIndTipRegIsNotNull() {
            addCriterion("cod_ind_tip_reg is not null");
            return this;
        }

        public Criteria andCodIndTipRegEqualTo(String value) {
            addCriterion("cod_ind_tip_reg =", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegNotEqualTo(String value) {
            addCriterion("cod_ind_tip_reg <>", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegGreaterThan(String value) {
            addCriterion("cod_ind_tip_reg >", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ind_tip_reg >=", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegLessThan(String value) {
            addCriterion("cod_ind_tip_reg <", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegLessThanOrEqualTo(String value) {
            addCriterion("cod_ind_tip_reg <=", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegLike(String value) {
            addCriterion("cod_ind_tip_reg like", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegNotLike(String value) {
            addCriterion("cod_ind_tip_reg not like", value, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegIn(List<String> values) {
            addCriterion("cod_ind_tip_reg in", values, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegNotIn(List<String> values) {
            addCriterion("cod_ind_tip_reg not in", values, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegBetween(String value1, String value2) {
            addCriterion("cod_ind_tip_reg between", value1, value2, "codIndTipReg");
            return this;
        }

        public Criteria andCodIndTipRegNotBetween(String value1, String value2) {
            addCriterion("cod_ind_tip_reg not between", value1, value2, "codIndTipReg");
            return this;
        }

        public Criteria andCodEpsIsNull() {
            addCriterion("cod_eps is null");
            return this;
        }

        public Criteria andCodEpsIsNotNull() {
            addCriterion("cod_eps is not null");
            return this;
        }

        public Criteria andCodEpsEqualTo(String value) {
            addCriterion("cod_eps =", value, "codEps");
            return this;
        }

        public Criteria andCodEpsNotEqualTo(String value) {
            addCriterion("cod_eps <>", value, "codEps");
            return this;
        }

        public Criteria andCodEpsGreaterThan(String value) {
            addCriterion("cod_eps >", value, "codEps");
            return this;
        }

        public Criteria andCodEpsGreaterThanOrEqualTo(String value) {
            addCriterion("cod_eps >=", value, "codEps");
            return this;
        }

        public Criteria andCodEpsLessThan(String value) {
            addCriterion("cod_eps <", value, "codEps");
            return this;
        }

        public Criteria andCodEpsLessThanOrEqualTo(String value) {
            addCriterion("cod_eps <=", value, "codEps");
            return this;
        }

        public Criteria andCodEpsLike(String value) {
            addCriterion("cod_eps like", value, "codEps");
            return this;
        }

        public Criteria andCodEpsNotLike(String value) {
            addCriterion("cod_eps not like", value, "codEps");
            return this;
        }

        public Criteria andCodEpsIn(List<String> values) {
            addCriterion("cod_eps in", values, "codEps");
            return this;
        }

        public Criteria andCodEpsNotIn(List<String> values) {
            addCriterion("cod_eps not in", values, "codEps");
            return this;
        }

        public Criteria andCodEpsBetween(String value1, String value2) {
            addCriterion("cod_eps between", value1, value2, "codEps");
            return this;
        }

        public Criteria andCodEpsNotBetween(String value1, String value2) {
            addCriterion("cod_eps not between", value1, value2, "codEps");
            return this;
        }

        public Criteria andEstProcesoIsNull() {
            addCriterion("est_proceso is null");
            return this;
        }

        public Criteria andEstProcesoIsNotNull() {
            addCriterion("est_proceso is not null");
            return this;
        }

        public Criteria andEstProcesoEqualTo(String value) {
            addCriterion("est_proceso =", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotEqualTo(String value) {
            addCriterion("est_proceso <>", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThan(String value) {
            addCriterion("est_proceso >", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThanOrEqualTo(String value) {
            addCriterion("est_proceso >=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThan(String value) {
            addCriterion("est_proceso <", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThanOrEqualTo(String value) {
            addCriterion("est_proceso <=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLike(String value) {
            addCriterion("est_proceso like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotLike(String value) {
            addCriterion("est_proceso not like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoIn(List<String> values) {
            addCriterion("est_proceso in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotIn(List<String> values) {
            addCriterion("est_proceso not in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoBetween(String value1, String value2) {
            addCriterion("est_proceso between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotBetween(String value1, String value2) {
            addCriterion("est_proceso not between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andAccCreacionIsNull() {
            addCriterion("acc_creacion is null");
            return this;
        }

        public Criteria andAccCreacionIsNotNull() {
            addCriterion("acc_creacion is not null");
            return this;
        }

        public Criteria andAccCreacionEqualTo(String value) {
            addCriterion("acc_creacion =", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotEqualTo(String value) {
            addCriterion("acc_creacion <>", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThan(String value) {
            addCriterion("acc_creacion >", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThanOrEqualTo(String value) {
            addCriterion("acc_creacion >=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThan(String value) {
            addCriterion("acc_creacion <", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThanOrEqualTo(String value) {
            addCriterion("acc_creacion <=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLike(String value) {
            addCriterion("acc_creacion like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotLike(String value) {
            addCriterion("acc_creacion not like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionIn(List<String> values) {
            addCriterion("acc_creacion in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotIn(List<String> values) {
            addCriterion("acc_creacion not in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionBetween(String value1, String value2) {
            addCriterion("acc_creacion between", value1, value2, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotBetween(String value1, String value2) {
            addCriterion("acc_creacion not between", value1, value2, "accCreacion");
            return this;
        }
    }
}