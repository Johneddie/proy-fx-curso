package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FormacionExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public FormacionExample() {
        oredCriteria = new ArrayList<>();
    }

    protected FormacionExample(FormacionExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andT29codPersIsNull() {
            addCriterion("t29cod_pers is null");
            return this;
        }

        public Criteria andT29codPersIsNotNull() {
            addCriterion("t29cod_pers is not null");
            return this;
        }

        public Criteria andT29codPersEqualTo(String value) {
            addCriterion("t29cod_pers =", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersNotEqualTo(String value) {
            addCriterion("t29cod_pers <>", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersGreaterThan(String value) {
            addCriterion("t29cod_pers >", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersGreaterThanOrEqualTo(String value) {
            addCriterion("t29cod_pers >=", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersLessThan(String value) {
            addCriterion("t29cod_pers <", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersLessThanOrEqualTo(String value) {
            addCriterion("t29cod_pers <=", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersLike(String value) {
            addCriterion("t29cod_pers like", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersNotLike(String value) {
            addCriterion("t29cod_pers not like", value, "t29codPers");
            return this;
        }

        public Criteria andT29codPersIn(List<String> values) {
            addCriterion("t29cod_pers in", values, "t29codPers");
            return this;
        }

        public Criteria andT29codPersNotIn(List<String> values) {
            addCriterion("t29cod_pers not in", values, "t29codPers");
            return this;
        }

        public Criteria andT29codPersBetween(String value1, String value2) {
            addCriterion("t29cod_pers between", value1, value2, "t29codPers");
            return this;
        }

        public Criteria andT29codPersNotBetween(String value1, String value2) {
            addCriterion("t29cod_pers not between", value1, value2, "t29codPers");
            return this;
        }

        public Criteria andT29codGradoIsNull() {
            addCriterion("t29cod_grado is null");
            return this;
        }

        public Criteria andT29codGradoIsNotNull() {
            addCriterion("t29cod_grado is not null");
            return this;
        }

        public Criteria andT29codGradoEqualTo(String value) {
            addCriterion("t29cod_grado =", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoNotEqualTo(String value) {
            addCriterion("t29cod_grado <>", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoGreaterThan(String value) {
            addCriterion("t29cod_grado >", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoGreaterThanOrEqualTo(String value) {
            addCriterion("t29cod_grado >=", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoLessThan(String value) {
            addCriterion("t29cod_grado <", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoLessThanOrEqualTo(String value) {
            addCriterion("t29cod_grado <=", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoLike(String value) {
            addCriterion("t29cod_grado like", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoNotLike(String value) {
            addCriterion("t29cod_grado not like", value, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoIn(List<String> values) {
            addCriterion("t29cod_grado in", values, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoNotIn(List<String> values) {
            addCriterion("t29cod_grado not in", values, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoBetween(String value1, String value2) {
            addCriterion("t29cod_grado between", value1, value2, "t29codGrado");
            return this;
        }

        public Criteria andT29codGradoNotBetween(String value1, String value2) {
            addCriterion("t29cod_grado not between", value1, value2, "t29codGrado");
            return this;
        }

        public Criteria andT29codUniIsNull() {
            addCriterion("t29cod_uni is null");
            return this;
        }

        public Criteria andT29codUniIsNotNull() {
            addCriterion("t29cod_uni is not null");
            return this;
        }

        public Criteria andT29codUniEqualTo(String value) {
            addCriterion("t29cod_uni =", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniNotEqualTo(String value) {
            addCriterion("t29cod_uni <>", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniGreaterThan(String value) {
            addCriterion("t29cod_uni >", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniGreaterThanOrEqualTo(String value) {
            addCriterion("t29cod_uni >=", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniLessThan(String value) {
            addCriterion("t29cod_uni <", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniLessThanOrEqualTo(String value) {
            addCriterion("t29cod_uni <=", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniLike(String value) {
            addCriterion("t29cod_uni like", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniNotLike(String value) {
            addCriterion("t29cod_uni not like", value, "t29codUni");
            return this;
        }

        public Criteria andT29codUniIn(List<String> values) {
            addCriterion("t29cod_uni in", values, "t29codUni");
            return this;
        }

        public Criteria andT29codUniNotIn(List<String> values) {
            addCriterion("t29cod_uni not in", values, "t29codUni");
            return this;
        }

        public Criteria andT29codUniBetween(String value1, String value2) {
            addCriterion("t29cod_uni between", value1, value2, "t29codUni");
            return this;
        }

        public Criteria andT29codUniNotBetween(String value1, String value2) {
            addCriterion("t29cod_uni not between", value1, value2, "t29codUni");
            return this;
        }

        public Criteria andT29codEspIsNull() {
            addCriterion("t29cod_esp is null");
            return this;
        }

        public Criteria andT29codEspIsNotNull() {
            addCriterion("t29cod_esp is not null");
            return this;
        }

        public Criteria andT29codEspEqualTo(String value) {
            addCriterion("t29cod_esp =", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspNotEqualTo(String value) {
            addCriterion("t29cod_esp <>", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspGreaterThan(String value) {
            addCriterion("t29cod_esp >", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspGreaterThanOrEqualTo(String value) {
            addCriterion("t29cod_esp >=", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspLessThan(String value) {
            addCriterion("t29cod_esp <", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspLessThanOrEqualTo(String value) {
            addCriterion("t29cod_esp <=", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspLike(String value) {
            addCriterion("t29cod_esp like", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspNotLike(String value) {
            addCriterion("t29cod_esp not like", value, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspIn(List<String> values) {
            addCriterion("t29cod_esp in", values, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspNotIn(List<String> values) {
            addCriterion("t29cod_esp not in", values, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspBetween(String value1, String value2) {
            addCriterion("t29cod_esp between", value1, value2, "t29codEsp");
            return this;
        }

        public Criteria andT29codEspNotBetween(String value1, String value2) {
            addCriterion("t29cod_esp not between", value1, value2, "t29codEsp");
            return this;
        }

        public Criteria andT29numColeIsNull() {
            addCriterion("t29num_cole is null");
            return this;
        }

        public Criteria andT29numColeIsNotNull() {
            addCriterion("t29num_cole is not null");
            return this;
        }

        public Criteria andT29numColeEqualTo(String value) {
            addCriterion("t29num_cole =", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeNotEqualTo(String value) {
            addCriterion("t29num_cole <>", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeGreaterThan(String value) {
            addCriterion("t29num_cole >", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeGreaterThanOrEqualTo(String value) {
            addCriterion("t29num_cole >=", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeLessThan(String value) {
            addCriterion("t29num_cole <", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeLessThanOrEqualTo(String value) {
            addCriterion("t29num_cole <=", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeLike(String value) {
            addCriterion("t29num_cole like", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeNotLike(String value) {
            addCriterion("t29num_cole not like", value, "t29numCole");
            return this;
        }

        public Criteria andT29numColeIn(List<String> values) {
            addCriterion("t29num_cole in", values, "t29numCole");
            return this;
        }

        public Criteria andT29numColeNotIn(List<String> values) {
            addCriterion("t29num_cole not in", values, "t29numCole");
            return this;
        }

        public Criteria andT29numColeBetween(String value1, String value2) {
            addCriterion("t29num_cole between", value1, value2, "t29numCole");
            return this;
        }

        public Criteria andT29numColeNotBetween(String value1, String value2) {
            addCriterion("t29num_cole not between", value1, value2, "t29numCole");
            return this;
        }

        public Criteria andT29finGradoIsNull() {
            addCriterion("t29fin_grado is null");
            return this;
        }

        public Criteria andT29finGradoIsNotNull() {
            addCriterion("t29fin_grado is not null");
            return this;
        }

        public Criteria andT29finGradoEqualTo(String value) {
            addCriterion("t29fin_grado =", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoNotEqualTo(String value) {
            addCriterion("t29fin_grado <>", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoGreaterThan(String value) {
            addCriterion("t29fin_grado >", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoGreaterThanOrEqualTo(String value) {
            addCriterion("t29fin_grado >=", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoLessThan(String value) {
            addCriterion("t29fin_grado <", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoLessThanOrEqualTo(String value) {
            addCriterion("t29fin_grado <=", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoLike(String value) {
            addCriterion("t29fin_grado like", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoNotLike(String value) {
            addCriterion("t29fin_grado not like", value, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoIn(List<String> values) {
            addCriterion("t29fin_grado in", values, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoNotIn(List<String> values) {
            addCriterion("t29fin_grado not in", values, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoBetween(String value1, String value2) {
            addCriterion("t29fin_grado between", value1, value2, "t29finGrado");
            return this;
        }

        public Criteria andT29finGradoNotBetween(String value1, String value2) {
            addCriterion("t29fin_grado not between", value1, value2, "t29finGrado");
            return this;
        }

        public Criteria andT29sustentoIsNull() {
            addCriterion("t29sustento is null");
            return this;
        }

        public Criteria andT29sustentoIsNotNull() {
            addCriterion("t29sustento is not null");
            return this;
        }

        public Criteria andT29sustentoEqualTo(String value) {
            addCriterion("t29sustento =", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoNotEqualTo(String value) {
            addCriterion("t29sustento <>", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoGreaterThan(String value) {
            addCriterion("t29sustento >", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoGreaterThanOrEqualTo(String value) {
            addCriterion("t29sustento >=", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoLessThan(String value) {
            addCriterion("t29sustento <", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoLessThanOrEqualTo(String value) {
            addCriterion("t29sustento <=", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoLike(String value) {
            addCriterion("t29sustento like", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoNotLike(String value) {
            addCriterion("t29sustento not like", value, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoIn(List<String> values) {
            addCriterion("t29sustento in", values, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoNotIn(List<String> values) {
            addCriterion("t29sustento not in", values, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoBetween(String value1, String value2) {
            addCriterion("t29sustento between", value1, value2, "t29sustento");
            return this;
        }

        public Criteria andT29sustentoNotBetween(String value1, String value2) {
            addCriterion("t29sustento not between", value1, value2, "t29sustento");
            return this;
        }

        public Criteria andT29observaIsNull() {
            addCriterion("t29observa is null");
            return this;
        }

        public Criteria andT29observaIsNotNull() {
            addCriterion("t29observa is not null");
            return this;
        }

        public Criteria andT29observaEqualTo(String value) {
            addCriterion("t29observa =", value, "t29observa");
            return this;
        }

        public Criteria andT29observaNotEqualTo(String value) {
            addCriterion("t29observa <>", value, "t29observa");
            return this;
        }

        public Criteria andT29observaGreaterThan(String value) {
            addCriterion("t29observa >", value, "t29observa");
            return this;
        }

        public Criteria andT29observaGreaterThanOrEqualTo(String value) {
            addCriterion("t29observa >=", value, "t29observa");
            return this;
        }

        public Criteria andT29observaLessThan(String value) {
            addCriterion("t29observa <", value, "t29observa");
            return this;
        }

        public Criteria andT29observaLessThanOrEqualTo(String value) {
            addCriterion("t29observa <=", value, "t29observa");
            return this;
        }

        public Criteria andT29observaLike(String value) {
            addCriterion("t29observa like", value, "t29observa");
            return this;
        }

        public Criteria andT29observaNotLike(String value) {
            addCriterion("t29observa not like", value, "t29observa");
            return this;
        }

        public Criteria andT29observaIn(List<String> values) {
            addCriterion("t29observa in", values, "t29observa");
            return this;
        }

        public Criteria andT29observaNotIn(List<String> values) {
            addCriterion("t29observa not in", values, "t29observa");
            return this;
        }

        public Criteria andT29observaBetween(String value1, String value2) {
            addCriterion("t29observa between", value1, value2, "t29observa");
            return this;
        }

        public Criteria andT29observaNotBetween(String value1, String value2) {
            addCriterion("t29observa not between", value1, value2, "t29observa");
            return this;
        }

        public Criteria andT29desGradoIsNull() {
            addCriterion("t29des_grado is null");
            return this;
        }

        public Criteria andT29desGradoIsNotNull() {
            addCriterion("t29des_grado is not null");
            return this;
        }

        public Criteria andT29desGradoEqualTo(String value) {
            addCriterion("t29des_grado =", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoNotEqualTo(String value) {
            addCriterion("t29des_grado <>", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoGreaterThan(String value) {
            addCriterion("t29des_grado >", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoGreaterThanOrEqualTo(String value) {
            addCriterion("t29des_grado >=", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoLessThan(String value) {
            addCriterion("t29des_grado <", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoLessThanOrEqualTo(String value) {
            addCriterion("t29des_grado <=", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoLike(String value) {
            addCriterion("t29des_grado like", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoNotLike(String value) {
            addCriterion("t29des_grado not like", value, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoIn(List<String> values) {
            addCriterion("t29des_grado in", values, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoNotIn(List<String> values) {
            addCriterion("t29des_grado not in", values, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoBetween(String value1, String value2) {
            addCriterion("t29des_grado between", value1, value2, "t29desGrado");
            return this;
        }

        public Criteria andT29desGradoNotBetween(String value1, String value2) {
            addCriterion("t29des_grado not between", value1, value2, "t29desGrado");
            return this;
        }

        public Criteria andTituVerifIsNull() {
            addCriterion("titu_verif is null");
            return this;
        }

        public Criteria andTituVerifIsNotNull() {
            addCriterion("titu_verif is not null");
            return this;
        }

        public Criteria andTituVerifEqualTo(String value) {
            addCriterion("titu_verif =", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifNotEqualTo(String value) {
            addCriterion("titu_verif <>", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifGreaterThan(String value) {
            addCriterion("titu_verif >", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifGreaterThanOrEqualTo(String value) {
            addCriterion("titu_verif >=", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifLessThan(String value) {
            addCriterion("titu_verif <", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifLessThanOrEqualTo(String value) {
            addCriterion("titu_verif <=", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifLike(String value) {
            addCriterion("titu_verif like", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifNotLike(String value) {
            addCriterion("titu_verif not like", value, "tituVerif");
            return this;
        }

        public Criteria andTituVerifIn(List<String> values) {
            addCriterion("titu_verif in", values, "tituVerif");
            return this;
        }

        public Criteria andTituVerifNotIn(List<String> values) {
            addCriterion("titu_verif not in", values, "tituVerif");
            return this;
        }

        public Criteria andTituVerifBetween(String value1, String value2) {
            addCriterion("titu_verif between", value1, value2, "tituVerif");
            return this;
        }

        public Criteria andTituVerifNotBetween(String value1, String value2) {
            addCriterion("titu_verif not between", value1, value2, "tituVerif");
            return this;
        }

        public Criteria andT29fGrabaIsNull() {
            addCriterion("t29f_graba is null");
            return this;
        }

        public Criteria andT29fGrabaIsNotNull() {
            addCriterion("t29f_graba is not null");
            return this;
        }

        public Criteria andT29fGrabaEqualTo(Date value) {
            addCriterion("t29f_graba =", value, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaNotEqualTo(Date value) {
            addCriterion("t29f_graba <>", value, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaGreaterThan(Date value) {
            addCriterion("t29f_graba >", value, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t29f_graba >=", value, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaLessThan(Date value) {
            addCriterion("t29f_graba <", value, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t29f_graba <=", value, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaIn(List<Date> values) {
            addCriterion("t29f_graba in", values, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaNotIn(List<Date> values) {
            addCriterion("t29f_graba not in", values, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaBetween(Date value1, Date value2) {
            addCriterion("t29f_graba between", value1, value2, "t29fGraba");
            return this;
        }

        public Criteria andT29fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t29f_graba not between", value1, value2, "t29fGraba");
            return this;
        }

        public Criteria andT29codUserIsNull() {
            addCriterion("t29cod_user is null");
            return this;
        }

        public Criteria andT29codUserIsNotNull() {
            addCriterion("t29cod_user is not null");
            return this;
        }

        public Criteria andT29codUserEqualTo(String value) {
            addCriterion("t29cod_user =", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserNotEqualTo(String value) {
            addCriterion("t29cod_user <>", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserGreaterThan(String value) {
            addCriterion("t29cod_user >", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t29cod_user >=", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserLessThan(String value) {
            addCriterion("t29cod_user <", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserLessThanOrEqualTo(String value) {
            addCriterion("t29cod_user <=", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserLike(String value) {
            addCriterion("t29cod_user like", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserNotLike(String value) {
            addCriterion("t29cod_user not like", value, "t29codUser");
            return this;
        }

        public Criteria andT29codUserIn(List<String> values) {
            addCriterion("t29cod_user in", values, "t29codUser");
            return this;
        }

        public Criteria andT29codUserNotIn(List<String> values) {
            addCriterion("t29cod_user not in", values, "t29codUser");
            return this;
        }

        public Criteria andT29codUserBetween(String value1, String value2) {
            addCriterion("t29cod_user between", value1, value2, "t29codUser");
            return this;
        }

        public Criteria andT29codUserNotBetween(String value1, String value2) {
            addCriterion("t29cod_user not between", value1, value2, "t29codUser");
            return this;
        }

        public Criteria andNumHorasIsNull() {
            addCriterion("num_horas is null");
            return this;
        }

        public Criteria andNumHorasIsNotNull() {
            addCriterion("num_horas is not null");
            return this;
        }

        public Criteria andNumHorasEqualTo(BigDecimal value) {
            addCriterion("num_horas =", value, "numHoras");
            return this;
        }

        public Criteria andNumHorasNotEqualTo(BigDecimal value) {
            addCriterion("num_horas <>", value, "numHoras");
            return this;
        }

        public Criteria andNumHorasGreaterThan(BigDecimal value) {
            addCriterion("num_horas >", value, "numHoras");
            return this;
        }

        public Criteria andNumHorasGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("num_horas >=", value, "numHoras");
            return this;
        }

        public Criteria andNumHorasLessThan(BigDecimal value) {
            addCriterion("num_horas <", value, "numHoras");
            return this;
        }

        public Criteria andNumHorasLessThanOrEqualTo(BigDecimal value) {
            addCriterion("num_horas <=", value, "numHoras");
            return this;
        }

        public Criteria andNumHorasIn(List<BigDecimal> values) {
            addCriterion("num_horas in", values, "numHoras");
            return this;
        }

        public Criteria andNumHorasNotIn(List<BigDecimal> values) {
            addCriterion("num_horas not in", values, "numHoras");
            return this;
        }

        public Criteria andNumHorasBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_horas between", value1, value2, "numHoras");
            return this;
        }

        public Criteria andNumHorasNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_horas not between", value1, value2, "numHoras");
            return this;
        }

        public Criteria andIndOrigenIsNull() {
            addCriterion("ind_origen is null");
            return this;
        }

        public Criteria andIndOrigenIsNotNull() {
            addCriterion("ind_origen is not null");
            return this;
        }

        public Criteria andIndOrigenEqualTo(String value) {
            addCriterion("ind_origen =", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenNotEqualTo(String value) {
            addCriterion("ind_origen <>", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenGreaterThan(String value) {
            addCriterion("ind_origen >", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenGreaterThanOrEqualTo(String value) {
            addCriterion("ind_origen >=", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenLessThan(String value) {
            addCriterion("ind_origen <", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenLessThanOrEqualTo(String value) {
            addCriterion("ind_origen <=", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenLike(String value) {
            addCriterion("ind_origen like", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenNotLike(String value) {
            addCriterion("ind_origen not like", value, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenIn(List<String> values) {
            addCriterion("ind_origen in", values, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenNotIn(List<String> values) {
            addCriterion("ind_origen not in", values, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenBetween(String value1, String value2) {
            addCriterion("ind_origen between", value1, value2, "indOrigen");
            return this;
        }

        public Criteria andIndOrigenNotBetween(String value1, String value2) {
            addCriterion("ind_origen not between", value1, value2, "indOrigen");
            return this;
        }

        public Criteria andFecPresentaIsNull() {
            addCriterion("fec_presenta is null");
            return this;
        }

        public Criteria andFecPresentaIsNotNull() {
            addCriterion("fec_presenta is not null");
            return this;
        }

        public Criteria andFecPresentaEqualTo(Date value) {
            addCriterion("fec_presenta =", value, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaNotEqualTo(Date value) {
            addCriterion("fec_presenta <>", value, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaGreaterThan(Date value) {
            addCriterion("fec_presenta >", value, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_presenta >=", value, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaLessThan(Date value) {
            addCriterion("fec_presenta <", value, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaLessThanOrEqualTo(Date value) {
            addCriterion("fec_presenta <=", value, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaIn(List<Date> values) {
            addCriterion("fec_presenta in", values, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaNotIn(List<Date> values) {
            addCriterion("fec_presenta not in", values, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaBetween(Date value1, Date value2) {
            addCriterion("fec_presenta between", value1, value2, "fecPresenta");
            return this;
        }

        public Criteria andFecPresentaNotBetween(Date value1, Date value2) {
            addCriterion("fec_presenta not between", value1, value2, "fecPresenta");
            return this;
        }
    }
}