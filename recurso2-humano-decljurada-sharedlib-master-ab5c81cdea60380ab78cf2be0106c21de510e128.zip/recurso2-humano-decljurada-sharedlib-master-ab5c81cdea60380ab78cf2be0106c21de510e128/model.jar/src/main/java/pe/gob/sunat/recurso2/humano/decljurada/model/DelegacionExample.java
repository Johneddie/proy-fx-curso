package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DelegacionExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public DelegacionExample() {
        oredCriteria = new ArrayList<>();
    }

    protected DelegacionExample(DelegacionExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andCodOpcionIsNull() {
            addCriterion("cod_opcion is null");
            return this;
        }

        public Criteria andCodOpcionIsNotNull() {
            addCriterion("cod_opcion is not null");
            return this;
        }

        public Criteria andCodOpcionEqualTo(String value) {
            addCriterion("cod_opcion =", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionNotEqualTo(String value) {
            addCriterion("cod_opcion <>", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionGreaterThan(String value) {
            addCriterion("cod_opcion >", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionGreaterThanOrEqualTo(String value) {
            addCriterion("cod_opcion >=", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionLessThan(String value) {
            addCriterion("cod_opcion <", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionLessThanOrEqualTo(String value) {
            addCriterion("cod_opcion <=", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionLike(String value) {
            addCriterion("cod_opcion like", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionNotLike(String value) {
            addCriterion("cod_opcion not like", value, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionIn(List<String> values) {
            addCriterion("cod_opcion in", values, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionNotIn(List<String> values) {
            addCriterion("cod_opcion not in", values, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionBetween(String value1, String value2) {
            addCriterion("cod_opcion between", value1, value2, "codOpcion");
            return this;
        }

        public Criteria andCodOpcionNotBetween(String value1, String value2) {
            addCriterion("cod_opcion not between", value1, value2, "codOpcion");
            return this;
        }

        public Criteria andCodPersonalJefeIsNull() {
            addCriterion("cod_personal_jefe is null");
            return this;
        }

        public Criteria andCodPersonalJefeIsNotNull() {
            addCriterion("cod_personal_jefe is not null");
            return this;
        }

        public Criteria andCodPersonalJefeEqualTo(String value) {
            addCriterion("cod_personal_jefe =", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeNotEqualTo(String value) {
            addCriterion("cod_personal_jefe <>", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeGreaterThan(String value) {
            addCriterion("cod_personal_jefe >", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeGreaterThanOrEqualTo(String value) {
            addCriterion("cod_personal_jefe >=", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeLessThan(String value) {
            addCriterion("cod_personal_jefe <", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeLessThanOrEqualTo(String value) {
            addCriterion("cod_personal_jefe <=", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeLike(String value) {
            addCriterion("cod_personal_jefe like", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeNotLike(String value) {
            addCriterion("cod_personal_jefe not like", value, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeIn(List<String> values) {
            addCriterion("cod_personal_jefe in", values, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeNotIn(List<String> values) {
            addCriterion("cod_personal_jefe not in", values, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeBetween(String value1, String value2) {
            addCriterion("cod_personal_jefe between", value1, value2, "codPersonalJefe");
            return this;
        }

        public Criteria andCodPersonalJefeNotBetween(String value1, String value2) {
            addCriterion("cod_personal_jefe not between", value1, value2, "codPersonalJefe");
            return this;
        }

        public Criteria andCunidadOrganIsNull() {
            addCriterion("cunidad_organ is null");
            return this;
        }

        public Criteria andCunidadOrganIsNotNull() {
            addCriterion("cunidad_organ is not null");
            return this;
        }

        public Criteria andCunidadOrganEqualTo(String value) {
            addCriterion("cunidad_organ =", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganNotEqualTo(String value) {
            addCriterion("cunidad_organ <>", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganGreaterThan(String value) {
            addCriterion("cunidad_organ >", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganGreaterThanOrEqualTo(String value) {
            addCriterion("cunidad_organ >=", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganLessThan(String value) {
            addCriterion("cunidad_organ <", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganLessThanOrEqualTo(String value) {
            addCriterion("cunidad_organ <=", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganLike(String value) {
            addCriterion("cunidad_organ like", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganNotLike(String value) {
            addCriterion("cunidad_organ not like", value, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganIn(List<String> values) {
            addCriterion("cunidad_organ in", values, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganNotIn(List<String> values) {
            addCriterion("cunidad_organ not in", values, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganBetween(String value1, String value2) {
            addCriterion("cunidad_organ between", value1, value2, "cunidadOrgan");
            return this;
        }

        public Criteria andCunidadOrganNotBetween(String value1, String value2) {
            addCriterion("cunidad_organ not between", value1, value2, "cunidadOrgan");
            return this;
        }

        public Criteria andCodPersonalDelegIsNull() {
            addCriterion("cod_personal_deleg is null");
            return this;
        }

        public Criteria andCodPersonalDelegIsNotNull() {
            addCriterion("cod_personal_deleg is not null");
            return this;
        }

        public Criteria andCodPersonalDelegEqualTo(String value) {
            addCriterion("cod_personal_deleg =", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegNotEqualTo(String value) {
            addCriterion("cod_personal_deleg <>", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegGreaterThan(String value) {
            addCriterion("cod_personal_deleg >", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegGreaterThanOrEqualTo(String value) {
            addCriterion("cod_personal_deleg >=", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegLessThan(String value) {
            addCriterion("cod_personal_deleg <", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegLessThanOrEqualTo(String value) {
            addCriterion("cod_personal_deleg <=", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegLike(String value) {
            addCriterion("cod_personal_deleg like", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegNotLike(String value) {
            addCriterion("cod_personal_deleg not like", value, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegIn(List<String> values) {
            addCriterion("cod_personal_deleg in", values, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegNotIn(List<String> values) {
            addCriterion("cod_personal_deleg not in", values, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegBetween(String value1, String value2) {
            addCriterion("cod_personal_deleg between", value1, value2, "codPersonalDeleg");
            return this;
        }

        public Criteria andCodPersonalDelegNotBetween(String value1, String value2) {
            addCriterion("cod_personal_deleg not between", value1, value2, "codPersonalDeleg");
            return this;
        }

        public Criteria andFinivigIsNull() {
            addCriterion("finivig is null");
            return this;
        }

        public Criteria andFinivigIsNotNull() {
            addCriterion("finivig is not null");
            return this;
        }

        public Criteria andFinivigEqualTo(Date value) {
            addCriterionForJDBCDate("finivig =", value, "finivig");
            return this;
        }

        public Criteria andFinivigNotEqualTo(Date value) {
            addCriterionForJDBCDate("finivig <>", value, "finivig");
            return this;
        }

        public Criteria andFinivigGreaterThan(Date value) {
            addCriterionForJDBCDate("finivig >", value, "finivig");
            return this;
        }

        public Criteria andFinivigGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("finivig >=", value, "finivig");
            return this;
        }

        public Criteria andFinivigLessThan(Date value) {
            addCriterionForJDBCDate("finivig <", value, "finivig");
            return this;
        }

        public Criteria andFinivigLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("finivig <=", value, "finivig");
            return this;
        }

        public Criteria andFinivigIn(List<Date> values) {
            addCriterionForJDBCDate("finivig in", values, "finivig");
            return this;
        }

        public Criteria andFinivigNotIn(List<Date> values) {
            addCriterionForJDBCDate("finivig not in", values, "finivig");
            return this;
        }

        public Criteria andFinivigBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("finivig between", value1, value2, "finivig");
            return this;
        }

        public Criteria andFinivigNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("finivig not between", value1, value2, "finivig");
            return this;
        }

        public Criteria andFfinvigIsNull() {
            addCriterion("ffinvig is null");
            return this;
        }

        public Criteria andFfinvigIsNotNull() {
            addCriterion("ffinvig is not null");
            return this;
        }

        public Criteria andFfinvigEqualTo(Date value) {
            addCriterionForJDBCDate("ffinvig =", value, "ffinvig");
            return this;
        }

        public Criteria andFfinvigNotEqualTo(Date value) {
            addCriterionForJDBCDate("ffinvig <>", value, "ffinvig");
            return this;
        }

        public Criteria andFfinvigGreaterThan(Date value) {
            addCriterionForJDBCDate("ffinvig >", value, "ffinvig");
            return this;
        }

        public Criteria andFfinvigGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ffinvig >=", value, "ffinvig");
            return this;
        }

        public Criteria andFfinvigLessThan(Date value) {
            addCriterionForJDBCDate("ffinvig <", value, "ffinvig");
            return this;
        }

        public Criteria andFfinvigLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("ffinvig <=", value, "ffinvig");
            return this;
        }

        public Criteria andFfinvigIn(List<Date> values) {
            addCriterionForJDBCDate("ffinvig in", values, "ffinvig");
            return this;
        }

        public Criteria andFfinvigNotIn(List<Date> values) {
            addCriterionForJDBCDate("ffinvig not in", values, "ffinvig");
            return this;
        }

        public Criteria andFfinvigBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ffinvig between", value1, value2, "ffinvig");
            return this;
        }

        public Criteria andFfinvigNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("ffinvig not between", value1, value2, "ffinvig");
            return this;
        }

        public Criteria andSestadoActivoIsNull() {
            addCriterion("sestado_activo is null");
            return this;
        }

        public Criteria andSestadoActivoIsNotNull() {
            addCriterion("sestado_activo is not null");
            return this;
        }

        public Criteria andSestadoActivoEqualTo(String value) {
            addCriterion("sestado_activo =", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoNotEqualTo(String value) {
            addCriterion("sestado_activo <>", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoGreaterThan(String value) {
            addCriterion("sestado_activo >", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoGreaterThanOrEqualTo(String value) {
            addCriterion("sestado_activo >=", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoLessThan(String value) {
            addCriterion("sestado_activo <", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoLessThanOrEqualTo(String value) {
            addCriterion("sestado_activo <=", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoLike(String value) {
            addCriterion("sestado_activo like", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoNotLike(String value) {
            addCriterion("sestado_activo not like", value, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoIn(List<String> values) {
            addCriterion("sestado_activo in", values, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoNotIn(List<String> values) {
            addCriterion("sestado_activo not in", values, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoBetween(String value1, String value2) {
            addCriterion("sestado_activo between", value1, value2, "sestadoActivo");
            return this;
        }

        public Criteria andSestadoActivoNotBetween(String value1, String value2) {
            addCriterion("sestado_activo not between", value1, value2, "sestadoActivo");
            return this;
        }

        public Criteria andCuserModIsNull() {
            addCriterion("cuser_mod is null");
            return this;
        }

        public Criteria andCuserModIsNotNull() {
            addCriterion("cuser_mod is not null");
            return this;
        }

        public Criteria andCuserModEqualTo(String value) {
            addCriterion("cuser_mod =", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModNotEqualTo(String value) {
            addCriterion("cuser_mod <>", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModGreaterThan(String value) {
            addCriterion("cuser_mod >", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModGreaterThanOrEqualTo(String value) {
            addCriterion("cuser_mod >=", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModLessThan(String value) {
            addCriterion("cuser_mod <", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModLessThanOrEqualTo(String value) {
            addCriterion("cuser_mod <=", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModLike(String value) {
            addCriterion("cuser_mod like", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModNotLike(String value) {
            addCriterion("cuser_mod not like", value, "cuserMod");
            return this;
        }

        public Criteria andCuserModIn(List<String> values) {
            addCriterion("cuser_mod in", values, "cuserMod");
            return this;
        }

        public Criteria andCuserModNotIn(List<String> values) {
            addCriterion("cuser_mod not in", values, "cuserMod");
            return this;
        }

        public Criteria andCuserModBetween(String value1, String value2) {
            addCriterion("cuser_mod between", value1, value2, "cuserMod");
            return this;
        }

        public Criteria andCuserModNotBetween(String value1, String value2) {
            addCriterion("cuser_mod not between", value1, value2, "cuserMod");
            return this;
        }

        public Criteria andFmodIsNull() {
            addCriterion("fmod is null");
            return this;
        }

        public Criteria andFmodIsNotNull() {
            addCriterion("fmod is not null");
            return this;
        }

        public Criteria andFmodEqualTo(Date value) {
            addCriterion("fmod =", value, "fmod");
            return this;
        }

        public Criteria andFmodNotEqualTo(Date value) {
            addCriterion("fmod <>", value, "fmod");
            return this;
        }

        public Criteria andFmodGreaterThan(Date value) {
            addCriterion("fmod >", value, "fmod");
            return this;
        }

        public Criteria andFmodGreaterThanOrEqualTo(Date value) {
            addCriterion("fmod >=", value, "fmod");
            return this;
        }

        public Criteria andFmodLessThan(Date value) {
            addCriterion("fmod <", value, "fmod");
            return this;
        }

        public Criteria andFmodLessThanOrEqualTo(Date value) {
            addCriterion("fmod <=", value, "fmod");
            return this;
        }

        public Criteria andFmodIn(List<Date> values) {
            addCriterion("fmod in", values, "fmod");
            return this;
        }

        public Criteria andFmodNotIn(List<Date> values) {
            addCriterion("fmod not in", values, "fmod");
            return this;
        }

        public Criteria andFmodBetween(Date value1, Date value2) {
            addCriterion("fmod between", value1, value2, "fmod");
            return this;
        }

        public Criteria andFmodNotBetween(Date value1, Date value2) {
            addCriterion("fmod not between", value1, value2, "fmod");
            return this;
        }
    }
}