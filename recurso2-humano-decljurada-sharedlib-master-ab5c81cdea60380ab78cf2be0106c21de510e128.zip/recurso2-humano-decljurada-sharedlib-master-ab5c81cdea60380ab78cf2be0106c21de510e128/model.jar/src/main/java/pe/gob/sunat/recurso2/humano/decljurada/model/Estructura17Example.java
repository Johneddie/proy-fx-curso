package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Estructura17Example {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public Estructura17Example() {
        oredCriteria = new ArrayList<>();
    }

    protected Estructura17Example(Estructura17Example example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andFecProcesoIsNull() {
            addCriterion("fec_proceso is null");
            return this;
        }

        public Criteria andFecProcesoIsNotNull() {
            addCriterion("fec_proceso is not null");
            return this;
        }

        public Criteria andFecProcesoEqualTo(Date value) {
            addCriterion("fec_proceso =", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotEqualTo(Date value) {
            addCriterion("fec_proceso <>", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThan(Date value) {
            addCriterion("fec_proceso >", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_proceso >=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThan(Date value) {
            addCriterion("fec_proceso <", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThanOrEqualTo(Date value) {
            addCriterion("fec_proceso <=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoIn(List<Date> values) {
            addCriterion("fec_proceso in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotIn(List<Date> values) {
            addCriterion("fec_proceso not in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoBetween(Date value1, Date value2) {
            addCriterion("fec_proceso between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotBetween(Date value1, Date value2) {
            addCriterion("fec_proceso not between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andNumRucEmplIsNull() {
            addCriterion("num_ruc_empl is null");
            return this;
        }

        public Criteria andNumRucEmplIsNotNull() {
            addCriterion("num_ruc_empl is not null");
            return this;
        }

        public Criteria andNumRucEmplEqualTo(String value) {
            addCriterion("num_ruc_empl =", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplNotEqualTo(String value) {
            addCriterion("num_ruc_empl <>", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplGreaterThan(String value) {
            addCriterion("num_ruc_empl >", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplGreaterThanOrEqualTo(String value) {
            addCriterion("num_ruc_empl >=", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplLessThan(String value) {
            addCriterion("num_ruc_empl <", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplLessThanOrEqualTo(String value) {
            addCriterion("num_ruc_empl <=", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplLike(String value) {
            addCriterion("num_ruc_empl like", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplNotLike(String value) {
            addCriterion("num_ruc_empl not like", value, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplIn(List<String> values) {
            addCriterion("num_ruc_empl in", values, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplNotIn(List<String> values) {
            addCriterion("num_ruc_empl not in", values, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplBetween(String value1, String value2) {
            addCriterion("num_ruc_empl between", value1, value2, "numRucEmpl");
            return this;
        }

        public Criteria andNumRucEmplNotBetween(String value1, String value2) {
            addCriterion("num_ruc_empl not between", value1, value2, "numRucEmpl");
            return this;
        }

        public Criteria andCodEstableIsNull() {
            addCriterion("cod_estable is null");
            return this;
        }

        public Criteria andCodEstableIsNotNull() {
            addCriterion("cod_estable is not null");
            return this;
        }

        public Criteria andCodEstableEqualTo(String value) {
            addCriterion("cod_estable =", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableNotEqualTo(String value) {
            addCriterion("cod_estable <>", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableGreaterThan(String value) {
            addCriterion("cod_estable >", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estable >=", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableLessThan(String value) {
            addCriterion("cod_estable <", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableLessThanOrEqualTo(String value) {
            addCriterion("cod_estable <=", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableLike(String value) {
            addCriterion("cod_estable like", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableNotLike(String value) {
            addCriterion("cod_estable not like", value, "codEstable");
            return this;
        }

        public Criteria andCodEstableIn(List<String> values) {
            addCriterion("cod_estable in", values, "codEstable");
            return this;
        }

        public Criteria andCodEstableNotIn(List<String> values) {
            addCriterion("cod_estable not in", values, "codEstable");
            return this;
        }

        public Criteria andCodEstableBetween(String value1, String value2) {
            addCriterion("cod_estable between", value1, value2, "codEstable");
            return this;
        }

        public Criteria andCodEstableNotBetween(String value1, String value2) {
            addCriterion("cod_estable not between", value1, value2, "codEstable");
            return this;
        }

        public Criteria andEstProcesoIsNull() {
            addCriterion("est_proceso is null");
            return this;
        }

        public Criteria andEstProcesoIsNotNull() {
            addCriterion("est_proceso is not null");
            return this;
        }

        public Criteria andEstProcesoEqualTo(String value) {
            addCriterion("est_proceso =", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotEqualTo(String value) {
            addCriterion("est_proceso <>", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThan(String value) {
            addCriterion("est_proceso >", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThanOrEqualTo(String value) {
            addCriterion("est_proceso >=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThan(String value) {
            addCriterion("est_proceso <", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThanOrEqualTo(String value) {
            addCriterion("est_proceso <=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLike(String value) {
            addCriterion("est_proceso like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotLike(String value) {
            addCriterion("est_proceso not like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoIn(List<String> values) {
            addCriterion("est_proceso in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotIn(List<String> values) {
            addCriterion("est_proceso not in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoBetween(String value1, String value2) {
            addCriterion("est_proceso between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotBetween(String value1, String value2) {
            addCriterion("est_proceso not between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andAccCreacionIsNull() {
            addCriterion("acc_creacion is null");
            return this;
        }

        public Criteria andAccCreacionIsNotNull() {
            addCriterion("acc_creacion is not null");
            return this;
        }

        public Criteria andAccCreacionEqualTo(String value) {
            addCriterion("acc_creacion =", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotEqualTo(String value) {
            addCriterion("acc_creacion <>", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThan(String value) {
            addCriterion("acc_creacion >", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThanOrEqualTo(String value) {
            addCriterion("acc_creacion >=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThan(String value) {
            addCriterion("acc_creacion <", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThanOrEqualTo(String value) {
            addCriterion("acc_creacion <=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLike(String value) {
            addCriterion("acc_creacion like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotLike(String value) {
            addCriterion("acc_creacion not like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionIn(List<String> values) {
            addCriterion("acc_creacion in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotIn(List<String> values) {
            addCriterion("acc_creacion not in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionBetween(String value1, String value2) {
            addCriterion("acc_creacion between", value1, value2, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotBetween(String value1, String value2) {
            addCriterion("acc_creacion not between", value1, value2, "accCreacion");
            return this;
        }
    }
}