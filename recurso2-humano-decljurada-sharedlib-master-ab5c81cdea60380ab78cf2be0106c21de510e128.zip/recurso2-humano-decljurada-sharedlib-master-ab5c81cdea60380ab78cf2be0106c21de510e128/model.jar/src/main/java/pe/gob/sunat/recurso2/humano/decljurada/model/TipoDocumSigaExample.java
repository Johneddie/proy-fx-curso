package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class TipoDocumSigaExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public TipoDocumSigaExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected TipoDocumSigaExample(TipoDocumSigaExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andTipoDocuIdeIsNull() {
            addCriterion("TIPO_DOCU_IDE is null");
            return this;
        }

        public Criteria andTipoDocuIdeIsNotNull() {
            addCriterion("TIPO_DOCU_IDE is not null");
            return this;
        }

        public Criteria andTipoDocuIdeEqualTo(String value) {
            addCriterion("TIPO_DOCU_IDE =", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeNotEqualTo(String value) {
            addCriterion("TIPO_DOCU_IDE <>", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeGreaterThan(String value) {
            addCriterion("TIPO_DOCU_IDE >", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeGreaterThanOrEqualTo(String value) {
            addCriterion("TIPO_DOCU_IDE >=", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeLessThan(String value) {
            addCriterion("TIPO_DOCU_IDE <", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeLessThanOrEqualTo(String value) {
            addCriterion("TIPO_DOCU_IDE <=", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeLike(String value) {
            addCriterion("TIPO_DOCU_IDE like", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeNotLike(String value) {
            addCriterion("TIPO_DOCU_IDE not like", value, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeIn(List<String> values) {
            addCriterion("TIPO_DOCU_IDE in", values, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeNotIn(List<String> values) {
            addCriterion("TIPO_DOCU_IDE not in", values, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeBetween(String value1, String value2) {
            addCriterion("TIPO_DOCU_IDE between", value1, value2, "tipoDocuIde");
            return this;
        }

        public Criteria andTipoDocuIdeNotBetween(String value1, String value2) {
            addCriterion("TIPO_DOCU_IDE not between", value1, value2, "tipoDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeIsNull() {
            addCriterion("NOMB_DOCU_IDE is null");
            return this;
        }

        public Criteria andNombDocuIdeIsNotNull() {
            addCriterion("NOMB_DOCU_IDE is not null");
            return this;
        }

        public Criteria andNombDocuIdeEqualTo(String value) {
            addCriterion("NOMB_DOCU_IDE =", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeNotEqualTo(String value) {
            addCriterion("NOMB_DOCU_IDE <>", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeGreaterThan(String value) {
            addCriterion("NOMB_DOCU_IDE >", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeGreaterThanOrEqualTo(String value) {
            addCriterion("NOMB_DOCU_IDE >=", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeLessThan(String value) {
            addCriterion("NOMB_DOCU_IDE <", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeLessThanOrEqualTo(String value) {
            addCriterion("NOMB_DOCU_IDE <=", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeLike(String value) {
            addCriterion("NOMB_DOCU_IDE like", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeNotLike(String value) {
            addCriterion("NOMB_DOCU_IDE not like", value, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeIn(List<String> values) {
            addCriterion("NOMB_DOCU_IDE in", values, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeNotIn(List<String> values) {
            addCriterion("NOMB_DOCU_IDE not in", values, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeBetween(String value1, String value2) {
            addCriterion("NOMB_DOCU_IDE between", value1, value2, "nombDocuIde");
            return this;
        }

        public Criteria andNombDocuIdeNotBetween(String value1, String value2) {
            addCriterion("NOMB_DOCU_IDE not between", value1, value2, "nombDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeIsNull() {
            addCriterion("LONG_DOCU_IDE is null");
            return this;
        }

        public Criteria andLongDocuIdeIsNotNull() {
            addCriterion("LONG_DOCU_IDE is not null");
            return this;
        }

        public Criteria andLongDocuIdeEqualTo(Short value) {
            addCriterion("LONG_DOCU_IDE =", value, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeNotEqualTo(Short value) {
            addCriterion("LONG_DOCU_IDE <>", value, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeGreaterThan(Short value) {
            addCriterion("LONG_DOCU_IDE >", value, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeGreaterThanOrEqualTo(Short value) {
            addCriterion("LONG_DOCU_IDE >=", value, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeLessThan(Short value) {
            addCriterion("LONG_DOCU_IDE <", value, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeLessThanOrEqualTo(Short value) {
            addCriterion("LONG_DOCU_IDE <=", value, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeIn(List<Short> values) {
            addCriterion("LONG_DOCU_IDE in", values, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeNotIn(List<Short> values) {
            addCriterion("LONG_DOCU_IDE not in", values, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeBetween(Short value1, Short value2) {
            addCriterion("LONG_DOCU_IDE between", value1, value2, "longDocuIde");
            return this;
        }

        public Criteria andLongDocuIdeNotBetween(Short value1, Short value2) {
            addCriterion("LONG_DOCU_IDE not between", value1, value2, "longDocuIde");
            return this;
        }

        public Criteria andCodigoMefIsNull() {
            addCriterion("CODIGO_MEF is null");
            return this;
        }

        public Criteria andCodigoMefIsNotNull() {
            addCriterion("CODIGO_MEF is not null");
            return this;
        }

        public Criteria andCodigoMefEqualTo(String value) {
            addCriterion("CODIGO_MEF =", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefNotEqualTo(String value) {
            addCriterion("CODIGO_MEF <>", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefGreaterThan(String value) {
            addCriterion("CODIGO_MEF >", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_MEF >=", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefLessThan(String value) {
            addCriterion("CODIGO_MEF <", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_MEF <=", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefLike(String value) {
            addCriterion("CODIGO_MEF like", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefNotLike(String value) {
            addCriterion("CODIGO_MEF not like", value, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefIn(List<String> values) {
            addCriterion("CODIGO_MEF in", values, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefNotIn(List<String> values) {
            addCriterion("CODIGO_MEF not in", values, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefBetween(String value1, String value2) {
            addCriterion("CODIGO_MEF between", value1, value2, "codigoMef");
            return this;
        }

        public Criteria andCodigoMefNotBetween(String value1, String value2) {
            addCriterion("CODIGO_MEF not between", value1, value2, "codigoMef");
            return this;
        }

        public Criteria andUserCreaIsNull() {
            addCriterion("USER_CREA is null");
            return this;
        }

        public Criteria andUserCreaIsNotNull() {
            addCriterion("USER_CREA is not null");
            return this;
        }

        public Criteria andUserCreaEqualTo(String value) {
            addCriterion("USER_CREA =", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotEqualTo(String value) {
            addCriterion("USER_CREA <>", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaGreaterThan(String value) {
            addCriterion("USER_CREA >", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaGreaterThanOrEqualTo(String value) {
            addCriterion("USER_CREA >=", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaLessThan(String value) {
            addCriterion("USER_CREA <", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaLessThanOrEqualTo(String value) {
            addCriterion("USER_CREA <=", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaLike(String value) {
            addCriterion("USER_CREA like", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotLike(String value) {
            addCriterion("USER_CREA not like", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaIn(List<String> values) {
            addCriterion("USER_CREA in", values, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotIn(List<String> values) {
            addCriterion("USER_CREA not in", values, "userCrea");
            return this;
        }

        public Criteria andUserCreaBetween(String value1, String value2) {
            addCriterion("USER_CREA between", value1, value2, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotBetween(String value1, String value2) {
            addCriterion("USER_CREA not between", value1, value2, "userCrea");
            return this;
        }

        public Criteria andFechCreaIsNull() {
            addCriterion("FECH_CREA is null");
            return this;
        }

        public Criteria andFechCreaIsNotNull() {
            addCriterion("FECH_CREA is not null");
            return this;
        }

        public Criteria andFechCreaEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA =", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA <>", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaGreaterThan(Date value) {
            addCriterionForJDBCDate("FECH_CREA >", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA >=", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaLessThan(Date value) {
            addCriterionForJDBCDate("FECH_CREA <", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA <=", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_CREA in", values, "fechCrea");
            return this;
        }

        public Criteria andFechCreaNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_CREA not in", values, "fechCrea");
            return this;
        }

        public Criteria andFechCreaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_CREA between", value1, value2, "fechCrea");
            return this;
        }

        public Criteria andFechCreaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_CREA not between", value1, value2, "fechCrea");
            return this;
        }

        public Criteria andUserModiIsNull() {
            addCriterion("USER_MODI is null");
            return this;
        }

        public Criteria andUserModiIsNotNull() {
            addCriterion("USER_MODI is not null");
            return this;
        }

        public Criteria andUserModiEqualTo(String value) {
            addCriterion("USER_MODI =", value, "userModi");
            return this;
        }

        public Criteria andUserModiNotEqualTo(String value) {
            addCriterion("USER_MODI <>", value, "userModi");
            return this;
        }

        public Criteria andUserModiGreaterThan(String value) {
            addCriterion("USER_MODI >", value, "userModi");
            return this;
        }

        public Criteria andUserModiGreaterThanOrEqualTo(String value) {
            addCriterion("USER_MODI >=", value, "userModi");
            return this;
        }

        public Criteria andUserModiLessThan(String value) {
            addCriterion("USER_MODI <", value, "userModi");
            return this;
        }

        public Criteria andUserModiLessThanOrEqualTo(String value) {
            addCriterion("USER_MODI <=", value, "userModi");
            return this;
        }

        public Criteria andUserModiLike(String value) {
            addCriterion("USER_MODI like", value, "userModi");
            return this;
        }

        public Criteria andUserModiNotLike(String value) {
            addCriterion("USER_MODI not like", value, "userModi");
            return this;
        }

        public Criteria andUserModiIn(List<String> values) {
            addCriterion("USER_MODI in", values, "userModi");
            return this;
        }

        public Criteria andUserModiNotIn(List<String> values) {
            addCriterion("USER_MODI not in", values, "userModi");
            return this;
        }

        public Criteria andUserModiBetween(String value1, String value2) {
            addCriterion("USER_MODI between", value1, value2, "userModi");
            return this;
        }

        public Criteria andUserModiNotBetween(String value1, String value2) {
            addCriterion("USER_MODI not between", value1, value2, "userModi");
            return this;
        }

        public Criteria andFechModiIsNull() {
            addCriterion("FECH_MODI is null");
            return this;
        }

        public Criteria andFechModiIsNotNull() {
            addCriterion("FECH_MODI is not null");
            return this;
        }

        public Criteria andFechModiEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI =", value, "fechModi");
            return this;
        }

        public Criteria andFechModiNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI <>", value, "fechModi");
            return this;
        }

        public Criteria andFechModiGreaterThan(Date value) {
            addCriterionForJDBCDate("FECH_MODI >", value, "fechModi");
            return this;
        }

        public Criteria andFechModiGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI >=", value, "fechModi");
            return this;
        }

        public Criteria andFechModiLessThan(Date value) {
            addCriterionForJDBCDate("FECH_MODI <", value, "fechModi");
            return this;
        }

        public Criteria andFechModiLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI <=", value, "fechModi");
            return this;
        }

        public Criteria andFechModiIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_MODI in", values, "fechModi");
            return this;
        }

        public Criteria andFechModiNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_MODI not in", values, "fechModi");
            return this;
        }

        public Criteria andFechModiBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_MODI between", value1, value2, "fechModi");
            return this;
        }

        public Criteria andFechModiNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_MODI not between", value1, value2, "fechModi");
            return this;
        }

        public Criteria andCodReniecIsNull() {
            addCriterion("COD_RENIEC is null");
            return this;
        }

        public Criteria andCodReniecIsNotNull() {
            addCriterion("COD_RENIEC is not null");
            return this;
        }

        public Criteria andCodReniecEqualTo(String value) {
            addCriterion("COD_RENIEC =", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecNotEqualTo(String value) {
            addCriterion("COD_RENIEC <>", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecGreaterThan(String value) {
            addCriterion("COD_RENIEC >", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecGreaterThanOrEqualTo(String value) {
            addCriterion("COD_RENIEC >=", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecLessThan(String value) {
            addCriterion("COD_RENIEC <", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecLessThanOrEqualTo(String value) {
            addCriterion("COD_RENIEC <=", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecLike(String value) {
            addCriterion("COD_RENIEC like", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecNotLike(String value) {
            addCriterion("COD_RENIEC not like", value, "codReniec");
            return this;
        }

        public Criteria andCodReniecIn(List<String> values) {
            addCriterion("COD_RENIEC in", values, "codReniec");
            return this;
        }

        public Criteria andCodReniecNotIn(List<String> values) {
            addCriterion("COD_RENIEC not in", values, "codReniec");
            return this;
        }

        public Criteria andCodReniecBetween(String value1, String value2) {
            addCriterion("COD_RENIEC between", value1, value2, "codReniec");
            return this;
        }

        public Criteria andCodReniecNotBetween(String value1, String value2) {
            addCriterion("COD_RENIEC not between", value1, value2, "codReniec");
            return this;
        }

        public Criteria andDesReniecIsNull() {
            addCriterion("DES_RENIEC is null");
            return this;
        }

        public Criteria andDesReniecIsNotNull() {
            addCriterion("DES_RENIEC is not null");
            return this;
        }

        public Criteria andDesReniecEqualTo(String value) {
            addCriterion("DES_RENIEC =", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecNotEqualTo(String value) {
            addCriterion("DES_RENIEC <>", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecGreaterThan(String value) {
            addCriterion("DES_RENIEC >", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecGreaterThanOrEqualTo(String value) {
            addCriterion("DES_RENIEC >=", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecLessThan(String value) {
            addCriterion("DES_RENIEC <", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecLessThanOrEqualTo(String value) {
            addCriterion("DES_RENIEC <=", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecLike(String value) {
            addCriterion("DES_RENIEC like", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecNotLike(String value) {
            addCriterion("DES_RENIEC not like", value, "desReniec");
            return this;
        }

        public Criteria andDesReniecIn(List<String> values) {
            addCriterion("DES_RENIEC in", values, "desReniec");
            return this;
        }

        public Criteria andDesReniecNotIn(List<String> values) {
            addCriterion("DES_RENIEC not in", values, "desReniec");
            return this;
        }

        public Criteria andDesReniecBetween(String value1, String value2) {
            addCriterion("DES_RENIEC between", value1, value2, "desReniec");
            return this;
        }

        public Criteria andDesReniecNotBetween(String value1, String value2) {
            addCriterion("DES_RENIEC not between", value1, value2, "desReniec");
            return this;
        }

        public Criteria andCodSirhIsNull() {
            addCriterion("COD_SIRH is null");
            return this;
        }

        public Criteria andCodSirhIsNotNull() {
            addCriterion("COD_SIRH is not null");
            return this;
        }

        public Criteria andCodSirhEqualTo(String value) {
            addCriterion("COD_SIRH =", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhNotEqualTo(String value) {
            addCriterion("COD_SIRH <>", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhGreaterThan(String value) {
            addCriterion("COD_SIRH >", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhGreaterThanOrEqualTo(String value) {
            addCriterion("COD_SIRH >=", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhLessThan(String value) {
            addCriterion("COD_SIRH <", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhLessThanOrEqualTo(String value) {
            addCriterion("COD_SIRH <=", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhLike(String value) {
            addCriterion("COD_SIRH like", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhNotLike(String value) {
            addCriterion("COD_SIRH not like", value, "codSirh");
            return this;
        }

        public Criteria andCodSirhIn(List<String> values) {
            addCriterion("COD_SIRH in", values, "codSirh");
            return this;
        }

        public Criteria andCodSirhNotIn(List<String> values) {
            addCriterion("COD_SIRH not in", values, "codSirh");
            return this;
        }

        public Criteria andCodSirhBetween(String value1, String value2) {
            addCriterion("COD_SIRH between", value1, value2, "codSirh");
            return this;
        }

        public Criteria andCodSirhNotBetween(String value1, String value2) {
            addCriterion("COD_SIRH not between", value1, value2, "codSirh");
            return this;
        }

        public Criteria andCodDdsIsNull() {
            addCriterion("COD_DDS is null");
            return this;
        }

        public Criteria andCodDdsIsNotNull() {
            addCriterion("COD_DDS is not null");
            return this;
        }

        public Criteria andCodDdsEqualTo(String value) {
            addCriterion("COD_DDS =", value, "codDds");
            return this;
        }

        public Criteria andCodDdsNotEqualTo(String value) {
            addCriterion("COD_DDS <>", value, "codDds");
            return this;
        }

        public Criteria andCodDdsGreaterThan(String value) {
            addCriterion("COD_DDS >", value, "codDds");
            return this;
        }

        public Criteria andCodDdsGreaterThanOrEqualTo(String value) {
            addCriterion("COD_DDS >=", value, "codDds");
            return this;
        }

        public Criteria andCodDdsLessThan(String value) {
            addCriterion("COD_DDS <", value, "codDds");
            return this;
        }

        public Criteria andCodDdsLessThanOrEqualTo(String value) {
            addCriterion("COD_DDS <=", value, "codDds");
            return this;
        }

        public Criteria andCodDdsLike(String value) {
            addCriterion("COD_DDS like", value, "codDds");
            return this;
        }

        public Criteria andCodDdsNotLike(String value) {
            addCriterion("COD_DDS not like", value, "codDds");
            return this;
        }

        public Criteria andCodDdsIn(List<String> values) {
            addCriterion("COD_DDS in", values, "codDds");
            return this;
        }

        public Criteria andCodDdsNotIn(List<String> values) {
            addCriterion("COD_DDS not in", values, "codDds");
            return this;
        }

        public Criteria andCodDdsBetween(String value1, String value2) {
            addCriterion("COD_DDS between", value1, value2, "codDds");
            return this;
        }

        public Criteria andCodDdsNotBetween(String value1, String value2) {
            addCriterion("COD_DDS not between", value1, value2, "codDds");
            return this;
        }
    }
}