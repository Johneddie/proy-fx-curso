package pe.gob.sunat.recurso2.humano.decljurada.model;

public class DerechohabSelKey {
    private Short numCorrel;

    private Integer numPostulante;

    public Short getNumCorrel() {
        return numCorrel;
    }

    public void setNumCorrel(Short numCorrel) {
        this.numCorrel = numCorrel;
    }

    public Integer getNumPostulante() {
        return numPostulante;
    }

    public void setNumPostulante(Integer numPostulante) {
        this.numPostulante = numPostulante;
    }
}