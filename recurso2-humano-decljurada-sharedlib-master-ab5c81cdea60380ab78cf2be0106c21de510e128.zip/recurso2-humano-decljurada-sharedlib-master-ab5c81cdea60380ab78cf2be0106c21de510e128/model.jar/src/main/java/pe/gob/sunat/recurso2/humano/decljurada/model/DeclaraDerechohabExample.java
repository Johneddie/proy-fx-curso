package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DeclaraDerechohabExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public DeclaraDerechohabExample() {
        oredCriteria = new ArrayList<>();
    }

    protected DeclaraDerechohabExample(DeclaraDerechohabExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andAnnDdjjIsNull() {
            addCriterion("ann_ddjj is null");
            return this;
        }

        public Criteria andAnnDdjjIsNotNull() {
            addCriterion("ann_ddjj is not null");
            return this;
        }

        public Criteria andAnnDdjjEqualTo(String value) {
            addCriterion("ann_ddjj =", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotEqualTo(String value) {
            addCriterion("ann_ddjj <>", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThan(String value) {
            addCriterion("ann_ddjj >", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThanOrEqualTo(String value) {
            addCriterion("ann_ddjj >=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThan(String value) {
            addCriterion("ann_ddjj <", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThanOrEqualTo(String value) {
            addCriterion("ann_ddjj <=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLike(String value) {
            addCriterion("ann_ddjj like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotLike(String value) {
            addCriterion("ann_ddjj not like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjIn(List<String> values) {
            addCriterion("ann_ddjj in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotIn(List<String> values) {
            addCriterion("ann_ddjj not in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjBetween(String value1, String value2) {
            addCriterion("ann_ddjj between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotBetween(String value1, String value2) {
            addCriterion("ann_ddjj not between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andIndEstadoIsNull() {
            addCriterion("ind_estado is null");
            return this;
        }

        public Criteria andIndEstadoIsNotNull() {
            addCriterion("ind_estado is not null");
            return this;
        }

        public Criteria andIndEstadoEqualTo(String value) {
            addCriterion("ind_estado =", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotEqualTo(String value) {
            addCriterion("ind_estado <>", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoGreaterThan(String value) {
            addCriterion("ind_estado >", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_estado >=", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLessThan(String value) {
            addCriterion("ind_estado <", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLessThanOrEqualTo(String value) {
            addCriterion("ind_estado <=", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLike(String value) {
            addCriterion("ind_estado like", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotLike(String value) {
            addCriterion("ind_estado not like", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoIn(List<String> values) {
            addCriterion("ind_estado in", values, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotIn(List<String> values) {
            addCriterion("ind_estado not in", values, "indEstado");
            return this;
        }

        public Criteria andIndEstadoBetween(String value1, String value2) {
            addCriterion("ind_estado between", value1, value2, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotBetween(String value1, String value2) {
            addCriterion("ind_estado not between", value1, value2, "indEstado");
            return this;
        }

        public Criteria andNumDdjjIsNull() {
            addCriterion("num_ddjj is null");
            return this;
        }

        public Criteria andNumDdjjIsNotNull() {
            addCriterion("num_ddjj is not null");
            return this;
        }

        public Criteria andNumDdjjEqualTo(Integer value) {
            addCriterion("num_ddjj =", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotEqualTo(Integer value) {
            addCriterion("num_ddjj <>", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThan(Integer value) {
            addCriterion("num_ddjj >", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj >=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThan(Integer value) {
            addCriterion("num_ddjj <", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj <=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjIn(List<Integer> values) {
            addCriterion("num_ddjj in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotIn(List<Integer> values) {
            addCriterion("num_ddjj not in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj not between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andCodPersonalIsNull() {
            addCriterion("cod_personal is null");
            return this;
        }

        public Criteria andCodPersonalIsNotNull() {
            addCriterion("cod_personal is not null");
            return this;
        }

        public Criteria andCodPersonalEqualTo(String value) {
            addCriterion("cod_personal =", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotEqualTo(String value) {
            addCriterion("cod_personal <>", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThan(String value) {
            addCriterion("cod_personal >", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThanOrEqualTo(String value) {
            addCriterion("cod_personal >=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThan(String value) {
            addCriterion("cod_personal <", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThanOrEqualTo(String value) {
            addCriterion("cod_personal <=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLike(String value) {
            addCriterion("cod_personal like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotLike(String value) {
            addCriterion("cod_personal not like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalIn(List<String> values) {
            addCriterion("cod_personal in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotIn(List<String> values) {
            addCriterion("cod_personal not in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalBetween(String value1, String value2) {
            addCriterion("cod_personal between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotBetween(String value1, String value2) {
            addCriterion("cod_personal not between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andCodUorganIsNull() {
            addCriterion("cod_uorgan is null");
            return this;
        }

        public Criteria andCodUorganIsNotNull() {
            addCriterion("cod_uorgan is not null");
            return this;
        }

        public Criteria andCodUorganEqualTo(String value) {
            addCriterion("cod_uorgan =", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotEqualTo(String value) {
            addCriterion("cod_uorgan <>", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThan(String value) {
            addCriterion("cod_uorgan >", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThanOrEqualTo(String value) {
            addCriterion("cod_uorgan >=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThan(String value) {
            addCriterion("cod_uorgan <", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThanOrEqualTo(String value) {
            addCriterion("cod_uorgan <=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLike(String value) {
            addCriterion("cod_uorgan like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotLike(String value) {
            addCriterion("cod_uorgan not like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganIn(List<String> values) {
            addCriterion("cod_uorgan in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotIn(List<String> values) {
            addCriterion("cod_uorgan not in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganBetween(String value1, String value2) {
            addCriterion("cod_uorgan between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotBetween(String value1, String value2) {
            addCriterion("cod_uorgan not between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodDocumDerIsNull() {
            addCriterion("cod_docum_der is null");
            return this;
        }

        public Criteria andCodDocumDerIsNotNull() {
            addCriterion("cod_docum_der is not null");
            return this;
        }

        public Criteria andCodDocumDerEqualTo(String value) {
            addCriterion("cod_docum_der =", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotEqualTo(String value) {
            addCriterion("cod_docum_der <>", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerGreaterThan(String value) {
            addCriterion("cod_docum_der >", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum_der >=", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLessThan(String value) {
            addCriterion("cod_docum_der <", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLessThanOrEqualTo(String value) {
            addCriterion("cod_docum_der <=", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLike(String value) {
            addCriterion("cod_docum_der like", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotLike(String value) {
            addCriterion("cod_docum_der not like", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerIn(List<String> values) {
            addCriterion("cod_docum_der in", values, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotIn(List<String> values) {
            addCriterion("cod_docum_der not in", values, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerBetween(String value1, String value2) {
            addCriterion("cod_docum_der between", value1, value2, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotBetween(String value1, String value2) {
            addCriterion("cod_docum_der not between", value1, value2, "codDocumDer");
            return this;
        }

        public Criteria andNumDocumDerIsNull() {
            addCriterion("num_docum_der is null");
            return this;
        }

        public Criteria andNumDocumDerIsNotNull() {
            addCriterion("num_docum_der is not null");
            return this;
        }

        public Criteria andNumDocumDerEqualTo(String value) {
            addCriterion("num_docum_der =", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotEqualTo(String value) {
            addCriterion("num_docum_der <>", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerGreaterThan(String value) {
            addCriterion("num_docum_der >", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum_der >=", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLessThan(String value) {
            addCriterion("num_docum_der <", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLessThanOrEqualTo(String value) {
            addCriterion("num_docum_der <=", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLike(String value) {
            addCriterion("num_docum_der like", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotLike(String value) {
            addCriterion("num_docum_der not like", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerIn(List<String> values) {
            addCriterion("num_docum_der in", values, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotIn(List<String> values) {
            addCriterion("num_docum_der not in", values, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerBetween(String value1, String value2) {
            addCriterion("num_docum_der between", value1, value2, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotBetween(String value1, String value2) {
            addCriterion("num_docum_der not between", value1, value2, "numDocumDer");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andFecNacimientoDerIsNull() {
            addCriterion("fec_nacimiento_der is null");
            return this;
        }

        public Criteria andFecNacimientoDerIsNotNull() {
            addCriterion("fec_nacimiento_der is not null");
            return this;
        }

        public Criteria andFecNacimientoDerEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der =", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der <>", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der >", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der >=", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerLessThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der <", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der <=", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento_der in", values, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento_der not in", values, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento_der between", value1, value2, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento_der not between", value1, value2, "fecNacimientoDer");
            return this;
        }

        public Criteria andApePatDerIsNull() {
            addCriterion("ape_pat_der is null");
            return this;
        }

        public Criteria andApePatDerIsNotNull() {
            addCriterion("ape_pat_der is not null");
            return this;
        }

        public Criteria andApePatDerEqualTo(String value) {
            addCriterion("ape_pat_der =", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotEqualTo(String value) {
            addCriterion("ape_pat_der <>", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerGreaterThan(String value) {
            addCriterion("ape_pat_der >", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerGreaterThanOrEqualTo(String value) {
            addCriterion("ape_pat_der >=", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLessThan(String value) {
            addCriterion("ape_pat_der <", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLessThanOrEqualTo(String value) {
            addCriterion("ape_pat_der <=", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLike(String value) {
            addCriterion("ape_pat_der like", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotLike(String value) {
            addCriterion("ape_pat_der not like", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerIn(List<String> values) {
            addCriterion("ape_pat_der in", values, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotIn(List<String> values) {
            addCriterion("ape_pat_der not in", values, "apePatDer");
            return this;
        }

        public Criteria andApePatDerBetween(String value1, String value2) {
            addCriterion("ape_pat_der between", value1, value2, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotBetween(String value1, String value2) {
            addCriterion("ape_pat_der not between", value1, value2, "apePatDer");
            return this;
        }

        public Criteria andApeMatDerIsNull() {
            addCriterion("ape_mat_der is null");
            return this;
        }

        public Criteria andApeMatDerIsNotNull() {
            addCriterion("ape_mat_der is not null");
            return this;
        }

        public Criteria andApeMatDerEqualTo(String value) {
            addCriterion("ape_mat_der =", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotEqualTo(String value) {
            addCriterion("ape_mat_der <>", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerGreaterThan(String value) {
            addCriterion("ape_mat_der >", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerGreaterThanOrEqualTo(String value) {
            addCriterion("ape_mat_der >=", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLessThan(String value) {
            addCriterion("ape_mat_der <", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLessThanOrEqualTo(String value) {
            addCriterion("ape_mat_der <=", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLike(String value) {
            addCriterion("ape_mat_der like", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotLike(String value) {
            addCriterion("ape_mat_der not like", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerIn(List<String> values) {
            addCriterion("ape_mat_der in", values, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotIn(List<String> values) {
            addCriterion("ape_mat_der not in", values, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerBetween(String value1, String value2) {
            addCriterion("ape_mat_der between", value1, value2, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotBetween(String value1, String value2) {
            addCriterion("ape_mat_der not between", value1, value2, "apeMatDer");
            return this;
        }

        public Criteria andNomDerIsNull() {
            addCriterion("nom_der is null");
            return this;
        }

        public Criteria andNomDerIsNotNull() {
            addCriterion("nom_der is not null");
            return this;
        }

        public Criteria andNomDerEqualTo(String value) {
            addCriterion("nom_der =", value, "nomDer");
            return this;
        }

        public Criteria andNomDerNotEqualTo(String value) {
            addCriterion("nom_der <>", value, "nomDer");
            return this;
        }

        public Criteria andNomDerGreaterThan(String value) {
            addCriterion("nom_der >", value, "nomDer");
            return this;
        }

        public Criteria andNomDerGreaterThanOrEqualTo(String value) {
            addCriterion("nom_der >=", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLessThan(String value) {
            addCriterion("nom_der <", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLessThanOrEqualTo(String value) {
            addCriterion("nom_der <=", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLike(String value) {
            addCriterion("nom_der like", value, "nomDer");
            return this;
        }

        public Criteria andNomDerNotLike(String value) {
            addCriterion("nom_der not like", value, "nomDer");
            return this;
        }

        public Criteria andNomDerIn(List<String> values) {
            addCriterion("nom_der in", values, "nomDer");
            return this;
        }

        public Criteria andNomDerNotIn(List<String> values) {
            addCriterion("nom_der not in", values, "nomDer");
            return this;
        }

        public Criteria andNomDerBetween(String value1, String value2) {
            addCriterion("nom_der between", value1, value2, "nomDer");
            return this;
        }

        public Criteria andNomDerNotBetween(String value1, String value2) {
            addCriterion("nom_der not between", value1, value2, "nomDer");
            return this;
        }

        public Criteria andIndSexoDerIsNull() {
            addCriterion("ind_sexo_der is null");
            return this;
        }

        public Criteria andIndSexoDerIsNotNull() {
            addCriterion("ind_sexo_der is not null");
            return this;
        }

        public Criteria andIndSexoDerEqualTo(String value) {
            addCriterion("ind_sexo_der =", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotEqualTo(String value) {
            addCriterion("ind_sexo_der <>", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerGreaterThan(String value) {
            addCriterion("ind_sexo_der >", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sexo_der >=", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerLessThan(String value) {
            addCriterion("ind_sexo_der <", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerLessThanOrEqualTo(String value) {
            addCriterion("ind_sexo_der <=", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerLike(String value) {
            addCriterion("ind_sexo_der like", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotLike(String value) {
            addCriterion("ind_sexo_der not like", value, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerIn(List<String> values) {
            addCriterion("ind_sexo_der in", values, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotIn(List<String> values) {
            addCriterion("ind_sexo_der not in", values, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerBetween(String value1, String value2) {
            addCriterion("ind_sexo_der between", value1, value2, "indSexoDer");
            return this;
        }

        public Criteria andIndSexoDerNotBetween(String value1, String value2) {
            addCriterion("ind_sexo_der not between", value1, value2, "indSexoDer");
            return this;
        }

        public Criteria andCodVinFamIsNull() {
            addCriterion("cod_vin_fam is null");
            return this;
        }

        public Criteria andCodVinFamIsNotNull() {
            addCriterion("cod_vin_fam is not null");
            return this;
        }

        public Criteria andCodVinFamEqualTo(String value) {
            addCriterion("cod_vin_fam =", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotEqualTo(String value) {
            addCriterion("cod_vin_fam <>", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamGreaterThan(String value) {
            addCriterion("cod_vin_fam >", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamGreaterThanOrEqualTo(String value) {
            addCriterion("cod_vin_fam >=", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLessThan(String value) {
            addCriterion("cod_vin_fam <", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLessThanOrEqualTo(String value) {
            addCriterion("cod_vin_fam <=", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLike(String value) {
            addCriterion("cod_vin_fam like", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotLike(String value) {
            addCriterion("cod_vin_fam not like", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamIn(List<String> values) {
            addCriterion("cod_vin_fam in", values, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotIn(List<String> values) {
            addCriterion("cod_vin_fam not in", values, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamBetween(String value1, String value2) {
            addCriterion("cod_vin_fam between", value1, value2, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotBetween(String value1, String value2) {
            addCriterion("cod_vin_fam not between", value1, value2, "codVinFam");
            return this;
        }

        public Criteria andCodDocAcreVinIsNull() {
            addCriterion("cod_doc_acre_vin is null");
            return this;
        }

        public Criteria andCodDocAcreVinIsNotNull() {
            addCriterion("cod_doc_acre_vin is not null");
            return this;
        }

        public Criteria andCodDocAcreVinEqualTo(String value) {
            addCriterion("cod_doc_acre_vin =", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotEqualTo(String value) {
            addCriterion("cod_doc_acre_vin <>", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinGreaterThan(String value) {
            addCriterion("cod_doc_acre_vin >", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinGreaterThanOrEqualTo(String value) {
            addCriterion("cod_doc_acre_vin >=", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinLessThan(String value) {
            addCriterion("cod_doc_acre_vin <", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinLessThanOrEqualTo(String value) {
            addCriterion("cod_doc_acre_vin <=", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinLike(String value) {
            addCriterion("cod_doc_acre_vin like", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotLike(String value) {
            addCriterion("cod_doc_acre_vin not like", value, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinIn(List<String> values) {
            addCriterion("cod_doc_acre_vin in", values, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotIn(List<String> values) {
            addCriterion("cod_doc_acre_vin not in", values, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinBetween(String value1, String value2) {
            addCriterion("cod_doc_acre_vin between", value1, value2, "codDocAcreVin");
            return this;
        }

        public Criteria andCodDocAcreVinNotBetween(String value1, String value2) {
            addCriterion("cod_doc_acre_vin not between", value1, value2, "codDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinIsNull() {
            addCriterion("num_doc_acre_vin is null");
            return this;
        }

        public Criteria andNumDocAcreVinIsNotNull() {
            addCriterion("num_doc_acre_vin is not null");
            return this;
        }

        public Criteria andNumDocAcreVinEqualTo(String value) {
            addCriterion("num_doc_acre_vin =", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotEqualTo(String value) {
            addCriterion("num_doc_acre_vin <>", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinGreaterThan(String value) {
            addCriterion("num_doc_acre_vin >", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinGreaterThanOrEqualTo(String value) {
            addCriterion("num_doc_acre_vin >=", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinLessThan(String value) {
            addCriterion("num_doc_acre_vin <", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinLessThanOrEqualTo(String value) {
            addCriterion("num_doc_acre_vin <=", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinLike(String value) {
            addCriterion("num_doc_acre_vin like", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotLike(String value) {
            addCriterion("num_doc_acre_vin not like", value, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinIn(List<String> values) {
            addCriterion("num_doc_acre_vin in", values, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotIn(List<String> values) {
            addCriterion("num_doc_acre_vin not in", values, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinBetween(String value1, String value2) {
            addCriterion("num_doc_acre_vin between", value1, value2, "numDocAcreVin");
            return this;
        }

        public Criteria andNumDocAcreVinNotBetween(String value1, String value2) {
            addCriterion("num_doc_acre_vin not between", value1, value2, "numDocAcreVin");
            return this;
        }

        public Criteria andNumMesConcepIsNull() {
            addCriterion("num_mes_concep is null");
            return this;
        }

        public Criteria andNumMesConcepIsNotNull() {
            addCriterion("num_mes_concep is not null");
            return this;
        }

        public Criteria andNumMesConcepEqualTo(String value) {
            addCriterion("num_mes_concep =", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotEqualTo(String value) {
            addCriterion("num_mes_concep <>", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepGreaterThan(String value) {
            addCriterion("num_mes_concep >", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepGreaterThanOrEqualTo(String value) {
            addCriterion("num_mes_concep >=", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepLessThan(String value) {
            addCriterion("num_mes_concep <", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepLessThanOrEqualTo(String value) {
            addCriterion("num_mes_concep <=", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepLike(String value) {
            addCriterion("num_mes_concep like", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotLike(String value) {
            addCriterion("num_mes_concep not like", value, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepIn(List<String> values) {
            addCriterion("num_mes_concep in", values, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotIn(List<String> values) {
            addCriterion("num_mes_concep not in", values, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepBetween(String value1, String value2) {
            addCriterion("num_mes_concep between", value1, value2, "numMesConcep");
            return this;
        }

        public Criteria andNumMesConcepNotBetween(String value1, String value2) {
            addCriterion("num_mes_concep not between", value1, value2, "numMesConcep");
            return this;
        }

        public Criteria andIndSituFamIsNull() {
            addCriterion("ind_situ_fam is null");
            return this;
        }

        public Criteria andIndSituFamIsNotNull() {
            addCriterion("ind_situ_fam is not null");
            return this;
        }

        public Criteria andIndSituFamEqualTo(String value) {
            addCriterion("ind_situ_fam =", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamNotEqualTo(String value) {
            addCriterion("ind_situ_fam <>", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamGreaterThan(String value) {
            addCriterion("ind_situ_fam >", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamGreaterThanOrEqualTo(String value) {
            addCriterion("ind_situ_fam >=", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamLessThan(String value) {
            addCriterion("ind_situ_fam <", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamLessThanOrEqualTo(String value) {
            addCriterion("ind_situ_fam <=", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamLike(String value) {
            addCriterion("ind_situ_fam like", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamNotLike(String value) {
            addCriterion("ind_situ_fam not like", value, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamIn(List<String> values) {
            addCriterion("ind_situ_fam in", values, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamNotIn(List<String> values) {
            addCriterion("ind_situ_fam not in", values, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamBetween(String value1, String value2) {
            addCriterion("ind_situ_fam between", value1, value2, "indSituFam");
            return this;
        }

        public Criteria andIndSituFamNotBetween(String value1, String value2) {
            addCriterion("ind_situ_fam not between", value1, value2, "indSituFam");
            return this;
        }

        public Criteria andFecBajaIsNull() {
            addCriterion("fec_baja is null");
            return this;
        }

        public Criteria andFecBajaIsNotNull() {
            addCriterion("fec_baja is not null");
            return this;
        }

        public Criteria andFecBajaEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja =", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja <>", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_baja >", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja >=", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaLessThan(Date value) {
            addCriterionForJDBCDate("fec_baja <", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja <=", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaIn(List<Date> values) {
            addCriterionForJDBCDate("fec_baja in", values, "fecBaja");
            return this;
        }

        public Criteria andFecBajaNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_baja not in", values, "fecBaja");
            return this;
        }

        public Criteria andFecBajaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_baja between", value1, value2, "fecBaja");
            return this;
        }

        public Criteria andFecBajaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_baja not between", value1, value2, "fecBaja");
            return this;
        }

        public Criteria andCodBajaIsNull() {
            addCriterion("cod_baja is null");
            return this;
        }

        public Criteria andCodBajaIsNotNull() {
            addCriterion("cod_baja is not null");
            return this;
        }

        public Criteria andCodBajaEqualTo(String value) {
            addCriterion("cod_baja =", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotEqualTo(String value) {
            addCriterion("cod_baja <>", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaGreaterThan(String value) {
            addCriterion("cod_baja >", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_baja >=", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaLessThan(String value) {
            addCriterion("cod_baja <", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaLessThanOrEqualTo(String value) {
            addCriterion("cod_baja <=", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaLike(String value) {
            addCriterion("cod_baja like", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotLike(String value) {
            addCriterion("cod_baja not like", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaIn(List<String> values) {
            addCriterion("cod_baja in", values, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotIn(List<String> values) {
            addCriterion("cod_baja not in", values, "codBaja");
            return this;
        }

        public Criteria andCodBajaBetween(String value1, String value2) {
            addCriterion("cod_baja between", value1, value2, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotBetween(String value1, String value2) {
            addCriterion("cod_baja not between", value1, value2, "codBaja");
            return this;
        }

        public Criteria andNumDocBajaIsNull() {
            addCriterion("num_doc_baja is null");
            return this;
        }

        public Criteria andNumDocBajaIsNotNull() {
            addCriterion("num_doc_baja is not null");
            return this;
        }

        public Criteria andNumDocBajaEqualTo(String value) {
            addCriterion("num_doc_baja =", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaNotEqualTo(String value) {
            addCriterion("num_doc_baja <>", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaGreaterThan(String value) {
            addCriterion("num_doc_baja >", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaGreaterThanOrEqualTo(String value) {
            addCriterion("num_doc_baja >=", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaLessThan(String value) {
            addCriterion("num_doc_baja <", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaLessThanOrEqualTo(String value) {
            addCriterion("num_doc_baja <=", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaLike(String value) {
            addCriterion("num_doc_baja like", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaNotLike(String value) {
            addCriterion("num_doc_baja not like", value, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaIn(List<String> values) {
            addCriterion("num_doc_baja in", values, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaNotIn(List<String> values) {
            addCriterion("num_doc_baja not in", values, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaBetween(String value1, String value2) {
            addCriterion("num_doc_baja between", value1, value2, "numDocBaja");
            return this;
        }

        public Criteria andNumDocBajaNotBetween(String value1, String value2) {
            addCriterion("num_doc_baja not between", value1, value2, "numDocBaja");
            return this;
        }

        public Criteria andIndTrabSunatIsNull() {
            addCriterion("ind_trab_sunat is null");
            return this;
        }

        public Criteria andIndTrabSunatIsNotNull() {
            addCriterion("ind_trab_sunat is not null");
            return this;
        }

        public Criteria andIndTrabSunatEqualTo(String value) {
            addCriterion("ind_trab_sunat =", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotEqualTo(String value) {
            addCriterion("ind_trab_sunat <>", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatGreaterThan(String value) {
            addCriterion("ind_trab_sunat >", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatGreaterThanOrEqualTo(String value) {
            addCriterion("ind_trab_sunat >=", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatLessThan(String value) {
            addCriterion("ind_trab_sunat <", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatLessThanOrEqualTo(String value) {
            addCriterion("ind_trab_sunat <=", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatLike(String value) {
            addCriterion("ind_trab_sunat like", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotLike(String value) {
            addCriterion("ind_trab_sunat not like", value, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatIn(List<String> values) {
            addCriterion("ind_trab_sunat in", values, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotIn(List<String> values) {
            addCriterion("ind_trab_sunat not in", values, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatBetween(String value1, String value2) {
            addCriterion("ind_trab_sunat between", value1, value2, "indTrabSunat");
            return this;
        }

        public Criteria andIndTrabSunatNotBetween(String value1, String value2) {
            addCriterion("ind_trab_sunat not between", value1, value2, "indTrabSunat");
            return this;
        }

        public Criteria andNumRegistroIsNull() {
            addCriterion("num_registro is null");
            return this;
        }

        public Criteria andNumRegistroIsNotNull() {
            addCriterion("num_registro is not null");
            return this;
        }

        public Criteria andNumRegistroEqualTo(String value) {
            addCriterion("num_registro =", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotEqualTo(String value) {
            addCriterion("num_registro <>", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroGreaterThan(String value) {
            addCriterion("num_registro >", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroGreaterThanOrEqualTo(String value) {
            addCriterion("num_registro >=", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroLessThan(String value) {
            addCriterion("num_registro <", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroLessThanOrEqualTo(String value) {
            addCriterion("num_registro <=", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroLike(String value) {
            addCriterion("num_registro like", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotLike(String value) {
            addCriterion("num_registro not like", value, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroIn(List<String> values) {
            addCriterion("num_registro in", values, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotIn(List<String> values) {
            addCriterion("num_registro not in", values, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroBetween(String value1, String value2) {
            addCriterion("num_registro between", value1, value2, "numRegistro");
            return this;
        }

        public Criteria andNumRegistroNotBetween(String value1, String value2) {
            addCriterion("num_registro not between", value1, value2, "numRegistro");
            return this;
        }

        public Criteria andCodViaDir1IsNull() {
            addCriterion("cod_via_dir1 is null");
            return this;
        }

        public Criteria andCodViaDir1IsNotNull() {
            addCriterion("cod_via_dir1 is not null");
            return this;
        }

        public Criteria andCodViaDir1EqualTo(String value) {
            addCriterion("cod_via_dir1 =", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotEqualTo(String value) {
            addCriterion("cod_via_dir1 <>", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThan(String value) {
            addCriterion("cod_via_dir1 >", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 >=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThan(String value) {
            addCriterion("cod_via_dir1 <", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 <=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Like(String value) {
            addCriterion("cod_via_dir1 like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotLike(String value) {
            addCriterion("cod_via_dir1 not like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1In(List<String> values) {
            addCriterion("cod_via_dir1 in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotIn(List<String> values) {
            addCriterion("cod_via_dir1 not in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Between(String value1, String value2) {
            addCriterion("cod_via_dir1 between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir1 not between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andNomViaDir1IsNull() {
            addCriterion("nom_via_dir1 is null");
            return this;
        }

        public Criteria andNomViaDir1IsNotNull() {
            addCriterion("nom_via_dir1 is not null");
            return this;
        }

        public Criteria andNomViaDir1EqualTo(String value) {
            addCriterion("nom_via_dir1 =", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotEqualTo(String value) {
            addCriterion("nom_via_dir1 <>", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThan(String value) {
            addCriterion("nom_via_dir1 >", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 >=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThan(String value) {
            addCriterion("nom_via_dir1 <", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 <=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Like(String value) {
            addCriterion("nom_via_dir1 like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotLike(String value) {
            addCriterion("nom_via_dir1 not like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1In(List<String> values) {
            addCriterion("nom_via_dir1 in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotIn(List<String> values) {
            addCriterion("nom_via_dir1 not in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Between(String value1, String value2) {
            addCriterion("nom_via_dir1 between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir1 not between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNumViaDir1IsNull() {
            addCriterion("num_via_dir1 is null");
            return this;
        }

        public Criteria andNumViaDir1IsNotNull() {
            addCriterion("num_via_dir1 is not null");
            return this;
        }

        public Criteria andNumViaDir1EqualTo(String value) {
            addCriterion("num_via_dir1 =", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotEqualTo(String value) {
            addCriterion("num_via_dir1 <>", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThan(String value) {
            addCriterion("num_via_dir1 >", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 >=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThan(String value) {
            addCriterion("num_via_dir1 <", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 <=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Like(String value) {
            addCriterion("num_via_dir1 like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotLike(String value) {
            addCriterion("num_via_dir1 not like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1In(List<String> values) {
            addCriterion("num_via_dir1 in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotIn(List<String> values) {
            addCriterion("num_via_dir1 not in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Between(String value1, String value2) {
            addCriterion("num_via_dir1 between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotBetween(String value1, String value2) {
            addCriterion("num_via_dir1 not between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumDepaDir1IsNull() {
            addCriterion("num_depa_dir1 is null");
            return this;
        }

        public Criteria andNumDepaDir1IsNotNull() {
            addCriterion("num_depa_dir1 is not null");
            return this;
        }

        public Criteria andNumDepaDir1EqualTo(String value) {
            addCriterion("num_depa_dir1 =", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotEqualTo(String value) {
            addCriterion("num_depa_dir1 <>", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThan(String value) {
            addCriterion("num_depa_dir1 >", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 >=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThan(String value) {
            addCriterion("num_depa_dir1 <", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 <=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Like(String value) {
            addCriterion("num_depa_dir1 like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotLike(String value) {
            addCriterion("num_depa_dir1 not like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1In(List<String> values) {
            addCriterion("num_depa_dir1 in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotIn(List<String> values) {
            addCriterion("num_depa_dir1 not in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Between(String value1, String value2) {
            addCriterion("num_depa_dir1 between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir1 not between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumInteriorDir1IsNull() {
            addCriterion("num_interior_dir1 is null");
            return this;
        }

        public Criteria andNumInteriorDir1IsNotNull() {
            addCriterion("num_interior_dir1 is not null");
            return this;
        }

        public Criteria andNumInteriorDir1EqualTo(String value) {
            addCriterion("num_interior_dir1 =", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotEqualTo(String value) {
            addCriterion("num_interior_dir1 <>", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThan(String value) {
            addCriterion("num_interior_dir1 >", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 >=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThan(String value) {
            addCriterion("num_interior_dir1 <", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 <=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Like(String value) {
            addCriterion("num_interior_dir1 like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotLike(String value) {
            addCriterion("num_interior_dir1 not like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1In(List<String> values) {
            addCriterion("num_interior_dir1 in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotIn(List<String> values) {
            addCriterion("num_interior_dir1 not in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Between(String value1, String value2) {
            addCriterion("num_interior_dir1 between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir1 not between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumManzDir1IsNull() {
            addCriterion("num_manz_dir1 is null");
            return this;
        }

        public Criteria andNumManzDir1IsNotNull() {
            addCriterion("num_manz_dir1 is not null");
            return this;
        }

        public Criteria andNumManzDir1EqualTo(String value) {
            addCriterion("num_manz_dir1 =", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotEqualTo(String value) {
            addCriterion("num_manz_dir1 <>", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThan(String value) {
            addCriterion("num_manz_dir1 >", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 >=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThan(String value) {
            addCriterion("num_manz_dir1 <", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 <=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Like(String value) {
            addCriterion("num_manz_dir1 like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotLike(String value) {
            addCriterion("num_manz_dir1 not like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1In(List<String> values) {
            addCriterion("num_manz_dir1 in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotIn(List<String> values) {
            addCriterion("num_manz_dir1 not in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Between(String value1, String value2) {
            addCriterion("num_manz_dir1 between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir1 not between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumLoteDir1IsNull() {
            addCriterion("num_lote_dir1 is null");
            return this;
        }

        public Criteria andNumLoteDir1IsNotNull() {
            addCriterion("num_lote_dir1 is not null");
            return this;
        }

        public Criteria andNumLoteDir1EqualTo(String value) {
            addCriterion("num_lote_dir1 =", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotEqualTo(String value) {
            addCriterion("num_lote_dir1 <>", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThan(String value) {
            addCriterion("num_lote_dir1 >", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 >=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThan(String value) {
            addCriterion("num_lote_dir1 <", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 <=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Like(String value) {
            addCriterion("num_lote_dir1 like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotLike(String value) {
            addCriterion("num_lote_dir1 not like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1In(List<String> values) {
            addCriterion("num_lote_dir1 in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotIn(List<String> values) {
            addCriterion("num_lote_dir1 not in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Between(String value1, String value2) {
            addCriterion("num_lote_dir1 between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir1 not between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumKilomDir1IsNull() {
            addCriterion("num_kilom_dir1 is null");
            return this;
        }

        public Criteria andNumKilomDir1IsNotNull() {
            addCriterion("num_kilom_dir1 is not null");
            return this;
        }

        public Criteria andNumKilomDir1EqualTo(String value) {
            addCriterion("num_kilom_dir1 =", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotEqualTo(String value) {
            addCriterion("num_kilom_dir1 <>", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThan(String value) {
            addCriterion("num_kilom_dir1 >", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 >=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThan(String value) {
            addCriterion("num_kilom_dir1 <", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 <=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Like(String value) {
            addCriterion("num_kilom_dir1 like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotLike(String value) {
            addCriterion("num_kilom_dir1 not like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1In(List<String> values) {
            addCriterion("num_kilom_dir1 in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotIn(List<String> values) {
            addCriterion("num_kilom_dir1 not in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Between(String value1, String value2) {
            addCriterion("num_kilom_dir1 between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir1 not between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumBlockDir1IsNull() {
            addCriterion("num_block_dir1 is null");
            return this;
        }

        public Criteria andNumBlockDir1IsNotNull() {
            addCriterion("num_block_dir1 is not null");
            return this;
        }

        public Criteria andNumBlockDir1EqualTo(String value) {
            addCriterion("num_block_dir1 =", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotEqualTo(String value) {
            addCriterion("num_block_dir1 <>", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThan(String value) {
            addCriterion("num_block_dir1 >", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 >=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThan(String value) {
            addCriterion("num_block_dir1 <", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 <=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Like(String value) {
            addCriterion("num_block_dir1 like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotLike(String value) {
            addCriterion("num_block_dir1 not like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1In(List<String> values) {
            addCriterion("num_block_dir1 in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotIn(List<String> values) {
            addCriterion("num_block_dir1 not in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Between(String value1, String value2) {
            addCriterion("num_block_dir1 between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotBetween(String value1, String value2) {
            addCriterion("num_block_dir1 not between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumEtapaDir1IsNull() {
            addCriterion("num_etapa_dir1 is null");
            return this;
        }

        public Criteria andNumEtapaDir1IsNotNull() {
            addCriterion("num_etapa_dir1 is not null");
            return this;
        }

        public Criteria andNumEtapaDir1EqualTo(String value) {
            addCriterion("num_etapa_dir1 =", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotEqualTo(String value) {
            addCriterion("num_etapa_dir1 <>", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThan(String value) {
            addCriterion("num_etapa_dir1 >", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 >=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThan(String value) {
            addCriterion("num_etapa_dir1 <", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 <=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Like(String value) {
            addCriterion("num_etapa_dir1 like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotLike(String value) {
            addCriterion("num_etapa_dir1 not like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1In(List<String> values) {
            addCriterion("num_etapa_dir1 in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotIn(List<String> values) {
            addCriterion("num_etapa_dir1 not in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Between(String value1, String value2) {
            addCriterion("num_etapa_dir1 between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir1 not between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andCodZonaDir1IsNull() {
            addCriterion("cod_zona_dir1 is null");
            return this;
        }

        public Criteria andCodZonaDir1IsNotNull() {
            addCriterion("cod_zona_dir1 is not null");
            return this;
        }

        public Criteria andCodZonaDir1EqualTo(String value) {
            addCriterion("cod_zona_dir1 =", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotEqualTo(String value) {
            addCriterion("cod_zona_dir1 <>", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThan(String value) {
            addCriterion("cod_zona_dir1 >", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 >=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThan(String value) {
            addCriterion("cod_zona_dir1 <", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 <=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Like(String value) {
            addCriterion("cod_zona_dir1 like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotLike(String value) {
            addCriterion("cod_zona_dir1 not like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1In(List<String> values) {
            addCriterion("cod_zona_dir1 in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotIn(List<String> values) {
            addCriterion("cod_zona_dir1 not in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Between(String value1, String value2) {
            addCriterion("cod_zona_dir1 between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir1 not between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1IsNull() {
            addCriterion("nom_zona_dir1 is null");
            return this;
        }

        public Criteria andNomZonaDir1IsNotNull() {
            addCriterion("nom_zona_dir1 is not null");
            return this;
        }

        public Criteria andNomZonaDir1EqualTo(String value) {
            addCriterion("nom_zona_dir1 =", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotEqualTo(String value) {
            addCriterion("nom_zona_dir1 <>", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThan(String value) {
            addCriterion("nom_zona_dir1 >", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 >=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThan(String value) {
            addCriterion("nom_zona_dir1 <", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 <=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Like(String value) {
            addCriterion("nom_zona_dir1 like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotLike(String value) {
            addCriterion("nom_zona_dir1 not like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1In(List<String> values) {
            addCriterion("nom_zona_dir1 in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotIn(List<String> values) {
            addCriterion("nom_zona_dir1 not in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Between(String value1, String value2) {
            addCriterion("nom_zona_dir1 between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir1 not between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andDesReferDir1IsNull() {
            addCriterion("des_refer_dir1 is null");
            return this;
        }

        public Criteria andDesReferDir1IsNotNull() {
            addCriterion("des_refer_dir1 is not null");
            return this;
        }

        public Criteria andDesReferDir1EqualTo(String value) {
            addCriterion("des_refer_dir1 =", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotEqualTo(String value) {
            addCriterion("des_refer_dir1 <>", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThan(String value) {
            addCriterion("des_refer_dir1 >", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 >=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThan(String value) {
            addCriterion("des_refer_dir1 <", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 <=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Like(String value) {
            addCriterion("des_refer_dir1 like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotLike(String value) {
            addCriterion("des_refer_dir1 not like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1In(List<String> values) {
            addCriterion("des_refer_dir1 in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotIn(List<String> values) {
            addCriterion("des_refer_dir1 not in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Between(String value1, String value2) {
            addCriterion("des_refer_dir1 between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotBetween(String value1, String value2) {
            addCriterion("des_refer_dir1 not between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNull() {
            addCriterion("cod_ubigeo_dir1 is null");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNotNull() {
            addCriterion("cod_ubigeo_dir1 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir1EqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 =", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <>", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir1 >", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 >=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThan(String value) {
            addCriterion("cod_ubigeo_dir1 <", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Like(String value) {
            addCriterion("cod_ubigeo_dir1 like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotLike(String value) {
            addCriterion("cod_ubigeo_dir1 not like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1In(List<String> values) {
            addCriterion("cod_ubigeo_dir1 in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir1 not in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 not between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodViaDir2IsNull() {
            addCriterion("cod_via_dir2 is null");
            return this;
        }

        public Criteria andCodViaDir2IsNotNull() {
            addCriterion("cod_via_dir2 is not null");
            return this;
        }

        public Criteria andCodViaDir2EqualTo(String value) {
            addCriterion("cod_via_dir2 =", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotEqualTo(String value) {
            addCriterion("cod_via_dir2 <>", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThan(String value) {
            addCriterion("cod_via_dir2 >", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 >=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThan(String value) {
            addCriterion("cod_via_dir2 <", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 <=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Like(String value) {
            addCriterion("cod_via_dir2 like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotLike(String value) {
            addCriterion("cod_via_dir2 not like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2In(List<String> values) {
            addCriterion("cod_via_dir2 in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotIn(List<String> values) {
            addCriterion("cod_via_dir2 not in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Between(String value1, String value2) {
            addCriterion("cod_via_dir2 between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir2 not between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andNomViaDir2IsNull() {
            addCriterion("nom_via_dir2 is null");
            return this;
        }

        public Criteria andNomViaDir2IsNotNull() {
            addCriterion("nom_via_dir2 is not null");
            return this;
        }

        public Criteria andNomViaDir2EqualTo(String value) {
            addCriterion("nom_via_dir2 =", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotEqualTo(String value) {
            addCriterion("nom_via_dir2 <>", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThan(String value) {
            addCriterion("nom_via_dir2 >", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 >=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThan(String value) {
            addCriterion("nom_via_dir2 <", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 <=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Like(String value) {
            addCriterion("nom_via_dir2 like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotLike(String value) {
            addCriterion("nom_via_dir2 not like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2In(List<String> values) {
            addCriterion("nom_via_dir2 in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotIn(List<String> values) {
            addCriterion("nom_via_dir2 not in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Between(String value1, String value2) {
            addCriterion("nom_via_dir2 between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir2 not between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNumViaDir2IsNull() {
            addCriterion("num_via_dir2 is null");
            return this;
        }

        public Criteria andNumViaDir2IsNotNull() {
            addCriterion("num_via_dir2 is not null");
            return this;
        }

        public Criteria andNumViaDir2EqualTo(String value) {
            addCriterion("num_via_dir2 =", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotEqualTo(String value) {
            addCriterion("num_via_dir2 <>", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThan(String value) {
            addCriterion("num_via_dir2 >", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 >=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThan(String value) {
            addCriterion("num_via_dir2 <", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 <=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Like(String value) {
            addCriterion("num_via_dir2 like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotLike(String value) {
            addCriterion("num_via_dir2 not like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2In(List<String> values) {
            addCriterion("num_via_dir2 in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotIn(List<String> values) {
            addCriterion("num_via_dir2 not in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Between(String value1, String value2) {
            addCriterion("num_via_dir2 between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotBetween(String value1, String value2) {
            addCriterion("num_via_dir2 not between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumDepaDir2IsNull() {
            addCriterion("num_depa_dir2 is null");
            return this;
        }

        public Criteria andNumDepaDir2IsNotNull() {
            addCriterion("num_depa_dir2 is not null");
            return this;
        }

        public Criteria andNumDepaDir2EqualTo(String value) {
            addCriterion("num_depa_dir2 =", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotEqualTo(String value) {
            addCriterion("num_depa_dir2 <>", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThan(String value) {
            addCriterion("num_depa_dir2 >", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 >=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThan(String value) {
            addCriterion("num_depa_dir2 <", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 <=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Like(String value) {
            addCriterion("num_depa_dir2 like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotLike(String value) {
            addCriterion("num_depa_dir2 not like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2In(List<String> values) {
            addCriterion("num_depa_dir2 in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotIn(List<String> values) {
            addCriterion("num_depa_dir2 not in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Between(String value1, String value2) {
            addCriterion("num_depa_dir2 between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir2 not between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumInteriorDir2IsNull() {
            addCriterion("num_interior_dir2 is null");
            return this;
        }

        public Criteria andNumInteriorDir2IsNotNull() {
            addCriterion("num_interior_dir2 is not null");
            return this;
        }

        public Criteria andNumInteriorDir2EqualTo(String value) {
            addCriterion("num_interior_dir2 =", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotEqualTo(String value) {
            addCriterion("num_interior_dir2 <>", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThan(String value) {
            addCriterion("num_interior_dir2 >", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 >=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThan(String value) {
            addCriterion("num_interior_dir2 <", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 <=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Like(String value) {
            addCriterion("num_interior_dir2 like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotLike(String value) {
            addCriterion("num_interior_dir2 not like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2In(List<String> values) {
            addCriterion("num_interior_dir2 in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotIn(List<String> values) {
            addCriterion("num_interior_dir2 not in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Between(String value1, String value2) {
            addCriterion("num_interior_dir2 between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir2 not between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumManzDir2IsNull() {
            addCriterion("num_manz_dir2 is null");
            return this;
        }

        public Criteria andNumManzDir2IsNotNull() {
            addCriterion("num_manz_dir2 is not null");
            return this;
        }

        public Criteria andNumManzDir2EqualTo(String value) {
            addCriterion("num_manz_dir2 =", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotEqualTo(String value) {
            addCriterion("num_manz_dir2 <>", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThan(String value) {
            addCriterion("num_manz_dir2 >", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 >=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThan(String value) {
            addCriterion("num_manz_dir2 <", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 <=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Like(String value) {
            addCriterion("num_manz_dir2 like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotLike(String value) {
            addCriterion("num_manz_dir2 not like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2In(List<String> values) {
            addCriterion("num_manz_dir2 in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotIn(List<String> values) {
            addCriterion("num_manz_dir2 not in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Between(String value1, String value2) {
            addCriterion("num_manz_dir2 between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir2 not between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumLoteDir2IsNull() {
            addCriterion("num_lote_dir2 is null");
            return this;
        }

        public Criteria andNumLoteDir2IsNotNull() {
            addCriterion("num_lote_dir2 is not null");
            return this;
        }

        public Criteria andNumLoteDir2EqualTo(String value) {
            addCriterion("num_lote_dir2 =", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotEqualTo(String value) {
            addCriterion("num_lote_dir2 <>", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThan(String value) {
            addCriterion("num_lote_dir2 >", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 >=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThan(String value) {
            addCriterion("num_lote_dir2 <", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 <=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Like(String value) {
            addCriterion("num_lote_dir2 like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotLike(String value) {
            addCriterion("num_lote_dir2 not like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2In(List<String> values) {
            addCriterion("num_lote_dir2 in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotIn(List<String> values) {
            addCriterion("num_lote_dir2 not in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Between(String value1, String value2) {
            addCriterion("num_lote_dir2 between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir2 not between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumKilomDir2IsNull() {
            addCriterion("num_kilom_dir2 is null");
            return this;
        }

        public Criteria andNumKilomDir2IsNotNull() {
            addCriterion("num_kilom_dir2 is not null");
            return this;
        }

        public Criteria andNumKilomDir2EqualTo(String value) {
            addCriterion("num_kilom_dir2 =", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotEqualTo(String value) {
            addCriterion("num_kilom_dir2 <>", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThan(String value) {
            addCriterion("num_kilom_dir2 >", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 >=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThan(String value) {
            addCriterion("num_kilom_dir2 <", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 <=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Like(String value) {
            addCriterion("num_kilom_dir2 like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotLike(String value) {
            addCriterion("num_kilom_dir2 not like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2In(List<String> values) {
            addCriterion("num_kilom_dir2 in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotIn(List<String> values) {
            addCriterion("num_kilom_dir2 not in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Between(String value1, String value2) {
            addCriterion("num_kilom_dir2 between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir2 not between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumBlockDir2IsNull() {
            addCriterion("num_block_dir2 is null");
            return this;
        }

        public Criteria andNumBlockDir2IsNotNull() {
            addCriterion("num_block_dir2 is not null");
            return this;
        }

        public Criteria andNumBlockDir2EqualTo(String value) {
            addCriterion("num_block_dir2 =", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotEqualTo(String value) {
            addCriterion("num_block_dir2 <>", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThan(String value) {
            addCriterion("num_block_dir2 >", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 >=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThan(String value) {
            addCriterion("num_block_dir2 <", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 <=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Like(String value) {
            addCriterion("num_block_dir2 like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotLike(String value) {
            addCriterion("num_block_dir2 not like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2In(List<String> values) {
            addCriterion("num_block_dir2 in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotIn(List<String> values) {
            addCriterion("num_block_dir2 not in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Between(String value1, String value2) {
            addCriterion("num_block_dir2 between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotBetween(String value1, String value2) {
            addCriterion("num_block_dir2 not between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumEtapaDir2IsNull() {
            addCriterion("num_etapa_dir2 is null");
            return this;
        }

        public Criteria andNumEtapaDir2IsNotNull() {
            addCriterion("num_etapa_dir2 is not null");
            return this;
        }

        public Criteria andNumEtapaDir2EqualTo(String value) {
            addCriterion("num_etapa_dir2 =", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotEqualTo(String value) {
            addCriterion("num_etapa_dir2 <>", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThan(String value) {
            addCriterion("num_etapa_dir2 >", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 >=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThan(String value) {
            addCriterion("num_etapa_dir2 <", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 <=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Like(String value) {
            addCriterion("num_etapa_dir2 like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotLike(String value) {
            addCriterion("num_etapa_dir2 not like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2In(List<String> values) {
            addCriterion("num_etapa_dir2 in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotIn(List<String> values) {
            addCriterion("num_etapa_dir2 not in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Between(String value1, String value2) {
            addCriterion("num_etapa_dir2 between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir2 not between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andCodZonaDir2IsNull() {
            addCriterion("cod_zona_dir2 is null");
            return this;
        }

        public Criteria andCodZonaDir2IsNotNull() {
            addCriterion("cod_zona_dir2 is not null");
            return this;
        }

        public Criteria andCodZonaDir2EqualTo(String value) {
            addCriterion("cod_zona_dir2 =", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotEqualTo(String value) {
            addCriterion("cod_zona_dir2 <>", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThan(String value) {
            addCriterion("cod_zona_dir2 >", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 >=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThan(String value) {
            addCriterion("cod_zona_dir2 <", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 <=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Like(String value) {
            addCriterion("cod_zona_dir2 like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotLike(String value) {
            addCriterion("cod_zona_dir2 not like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2In(List<String> values) {
            addCriterion("cod_zona_dir2 in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotIn(List<String> values) {
            addCriterion("cod_zona_dir2 not in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Between(String value1, String value2) {
            addCriterion("cod_zona_dir2 between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir2 not between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2IsNull() {
            addCriterion("nom_zona_dir2 is null");
            return this;
        }

        public Criteria andNomZonaDir2IsNotNull() {
            addCriterion("nom_zona_dir2 is not null");
            return this;
        }

        public Criteria andNomZonaDir2EqualTo(String value) {
            addCriterion("nom_zona_dir2 =", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotEqualTo(String value) {
            addCriterion("nom_zona_dir2 <>", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThan(String value) {
            addCriterion("nom_zona_dir2 >", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 >=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThan(String value) {
            addCriterion("nom_zona_dir2 <", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 <=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Like(String value) {
            addCriterion("nom_zona_dir2 like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotLike(String value) {
            addCriterion("nom_zona_dir2 not like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2In(List<String> values) {
            addCriterion("nom_zona_dir2 in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotIn(List<String> values) {
            addCriterion("nom_zona_dir2 not in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Between(String value1, String value2) {
            addCriterion("nom_zona_dir2 between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir2 not between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andDesReferDir2IsNull() {
            addCriterion("des_refer_dir2 is null");
            return this;
        }

        public Criteria andDesReferDir2IsNotNull() {
            addCriterion("des_refer_dir2 is not null");
            return this;
        }

        public Criteria andDesReferDir2EqualTo(String value) {
            addCriterion("des_refer_dir2 =", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotEqualTo(String value) {
            addCriterion("des_refer_dir2 <>", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2GreaterThan(String value) {
            addCriterion("des_refer_dir2 >", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2GreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir2 >=", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2LessThan(String value) {
            addCriterion("des_refer_dir2 <", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2LessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir2 <=", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2Like(String value) {
            addCriterion("des_refer_dir2 like", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotLike(String value) {
            addCriterion("des_refer_dir2 not like", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2In(List<String> values) {
            addCriterion("des_refer_dir2 in", values, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotIn(List<String> values) {
            addCriterion("des_refer_dir2 not in", values, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2Between(String value1, String value2) {
            addCriterion("des_refer_dir2 between", value1, value2, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotBetween(String value1, String value2) {
            addCriterion("des_refer_dir2 not between", value1, value2, "desReferDir2");
            return this;
        }

        public Criteria andIndCentAsisIsNull() {
            addCriterion("ind_cent_asis is null");
            return this;
        }

        public Criteria andIndCentAsisIsNotNull() {
            addCriterion("ind_cent_asis is not null");
            return this;
        }

        public Criteria andIndCentAsisEqualTo(String value) {
            addCriterion("ind_cent_asis =", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotEqualTo(String value) {
            addCriterion("ind_cent_asis <>", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThan(String value) {
            addCriterion("ind_cent_asis >", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis >=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThan(String value) {
            addCriterion("ind_cent_asis <", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis <=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLike(String value) {
            addCriterion("ind_cent_asis like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotLike(String value) {
            addCriterion("ind_cent_asis not like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisIn(List<String> values) {
            addCriterion("ind_cent_asis in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotIn(List<String> values) {
            addCriterion("ind_cent_asis not in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisBetween(String value1, String value2) {
            addCriterion("ind_cent_asis between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotBetween(String value1, String value2) {
            addCriterion("ind_cent_asis not between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNull() {
            addCriterion("cod_ubigeo_dir2 is null");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNotNull() {
            addCriterion("cod_ubigeo_dir2 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir2EqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 =", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <>", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir2 >", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 >=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThan(String value) {
            addCriterion("cod_ubigeo_dir2 <", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Like(String value) {
            addCriterion("cod_ubigeo_dir2 like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotLike(String value) {
            addCriterion("cod_ubigeo_dir2 not like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2In(List<String> values) {
            addCriterion("cod_ubigeo_dir2 in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir2 not in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 not between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andCodTelefLarDisIsNull() {
            addCriterion("cod_telef_lar_dis is null");
            return this;
        }

        public Criteria andCodTelefLarDisIsNotNull() {
            addCriterion("cod_telef_lar_dis is not null");
            return this;
        }

        public Criteria andCodTelefLarDisEqualTo(String value) {
            addCriterion("cod_telef_lar_dis =", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotEqualTo(String value) {
            addCriterion("cod_telef_lar_dis <>", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisGreaterThan(String value) {
            addCriterion("cod_telef_lar_dis >", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_telef_lar_dis >=", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLessThan(String value) {
            addCriterion("cod_telef_lar_dis <", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLessThanOrEqualTo(String value) {
            addCriterion("cod_telef_lar_dis <=", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLike(String value) {
            addCriterion("cod_telef_lar_dis like", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotLike(String value) {
            addCriterion("cod_telef_lar_dis not like", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisIn(List<String> values) {
            addCriterion("cod_telef_lar_dis in", values, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotIn(List<String> values) {
            addCriterion("cod_telef_lar_dis not in", values, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisBetween(String value1, String value2) {
            addCriterion("cod_telef_lar_dis between", value1, value2, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotBetween(String value1, String value2) {
            addCriterion("cod_telef_lar_dis not between", value1, value2, "codTelefLarDis");
            return this;
        }

        public Criteria andNumTelefIsNull() {
            addCriterion("num_telef is null");
            return this;
        }

        public Criteria andNumTelefIsNotNull() {
            addCriterion("num_telef is not null");
            return this;
        }

        public Criteria andNumTelefEqualTo(String value) {
            addCriterion("num_telef =", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotEqualTo(String value) {
            addCriterion("num_telef <>", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThan(String value) {
            addCriterion("num_telef >", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThanOrEqualTo(String value) {
            addCriterion("num_telef >=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThan(String value) {
            addCriterion("num_telef <", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThanOrEqualTo(String value) {
            addCriterion("num_telef <=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLike(String value) {
            addCriterion("num_telef like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotLike(String value) {
            addCriterion("num_telef not like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefIn(List<String> values) {
            addCriterion("num_telef in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotIn(List<String> values) {
            addCriterion("num_telef not in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefBetween(String value1, String value2) {
            addCriterion("num_telef between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotBetween(String value1, String value2) {
            addCriterion("num_telef not between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andCodCelLarDisIsNull() {
            addCriterion("cod_cel_lar_dis is null");
            return this;
        }

        public Criteria andCodCelLarDisIsNotNull() {
            addCriterion("cod_cel_lar_dis is not null");
            return this;
        }

        public Criteria andCodCelLarDisEqualTo(String value) {
            addCriterion("cod_cel_lar_dis =", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotEqualTo(String value) {
            addCriterion("cod_cel_lar_dis <>", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisGreaterThan(String value) {
            addCriterion("cod_cel_lar_dis >", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_cel_lar_dis >=", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisLessThan(String value) {
            addCriterion("cod_cel_lar_dis <", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisLessThanOrEqualTo(String value) {
            addCriterion("cod_cel_lar_dis <=", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisLike(String value) {
            addCriterion("cod_cel_lar_dis like", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotLike(String value) {
            addCriterion("cod_cel_lar_dis not like", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisIn(List<String> values) {
            addCriterion("cod_cel_lar_dis in", values, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotIn(List<String> values) {
            addCriterion("cod_cel_lar_dis not in", values, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisBetween(String value1, String value2) {
            addCriterion("cod_cel_lar_dis between", value1, value2, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotBetween(String value1, String value2) {
            addCriterion("cod_cel_lar_dis not between", value1, value2, "codCelLarDis");
            return this;
        }

        public Criteria andNumCelularIsNull() {
            addCriterion("num_celular is null");
            return this;
        }

        public Criteria andNumCelularIsNotNull() {
            addCriterion("num_celular is not null");
            return this;
        }

        public Criteria andNumCelularEqualTo(String value) {
            addCriterion("num_celular =", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotEqualTo(String value) {
            addCriterion("num_celular <>", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularGreaterThan(String value) {
            addCriterion("num_celular >", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularGreaterThanOrEqualTo(String value) {
            addCriterion("num_celular >=", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLessThan(String value) {
            addCriterion("num_celular <", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLessThanOrEqualTo(String value) {
            addCriterion("num_celular <=", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLike(String value) {
            addCriterion("num_celular like", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotLike(String value) {
            addCriterion("num_celular not like", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularIn(List<String> values) {
            addCriterion("num_celular in", values, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotIn(List<String> values) {
            addCriterion("num_celular not in", values, "numCelular");
            return this;
        }

        public Criteria andNumCelularBetween(String value1, String value2) {
            addCriterion("num_celular between", value1, value2, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotBetween(String value1, String value2) {
            addCriterion("num_celular not between", value1, value2, "numCelular");
            return this;
        }

        public Criteria andDesCorreoIsNull() {
            addCriterion("des_correo is null");
            return this;
        }

        public Criteria andDesCorreoIsNotNull() {
            addCriterion("des_correo is not null");
            return this;
        }

        public Criteria andDesCorreoEqualTo(String value) {
            addCriterion("des_correo =", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotEqualTo(String value) {
            addCriterion("des_correo <>", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThan(String value) {
            addCriterion("des_correo >", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThanOrEqualTo(String value) {
            addCriterion("des_correo >=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThan(String value) {
            addCriterion("des_correo <", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThanOrEqualTo(String value) {
            addCriterion("des_correo <=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLike(String value) {
            addCriterion("des_correo like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotLike(String value) {
            addCriterion("des_correo not like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoIn(List<String> values) {
            addCriterion("des_correo in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotIn(List<String> values) {
            addCriterion("des_correo not in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoBetween(String value1, String value2) {
            addCriterion("des_correo between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotBetween(String value1, String value2) {
            addCriterion("des_correo not between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesDomiciDir1IsNull() {
            addCriterion("des_domici_dir1 is null");
            return this;
        }

        public Criteria andDesDomiciDir1IsNotNull() {
            addCriterion("des_domici_dir1 is not null");
            return this;
        }

        public Criteria andDesDomiciDir1EqualTo(String value) {
            addCriterion("des_domici_dir1 =", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotEqualTo(String value) {
            addCriterion("des_domici_dir1 <>", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1GreaterThan(String value) {
            addCriterion("des_domici_dir1 >", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_domici_dir1 >=", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1LessThan(String value) {
            addCriterion("des_domici_dir1 <", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1LessThanOrEqualTo(String value) {
            addCriterion("des_domici_dir1 <=", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1Like(String value) {
            addCriterion("des_domici_dir1 like", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotLike(String value) {
            addCriterion("des_domici_dir1 not like", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1In(List<String> values) {
            addCriterion("des_domici_dir1 in", values, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotIn(List<String> values) {
            addCriterion("des_domici_dir1 not in", values, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1Between(String value1, String value2) {
            addCriterion("des_domici_dir1 between", value1, value2, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotBetween(String value1, String value2) {
            addCriterion("des_domici_dir1 not between", value1, value2, "desDomiciDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1IsNull() {
            addCriterion("des_ubigeo_dir1 is null");
            return this;
        }

        public Criteria andDesUbigeoDir1IsNotNull() {
            addCriterion("des_ubigeo_dir1 is not null");
            return this;
        }

        public Criteria andDesUbigeoDir1EqualTo(String value) {
            addCriterion("des_ubigeo_dir1 =", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 <>", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1GreaterThan(String value) {
            addCriterion("des_ubigeo_dir1 >", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 >=", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1LessThan(String value) {
            addCriterion("des_ubigeo_dir1 <", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1LessThanOrEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 <=", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1Like(String value) {
            addCriterion("des_ubigeo_dir1 like", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotLike(String value) {
            addCriterion("des_ubigeo_dir1 not like", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1In(List<String> values) {
            addCriterion("des_ubigeo_dir1 in", values, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotIn(List<String> values) {
            addCriterion("des_ubigeo_dir1 not in", values, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1Between(String value1, String value2) {
            addCriterion("des_ubigeo_dir1 between", value1, value2, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotBetween(String value1, String value2) {
            addCriterion("des_ubigeo_dir1 not between", value1, value2, "desUbigeoDir1");
            return this;
        }

        public Criteria andIndReniecIsNull() {
            addCriterion("ind_reniec is null");
            return this;
        }

        public Criteria andIndReniecIsNotNull() {
            addCriterion("ind_reniec is not null");
            return this;
        }

        public Criteria andIndReniecEqualTo(String value) {
            addCriterion("ind_reniec =", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotEqualTo(String value) {
            addCriterion("ind_reniec <>", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecGreaterThan(String value) {
            addCriterion("ind_reniec >", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecGreaterThanOrEqualTo(String value) {
            addCriterion("ind_reniec >=", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLessThan(String value) {
            addCriterion("ind_reniec <", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLessThanOrEqualTo(String value) {
            addCriterion("ind_reniec <=", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLike(String value) {
            addCriterion("ind_reniec like", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotLike(String value) {
            addCriterion("ind_reniec not like", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecIn(List<String> values) {
            addCriterion("ind_reniec in", values, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotIn(List<String> values) {
            addCriterion("ind_reniec not in", values, "indReniec");
            return this;
        }

        public Criteria andIndReniecBetween(String value1, String value2) {
            addCriterion("ind_reniec between", value1, value2, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotBetween(String value1, String value2) {
            addCriterion("ind_reniec not between", value1, value2, "indReniec");
            return this;
        }

        public Criteria andFecInivincIsNull() {
            addCriterion("fec_inivinc is null");
            return this;
        }

        public Criteria andFecInivincIsNotNull() {
            addCriterion("fec_inivinc is not null");
            return this;
        }

        public Criteria andFecInivincEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inivinc =", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inivinc <>", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_inivinc >", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inivinc >=", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincLessThan(Date value) {
            addCriterionForJDBCDate("fec_inivinc <", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inivinc <=", value, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincIn(List<Date> values) {
            addCriterionForJDBCDate("fec_inivinc in", values, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_inivinc not in", values, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_inivinc between", value1, value2, "fecInivinc");
            return this;
        }

        public Criteria andFecInivincNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_inivinc not between", value1, value2, "fecInivinc");
            return this;
        }

        public Criteria andIndSubsidSepeIsNull() {
            addCriterion("ind_subsid_sepe is null");
            return this;
        }

        public Criteria andIndSubsidSepeIsNotNull() {
            addCriterion("ind_subsid_sepe is not null");
            return this;
        }

        public Criteria andIndSubsidSepeEqualTo(String value) {
            addCriterion("ind_subsid_sepe =", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeNotEqualTo(String value) {
            addCriterion("ind_subsid_sepe <>", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeGreaterThan(String value) {
            addCriterion("ind_subsid_sepe >", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeGreaterThanOrEqualTo(String value) {
            addCriterion("ind_subsid_sepe >=", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeLessThan(String value) {
            addCriterion("ind_subsid_sepe <", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeLessThanOrEqualTo(String value) {
            addCriterion("ind_subsid_sepe <=", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeLike(String value) {
            addCriterion("ind_subsid_sepe like", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeNotLike(String value) {
            addCriterion("ind_subsid_sepe not like", value, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeIn(List<String> values) {
            addCriterion("ind_subsid_sepe in", values, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeNotIn(List<String> values) {
            addCriterion("ind_subsid_sepe not in", values, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeBetween(String value1, String value2) {
            addCriterion("ind_subsid_sepe between", value1, value2, "indSubsidSepe");
            return this;
        }

        public Criteria andIndSubsidSepeNotBetween(String value1, String value2) {
            addCriterion("ind_subsid_sepe not between", value1, value2, "indSubsidSepe");
            return this;
        }

        public Criteria andIndDiscapacidadIsNull() {
            addCriterion("ind_discapacidad is null");
            return this;
        }

        public Criteria andIndDiscapacidadIsNotNull() {
            addCriterion("ind_discapacidad is not null");
            return this;
        }

        public Criteria andIndDiscapacidadEqualTo(String value) {
            addCriterion("ind_discapacidad =", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotEqualTo(String value) {
            addCriterion("ind_discapacidad <>", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadGreaterThan(String value) {
            addCriterion("ind_discapacidad >", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadGreaterThanOrEqualTo(String value) {
            addCriterion("ind_discapacidad >=", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLessThan(String value) {
            addCriterion("ind_discapacidad <", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLessThanOrEqualTo(String value) {
            addCriterion("ind_discapacidad <=", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLike(String value) {
            addCriterion("ind_discapacidad like", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotLike(String value) {
            addCriterion("ind_discapacidad not like", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadIn(List<String> values) {
            addCriterion("ind_discapacidad in", values, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotIn(List<String> values) {
            addCriterion("ind_discapacidad not in", values, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadBetween(String value1, String value2) {
            addCriterion("ind_discapacidad between", value1, value2, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotBetween(String value1, String value2) {
            addCriterion("ind_discapacidad not between", value1, value2, "indDiscapacidad");
            return this;
        }

        public Criteria andIndEstudianteIsNull() {
            addCriterion("ind_estudiante is null");
            return this;
        }

        public Criteria andIndEstudianteIsNotNull() {
            addCriterion("ind_estudiante is not null");
            return this;
        }

        public Criteria andIndEstudianteEqualTo(String value) {
            addCriterion("ind_estudiante =", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteNotEqualTo(String value) {
            addCriterion("ind_estudiante <>", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteGreaterThan(String value) {
            addCriterion("ind_estudiante >", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteGreaterThanOrEqualTo(String value) {
            addCriterion("ind_estudiante >=", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteLessThan(String value) {
            addCriterion("ind_estudiante <", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteLessThanOrEqualTo(String value) {
            addCriterion("ind_estudiante <=", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteLike(String value) {
            addCriterion("ind_estudiante like", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteNotLike(String value) {
            addCriterion("ind_estudiante not like", value, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteIn(List<String> values) {
            addCriterion("ind_estudiante in", values, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteNotIn(List<String> values) {
            addCriterion("ind_estudiante not in", values, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteBetween(String value1, String value2) {
            addCriterion("ind_estudiante between", value1, value2, "indEstudiante");
            return this;
        }

        public Criteria andIndEstudianteNotBetween(String value1, String value2) {
            addCriterion("ind_estudiante not between", value1, value2, "indEstudiante");
            return this;
        }
    }
}