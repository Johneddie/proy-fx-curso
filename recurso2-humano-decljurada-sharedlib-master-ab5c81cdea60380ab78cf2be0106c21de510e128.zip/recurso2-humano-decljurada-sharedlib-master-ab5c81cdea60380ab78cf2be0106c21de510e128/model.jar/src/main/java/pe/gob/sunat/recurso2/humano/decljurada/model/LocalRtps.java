package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class LocalRtps extends LocalRtpsKey {
    private String sprUbigeo;

    private String sprNomvia;

    private String sprNumer1;

    private String sprInter1;

    private String sprNomzon;

    private String sprRefer1;

    private String sprNombre;

    private String sprTipest;

    private String sprLicenc;

    private String sprTipvia;

    private String sprTipzon;

    private String sprIndmaq;

    private String sprUserna;

    private Date sprFecact;

    public String getSprUbigeo() {
        return sprUbigeo;
    }

    public void setSprUbigeo(String sprUbigeo) {
        this.sprUbigeo = sprUbigeo == null ? null : sprUbigeo.trim();
    }

    public String getSprNomvia() {
        return sprNomvia;
    }

    public void setSprNomvia(String sprNomvia) {
        this.sprNomvia = sprNomvia == null ? null : sprNomvia.trim();
    }

    public String getSprNumer1() {
        return sprNumer1;
    }

    public void setSprNumer1(String sprNumer1) {
        this.sprNumer1 = sprNumer1 == null ? null : sprNumer1.trim();
    }

    public String getSprInter1() {
        return sprInter1;
    }

    public void setSprInter1(String sprInter1) {
        this.sprInter1 = sprInter1 == null ? null : sprInter1.trim();
    }

    public String getSprNomzon() {
        return sprNomzon;
    }

    public void setSprNomzon(String sprNomzon) {
        this.sprNomzon = sprNomzon == null ? null : sprNomzon.trim();
    }

    public String getSprRefer1() {
        return sprRefer1;
    }

    public void setSprRefer1(String sprRefer1) {
        this.sprRefer1 = sprRefer1 == null ? null : sprRefer1.trim();
    }

    public String getSprNombre() {
        return sprNombre;
    }

    public void setSprNombre(String sprNombre) {
        this.sprNombre = sprNombre == null ? null : sprNombre.trim();
    }

    public String getSprTipest() {
        return sprTipest;
    }

    public void setSprTipest(String sprTipest) {
        this.sprTipest = sprTipest == null ? null : sprTipest.trim();
    }

    public String getSprLicenc() {
        return sprLicenc;
    }

    public void setSprLicenc(String sprLicenc) {
        this.sprLicenc = sprLicenc == null ? null : sprLicenc.trim();
    }

    public String getSprTipvia() {
        return sprTipvia;
    }

    public void setSprTipvia(String sprTipvia) {
        this.sprTipvia = sprTipvia == null ? null : sprTipvia.trim();
    }

    public String getSprTipzon() {
        return sprTipzon;
    }

    public void setSprTipzon(String sprTipzon) {
        this.sprTipzon = sprTipzon == null ? null : sprTipzon.trim();
    }

    public String getSprIndmaq() {
        return sprIndmaq;
    }

    public void setSprIndmaq(String sprIndmaq) {
        this.sprIndmaq = sprIndmaq == null ? null : sprIndmaq.trim();
    }

    public String getSprUserna() {
        return sprUserna;
    }

    public void setSprUserna(String sprUserna) {
        this.sprUserna = sprUserna == null ? null : sprUserna.trim();
    }

    public Date getSprFecact() {
        return sprFecact;
    }

    public void setSprFecact(Date sprFecact) {
        this.sprFecact = sprFecact;
    }
}