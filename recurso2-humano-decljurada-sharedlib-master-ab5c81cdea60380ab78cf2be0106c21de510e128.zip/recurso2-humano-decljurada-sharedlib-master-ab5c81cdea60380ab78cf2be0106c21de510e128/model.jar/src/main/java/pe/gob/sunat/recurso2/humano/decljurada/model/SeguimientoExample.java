package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SeguimientoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public SeguimientoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected SeguimientoExample(SeguimientoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andAnnDdjjIsNull() {
            addCriterion("ann_ddjj is null");
            return this;
        }

        public Criteria andAnnDdjjIsNotNull() {
            addCriterion("ann_ddjj is not null");
            return this;
        }

        public Criteria andAnnDdjjEqualTo(String value) {
            addCriterion("ann_ddjj =", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotEqualTo(String value) {
            addCriterion("ann_ddjj <>", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThan(String value) {
            addCriterion("ann_ddjj >", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThanOrEqualTo(String value) {
            addCriterion("ann_ddjj >=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThan(String value) {
            addCriterion("ann_ddjj <", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThanOrEqualTo(String value) {
            addCriterion("ann_ddjj <=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLike(String value) {
            addCriterion("ann_ddjj like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotLike(String value) {
            addCriterion("ann_ddjj not like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjIn(List<String> values) {
            addCriterion("ann_ddjj in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotIn(List<String> values) {
            addCriterion("ann_ddjj not in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjBetween(String value1, String value2) {
            addCriterion("ann_ddjj between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotBetween(String value1, String value2) {
            addCriterion("ann_ddjj not between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andCodPersonalIsNull() {
            addCriterion("cod_personal is null");
            return this;
        }

        public Criteria andCodPersonalIsNotNull() {
            addCriterion("cod_personal is not null");
            return this;
        }

        public Criteria andCodPersonalEqualTo(String value) {
            addCriterion("cod_personal =", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotEqualTo(String value) {
            addCriterion("cod_personal <>", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThan(String value) {
            addCriterion("cod_personal >", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThanOrEqualTo(String value) {
            addCriterion("cod_personal >=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThan(String value) {
            addCriterion("cod_personal <", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThanOrEqualTo(String value) {
            addCriterion("cod_personal <=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLike(String value) {
            addCriterion("cod_personal like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotLike(String value) {
            addCriterion("cod_personal not like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalIn(List<String> values) {
            addCriterion("cod_personal in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotIn(List<String> values) {
            addCriterion("cod_personal not in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalBetween(String value1, String value2) {
            addCriterion("cod_personal between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotBetween(String value1, String value2) {
            addCriterion("cod_personal not between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andNumDdjjIsNull() {
            addCriterion("num_ddjj is null");
            return this;
        }

        public Criteria andNumDdjjIsNotNull() {
            addCriterion("num_ddjj is not null");
            return this;
        }

        public Criteria andNumDdjjEqualTo(Integer value) {
            addCriterion("num_ddjj =", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotEqualTo(Integer value) {
            addCriterion("num_ddjj <>", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThan(Integer value) {
            addCriterion("num_ddjj >", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj >=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThan(Integer value) {
            addCriterion("num_ddjj <", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj <=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjIn(List<Integer> values) {
            addCriterion("num_ddjj in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotIn(List<Integer> values) {
            addCriterion("num_ddjj not in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj not between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andNumSeguimIsNull() {
            addCriterion("num_seguim is null");
            return this;
        }

        public Criteria andNumSeguimIsNotNull() {
            addCriterion("num_seguim is not null");
            return this;
        }

        public Criteria andNumSeguimEqualTo(String value) {
            addCriterion("num_seguim =", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotEqualTo(String value) {
            addCriterion("num_seguim <>", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimGreaterThan(String value) {
            addCriterion("num_seguim >", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimGreaterThanOrEqualTo(String value) {
            addCriterion("num_seguim >=", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimLessThan(String value) {
            addCriterion("num_seguim <", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimLessThanOrEqualTo(String value) {
            addCriterion("num_seguim <=", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimLike(String value) {
            addCriterion("num_seguim like", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotLike(String value) {
            addCriterion("num_seguim not like", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimIn(List<String> values) {
            addCriterion("num_seguim in", values, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotIn(List<String> values) {
            addCriterion("num_seguim not in", values, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimBetween(String value1, String value2) {
            addCriterion("num_seguim between", value1, value2, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotBetween(String value1, String value2) {
            addCriterion("num_seguim not between", value1, value2, "numSeguim");
            return this;
        }

        public Criteria andCodUorganIsNull() {
            addCriterion("cod_uorgan is null");
            return this;
        }

        public Criteria andCodUorganIsNotNull() {
            addCriterion("cod_uorgan is not null");
            return this;
        }

        public Criteria andCodUorganEqualTo(String value) {
            addCriterion("cod_uorgan =", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotEqualTo(String value) {
            addCriterion("cod_uorgan <>", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThan(String value) {
            addCriterion("cod_uorgan >", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThanOrEqualTo(String value) {
            addCriterion("cod_uorgan >=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThan(String value) {
            addCriterion("cod_uorgan <", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThanOrEqualTo(String value) {
            addCriterion("cod_uorgan <=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLike(String value) {
            addCriterion("cod_uorgan like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotLike(String value) {
            addCriterion("cod_uorgan not like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganIn(List<String> values) {
            addCriterion("cod_uorgan in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotIn(List<String> values) {
            addCriterion("cod_uorgan not in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganBetween(String value1, String value2) {
            addCriterion("cod_uorgan between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotBetween(String value1, String value2) {
            addCriterion("cod_uorgan not between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andFecRecepIsNull() {
            addCriterion("fec_recep is null");
            return this;
        }

        public Criteria andFecRecepIsNotNull() {
            addCriterion("fec_recep is not null");
            return this;
        }

        public Criteria andFecRecepEqualTo(Date value) {
            addCriterion("fec_recep =", value, "fecRecep");
            return this;
        }

        public Criteria andFecRecepNotEqualTo(Date value) {
            addCriterion("fec_recep <>", value, "fecRecep");
            return this;
        }

        public Criteria andFecRecepGreaterThan(Date value) {
            addCriterion("fec_recep >", value, "fecRecep");
            return this;
        }

        public Criteria andFecRecepGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_recep >=", value, "fecRecep");
            return this;
        }

        public Criteria andFecRecepLessThan(Date value) {
            addCriterion("fec_recep <", value, "fecRecep");
            return this;
        }

        public Criteria andFecRecepLessThanOrEqualTo(Date value) {
            addCriterion("fec_recep <=", value, "fecRecep");
            return this;
        }

        public Criteria andFecRecepIn(List<Date> values) {
            addCriterion("fec_recep in", values, "fecRecep");
            return this;
        }

        public Criteria andFecRecepNotIn(List<Date> values) {
            addCriterion("fec_recep not in", values, "fecRecep");
            return this;
        }

        public Criteria andFecRecepBetween(Date value1, Date value2) {
            addCriterion("fec_recep between", value1, value2, "fecRecep");
            return this;
        }

        public Criteria andFecRecepNotBetween(Date value1, Date value2) {
            addCriterion("fec_recep not between", value1, value2, "fecRecep");
            return this;
        }

        public Criteria andFecDerivIsNull() {
            addCriterion("fec_deriv is null");
            return this;
        }

        public Criteria andFecDerivIsNotNull() {
            addCriterion("fec_deriv is not null");
            return this;
        }

        public Criteria andFecDerivEqualTo(Date value) {
            addCriterion("fec_deriv =", value, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivNotEqualTo(Date value) {
            addCriterion("fec_deriv <>", value, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivGreaterThan(Date value) {
            addCriterion("fec_deriv >", value, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_deriv >=", value, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivLessThan(Date value) {
            addCriterion("fec_deriv <", value, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivLessThanOrEqualTo(Date value) {
            addCriterion("fec_deriv <=", value, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivIn(List<Date> values) {
            addCriterion("fec_deriv in", values, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivNotIn(List<Date> values) {
            addCriterion("fec_deriv not in", values, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivBetween(Date value1, Date value2) {
            addCriterion("fec_deriv between", value1, value2, "fecDeriv");
            return this;
        }

        public Criteria andFecDerivNotBetween(Date value1, Date value2) {
            addCriterion("fec_deriv not between", value1, value2, "fecDeriv");
            return this;
        }

        public Criteria andIndAccionidIsNull() {
            addCriterion("ind_accionid is null");
            return this;
        }

        public Criteria andIndAccionidIsNotNull() {
            addCriterion("ind_accionid is not null");
            return this;
        }

        public Criteria andIndAccionidEqualTo(String value) {
            addCriterion("ind_accionid =", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidNotEqualTo(String value) {
            addCriterion("ind_accionid <>", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidGreaterThan(String value) {
            addCriterion("ind_accionid >", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidGreaterThanOrEqualTo(String value) {
            addCriterion("ind_accionid >=", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidLessThan(String value) {
            addCriterion("ind_accionid <", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidLessThanOrEqualTo(String value) {
            addCriterion("ind_accionid <=", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidLike(String value) {
            addCriterion("ind_accionid like", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidNotLike(String value) {
            addCriterion("ind_accionid not like", value, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidIn(List<String> values) {
            addCriterion("ind_accionid in", values, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidNotIn(List<String> values) {
            addCriterion("ind_accionid not in", values, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidBetween(String value1, String value2) {
            addCriterion("ind_accionid between", value1, value2, "indAccionid");
            return this;
        }

        public Criteria andIndAccionidNotBetween(String value1, String value2) {
            addCriterion("ind_accionid not between", value1, value2, "indAccionid");
            return this;
        }

        public Criteria andIndEstadoidIsNull() {
            addCriterion("ind_estadoid is null");
            return this;
        }

        public Criteria andIndEstadoidIsNotNull() {
            addCriterion("ind_estadoid is not null");
            return this;
        }

        public Criteria andIndEstadoidEqualTo(String value) {
            addCriterion("ind_estadoid =", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidNotEqualTo(String value) {
            addCriterion("ind_estadoid <>", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidGreaterThan(String value) {
            addCriterion("ind_estadoid >", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidGreaterThanOrEqualTo(String value) {
            addCriterion("ind_estadoid >=", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidLessThan(String value) {
            addCriterion("ind_estadoid <", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidLessThanOrEqualTo(String value) {
            addCriterion("ind_estadoid <=", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidLike(String value) {
            addCriterion("ind_estadoid like", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidNotLike(String value) {
            addCriterion("ind_estadoid not like", value, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidIn(List<String> values) {
            addCriterion("ind_estadoid in", values, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidNotIn(List<String> values) {
            addCriterion("ind_estadoid not in", values, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidBetween(String value1, String value2) {
            addCriterion("ind_estadoid between", value1, value2, "indEstadoid");
            return this;
        }

        public Criteria andIndEstadoidNotBetween(String value1, String value2) {
            addCriterion("ind_estadoid not between", value1, value2, "indEstadoid");
            return this;
        }

        public Criteria andCodUserorigIsNull() {
            addCriterion("cod_userorig is null");
            return this;
        }

        public Criteria andCodUserorigIsNotNull() {
            addCriterion("cod_userorig is not null");
            return this;
        }

        public Criteria andCodUserorigEqualTo(String value) {
            addCriterion("cod_userorig =", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigNotEqualTo(String value) {
            addCriterion("cod_userorig <>", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigGreaterThan(String value) {
            addCriterion("cod_userorig >", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigGreaterThanOrEqualTo(String value) {
            addCriterion("cod_userorig >=", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigLessThan(String value) {
            addCriterion("cod_userorig <", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigLessThanOrEqualTo(String value) {
            addCriterion("cod_userorig <=", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigLike(String value) {
            addCriterion("cod_userorig like", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigNotLike(String value) {
            addCriterion("cod_userorig not like", value, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigIn(List<String> values) {
            addCriterion("cod_userorig in", values, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigNotIn(List<String> values) {
            addCriterion("cod_userorig not in", values, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigBetween(String value1, String value2) {
            addCriterion("cod_userorig between", value1, value2, "codUserorig");
            return this;
        }

        public Criteria andCodUserorigNotBetween(String value1, String value2) {
            addCriterion("cod_userorig not between", value1, value2, "codUserorig");
            return this;
        }

        public Criteria andCodUserdestIsNull() {
            addCriterion("cod_userdest is null");
            return this;
        }

        public Criteria andCodUserdestIsNotNull() {
            addCriterion("cod_userdest is not null");
            return this;
        }

        public Criteria andCodUserdestEqualTo(String value) {
            addCriterion("cod_userdest =", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestNotEqualTo(String value) {
            addCriterion("cod_userdest <>", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestGreaterThan(String value) {
            addCriterion("cod_userdest >", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestGreaterThanOrEqualTo(String value) {
            addCriterion("cod_userdest >=", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestLessThan(String value) {
            addCriterion("cod_userdest <", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestLessThanOrEqualTo(String value) {
            addCriterion("cod_userdest <=", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestLike(String value) {
            addCriterion("cod_userdest like", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestNotLike(String value) {
            addCriterion("cod_userdest not like", value, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestIn(List<String> values) {
            addCriterion("cod_userdest in", values, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestNotIn(List<String> values) {
            addCriterion("cod_userdest not in", values, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestBetween(String value1, String value2) {
            addCriterion("cod_userdest between", value1, value2, "codUserdest");
            return this;
        }

        public Criteria andCodUserdestNotBetween(String value1, String value2) {
            addCriterion("cod_userdest not between", value1, value2, "codUserdest");
            return this;
        }

        public Criteria andObsSegIsNull() {
            addCriterion("obs_seg is null");
            return this;
        }

        public Criteria andObsSegIsNotNull() {
            addCriterion("obs_seg is not null");
            return this;
        }

        public Criteria andObsSegEqualTo(String value) {
            addCriterion("obs_seg =", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegNotEqualTo(String value) {
            addCriterion("obs_seg <>", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegGreaterThan(String value) {
            addCriterion("obs_seg >", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegGreaterThanOrEqualTo(String value) {
            addCriterion("obs_seg >=", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegLessThan(String value) {
            addCriterion("obs_seg <", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegLessThanOrEqualTo(String value) {
            addCriterion("obs_seg <=", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegLike(String value) {
            addCriterion("obs_seg like", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegNotLike(String value) {
            addCriterion("obs_seg not like", value, "obsSeg");
            return this;
        }

        public Criteria andObsSegIn(List<String> values) {
            addCriterion("obs_seg in", values, "obsSeg");
            return this;
        }

        public Criteria andObsSegNotIn(List<String> values) {
            addCriterion("obs_seg not in", values, "obsSeg");
            return this;
        }

        public Criteria andObsSegBetween(String value1, String value2) {
            addCriterion("obs_seg between", value1, value2, "obsSeg");
            return this;
        }

        public Criteria andObsSegNotBetween(String value1, String value2) {
            addCriterion("obs_seg not between", value1, value2, "obsSeg");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andTipDdjjIsNull() {
            addCriterion("tip_ddjj is null");
            return this;
        }

        public Criteria andTipDdjjIsNotNull() {
            addCriterion("tip_ddjj is not null");
            return this;
        }

        public Criteria andTipDdjjEqualTo(String value) {
            addCriterion("tip_ddjj =", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjNotEqualTo(String value) {
            addCriterion("tip_ddjj <>", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjGreaterThan(String value) {
            addCriterion("tip_ddjj >", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjGreaterThanOrEqualTo(String value) {
            addCriterion("tip_ddjj >=", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjLessThan(String value) {
            addCriterion("tip_ddjj <", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjLessThanOrEqualTo(String value) {
            addCriterion("tip_ddjj <=", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjLike(String value) {
            addCriterion("tip_ddjj like", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjNotLike(String value) {
            addCriterion("tip_ddjj not like", value, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjIn(List<String> values) {
            addCriterion("tip_ddjj in", values, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjNotIn(List<String> values) {
            addCriterion("tip_ddjj not in", values, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjBetween(String value1, String value2) {
            addCriterion("tip_ddjj between", value1, value2, "tipDdjj");
            return this;
        }

        public Criteria andTipDdjjNotBetween(String value1, String value2) {
            addCriterion("tip_ddjj not between", value1, value2, "tipDdjj");
            return this;
        }

        public Criteria andIndUltSegIsNull() {
            addCriterion("ind_ult_seg is null");
            return this;
        }

        public Criteria andIndUltSegIsNotNull() {
            addCriterion("ind_ult_seg is not null");
            return this;
        }

        public Criteria andIndUltSegEqualTo(String value) {
            addCriterion("ind_ult_seg =", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegNotEqualTo(String value) {
            addCriterion("ind_ult_seg <>", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegGreaterThan(String value) {
            addCriterion("ind_ult_seg >", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegGreaterThanOrEqualTo(String value) {
            addCriterion("ind_ult_seg >=", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegLessThan(String value) {
            addCriterion("ind_ult_seg <", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegLessThanOrEqualTo(String value) {
            addCriterion("ind_ult_seg <=", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegLike(String value) {
            addCriterion("ind_ult_seg like", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegNotLike(String value) {
            addCriterion("ind_ult_seg not like", value, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegIn(List<String> values) {
            addCriterion("ind_ult_seg in", values, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegNotIn(List<String> values) {
            addCriterion("ind_ult_seg not in", values, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegBetween(String value1, String value2) {
            addCriterion("ind_ult_seg between", value1, value2, "indUltSeg");
            return this;
        }

        public Criteria andIndUltSegNotBetween(String value1, String value2) {
            addCriterion("ind_ult_seg not between", value1, value2, "indUltSeg");
            return this;
        }
    }
}