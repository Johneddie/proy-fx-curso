package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Estructura11 {
    private Date fecProceso;

    private String codDocum;

    private String numDocum;

    private String codPaisEmiDoc;

    private String codCate;

    private String codTipReg;

    private Date fecIni;

    private Date fecFin;

    private String codIndTipReg;

    private String codEps;

    private String estProceso;

    private Date fecCreacion;

    private String accCreacion;

    public Date getFecProceso() {
        return fecProceso;
    }

    public void setFecProceso(Date fecProceso) {
        this.fecProceso = fecProceso;
    }

    public String getCodDocum() {
        return codDocum;
    }

    public void setCodDocum(String codDocum) {
        this.codDocum = codDocum == null ? null : codDocum.trim();
    }

    public String getNumDocum() {
        return numDocum;
    }

    public void setNumDocum(String numDocum) {
        this.numDocum = numDocum == null ? null : numDocum.trim();
    }

    public String getCodPaisEmiDoc() {
        return codPaisEmiDoc;
    }

    public void setCodPaisEmiDoc(String codPaisEmiDoc) {
        this.codPaisEmiDoc = codPaisEmiDoc == null ? null : codPaisEmiDoc.trim();
    }

    public String getCodCate() {
        return codCate;
    }

    public void setCodCate(String codCate) {
        this.codCate = codCate == null ? null : codCate.trim();
    }

    public String getCodTipReg() {
        return codTipReg;
    }

    public void setCodTipReg(String codTipReg) {
        this.codTipReg = codTipReg == null ? null : codTipReg.trim();
    }

    public Date getFecIni() {
        return fecIni;
    }

    public void setFecIni(Date fecIni) {
        this.fecIni = fecIni;
    }

    public Date getFecFin() {
        return fecFin;
    }

    public void setFecFin(Date fecFin) {
        this.fecFin = fecFin;
    }

    public String getCodIndTipReg() {
        return codIndTipReg;
    }

    public void setCodIndTipReg(String codIndTipReg) {
        this.codIndTipReg = codIndTipReg == null ? null : codIndTipReg.trim();
    }

    public String getCodEps() {
        return codEps;
    }

    public void setCodEps(String codEps) {
        this.codEps = codEps == null ? null : codEps.trim();
    }

    public String getEstProceso() {
        return estProceso;
    }

    public void setEstProceso(String estProceso) {
        this.estProceso = estProceso == null ? null : estProceso.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getAccCreacion() {
        return accCreacion;
    }

    public void setAccCreacion(String accCreacion) {
        this.accCreacion = accCreacion == null ? null : accCreacion.trim();
    }
}