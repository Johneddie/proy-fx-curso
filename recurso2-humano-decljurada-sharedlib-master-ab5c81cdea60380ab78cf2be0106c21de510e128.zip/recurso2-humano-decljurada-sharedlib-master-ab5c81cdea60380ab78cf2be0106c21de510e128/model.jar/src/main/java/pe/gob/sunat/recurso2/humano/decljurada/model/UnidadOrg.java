package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class UnidadOrg {
    private String t12codUorga;

    private String t12desUorga;

    private String t12desCorta;

    private Date t12fVigenci;

    private Date t12fBaja;

    private String t12codNivel;

    private String t12codCateg;

    private String t12codSubpr;

    private String t12indAplic;

    private String t12codAnter;

    private String t12indEstad;

    private String t12codJefat;

    private String t12codEncar;

    private String t12codRepor;

    private String t12tipo;

    private Date t12fGraba;

    private String t12codUser;

    private String t12indLima;

    private String codDpto;

    private Short codSede;

    public String getT12codUorga() {
        return t12codUorga;
    }

    public void setT12codUorga(String t12codUorga) {
        this.t12codUorga = t12codUorga == null ? null : t12codUorga.trim();
    }

    public String getT12desUorga() {
        return t12desUorga;
    }

    public void setT12desUorga(String t12desUorga) {
        this.t12desUorga = t12desUorga == null ? null : t12desUorga.trim();
    }

    public String getT12desCorta() {
        return t12desCorta;
    }

    public void setT12desCorta(String t12desCorta) {
        this.t12desCorta = t12desCorta == null ? null : t12desCorta.trim();
    }

    public Date getT12fVigenci() {
        return t12fVigenci;
    }

    public void setT12fVigenci(Date t12fVigenci) {
        this.t12fVigenci = t12fVigenci;
    }

    public Date getT12fBaja() {
        return t12fBaja;
    }

    public void setT12fBaja(Date t12fBaja) {
        this.t12fBaja = t12fBaja;
    }

    public String getT12codNivel() {
        return t12codNivel;
    }

    public void setT12codNivel(String t12codNivel) {
        this.t12codNivel = t12codNivel == null ? null : t12codNivel.trim();
    }

    public String getT12codCateg() {
        return t12codCateg;
    }

    public void setT12codCateg(String t12codCateg) {
        this.t12codCateg = t12codCateg == null ? null : t12codCateg.trim();
    }

    public String getT12codSubpr() {
        return t12codSubpr;
    }

    public void setT12codSubpr(String t12codSubpr) {
        this.t12codSubpr = t12codSubpr == null ? null : t12codSubpr.trim();
    }

    public String getT12indAplic() {
        return t12indAplic;
    }

    public void setT12indAplic(String t12indAplic) {
        this.t12indAplic = t12indAplic == null ? null : t12indAplic.trim();
    }

    public String getT12codAnter() {
        return t12codAnter;
    }

    public void setT12codAnter(String t12codAnter) {
        this.t12codAnter = t12codAnter == null ? null : t12codAnter.trim();
    }

    public String getT12indEstad() {
        return t12indEstad;
    }

    public void setT12indEstad(String t12indEstad) {
        this.t12indEstad = t12indEstad == null ? null : t12indEstad.trim();
    }

    public String getT12codJefat() {
        return t12codJefat;
    }

    public void setT12codJefat(String t12codJefat) {
        this.t12codJefat = t12codJefat == null ? null : t12codJefat.trim();
    }

    public String getT12codEncar() {
        return t12codEncar;
    }

    public void setT12codEncar(String t12codEncar) {
        this.t12codEncar = t12codEncar == null ? null : t12codEncar.trim();
    }

    public String getT12codRepor() {
        return t12codRepor;
    }

    public void setT12codRepor(String t12codRepor) {
        this.t12codRepor = t12codRepor == null ? null : t12codRepor.trim();
    }

    public String getT12tipo() {
        return t12tipo;
    }

    public void setT12tipo(String t12tipo) {
        this.t12tipo = t12tipo == null ? null : t12tipo.trim();
    }

    public Date getT12fGraba() {
        return t12fGraba;
    }

    public void setT12fGraba(Date t12fGraba) {
        this.t12fGraba = t12fGraba;
    }

    public String getT12codUser() {
        return t12codUser;
    }

    public void setT12codUser(String t12codUser) {
        this.t12codUser = t12codUser == null ? null : t12codUser.trim();
    }

    public String getT12indLima() {
        return t12indLima;
    }

    public void setT12indLima(String t12indLima) {
        this.t12indLima = t12indLima == null ? null : t12indLima.trim();
    }

    public String getCodDpto() {
        return codDpto;
    }

    public void setCodDpto(String codDpto) {
        this.codDpto = codDpto == null ? null : codDpto.trim();
    }

    public Short getCodSede() {
        return codSede;
    }

    public void setCodSede(Short codSede) {
        this.codSede = codSede;
    }
}