package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DeclaraDerechohab extends DeclaraDerechohabKey {
    private String codPersonal;

    private String codUorgan;

    private String codDocum;

    private String numDocum;

    private String codDocumDer;

    private String numDocumDer;

    private String codPaisEmiDoc;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy",timezone="GMT-5:00")
    private Date fecNacimientoDer;

    private String apePatDer;

    private String apeMatDer;

    private String nomDer;

    private String indSexoDer;

    private String codVinFam;

    private String codDocAcreVin;

    private String numDocAcreVin;

    private String numMesConcep;

    private String indSituFam;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy",timezone="GMT-5:00")
    private Date fecBaja;

    private String codBaja;

    private String numDocBaja;

    private String indTrabSunat;

    private String numRegistro;

    private String codViaDir1;

    private String nomViaDir1;

    private String numViaDir1;

    private String numDepaDir1;

    private String numInteriorDir1;

    private String numManzDir1;

    private String numLoteDir1;

    private String numKilomDir1;

    private String numBlockDir1;

    private String numEtapaDir1;

    private String codZonaDir1;

    private String nomZonaDir1;

    private String desReferDir1;

    private String codUbigeoDir1;

    private String codViaDir2;

    private String nomViaDir2;

    private String numViaDir2;

    private String numDepaDir2;

    private String numInteriorDir2;

    private String numManzDir2;

    private String numLoteDir2;

    private String numKilomDir2;

    private String numBlockDir2;

    private String numEtapaDir2;

    private String codZonaDir2;

    private String nomZonaDir2;

    private String desReferDir2;

    private String indCentAsis;

    private String codUbigeoDir2;

    private String indDel;

    private String codUsucrea;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss",timezone="GMT-5:00")
    private Date fecCreacion;

    private String codUsumodif;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss",timezone="GMT-5:00")
    private Date fecModif;

    private String codTelefLarDis;

    private String numTelef;

    private String codCelLarDis;

    private String numCelular;

    private String desCorreo;

    private String desDomiciDir1;

    private String desUbigeoDir1;

    private String indReniec;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy",timezone="GMT-5:00")
    private Date fecInivinc;

    private String indSubsidSepe;

    private String indDiscapacidad;

    private String indEstudiante;
    
    
    private String desVinFam;
    
    private String desSituFam;
    
    private String desIndEstado;
    
    private List<Archivo> archivosReferDomicilio;
    
    private List<Archivo> archivosAcredVinculo;
    
    private List<Archivo> archivosBajaDerechohab;
    
    private List<Archivo> archivosSubsidSepelio;
    
    private List<Archivo> archivosDiscapacidad;
    
    //se le permite subsidiar
    private String indReglSubsidSepe;

    public String getCodPersonal() {
        return codPersonal;
    }

    public void setCodPersonal(String codPersonal) {
        this.codPersonal = codPersonal == null ? null : codPersonal.trim();
    }

    public String getCodUorgan() {
        return codUorgan;
    }

    public void setCodUorgan(String codUorgan) {
        this.codUorgan = codUorgan == null ? null : codUorgan.trim();
    }

    public String getCodDocum() {
        return codDocum;
    }

    public void setCodDocum(String codDocum) {
        this.codDocum = codDocum == null ? null : codDocum.trim();
    }

    public String getNumDocum() {
        return numDocum;
    }

    public void setNumDocum(String numDocum) {
        this.numDocum = numDocum == null ? null : numDocum.trim();
    }

    public String getCodDocumDer() {
        return codDocumDer;
    }

    public void setCodDocumDer(String codDocumDer) {
        this.codDocumDer = codDocumDer == null ? null : codDocumDer.trim();
    }

    public String getNumDocumDer() {
        return numDocumDer;
    }

    public void setNumDocumDer(String numDocumDer) {
        this.numDocumDer = numDocumDer == null ? null : numDocumDer.trim();
    }

    public String getCodPaisEmiDoc() {
        return codPaisEmiDoc;
    }

    public void setCodPaisEmiDoc(String codPaisEmiDoc) {
        this.codPaisEmiDoc = codPaisEmiDoc == null ? null : codPaisEmiDoc.trim();
    }

    public Date getFecNacimientoDer() {
        return fecNacimientoDer;
    }

    public void setFecNacimientoDer(Date fecNacimientoDer) {
        this.fecNacimientoDer = fecNacimientoDer;
    }

    public String getApePatDer() {
        return apePatDer;
    }

    public void setApePatDer(String apePatDer) {
        this.apePatDer = apePatDer == null ? null : apePatDer.trim();
    }

    public String getApeMatDer() {
        return apeMatDer;
    }

    public void setApeMatDer(String apeMatDer) {
        this.apeMatDer = apeMatDer == null ? null : apeMatDer.trim();
    }

    public String getNomDer() {
        return nomDer;
    }

    public void setNomDer(String nomDer) {
        this.nomDer = nomDer == null ? null : nomDer.trim();
    }

    public String getIndSexoDer() {
        return indSexoDer;
    }

    public void setIndSexoDer(String indSexoDer) {
        this.indSexoDer = indSexoDer == null ? null : indSexoDer.trim();
    }

    public String getCodVinFam() {
        return codVinFam;
    }

    public void setCodVinFam(String codVinFam) {
        this.codVinFam = codVinFam == null ? null : codVinFam.trim();
    }

    public String getCodDocAcreVin() {
        return codDocAcreVin;
    }

    public void setCodDocAcreVin(String codDocAcreVin) {
        this.codDocAcreVin = codDocAcreVin == null ? null : codDocAcreVin.trim();
    }

    public String getNumDocAcreVin() {
        return numDocAcreVin;
    }

    public void setNumDocAcreVin(String numDocAcreVin) {
        this.numDocAcreVin = numDocAcreVin == null ? null : numDocAcreVin.trim();
    }

    public String getNumMesConcep() {
        return numMesConcep;
    }

    public void setNumMesConcep(String numMesConcep) {
        this.numMesConcep = numMesConcep == null ? null : numMesConcep.trim();
    }

    public String getIndSituFam() {
        return indSituFam;
    }

    public void setIndSituFam(String indSituFam) {
        this.indSituFam = indSituFam == null ? null : indSituFam.trim();
    }

    public Date getFecBaja() {
        return fecBaja;
    }

    public void setFecBaja(Date fecBaja) {
        this.fecBaja = fecBaja;
    }

    public String getCodBaja() {
        return codBaja;
    }

    public void setCodBaja(String codBaja) {
        this.codBaja = codBaja == null ? null : codBaja.trim();
    }

    public String getNumDocBaja() {
        return numDocBaja;
    }

    public void setNumDocBaja(String numDocBaja) {
        this.numDocBaja = numDocBaja == null ? null : numDocBaja.trim();
    }

    public String getIndTrabSunat() {
        return indTrabSunat;
    }

    public void setIndTrabSunat(String indTrabSunat) {
        this.indTrabSunat = indTrabSunat == null ? null : indTrabSunat.trim();
    }

    public String getNumRegistro() {
        return numRegistro;
    }

    public void setNumRegistro(String numRegistro) {
        this.numRegistro = numRegistro == null ? null : numRegistro.trim();
    }

    public String getCodViaDir1() {
        return codViaDir1;
    }

    public void setCodViaDir1(String codViaDir1) {
        this.codViaDir1 = codViaDir1 == null ? null : codViaDir1.trim();
    }

    public String getNomViaDir1() {
        return nomViaDir1;
    }

    public void setNomViaDir1(String nomViaDir1) {
        this.nomViaDir1 = nomViaDir1 == null ? null : nomViaDir1.trim();
    }

    public String getNumViaDir1() {
        return numViaDir1;
    }

    public void setNumViaDir1(String numViaDir1) {
        this.numViaDir1 = numViaDir1 == null ? null : numViaDir1.trim();
    }

    public String getNumDepaDir1() {
        return numDepaDir1;
    }

    public void setNumDepaDir1(String numDepaDir1) {
        this.numDepaDir1 = numDepaDir1 == null ? null : numDepaDir1.trim();
    }

    public String getNumInteriorDir1() {
        return numInteriorDir1;
    }

    public void setNumInteriorDir1(String numInteriorDir1) {
        this.numInteriorDir1 = numInteriorDir1 == null ? null : numInteriorDir1.trim();
    }

    public String getNumManzDir1() {
        return numManzDir1;
    }

    public void setNumManzDir1(String numManzDir1) {
        this.numManzDir1 = numManzDir1 == null ? null : numManzDir1.trim();
    }

    public String getNumLoteDir1() {
        return numLoteDir1;
    }

    public void setNumLoteDir1(String numLoteDir1) {
        this.numLoteDir1 = numLoteDir1 == null ? null : numLoteDir1.trim();
    }

    public String getNumKilomDir1() {
        return numKilomDir1;
    }

    public void setNumKilomDir1(String numKilomDir1) {
        this.numKilomDir1 = numKilomDir1 == null ? null : numKilomDir1.trim();
    }

    public String getNumBlockDir1() {
        return numBlockDir1;
    }

    public void setNumBlockDir1(String numBlockDir1) {
        this.numBlockDir1 = numBlockDir1 == null ? null : numBlockDir1.trim();
    }

    public String getNumEtapaDir1() {
        return numEtapaDir1;
    }

    public void setNumEtapaDir1(String numEtapaDir1) {
        this.numEtapaDir1 = numEtapaDir1 == null ? null : numEtapaDir1.trim();
    }

    public String getCodZonaDir1() {
        return codZonaDir1;
    }

    public void setCodZonaDir1(String codZonaDir1) {
        this.codZonaDir1 = codZonaDir1 == null ? null : codZonaDir1.trim();
    }

    public String getNomZonaDir1() {
        return nomZonaDir1;
    }

    public void setNomZonaDir1(String nomZonaDir1) {
        this.nomZonaDir1 = nomZonaDir1 == null ? null : nomZonaDir1.trim();
    }

    public String getDesReferDir1() {
        return desReferDir1;
    }

    public void setDesReferDir1(String desReferDir1) {
        this.desReferDir1 = desReferDir1 == null ? null : desReferDir1.trim();
    }

    public String getCodUbigeoDir1() {
        return codUbigeoDir1;
    }

    public void setCodUbigeoDir1(String codUbigeoDir1) {
        this.codUbigeoDir1 = codUbigeoDir1 == null ? null : codUbigeoDir1.trim();
    }

    public String getCodViaDir2() {
        return codViaDir2;
    }

    public void setCodViaDir2(String codViaDir2) {
        this.codViaDir2 = codViaDir2 == null ? null : codViaDir2.trim();
    }

    public String getNomViaDir2() {
        return nomViaDir2;
    }

    public void setNomViaDir2(String nomViaDir2) {
        this.nomViaDir2 = nomViaDir2 == null ? null : nomViaDir2.trim();
    }

    public String getNumViaDir2() {
        return numViaDir2;
    }

    public void setNumViaDir2(String numViaDir2) {
        this.numViaDir2 = numViaDir2 == null ? null : numViaDir2.trim();
    }

    public String getNumDepaDir2() {
        return numDepaDir2;
    }

    public void setNumDepaDir2(String numDepaDir2) {
        this.numDepaDir2 = numDepaDir2 == null ? null : numDepaDir2.trim();
    }

    public String getNumInteriorDir2() {
        return numInteriorDir2;
    }

    public void setNumInteriorDir2(String numInteriorDir2) {
        this.numInteriorDir2 = numInteriorDir2 == null ? null : numInteriorDir2.trim();
    }

    public String getNumManzDir2() {
        return numManzDir2;
    }

    public void setNumManzDir2(String numManzDir2) {
        this.numManzDir2 = numManzDir2 == null ? null : numManzDir2.trim();
    }

    public String getNumLoteDir2() {
        return numLoteDir2;
    }

    public void setNumLoteDir2(String numLoteDir2) {
        this.numLoteDir2 = numLoteDir2 == null ? null : numLoteDir2.trim();
    }

    public String getNumKilomDir2() {
        return numKilomDir2;
    }

    public void setNumKilomDir2(String numKilomDir2) {
        this.numKilomDir2 = numKilomDir2 == null ? null : numKilomDir2.trim();
    }

    public String getNumBlockDir2() {
        return numBlockDir2;
    }

    public void setNumBlockDir2(String numBlockDir2) {
        this.numBlockDir2 = numBlockDir2 == null ? null : numBlockDir2.trim();
    }

    public String getNumEtapaDir2() {
        return numEtapaDir2;
    }

    public void setNumEtapaDir2(String numEtapaDir2) {
        this.numEtapaDir2 = numEtapaDir2 == null ? null : numEtapaDir2.trim();
    }

    public String getCodZonaDir2() {
        return codZonaDir2;
    }

    public void setCodZonaDir2(String codZonaDir2) {
        this.codZonaDir2 = codZonaDir2 == null ? null : codZonaDir2.trim();
    }

    public String getNomZonaDir2() {
        return nomZonaDir2;
    }

    public void setNomZonaDir2(String nomZonaDir2) {
        this.nomZonaDir2 = nomZonaDir2 == null ? null : nomZonaDir2.trim();
    }

    public String getDesReferDir2() {
        return desReferDir2;
    }

    public void setDesReferDir2(String desReferDir2) {
        this.desReferDir2 = desReferDir2 == null ? null : desReferDir2.trim();
    }

    public String getIndCentAsis() {
        return indCentAsis;
    }

    public void setIndCentAsis(String indCentAsis) {
        this.indCentAsis = indCentAsis == null ? null : indCentAsis.trim();
    }

    public String getCodUbigeoDir2() {
        return codUbigeoDir2;
    }

    public void setCodUbigeoDir2(String codUbigeoDir2) {
        this.codUbigeoDir2 = codUbigeoDir2 == null ? null : codUbigeoDir2.trim();
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getCodTelefLarDis() {
        return codTelefLarDis;
    }

    public void setCodTelefLarDis(String codTelefLarDis) {
        this.codTelefLarDis = codTelefLarDis == null ? null : codTelefLarDis.trim();
    }

    public String getNumTelef() {
        return numTelef;
    }

    public void setNumTelef(String numTelef) {
        this.numTelef = numTelef == null ? null : numTelef.trim();
    }

    public String getCodCelLarDis() {
        return codCelLarDis;
    }

    public void setCodCelLarDis(String codCelLarDis) {
        this.codCelLarDis = codCelLarDis == null ? null : codCelLarDis.trim();
    }

    public String getNumCelular() {
        return numCelular;
    }

    public void setNumCelular(String numCelular) {
        this.numCelular = numCelular == null ? null : numCelular.trim();
    }

    public String getDesCorreo() {
        return desCorreo;
    }

    public void setDesCorreo(String desCorreo) {
        this.desCorreo = desCorreo == null ? null : desCorreo.trim();
    }

    public String getDesDomiciDir1() {
        return desDomiciDir1;
    }

    public void setDesDomiciDir1(String desDomiciDir1) {
        this.desDomiciDir1 = desDomiciDir1 == null ? null : desDomiciDir1.trim();
    }

    public String getDesUbigeoDir1() {
        return desUbigeoDir1;
    }

    public void setDesUbigeoDir1(String desUbigeoDir1) {
        this.desUbigeoDir1 = desUbigeoDir1 == null ? null : desUbigeoDir1.trim();
    }

    public String getIndReniec() {
        return indReniec;
    }

    public void setIndReniec(String indReniec) {
        this.indReniec = indReniec == null ? null : indReniec.trim();
    }

    public Date getFecInivinc() {
        return fecInivinc;
    }

    public void setFecInivinc(Date fecInivinc) {
        this.fecInivinc = fecInivinc;
    }

    public String getIndSubsidSepe() {
        return indSubsidSepe;
    }

    public void setIndSubsidSepe(String indSubsidSepe) {
        this.indSubsidSepe = indSubsidSepe == null ? null : indSubsidSepe.trim();
    }

    public String getIndDiscapacidad() {
        return indDiscapacidad;
    }

    public void setIndDiscapacidad(String indDiscapacidad) {
        this.indDiscapacidad = indDiscapacidad == null ? null : indDiscapacidad.trim();
    }

    public String getIndEstudiante() {
        return indEstudiante;
    }

    public void setIndEstudiante(String indEstudiante) {
        this.indEstudiante = indEstudiante == null ? null : indEstudiante.trim();
    }


	public String getDesVinFam() {
		return desVinFam;
	}

	public void setDesVinFam(String desVinFam) {
		this.desVinFam = desVinFam;
	}

	public String getDesSituFam() {
		return desSituFam;
	}

	public void setDesSituFam(String desSituFam) {
		this.desSituFam = desSituFam;
	}



	public String getDesIndEstado() {
		return desIndEstado;
	}

	public void setDesIndEstado(String desIndEstado) {
		this.desIndEstado = desIndEstado;
	}

	public List<Archivo> getArchivosReferDomicilio() {
		return archivosReferDomicilio;
	}

	public void setArchivosReferDomicilio(List<Archivo> archivosReferDomicilio) {
		this.archivosReferDomicilio = archivosReferDomicilio;
	}

	public List<Archivo> getArchivosAcredVinculo() {
		return archivosAcredVinculo;
	}

	public void setArchivosAcredVinculo(List<Archivo> archivosAcredVinculo) {
		this.archivosAcredVinculo = archivosAcredVinculo;
	}

	public List<Archivo> getArchivosBajaDerechohab() {
		return archivosBajaDerechohab;
	}

	public void setArchivosBajaDerechohab(List<Archivo> archivosBajaDerechohab) {
		this.archivosBajaDerechohab = archivosBajaDerechohab;
	}

	public List<Archivo> getArchivosSubsidSepelio() {
		return archivosSubsidSepelio;
	}

	public void setArchivosSubsidSepelio(List<Archivo> archivosSubsidSepelio) {
		this.archivosSubsidSepelio = archivosSubsidSepelio;
	}

	public String getIndReglSubsidSepe() {
		return indReglSubsidSepe;
	}

	public void setIndReglSubsidSepe(String indReglSubsidSepe) {
		this.indReglSubsidSepe = indReglSubsidSepe;
	}

	public List<Archivo> getArchivosDiscapacidad() {
		return archivosDiscapacidad;
	}

	public void setArchivosDiscapacidad(List<Archivo> archivosDiscapacidad) {
		this.archivosDiscapacidad = archivosDiscapacidad;
	}
    
}