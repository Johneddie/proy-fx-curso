package pe.gob.sunat.recurso2.humano.decljurada.model;

public class ArchivoRtpsWithBLOBs extends ArchivoRtps {
    private byte[] arcTrab;

    private byte[] arcDerhab;

    private byte[] arcTrabAlta;

    private byte[] arcTrabBaja;

    private byte[] arcTrabMod;

    private byte[] arcDerhabAlta;

    private byte[] arcDerhabBaja;

    public byte[] getArcTrab() {
        return arcTrab;
    }

    public void setArcTrab(byte[] arcTrab) {
        this.arcTrab = arcTrab;
    }

    public byte[] getArcDerhab() {
        return arcDerhab;
    }

    public void setArcDerhab(byte[] arcDerhab) {
        this.arcDerhab = arcDerhab;
    }

    public byte[] getArcTrabAlta() {
        return arcTrabAlta;
    }

    public void setArcTrabAlta(byte[] arcTrabAlta) {
        this.arcTrabAlta = arcTrabAlta;
    }

    public byte[] getArcTrabBaja() {
        return arcTrabBaja;
    }

    public void setArcTrabBaja(byte[] arcTrabBaja) {
        this.arcTrabBaja = arcTrabBaja;
    }

    public byte[] getArcTrabMod() {
        return arcTrabMod;
    }

    public void setArcTrabMod(byte[] arcTrabMod) {
        this.arcTrabMod = arcTrabMod;
    }

    public byte[] getArcDerhabAlta() {
        return arcDerhabAlta;
    }

    public void setArcDerhabAlta(byte[] arcDerhabAlta) {
        this.arcDerhabAlta = arcDerhabAlta;
    }

    public byte[] getArcDerhabBaja() {
        return arcDerhabBaja;
    }

    public void setArcDerhabBaja(byte[] arcDerhabBaja) {
        this.arcDerhabBaja = arcDerhabBaja;
    }
}