package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class PersonaRtpsExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public PersonaRtpsExample() {
        oredCriteria = new ArrayList<>();
    }

    protected PersonaRtpsExample(PersonaRtpsExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andNumDocidePnatIsNull() {
            addCriterion("num_docide_pnat is null");
            return this;
        }

        public Criteria andNumDocidePnatIsNotNull() {
            addCriterion("num_docide_pnat is not null");
            return this;
        }

        public Criteria andNumDocidePnatEqualTo(String value) {
            addCriterion("num_docide_pnat =", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatNotEqualTo(String value) {
            addCriterion("num_docide_pnat <>", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatGreaterThan(String value) {
            addCriterion("num_docide_pnat >", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatGreaterThanOrEqualTo(String value) {
            addCriterion("num_docide_pnat >=", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatLessThan(String value) {
            addCriterion("num_docide_pnat <", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatLessThanOrEqualTo(String value) {
            addCriterion("num_docide_pnat <=", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatLike(String value) {
            addCriterion("num_docide_pnat like", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatNotLike(String value) {
            addCriterion("num_docide_pnat not like", value, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatIn(List<String> values) {
            addCriterion("num_docide_pnat in", values, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatNotIn(List<String> values) {
            addCriterion("num_docide_pnat not in", values, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatBetween(String value1, String value2) {
            addCriterion("num_docide_pnat between", value1, value2, "numDocidePnat");
            return this;
        }

        public Criteria andNumDocidePnatNotBetween(String value1, String value2) {
            addCriterion("num_docide_pnat not between", value1, value2, "numDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatIsNull() {
            addCriterion("tip_docide_pnat is null");
            return this;
        }

        public Criteria andTipDocidePnatIsNotNull() {
            addCriterion("tip_docide_pnat is not null");
            return this;
        }

        public Criteria andTipDocidePnatEqualTo(String value) {
            addCriterion("tip_docide_pnat =", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatNotEqualTo(String value) {
            addCriterion("tip_docide_pnat <>", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatGreaterThan(String value) {
            addCriterion("tip_docide_pnat >", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatGreaterThanOrEqualTo(String value) {
            addCriterion("tip_docide_pnat >=", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatLessThan(String value) {
            addCriterion("tip_docide_pnat <", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatLessThanOrEqualTo(String value) {
            addCriterion("tip_docide_pnat <=", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatLike(String value) {
            addCriterion("tip_docide_pnat like", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatNotLike(String value) {
            addCriterion("tip_docide_pnat not like", value, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatIn(List<String> values) {
            addCriterion("tip_docide_pnat in", values, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatNotIn(List<String> values) {
            addCriterion("tip_docide_pnat not in", values, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatBetween(String value1, String value2) {
            addCriterion("tip_docide_pnat between", value1, value2, "tipDocidePnat");
            return this;
        }

        public Criteria andTipDocidePnatNotBetween(String value1, String value2) {
            addCriterion("tip_docide_pnat not between", value1, value2, "tipDocidePnat");
            return this;
        }

        public Criteria andDesApepatPnatIsNull() {
            addCriterion("des_apepat_pnat is null");
            return this;
        }

        public Criteria andDesApepatPnatIsNotNull() {
            addCriterion("des_apepat_pnat is not null");
            return this;
        }

        public Criteria andDesApepatPnatEqualTo(String value) {
            addCriterion("des_apepat_pnat =", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatNotEqualTo(String value) {
            addCriterion("des_apepat_pnat <>", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatGreaterThan(String value) {
            addCriterion("des_apepat_pnat >", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatGreaterThanOrEqualTo(String value) {
            addCriterion("des_apepat_pnat >=", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatLessThan(String value) {
            addCriterion("des_apepat_pnat <", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatLessThanOrEqualTo(String value) {
            addCriterion("des_apepat_pnat <=", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatLike(String value) {
            addCriterion("des_apepat_pnat like", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatNotLike(String value) {
            addCriterion("des_apepat_pnat not like", value, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatIn(List<String> values) {
            addCriterion("des_apepat_pnat in", values, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatNotIn(List<String> values) {
            addCriterion("des_apepat_pnat not in", values, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatBetween(String value1, String value2) {
            addCriterion("des_apepat_pnat between", value1, value2, "desApepatPnat");
            return this;
        }

        public Criteria andDesApepatPnatNotBetween(String value1, String value2) {
            addCriterion("des_apepat_pnat not between", value1, value2, "desApepatPnat");
            return this;
        }

        public Criteria andDesApematPnatIsNull() {
            addCriterion("des_apemat_pnat is null");
            return this;
        }

        public Criteria andDesApematPnatIsNotNull() {
            addCriterion("des_apemat_pnat is not null");
            return this;
        }

        public Criteria andDesApematPnatEqualTo(String value) {
            addCriterion("des_apemat_pnat =", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatNotEqualTo(String value) {
            addCriterion("des_apemat_pnat <>", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatGreaterThan(String value) {
            addCriterion("des_apemat_pnat >", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatGreaterThanOrEqualTo(String value) {
            addCriterion("des_apemat_pnat >=", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatLessThan(String value) {
            addCriterion("des_apemat_pnat <", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatLessThanOrEqualTo(String value) {
            addCriterion("des_apemat_pnat <=", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatLike(String value) {
            addCriterion("des_apemat_pnat like", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatNotLike(String value) {
            addCriterion("des_apemat_pnat not like", value, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatIn(List<String> values) {
            addCriterion("des_apemat_pnat in", values, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatNotIn(List<String> values) {
            addCriterion("des_apemat_pnat not in", values, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatBetween(String value1, String value2) {
            addCriterion("des_apemat_pnat between", value1, value2, "desApematPnat");
            return this;
        }

        public Criteria andDesApematPnatNotBetween(String value1, String value2) {
            addCriterion("des_apemat_pnat not between", value1, value2, "desApematPnat");
            return this;
        }

        public Criteria andDesNombrePnatIsNull() {
            addCriterion("des_nombre_pnat is null");
            return this;
        }

        public Criteria andDesNombrePnatIsNotNull() {
            addCriterion("des_nombre_pnat is not null");
            return this;
        }

        public Criteria andDesNombrePnatEqualTo(String value) {
            addCriterion("des_nombre_pnat =", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatNotEqualTo(String value) {
            addCriterion("des_nombre_pnat <>", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatGreaterThan(String value) {
            addCriterion("des_nombre_pnat >", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatGreaterThanOrEqualTo(String value) {
            addCriterion("des_nombre_pnat >=", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatLessThan(String value) {
            addCriterion("des_nombre_pnat <", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatLessThanOrEqualTo(String value) {
            addCriterion("des_nombre_pnat <=", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatLike(String value) {
            addCriterion("des_nombre_pnat like", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatNotLike(String value) {
            addCriterion("des_nombre_pnat not like", value, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatIn(List<String> values) {
            addCriterion("des_nombre_pnat in", values, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatNotIn(List<String> values) {
            addCriterion("des_nombre_pnat not in", values, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatBetween(String value1, String value2) {
            addCriterion("des_nombre_pnat between", value1, value2, "desNombrePnat");
            return this;
        }

        public Criteria andDesNombrePnatNotBetween(String value1, String value2) {
            addCriterion("des_nombre_pnat not between", value1, value2, "desNombrePnat");
            return this;
        }

        public Criteria andFecNacPnatIsNull() {
            addCriterion("fec_nac_pnat is null");
            return this;
        }

        public Criteria andFecNacPnatIsNotNull() {
            addCriterion("fec_nac_pnat is not null");
            return this;
        }

        public Criteria andFecNacPnatEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nac_pnat =", value, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nac_pnat <>", value, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_nac_pnat >", value, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nac_pnat >=", value, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatLessThan(Date value) {
            addCriterionForJDBCDate("fec_nac_pnat <", value, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nac_pnat <=", value, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nac_pnat in", values, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nac_pnat not in", values, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nac_pnat between", value1, value2, "fecNacPnat");
            return this;
        }

        public Criteria andFecNacPnatNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nac_pnat not between", value1, value2, "fecNacPnat");
            return this;
        }

        public Criteria andTipEstcivPnatIsNull() {
            addCriterion("tip_estciv_pnat is null");
            return this;
        }

        public Criteria andTipEstcivPnatIsNotNull() {
            addCriterion("tip_estciv_pnat is not null");
            return this;
        }

        public Criteria andTipEstcivPnatEqualTo(String value) {
            addCriterion("tip_estciv_pnat =", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatNotEqualTo(String value) {
            addCriterion("tip_estciv_pnat <>", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatGreaterThan(String value) {
            addCriterion("tip_estciv_pnat >", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatGreaterThanOrEqualTo(String value) {
            addCriterion("tip_estciv_pnat >=", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatLessThan(String value) {
            addCriterion("tip_estciv_pnat <", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatLessThanOrEqualTo(String value) {
            addCriterion("tip_estciv_pnat <=", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatLike(String value) {
            addCriterion("tip_estciv_pnat like", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatNotLike(String value) {
            addCriterion("tip_estciv_pnat not like", value, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatIn(List<String> values) {
            addCriterion("tip_estciv_pnat in", values, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatNotIn(List<String> values) {
            addCriterion("tip_estciv_pnat not in", values, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatBetween(String value1, String value2) {
            addCriterion("tip_estciv_pnat between", value1, value2, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipEstcivPnatNotBetween(String value1, String value2) {
            addCriterion("tip_estciv_pnat not between", value1, value2, "tipEstcivPnat");
            return this;
        }

        public Criteria andTipSexoPnatIsNull() {
            addCriterion("tip_sexo_pnat is null");
            return this;
        }

        public Criteria andTipSexoPnatIsNotNull() {
            addCriterion("tip_sexo_pnat is not null");
            return this;
        }

        public Criteria andTipSexoPnatEqualTo(String value) {
            addCriterion("tip_sexo_pnat =", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatNotEqualTo(String value) {
            addCriterion("tip_sexo_pnat <>", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatGreaterThan(String value) {
            addCriterion("tip_sexo_pnat >", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatGreaterThanOrEqualTo(String value) {
            addCriterion("tip_sexo_pnat >=", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatLessThan(String value) {
            addCriterion("tip_sexo_pnat <", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatLessThanOrEqualTo(String value) {
            addCriterion("tip_sexo_pnat <=", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatLike(String value) {
            addCriterion("tip_sexo_pnat like", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatNotLike(String value) {
            addCriterion("tip_sexo_pnat not like", value, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatIn(List<String> values) {
            addCriterion("tip_sexo_pnat in", values, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatNotIn(List<String> values) {
            addCriterion("tip_sexo_pnat not in", values, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatBetween(String value1, String value2) {
            addCriterion("tip_sexo_pnat between", value1, value2, "tipSexoPnat");
            return this;
        }

        public Criteria andTipSexoPnatNotBetween(String value1, String value2) {
            addCriterion("tip_sexo_pnat not between", value1, value2, "tipSexoPnat");
            return this;
        }

        public Criteria andDesDomiciPnatIsNull() {
            addCriterion("des_domici_pnat is null");
            return this;
        }

        public Criteria andDesDomiciPnatIsNotNull() {
            addCriterion("des_domici_pnat is not null");
            return this;
        }

        public Criteria andDesDomiciPnatEqualTo(String value) {
            addCriterion("des_domici_pnat =", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatNotEqualTo(String value) {
            addCriterion("des_domici_pnat <>", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatGreaterThan(String value) {
            addCriterion("des_domici_pnat >", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatGreaterThanOrEqualTo(String value) {
            addCriterion("des_domici_pnat >=", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatLessThan(String value) {
            addCriterion("des_domici_pnat <", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatLessThanOrEqualTo(String value) {
            addCriterion("des_domici_pnat <=", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatLike(String value) {
            addCriterion("des_domici_pnat like", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatNotLike(String value) {
            addCriterion("des_domici_pnat not like", value, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatIn(List<String> values) {
            addCriterion("des_domici_pnat in", values, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatNotIn(List<String> values) {
            addCriterion("des_domici_pnat not in", values, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatBetween(String value1, String value2) {
            addCriterion("des_domici_pnat between", value1, value2, "desDomiciPnat");
            return this;
        }

        public Criteria andDesDomiciPnatNotBetween(String value1, String value2) {
            addCriterion("des_domici_pnat not between", value1, value2, "desDomiciPnat");
            return this;
        }

        public Criteria andFecFallPnatIsNull() {
            addCriterion("fec_fall_pnat is null");
            return this;
        }

        public Criteria andFecFallPnatIsNotNull() {
            addCriterion("fec_fall_pnat is not null");
            return this;
        }

        public Criteria andFecFallPnatEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fall_pnat =", value, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fall_pnat <>", value, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_fall_pnat >", value, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fall_pnat >=", value, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatLessThan(Date value) {
            addCriterionForJDBCDate("fec_fall_pnat <", value, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_fall_pnat <=", value, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatIn(List<Date> values) {
            addCriterionForJDBCDate("fec_fall_pnat in", values, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_fall_pnat not in", values, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_fall_pnat between", value1, value2, "fecFallPnat");
            return this;
        }

        public Criteria andFecFallPnatNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_fall_pnat not between", value1, value2, "fecFallPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatIsNull() {
            addCriterion("cod_ubigeo_pnat is null");
            return this;
        }

        public Criteria andCodUbigeoPnatIsNotNull() {
            addCriterion("cod_ubigeo_pnat is not null");
            return this;
        }

        public Criteria andCodUbigeoPnatEqualTo(String value) {
            addCriterion("cod_ubigeo_pnat =", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatNotEqualTo(String value) {
            addCriterion("cod_ubigeo_pnat <>", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatGreaterThan(String value) {
            addCriterion("cod_ubigeo_pnat >", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_pnat >=", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatLessThan(String value) {
            addCriterion("cod_ubigeo_pnat <", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatLessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_pnat <=", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatLike(String value) {
            addCriterion("cod_ubigeo_pnat like", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatNotLike(String value) {
            addCriterion("cod_ubigeo_pnat not like", value, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatIn(List<String> values) {
            addCriterion("cod_ubigeo_pnat in", values, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatNotIn(List<String> values) {
            addCriterion("cod_ubigeo_pnat not in", values, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_pnat between", value1, value2, "codUbigeoPnat");
            return this;
        }

        public Criteria andCodUbigeoPnatNotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_pnat not between", value1, value2, "codUbigeoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatIsNull() {
            addCriterion("num_telefo_pnat is null");
            return this;
        }

        public Criteria andNumTelefoPnatIsNotNull() {
            addCriterion("num_telefo_pnat is not null");
            return this;
        }

        public Criteria andNumTelefoPnatEqualTo(String value) {
            addCriterion("num_telefo_pnat =", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatNotEqualTo(String value) {
            addCriterion("num_telefo_pnat <>", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatGreaterThan(String value) {
            addCriterion("num_telefo_pnat >", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatGreaterThanOrEqualTo(String value) {
            addCriterion("num_telefo_pnat >=", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatLessThan(String value) {
            addCriterion("num_telefo_pnat <", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatLessThanOrEqualTo(String value) {
            addCriterion("num_telefo_pnat <=", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatLike(String value) {
            addCriterion("num_telefo_pnat like", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatNotLike(String value) {
            addCriterion("num_telefo_pnat not like", value, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatIn(List<String> values) {
            addCriterion("num_telefo_pnat in", values, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatNotIn(List<String> values) {
            addCriterion("num_telefo_pnat not in", values, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatBetween(String value1, String value2) {
            addCriterion("num_telefo_pnat between", value1, value2, "numTelefoPnat");
            return this;
        }

        public Criteria andNumTelefoPnatNotBetween(String value1, String value2) {
            addCriterion("num_telefo_pnat not between", value1, value2, "numTelefoPnat");
            return this;
        }

        public Criteria andIndProcedPnatIsNull() {
            addCriterion("ind_proced_pnat is null");
            return this;
        }

        public Criteria andIndProcedPnatIsNotNull() {
            addCriterion("ind_proced_pnat is not null");
            return this;
        }

        public Criteria andIndProcedPnatEqualTo(String value) {
            addCriterion("ind_proced_pnat =", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatNotEqualTo(String value) {
            addCriterion("ind_proced_pnat <>", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatGreaterThan(String value) {
            addCriterion("ind_proced_pnat >", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatGreaterThanOrEqualTo(String value) {
            addCriterion("ind_proced_pnat >=", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatLessThan(String value) {
            addCriterion("ind_proced_pnat <", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatLessThanOrEqualTo(String value) {
            addCriterion("ind_proced_pnat <=", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatLike(String value) {
            addCriterion("ind_proced_pnat like", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatNotLike(String value) {
            addCriterion("ind_proced_pnat not like", value, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatIn(List<String> values) {
            addCriterion("ind_proced_pnat in", values, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatNotIn(List<String> values) {
            addCriterion("ind_proced_pnat not in", values, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatBetween(String value1, String value2) {
            addCriterion("ind_proced_pnat between", value1, value2, "indProcedPnat");
            return this;
        }

        public Criteria andIndProcedPnatNotBetween(String value1, String value2) {
            addCriterion("ind_proced_pnat not between", value1, value2, "indProcedPnat");
            return this;
        }

        public Criteria andFecActPnatIsNull() {
            addCriterion("fec_act_pnat is null");
            return this;
        }

        public Criteria andFecActPnatIsNotNull() {
            addCriterion("fec_act_pnat is not null");
            return this;
        }

        public Criteria andFecActPnatEqualTo(Date value) {
            addCriterionForJDBCDate("fec_act_pnat =", value, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_act_pnat <>", value, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_act_pnat >", value, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_act_pnat >=", value, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatLessThan(Date value) {
            addCriterionForJDBCDate("fec_act_pnat <", value, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_act_pnat <=", value, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatIn(List<Date> values) {
            addCriterionForJDBCDate("fec_act_pnat in", values, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_act_pnat not in", values, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_act_pnat between", value1, value2, "fecActPnat");
            return this;
        }

        public Criteria andFecActPnatNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_act_pnat not between", value1, value2, "fecActPnat");
            return this;
        }

        public Criteria andClaNombre1IsNull() {
            addCriterion("cla_nombre_1 is null");
            return this;
        }

        public Criteria andClaNombre1IsNotNull() {
            addCriterion("cla_nombre_1 is not null");
            return this;
        }

        public Criteria andClaNombre1EqualTo(String value) {
            addCriterion("cla_nombre_1 =", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1NotEqualTo(String value) {
            addCriterion("cla_nombre_1 <>", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1GreaterThan(String value) {
            addCriterion("cla_nombre_1 >", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1GreaterThanOrEqualTo(String value) {
            addCriterion("cla_nombre_1 >=", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1LessThan(String value) {
            addCriterion("cla_nombre_1 <", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1LessThanOrEqualTo(String value) {
            addCriterion("cla_nombre_1 <=", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1Like(String value) {
            addCriterion("cla_nombre_1 like", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1NotLike(String value) {
            addCriterion("cla_nombre_1 not like", value, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1In(List<String> values) {
            addCriterion("cla_nombre_1 in", values, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1NotIn(List<String> values) {
            addCriterion("cla_nombre_1 not in", values, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1Between(String value1, String value2) {
            addCriterion("cla_nombre_1 between", value1, value2, "claNombre1");
            return this;
        }

        public Criteria andClaNombre1NotBetween(String value1, String value2) {
            addCriterion("cla_nombre_1 not between", value1, value2, "claNombre1");
            return this;
        }

        public Criteria andClaNombre2IsNull() {
            addCriterion("cla_nombre_2 is null");
            return this;
        }

        public Criteria andClaNombre2IsNotNull() {
            addCriterion("cla_nombre_2 is not null");
            return this;
        }

        public Criteria andClaNombre2EqualTo(String value) {
            addCriterion("cla_nombre_2 =", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2NotEqualTo(String value) {
            addCriterion("cla_nombre_2 <>", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2GreaterThan(String value) {
            addCriterion("cla_nombre_2 >", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2GreaterThanOrEqualTo(String value) {
            addCriterion("cla_nombre_2 >=", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2LessThan(String value) {
            addCriterion("cla_nombre_2 <", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2LessThanOrEqualTo(String value) {
            addCriterion("cla_nombre_2 <=", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2Like(String value) {
            addCriterion("cla_nombre_2 like", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2NotLike(String value) {
            addCriterion("cla_nombre_2 not like", value, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2In(List<String> values) {
            addCriterion("cla_nombre_2 in", values, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2NotIn(List<String> values) {
            addCriterion("cla_nombre_2 not in", values, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2Between(String value1, String value2) {
            addCriterion("cla_nombre_2 between", value1, value2, "claNombre2");
            return this;
        }

        public Criteria andClaNombre2NotBetween(String value1, String value2) {
            addCriterion("cla_nombre_2 not between", value1, value2, "claNombre2");
            return this;
        }

        public Criteria andClaNombre3IsNull() {
            addCriterion("cla_nombre_3 is null");
            return this;
        }

        public Criteria andClaNombre3IsNotNull() {
            addCriterion("cla_nombre_3 is not null");
            return this;
        }

        public Criteria andClaNombre3EqualTo(String value) {
            addCriterion("cla_nombre_3 =", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3NotEqualTo(String value) {
            addCriterion("cla_nombre_3 <>", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3GreaterThan(String value) {
            addCriterion("cla_nombre_3 >", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3GreaterThanOrEqualTo(String value) {
            addCriterion("cla_nombre_3 >=", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3LessThan(String value) {
            addCriterion("cla_nombre_3 <", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3LessThanOrEqualTo(String value) {
            addCriterion("cla_nombre_3 <=", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3Like(String value) {
            addCriterion("cla_nombre_3 like", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3NotLike(String value) {
            addCriterion("cla_nombre_3 not like", value, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3In(List<String> values) {
            addCriterion("cla_nombre_3 in", values, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3NotIn(List<String> values) {
            addCriterion("cla_nombre_3 not in", values, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3Between(String value1, String value2) {
            addCriterion("cla_nombre_3 between", value1, value2, "claNombre3");
            return this;
        }

        public Criteria andClaNombre3NotBetween(String value1, String value2) {
            addCriterion("cla_nombre_3 not between", value1, value2, "claNombre3");
            return this;
        }

        public Criteria andClaNombre4IsNull() {
            addCriterion("cla_nombre_4 is null");
            return this;
        }

        public Criteria andClaNombre4IsNotNull() {
            addCriterion("cla_nombre_4 is not null");
            return this;
        }

        public Criteria andClaNombre4EqualTo(String value) {
            addCriterion("cla_nombre_4 =", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4NotEqualTo(String value) {
            addCriterion("cla_nombre_4 <>", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4GreaterThan(String value) {
            addCriterion("cla_nombre_4 >", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4GreaterThanOrEqualTo(String value) {
            addCriterion("cla_nombre_4 >=", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4LessThan(String value) {
            addCriterion("cla_nombre_4 <", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4LessThanOrEqualTo(String value) {
            addCriterion("cla_nombre_4 <=", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4Like(String value) {
            addCriterion("cla_nombre_4 like", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4NotLike(String value) {
            addCriterion("cla_nombre_4 not like", value, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4In(List<String> values) {
            addCriterion("cla_nombre_4 in", values, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4NotIn(List<String> values) {
            addCriterion("cla_nombre_4 not in", values, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4Between(String value1, String value2) {
            addCriterion("cla_nombre_4 between", value1, value2, "claNombre4");
            return this;
        }

        public Criteria andClaNombre4NotBetween(String value1, String value2) {
            addCriterion("cla_nombre_4 not between", value1, value2, "claNombre4");
            return this;
        }

        public Criteria andClaDirec1IsNull() {
            addCriterion("cla_direc_1 is null");
            return this;
        }

        public Criteria andClaDirec1IsNotNull() {
            addCriterion("cla_direc_1 is not null");
            return this;
        }

        public Criteria andClaDirec1EqualTo(String value) {
            addCriterion("cla_direc_1 =", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1NotEqualTo(String value) {
            addCriterion("cla_direc_1 <>", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1GreaterThan(String value) {
            addCriterion("cla_direc_1 >", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1GreaterThanOrEqualTo(String value) {
            addCriterion("cla_direc_1 >=", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1LessThan(String value) {
            addCriterion("cla_direc_1 <", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1LessThanOrEqualTo(String value) {
            addCriterion("cla_direc_1 <=", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1Like(String value) {
            addCriterion("cla_direc_1 like", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1NotLike(String value) {
            addCriterion("cla_direc_1 not like", value, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1In(List<String> values) {
            addCriterion("cla_direc_1 in", values, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1NotIn(List<String> values) {
            addCriterion("cla_direc_1 not in", values, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1Between(String value1, String value2) {
            addCriterion("cla_direc_1 between", value1, value2, "claDirec1");
            return this;
        }

        public Criteria andClaDirec1NotBetween(String value1, String value2) {
            addCriterion("cla_direc_1 not between", value1, value2, "claDirec1");
            return this;
        }

        public Criteria andClaDirec2IsNull() {
            addCriterion("cla_direc_2 is null");
            return this;
        }

        public Criteria andClaDirec2IsNotNull() {
            addCriterion("cla_direc_2 is not null");
            return this;
        }

        public Criteria andClaDirec2EqualTo(String value) {
            addCriterion("cla_direc_2 =", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2NotEqualTo(String value) {
            addCriterion("cla_direc_2 <>", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2GreaterThan(String value) {
            addCriterion("cla_direc_2 >", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2GreaterThanOrEqualTo(String value) {
            addCriterion("cla_direc_2 >=", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2LessThan(String value) {
            addCriterion("cla_direc_2 <", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2LessThanOrEqualTo(String value) {
            addCriterion("cla_direc_2 <=", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2Like(String value) {
            addCriterion("cla_direc_2 like", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2NotLike(String value) {
            addCriterion("cla_direc_2 not like", value, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2In(List<String> values) {
            addCriterion("cla_direc_2 in", values, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2NotIn(List<String> values) {
            addCriterion("cla_direc_2 not in", values, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2Between(String value1, String value2) {
            addCriterion("cla_direc_2 between", value1, value2, "claDirec2");
            return this;
        }

        public Criteria andClaDirec2NotBetween(String value1, String value2) {
            addCriterion("cla_direc_2 not between", value1, value2, "claDirec2");
            return this;
        }

        public Criteria andClaDirec3IsNull() {
            addCriterion("cla_direc_3 is null");
            return this;
        }

        public Criteria andClaDirec3IsNotNull() {
            addCriterion("cla_direc_3 is not null");
            return this;
        }

        public Criteria andClaDirec3EqualTo(String value) {
            addCriterion("cla_direc_3 =", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3NotEqualTo(String value) {
            addCriterion("cla_direc_3 <>", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3GreaterThan(String value) {
            addCriterion("cla_direc_3 >", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3GreaterThanOrEqualTo(String value) {
            addCriterion("cla_direc_3 >=", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3LessThan(String value) {
            addCriterion("cla_direc_3 <", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3LessThanOrEqualTo(String value) {
            addCriterion("cla_direc_3 <=", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3Like(String value) {
            addCriterion("cla_direc_3 like", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3NotLike(String value) {
            addCriterion("cla_direc_3 not like", value, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3In(List<String> values) {
            addCriterion("cla_direc_3 in", values, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3NotIn(List<String> values) {
            addCriterion("cla_direc_3 not in", values, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3Between(String value1, String value2) {
            addCriterion("cla_direc_3 between", value1, value2, "claDirec3");
            return this;
        }

        public Criteria andClaDirec3NotBetween(String value1, String value2) {
            addCriterion("cla_direc_3 not between", value1, value2, "claDirec3");
            return this;
        }

        public Criteria andNumPaqActualizaIsNull() {
            addCriterion("num_paq_actualiza is null");
            return this;
        }

        public Criteria andNumPaqActualizaIsNotNull() {
            addCriterion("num_paq_actualiza is not null");
            return this;
        }

        public Criteria andNumPaqActualizaEqualTo(String value) {
            addCriterion("num_paq_actualiza =", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaNotEqualTo(String value) {
            addCriterion("num_paq_actualiza <>", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaGreaterThan(String value) {
            addCriterion("num_paq_actualiza >", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaGreaterThanOrEqualTo(String value) {
            addCriterion("num_paq_actualiza >=", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaLessThan(String value) {
            addCriterion("num_paq_actualiza <", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaLessThanOrEqualTo(String value) {
            addCriterion("num_paq_actualiza <=", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaLike(String value) {
            addCriterion("num_paq_actualiza like", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaNotLike(String value) {
            addCriterion("num_paq_actualiza not like", value, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaIn(List<String> values) {
            addCriterion("num_paq_actualiza in", values, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaNotIn(List<String> values) {
            addCriterion("num_paq_actualiza not in", values, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaBetween(String value1, String value2) {
            addCriterion("num_paq_actualiza between", value1, value2, "numPaqActualiza");
            return this;
        }

        public Criteria andNumPaqActualizaNotBetween(String value1, String value2) {
            addCriterion("num_paq_actualiza not between", value1, value2, "numPaqActualiza");
            return this;
        }

        public Criteria andIndNovedadIsNull() {
            addCriterion("ind_novedad is null");
            return this;
        }

        public Criteria andIndNovedadIsNotNull() {
            addCriterion("ind_novedad is not null");
            return this;
        }

        public Criteria andIndNovedadEqualTo(String value) {
            addCriterion("ind_novedad =", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadNotEqualTo(String value) {
            addCriterion("ind_novedad <>", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadGreaterThan(String value) {
            addCriterion("ind_novedad >", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadGreaterThanOrEqualTo(String value) {
            addCriterion("ind_novedad >=", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadLessThan(String value) {
            addCriterion("ind_novedad <", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadLessThanOrEqualTo(String value) {
            addCriterion("ind_novedad <=", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadLike(String value) {
            addCriterion("ind_novedad like", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadNotLike(String value) {
            addCriterion("ind_novedad not like", value, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadIn(List<String> values) {
            addCriterion("ind_novedad in", values, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadNotIn(List<String> values) {
            addCriterion("ind_novedad not in", values, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadBetween(String value1, String value2) {
            addCriterion("ind_novedad between", value1, value2, "indNovedad");
            return this;
        }

        public Criteria andIndNovedadNotBetween(String value1, String value2) {
            addCriterion("ind_novedad not between", value1, value2, "indNovedad");
            return this;
        }

        public Criteria andCodUsernaIsNull() {
            addCriterion("cod_userna is null");
            return this;
        }

        public Criteria andCodUsernaIsNotNull() {
            addCriterion("cod_userna is not null");
            return this;
        }

        public Criteria andCodUsernaEqualTo(String value) {
            addCriterion("cod_userna =", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaNotEqualTo(String value) {
            addCriterion("cod_userna <>", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaGreaterThan(String value) {
            addCriterion("cod_userna >", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_userna >=", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaLessThan(String value) {
            addCriterion("cod_userna <", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaLessThanOrEqualTo(String value) {
            addCriterion("cod_userna <=", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaLike(String value) {
            addCriterion("cod_userna like", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaNotLike(String value) {
            addCriterion("cod_userna not like", value, "codUserna");
            return this;
        }

        public Criteria andCodUsernaIn(List<String> values) {
            addCriterion("cod_userna in", values, "codUserna");
            return this;
        }

        public Criteria andCodUsernaNotIn(List<String> values) {
            addCriterion("cod_userna not in", values, "codUserna");
            return this;
        }

        public Criteria andCodUsernaBetween(String value1, String value2) {
            addCriterion("cod_userna between", value1, value2, "codUserna");
            return this;
        }

        public Criteria andCodUsernaNotBetween(String value1, String value2) {
            addCriterion("cod_userna not between", value1, value2, "codUserna");
            return this;
        }

        public Criteria andFecActIsNull() {
            addCriterion("fec_act is null");
            return this;
        }

        public Criteria andFecActIsNotNull() {
            addCriterion("fec_act is not null");
            return this;
        }

        public Criteria andFecActEqualTo(Date value) {
            addCriterion("fec_act =", value, "fecAct");
            return this;
        }

        public Criteria andFecActNotEqualTo(Date value) {
            addCriterion("fec_act <>", value, "fecAct");
            return this;
        }

        public Criteria andFecActGreaterThan(Date value) {
            addCriterion("fec_act >", value, "fecAct");
            return this;
        }

        public Criteria andFecActGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_act >=", value, "fecAct");
            return this;
        }

        public Criteria andFecActLessThan(Date value) {
            addCriterion("fec_act <", value, "fecAct");
            return this;
        }

        public Criteria andFecActLessThanOrEqualTo(Date value) {
            addCriterion("fec_act <=", value, "fecAct");
            return this;
        }

        public Criteria andFecActIn(List<Date> values) {
            addCriterion("fec_act in", values, "fecAct");
            return this;
        }

        public Criteria andFecActNotIn(List<Date> values) {
            addCriterion("fec_act not in", values, "fecAct");
            return this;
        }

        public Criteria andFecActBetween(Date value1, Date value2) {
            addCriterion("fec_act between", value1, value2, "fecAct");
            return this;
        }

        public Criteria andFecActNotBetween(Date value1, Date value2) {
            addCriterion("fec_act not between", value1, value2, "fecAct");
            return this;
        }

        public Criteria andIndVerificaIsNull() {
            addCriterion("ind_verifica is null");
            return this;
        }

        public Criteria andIndVerificaIsNotNull() {
            addCriterion("ind_verifica is not null");
            return this;
        }

        public Criteria andIndVerificaEqualTo(String value) {
            addCriterion("ind_verifica =", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaNotEqualTo(String value) {
            addCriterion("ind_verifica <>", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaGreaterThan(String value) {
            addCriterion("ind_verifica >", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_verifica >=", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaLessThan(String value) {
            addCriterion("ind_verifica <", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaLessThanOrEqualTo(String value) {
            addCriterion("ind_verifica <=", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaLike(String value) {
            addCriterion("ind_verifica like", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaNotLike(String value) {
            addCriterion("ind_verifica not like", value, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaIn(List<String> values) {
            addCriterion("ind_verifica in", values, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaNotIn(List<String> values) {
            addCriterion("ind_verifica not in", values, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaBetween(String value1, String value2) {
            addCriterion("ind_verifica between", value1, value2, "indVerifica");
            return this;
        }

        public Criteria andIndVerificaNotBetween(String value1, String value2) {
            addCriterion("ind_verifica not between", value1, value2, "indVerifica");
            return this;
        }

        public Criteria andDesApeCasadaIsNull() {
            addCriterion("des_ape_casada is null");
            return this;
        }

        public Criteria andDesApeCasadaIsNotNull() {
            addCriterion("des_ape_casada is not null");
            return this;
        }

        public Criteria andDesApeCasadaEqualTo(String value) {
            addCriterion("des_ape_casada =", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaNotEqualTo(String value) {
            addCriterion("des_ape_casada <>", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaGreaterThan(String value) {
            addCriterion("des_ape_casada >", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaGreaterThanOrEqualTo(String value) {
            addCriterion("des_ape_casada >=", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaLessThan(String value) {
            addCriterion("des_ape_casada <", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaLessThanOrEqualTo(String value) {
            addCriterion("des_ape_casada <=", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaLike(String value) {
            addCriterion("des_ape_casada like", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaNotLike(String value) {
            addCriterion("des_ape_casada not like", value, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaIn(List<String> values) {
            addCriterion("des_ape_casada in", values, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaNotIn(List<String> values) {
            addCriterion("des_ape_casada not in", values, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaBetween(String value1, String value2) {
            addCriterion("des_ape_casada between", value1, value2, "desApeCasada");
            return this;
        }

        public Criteria andDesApeCasadaNotBetween(String value1, String value2) {
            addCriterion("des_ape_casada not between", value1, value2, "desApeCasada");
            return this;
        }

        public Criteria andIndInstruccionIsNull() {
            addCriterion("ind_instruccion is null");
            return this;
        }

        public Criteria andIndInstruccionIsNotNull() {
            addCriterion("ind_instruccion is not null");
            return this;
        }

        public Criteria andIndInstruccionEqualTo(String value) {
            addCriterion("ind_instruccion =", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionNotEqualTo(String value) {
            addCriterion("ind_instruccion <>", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionGreaterThan(String value) {
            addCriterion("ind_instruccion >", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionGreaterThanOrEqualTo(String value) {
            addCriterion("ind_instruccion >=", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionLessThan(String value) {
            addCriterion("ind_instruccion <", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionLessThanOrEqualTo(String value) {
            addCriterion("ind_instruccion <=", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionLike(String value) {
            addCriterion("ind_instruccion like", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionNotLike(String value) {
            addCriterion("ind_instruccion not like", value, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionIn(List<String> values) {
            addCriterion("ind_instruccion in", values, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionNotIn(List<String> values) {
            addCriterion("ind_instruccion not in", values, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionBetween(String value1, String value2) {
            addCriterion("ind_instruccion between", value1, value2, "indInstruccion");
            return this;
        }

        public Criteria andIndInstruccionNotBetween(String value1, String value2) {
            addCriterion("ind_instruccion not between", value1, value2, "indInstruccion");
            return this;
        }

        public Criteria andCodUbigeoDomIsNull() {
            addCriterion("cod_ubigeo_dom is null");
            return this;
        }

        public Criteria andCodUbigeoDomIsNotNull() {
            addCriterion("cod_ubigeo_dom is not null");
            return this;
        }

        public Criteria andCodUbigeoDomEqualTo(String value) {
            addCriterion("cod_ubigeo_dom =", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomNotEqualTo(String value) {
            addCriterion("cod_ubigeo_dom <>", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomGreaterThan(String value) {
            addCriterion("cod_ubigeo_dom >", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dom >=", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomLessThan(String value) {
            addCriterion("cod_ubigeo_dom <", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomLessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dom <=", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomLike(String value) {
            addCriterion("cod_ubigeo_dom like", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomNotLike(String value) {
            addCriterion("cod_ubigeo_dom not like", value, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomIn(List<String> values) {
            addCriterion("cod_ubigeo_dom in", values, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomNotIn(List<String> values) {
            addCriterion("cod_ubigeo_dom not in", values, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dom between", value1, value2, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoDomNotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dom not between", value1, value2, "codUbigeoDom");
            return this;
        }

        public Criteria andCodUbigeoNacIsNull() {
            addCriterion("cod_ubigeo_nac is null");
            return this;
        }

        public Criteria andCodUbigeoNacIsNotNull() {
            addCriterion("cod_ubigeo_nac is not null");
            return this;
        }

        public Criteria andCodUbigeoNacEqualTo(String value) {
            addCriterion("cod_ubigeo_nac =", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotEqualTo(String value) {
            addCriterion("cod_ubigeo_nac <>", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacGreaterThan(String value) {
            addCriterion("cod_ubigeo_nac >", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_nac >=", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacLessThan(String value) {
            addCriterion("cod_ubigeo_nac <", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacLessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_nac <=", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacLike(String value) {
            addCriterion("cod_ubigeo_nac like", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotLike(String value) {
            addCriterion("cod_ubigeo_nac not like", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacIn(List<String> values) {
            addCriterion("cod_ubigeo_nac in", values, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotIn(List<String> values) {
            addCriterion("cod_ubigeo_nac not in", values, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_nac between", value1, value2, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_nac not between", value1, value2, "codUbigeoNac");
            return this;
        }

        public Criteria andCodDocidePadreIsNull() {
            addCriterion("cod_docide_padre is null");
            return this;
        }

        public Criteria andCodDocidePadreIsNotNull() {
            addCriterion("cod_docide_padre is not null");
            return this;
        }

        public Criteria andCodDocidePadreEqualTo(String value) {
            addCriterion("cod_docide_padre =", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreNotEqualTo(String value) {
            addCriterion("cod_docide_padre <>", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreGreaterThan(String value) {
            addCriterion("cod_docide_padre >", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docide_padre >=", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreLessThan(String value) {
            addCriterion("cod_docide_padre <", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreLessThanOrEqualTo(String value) {
            addCriterion("cod_docide_padre <=", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreLike(String value) {
            addCriterion("cod_docide_padre like", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreNotLike(String value) {
            addCriterion("cod_docide_padre not like", value, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreIn(List<String> values) {
            addCriterion("cod_docide_padre in", values, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreNotIn(List<String> values) {
            addCriterion("cod_docide_padre not in", values, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreBetween(String value1, String value2) {
            addCriterion("cod_docide_padre between", value1, value2, "codDocidePadre");
            return this;
        }

        public Criteria andCodDocidePadreNotBetween(String value1, String value2) {
            addCriterion("cod_docide_padre not between", value1, value2, "codDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreIsNull() {
            addCriterion("num_docide_padre is null");
            return this;
        }

        public Criteria andNumDocidePadreIsNotNull() {
            addCriterion("num_docide_padre is not null");
            return this;
        }

        public Criteria andNumDocidePadreEqualTo(String value) {
            addCriterion("num_docide_padre =", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreNotEqualTo(String value) {
            addCriterion("num_docide_padre <>", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreGreaterThan(String value) {
            addCriterion("num_docide_padre >", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreGreaterThanOrEqualTo(String value) {
            addCriterion("num_docide_padre >=", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreLessThan(String value) {
            addCriterion("num_docide_padre <", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreLessThanOrEqualTo(String value) {
            addCriterion("num_docide_padre <=", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreLike(String value) {
            addCriterion("num_docide_padre like", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreNotLike(String value) {
            addCriterion("num_docide_padre not like", value, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreIn(List<String> values) {
            addCriterion("num_docide_padre in", values, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreNotIn(List<String> values) {
            addCriterion("num_docide_padre not in", values, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreBetween(String value1, String value2) {
            addCriterion("num_docide_padre between", value1, value2, "numDocidePadre");
            return this;
        }

        public Criteria andNumDocidePadreNotBetween(String value1, String value2) {
            addCriterion("num_docide_padre not between", value1, value2, "numDocidePadre");
            return this;
        }

        public Criteria andDesNombrePadreIsNull() {
            addCriterion("des_nombre_padre is null");
            return this;
        }

        public Criteria andDesNombrePadreIsNotNull() {
            addCriterion("des_nombre_padre is not null");
            return this;
        }

        public Criteria andDesNombrePadreEqualTo(String value) {
            addCriterion("des_nombre_padre =", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreNotEqualTo(String value) {
            addCriterion("des_nombre_padre <>", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreGreaterThan(String value) {
            addCriterion("des_nombre_padre >", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreGreaterThanOrEqualTo(String value) {
            addCriterion("des_nombre_padre >=", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreLessThan(String value) {
            addCriterion("des_nombre_padre <", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreLessThanOrEqualTo(String value) {
            addCriterion("des_nombre_padre <=", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreLike(String value) {
            addCriterion("des_nombre_padre like", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreNotLike(String value) {
            addCriterion("des_nombre_padre not like", value, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreIn(List<String> values) {
            addCriterion("des_nombre_padre in", values, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreNotIn(List<String> values) {
            addCriterion("des_nombre_padre not in", values, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreBetween(String value1, String value2) {
            addCriterion("des_nombre_padre between", value1, value2, "desNombrePadre");
            return this;
        }

        public Criteria andDesNombrePadreNotBetween(String value1, String value2) {
            addCriterion("des_nombre_padre not between", value1, value2, "desNombrePadre");
            return this;
        }

        public Criteria andCodDocideMadreIsNull() {
            addCriterion("cod_docide_madre is null");
            return this;
        }

        public Criteria andCodDocideMadreIsNotNull() {
            addCriterion("cod_docide_madre is not null");
            return this;
        }

        public Criteria andCodDocideMadreEqualTo(String value) {
            addCriterion("cod_docide_madre =", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreNotEqualTo(String value) {
            addCriterion("cod_docide_madre <>", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreGreaterThan(String value) {
            addCriterion("cod_docide_madre >", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docide_madre >=", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreLessThan(String value) {
            addCriterion("cod_docide_madre <", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreLessThanOrEqualTo(String value) {
            addCriterion("cod_docide_madre <=", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreLike(String value) {
            addCriterion("cod_docide_madre like", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreNotLike(String value) {
            addCriterion("cod_docide_madre not like", value, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreIn(List<String> values) {
            addCriterion("cod_docide_madre in", values, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreNotIn(List<String> values) {
            addCriterion("cod_docide_madre not in", values, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreBetween(String value1, String value2) {
            addCriterion("cod_docide_madre between", value1, value2, "codDocideMadre");
            return this;
        }

        public Criteria andCodDocideMadreNotBetween(String value1, String value2) {
            addCriterion("cod_docide_madre not between", value1, value2, "codDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreIsNull() {
            addCriterion("num_docide_madre is null");
            return this;
        }

        public Criteria andNumDocideMadreIsNotNull() {
            addCriterion("num_docide_madre is not null");
            return this;
        }

        public Criteria andNumDocideMadreEqualTo(String value) {
            addCriterion("num_docide_madre =", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreNotEqualTo(String value) {
            addCriterion("num_docide_madre <>", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreGreaterThan(String value) {
            addCriterion("num_docide_madre >", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreGreaterThanOrEqualTo(String value) {
            addCriterion("num_docide_madre >=", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreLessThan(String value) {
            addCriterion("num_docide_madre <", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreLessThanOrEqualTo(String value) {
            addCriterion("num_docide_madre <=", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreLike(String value) {
            addCriterion("num_docide_madre like", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreNotLike(String value) {
            addCriterion("num_docide_madre not like", value, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreIn(List<String> values) {
            addCriterion("num_docide_madre in", values, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreNotIn(List<String> values) {
            addCriterion("num_docide_madre not in", values, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreBetween(String value1, String value2) {
            addCriterion("num_docide_madre between", value1, value2, "numDocideMadre");
            return this;
        }

        public Criteria andNumDocideMadreNotBetween(String value1, String value2) {
            addCriterion("num_docide_madre not between", value1, value2, "numDocideMadre");
            return this;
        }

        public Criteria andDesNombreMadreIsNull() {
            addCriterion("des_nombre_madre is null");
            return this;
        }

        public Criteria andDesNombreMadreIsNotNull() {
            addCriterion("des_nombre_madre is not null");
            return this;
        }

        public Criteria andDesNombreMadreEqualTo(String value) {
            addCriterion("des_nombre_madre =", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreNotEqualTo(String value) {
            addCriterion("des_nombre_madre <>", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreGreaterThan(String value) {
            addCriterion("des_nombre_madre >", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreGreaterThanOrEqualTo(String value) {
            addCriterion("des_nombre_madre >=", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreLessThan(String value) {
            addCriterion("des_nombre_madre <", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreLessThanOrEqualTo(String value) {
            addCriterion("des_nombre_madre <=", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreLike(String value) {
            addCriterion("des_nombre_madre like", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreNotLike(String value) {
            addCriterion("des_nombre_madre not like", value, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreIn(List<String> values) {
            addCriterion("des_nombre_madre in", values, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreNotIn(List<String> values) {
            addCriterion("des_nombre_madre not in", values, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreBetween(String value1, String value2) {
            addCriterion("des_nombre_madre between", value1, value2, "desNombreMadre");
            return this;
        }

        public Criteria andDesNombreMadreNotBetween(String value1, String value2) {
            addCriterion("des_nombre_madre not between", value1, value2, "desNombreMadre");
            return this;
        }

        public Criteria andFecInscripcionIsNull() {
            addCriterion("fec_inscripcion is null");
            return this;
        }

        public Criteria andFecInscripcionIsNotNull() {
            addCriterion("fec_inscripcion is not null");
            return this;
        }

        public Criteria andFecInscripcionEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inscripcion =", value, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inscripcion <>", value, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_inscripcion >", value, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inscripcion >=", value, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionLessThan(Date value) {
            addCriterionForJDBCDate("fec_inscripcion <", value, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inscripcion <=", value, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionIn(List<Date> values) {
            addCriterionForJDBCDate("fec_inscripcion in", values, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_inscripcion not in", values, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_inscripcion between", value1, value2, "fecInscripcion");
            return this;
        }

        public Criteria andFecInscripcionNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_inscripcion not between", value1, value2, "fecInscripcion");
            return this;
        }

        public Criteria andFecExpedicionIsNull() {
            addCriterion("fec_expedicion is null");
            return this;
        }

        public Criteria andFecExpedicionIsNotNull() {
            addCriterion("fec_expedicion is not null");
            return this;
        }

        public Criteria andFecExpedicionEqualTo(Date value) {
            addCriterionForJDBCDate("fec_expedicion =", value, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_expedicion <>", value, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_expedicion >", value, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_expedicion >=", value, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionLessThan(Date value) {
            addCriterionForJDBCDate("fec_expedicion <", value, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_expedicion <=", value, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionIn(List<Date> values) {
            addCriterionForJDBCDate("fec_expedicion in", values, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_expedicion not in", values, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_expedicion between", value1, value2, "fecExpedicion");
            return this;
        }

        public Criteria andFecExpedicionNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_expedicion not between", value1, value2, "fecExpedicion");
            return this;
        }

        public Criteria andIndVotacionIsNull() {
            addCriterion("ind_votacion is null");
            return this;
        }

        public Criteria andIndVotacionIsNotNull() {
            addCriterion("ind_votacion is not null");
            return this;
        }

        public Criteria andIndVotacionEqualTo(String value) {
            addCriterion("ind_votacion =", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionNotEqualTo(String value) {
            addCriterion("ind_votacion <>", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionGreaterThan(String value) {
            addCriterion("ind_votacion >", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionGreaterThanOrEqualTo(String value) {
            addCriterion("ind_votacion >=", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionLessThan(String value) {
            addCriterion("ind_votacion <", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionLessThanOrEqualTo(String value) {
            addCriterion("ind_votacion <=", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionLike(String value) {
            addCriterion("ind_votacion like", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionNotLike(String value) {
            addCriterion("ind_votacion not like", value, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionIn(List<String> values) {
            addCriterion("ind_votacion in", values, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionNotIn(List<String> values) {
            addCriterion("ind_votacion not in", values, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionBetween(String value1, String value2) {
            addCriterion("ind_votacion between", value1, value2, "indVotacion");
            return this;
        }

        public Criteria andIndVotacionNotBetween(String value1, String value2) {
            addCriterion("ind_votacion not between", value1, value2, "indVotacion");
            return this;
        }

        public Criteria andIndRestriccionIsNull() {
            addCriterion("ind_restriccion is null");
            return this;
        }

        public Criteria andIndRestriccionIsNotNull() {
            addCriterion("ind_restriccion is not null");
            return this;
        }

        public Criteria andIndRestriccionEqualTo(String value) {
            addCriterion("ind_restriccion =", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionNotEqualTo(String value) {
            addCriterion("ind_restriccion <>", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionGreaterThan(String value) {
            addCriterion("ind_restriccion >", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionGreaterThanOrEqualTo(String value) {
            addCriterion("ind_restriccion >=", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionLessThan(String value) {
            addCriterion("ind_restriccion <", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionLessThanOrEqualTo(String value) {
            addCriterion("ind_restriccion <=", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionLike(String value) {
            addCriterion("ind_restriccion like", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionNotLike(String value) {
            addCriterion("ind_restriccion not like", value, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionIn(List<String> values) {
            addCriterion("ind_restriccion in", values, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionNotIn(List<String> values) {
            addCriterion("ind_restriccion not in", values, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionBetween(String value1, String value2) {
            addCriterion("ind_restriccion between", value1, value2, "indRestriccion");
            return this;
        }

        public Criteria andIndRestriccionNotBetween(String value1, String value2) {
            addCriterion("ind_restriccion not between", value1, value2, "indRestriccion");
            return this;
        }

        public Criteria andFecCaducidadIsNull() {
            addCriterion("fec_caducidad is null");
            return this;
        }

        public Criteria andFecCaducidadIsNotNull() {
            addCriterion("fec_caducidad is not null");
            return this;
        }

        public Criteria andFecCaducidadEqualTo(Date value) {
            addCriterionForJDBCDate("fec_caducidad =", value, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_caducidad <>", value, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_caducidad >", value, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_caducidad >=", value, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadLessThan(Date value) {
            addCriterionForJDBCDate("fec_caducidad <", value, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_caducidad <=", value, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadIn(List<Date> values) {
            addCriterionForJDBCDate("fec_caducidad in", values, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_caducidad not in", values, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_caducidad between", value1, value2, "fecCaducidad");
            return this;
        }

        public Criteria andFecCaducidadNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_caducidad not between", value1, value2, "fecCaducidad");
            return this;
        }

        public Criteria andCodViaIsNull() {
            addCriterion("cod_via is null");
            return this;
        }

        public Criteria andCodViaIsNotNull() {
            addCriterion("cod_via is not null");
            return this;
        }

        public Criteria andCodViaEqualTo(String value) {
            addCriterion("cod_via =", value, "codVia");
            return this;
        }

        public Criteria andCodViaNotEqualTo(String value) {
            addCriterion("cod_via <>", value, "codVia");
            return this;
        }

        public Criteria andCodViaGreaterThan(String value) {
            addCriterion("cod_via >", value, "codVia");
            return this;
        }

        public Criteria andCodViaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_via >=", value, "codVia");
            return this;
        }

        public Criteria andCodViaLessThan(String value) {
            addCriterion("cod_via <", value, "codVia");
            return this;
        }

        public Criteria andCodViaLessThanOrEqualTo(String value) {
            addCriterion("cod_via <=", value, "codVia");
            return this;
        }

        public Criteria andCodViaLike(String value) {
            addCriterion("cod_via like", value, "codVia");
            return this;
        }

        public Criteria andCodViaNotLike(String value) {
            addCriterion("cod_via not like", value, "codVia");
            return this;
        }

        public Criteria andCodViaIn(List<String> values) {
            addCriterion("cod_via in", values, "codVia");
            return this;
        }

        public Criteria andCodViaNotIn(List<String> values) {
            addCriterion("cod_via not in", values, "codVia");
            return this;
        }

        public Criteria andCodViaBetween(String value1, String value2) {
            addCriterion("cod_via between", value1, value2, "codVia");
            return this;
        }

        public Criteria andCodViaNotBetween(String value1, String value2) {
            addCriterion("cod_via not between", value1, value2, "codVia");
            return this;
        }

        public Criteria andDesViaIsNull() {
            addCriterion("des_via is null");
            return this;
        }

        public Criteria andDesViaIsNotNull() {
            addCriterion("des_via is not null");
            return this;
        }

        public Criteria andDesViaEqualTo(String value) {
            addCriterion("des_via =", value, "desVia");
            return this;
        }

        public Criteria andDesViaNotEqualTo(String value) {
            addCriterion("des_via <>", value, "desVia");
            return this;
        }

        public Criteria andDesViaGreaterThan(String value) {
            addCriterion("des_via >", value, "desVia");
            return this;
        }

        public Criteria andDesViaGreaterThanOrEqualTo(String value) {
            addCriterion("des_via >=", value, "desVia");
            return this;
        }

        public Criteria andDesViaLessThan(String value) {
            addCriterion("des_via <", value, "desVia");
            return this;
        }

        public Criteria andDesViaLessThanOrEqualTo(String value) {
            addCriterion("des_via <=", value, "desVia");
            return this;
        }

        public Criteria andDesViaLike(String value) {
            addCriterion("des_via like", value, "desVia");
            return this;
        }

        public Criteria andDesViaNotLike(String value) {
            addCriterion("des_via not like", value, "desVia");
            return this;
        }

        public Criteria andDesViaIn(List<String> values) {
            addCriterion("des_via in", values, "desVia");
            return this;
        }

        public Criteria andDesViaNotIn(List<String> values) {
            addCriterion("des_via not in", values, "desVia");
            return this;
        }

        public Criteria andDesViaBetween(String value1, String value2) {
            addCriterion("des_via between", value1, value2, "desVia");
            return this;
        }

        public Criteria andDesViaNotBetween(String value1, String value2) {
            addCriterion("des_via not between", value1, value2, "desVia");
            return this;
        }

        public Criteria andNumViaIsNull() {
            addCriterion("num_via is null");
            return this;
        }

        public Criteria andNumViaIsNotNull() {
            addCriterion("num_via is not null");
            return this;
        }

        public Criteria andNumViaEqualTo(String value) {
            addCriterion("num_via =", value, "numVia");
            return this;
        }

        public Criteria andNumViaNotEqualTo(String value) {
            addCriterion("num_via <>", value, "numVia");
            return this;
        }

        public Criteria andNumViaGreaterThan(String value) {
            addCriterion("num_via >", value, "numVia");
            return this;
        }

        public Criteria andNumViaGreaterThanOrEqualTo(String value) {
            addCriterion("num_via >=", value, "numVia");
            return this;
        }

        public Criteria andNumViaLessThan(String value) {
            addCriterion("num_via <", value, "numVia");
            return this;
        }

        public Criteria andNumViaLessThanOrEqualTo(String value) {
            addCriterion("num_via <=", value, "numVia");
            return this;
        }

        public Criteria andNumViaLike(String value) {
            addCriterion("num_via like", value, "numVia");
            return this;
        }

        public Criteria andNumViaNotLike(String value) {
            addCriterion("num_via not like", value, "numVia");
            return this;
        }

        public Criteria andNumViaIn(List<String> values) {
            addCriterion("num_via in", values, "numVia");
            return this;
        }

        public Criteria andNumViaNotIn(List<String> values) {
            addCriterion("num_via not in", values, "numVia");
            return this;
        }

        public Criteria andNumViaBetween(String value1, String value2) {
            addCriterion("num_via between", value1, value2, "numVia");
            return this;
        }

        public Criteria andNumViaNotBetween(String value1, String value2) {
            addCriterion("num_via not between", value1, value2, "numVia");
            return this;
        }

        public Criteria andNumBlockIsNull() {
            addCriterion("num_block is null");
            return this;
        }

        public Criteria andNumBlockIsNotNull() {
            addCriterion("num_block is not null");
            return this;
        }

        public Criteria andNumBlockEqualTo(String value) {
            addCriterion("num_block =", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockNotEqualTo(String value) {
            addCriterion("num_block <>", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockGreaterThan(String value) {
            addCriterion("num_block >", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockGreaterThanOrEqualTo(String value) {
            addCriterion("num_block >=", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockLessThan(String value) {
            addCriterion("num_block <", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockLessThanOrEqualTo(String value) {
            addCriterion("num_block <=", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockLike(String value) {
            addCriterion("num_block like", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockNotLike(String value) {
            addCriterion("num_block not like", value, "numBlock");
            return this;
        }

        public Criteria andNumBlockIn(List<String> values) {
            addCriterion("num_block in", values, "numBlock");
            return this;
        }

        public Criteria andNumBlockNotIn(List<String> values) {
            addCriterion("num_block not in", values, "numBlock");
            return this;
        }

        public Criteria andNumBlockBetween(String value1, String value2) {
            addCriterion("num_block between", value1, value2, "numBlock");
            return this;
        }

        public Criteria andNumBlockNotBetween(String value1, String value2) {
            addCriterion("num_block not between", value1, value2, "numBlock");
            return this;
        }

        public Criteria andNumInteriorIsNull() {
            addCriterion("num_interior is null");
            return this;
        }

        public Criteria andNumInteriorIsNotNull() {
            addCriterion("num_interior is not null");
            return this;
        }

        public Criteria andNumInteriorEqualTo(String value) {
            addCriterion("num_interior =", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorNotEqualTo(String value) {
            addCriterion("num_interior <>", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorGreaterThan(String value) {
            addCriterion("num_interior >", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorGreaterThanOrEqualTo(String value) {
            addCriterion("num_interior >=", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorLessThan(String value) {
            addCriterion("num_interior <", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorLessThanOrEqualTo(String value) {
            addCriterion("num_interior <=", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorLike(String value) {
            addCriterion("num_interior like", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorNotLike(String value) {
            addCriterion("num_interior not like", value, "numInterior");
            return this;
        }

        public Criteria andNumInteriorIn(List<String> values) {
            addCriterion("num_interior in", values, "numInterior");
            return this;
        }

        public Criteria andNumInteriorNotIn(List<String> values) {
            addCriterion("num_interior not in", values, "numInterior");
            return this;
        }

        public Criteria andNumInteriorBetween(String value1, String value2) {
            addCriterion("num_interior between", value1, value2, "numInterior");
            return this;
        }

        public Criteria andNumInteriorNotBetween(String value1, String value2) {
            addCriterion("num_interior not between", value1, value2, "numInterior");
            return this;
        }

        public Criteria andDesZonaIsNull() {
            addCriterion("des_zona is null");
            return this;
        }

        public Criteria andDesZonaIsNotNull() {
            addCriterion("des_zona is not null");
            return this;
        }

        public Criteria andDesZonaEqualTo(String value) {
            addCriterion("des_zona =", value, "desZona");
            return this;
        }

        public Criteria andDesZonaNotEqualTo(String value) {
            addCriterion("des_zona <>", value, "desZona");
            return this;
        }

        public Criteria andDesZonaGreaterThan(String value) {
            addCriterion("des_zona >", value, "desZona");
            return this;
        }

        public Criteria andDesZonaGreaterThanOrEqualTo(String value) {
            addCriterion("des_zona >=", value, "desZona");
            return this;
        }

        public Criteria andDesZonaLessThan(String value) {
            addCriterion("des_zona <", value, "desZona");
            return this;
        }

        public Criteria andDesZonaLessThanOrEqualTo(String value) {
            addCriterion("des_zona <=", value, "desZona");
            return this;
        }

        public Criteria andDesZonaLike(String value) {
            addCriterion("des_zona like", value, "desZona");
            return this;
        }

        public Criteria andDesZonaNotLike(String value) {
            addCriterion("des_zona not like", value, "desZona");
            return this;
        }

        public Criteria andDesZonaIn(List<String> values) {
            addCriterion("des_zona in", values, "desZona");
            return this;
        }

        public Criteria andDesZonaNotIn(List<String> values) {
            addCriterion("des_zona not in", values, "desZona");
            return this;
        }

        public Criteria andDesZonaBetween(String value1, String value2) {
            addCriterion("des_zona between", value1, value2, "desZona");
            return this;
        }

        public Criteria andDesZonaNotBetween(String value1, String value2) {
            addCriterion("des_zona not between", value1, value2, "desZona");
            return this;
        }

        public Criteria andNumEtapaIsNull() {
            addCriterion("num_etapa is null");
            return this;
        }

        public Criteria andNumEtapaIsNotNull() {
            addCriterion("num_etapa is not null");
            return this;
        }

        public Criteria andNumEtapaEqualTo(String value) {
            addCriterion("num_etapa =", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaNotEqualTo(String value) {
            addCriterion("num_etapa <>", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaGreaterThan(String value) {
            addCriterion("num_etapa >", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaGreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa >=", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaLessThan(String value) {
            addCriterion("num_etapa <", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaLessThanOrEqualTo(String value) {
            addCriterion("num_etapa <=", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaLike(String value) {
            addCriterion("num_etapa like", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaNotLike(String value) {
            addCriterion("num_etapa not like", value, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaIn(List<String> values) {
            addCriterion("num_etapa in", values, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaNotIn(List<String> values) {
            addCriterion("num_etapa not in", values, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaBetween(String value1, String value2) {
            addCriterion("num_etapa between", value1, value2, "numEtapa");
            return this;
        }

        public Criteria andNumEtapaNotBetween(String value1, String value2) {
            addCriterion("num_etapa not between", value1, value2, "numEtapa");
            return this;
        }

        public Criteria andNumManzanaIsNull() {
            addCriterion("num_manzana is null");
            return this;
        }

        public Criteria andNumManzanaIsNotNull() {
            addCriterion("num_manzana is not null");
            return this;
        }

        public Criteria andNumManzanaEqualTo(String value) {
            addCriterion("num_manzana =", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaNotEqualTo(String value) {
            addCriterion("num_manzana <>", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaGreaterThan(String value) {
            addCriterion("num_manzana >", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaGreaterThanOrEqualTo(String value) {
            addCriterion("num_manzana >=", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaLessThan(String value) {
            addCriterion("num_manzana <", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaLessThanOrEqualTo(String value) {
            addCriterion("num_manzana <=", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaLike(String value) {
            addCriterion("num_manzana like", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaNotLike(String value) {
            addCriterion("num_manzana not like", value, "numManzana");
            return this;
        }

        public Criteria andNumManzanaIn(List<String> values) {
            addCriterion("num_manzana in", values, "numManzana");
            return this;
        }

        public Criteria andNumManzanaNotIn(List<String> values) {
            addCriterion("num_manzana not in", values, "numManzana");
            return this;
        }

        public Criteria andNumManzanaBetween(String value1, String value2) {
            addCriterion("num_manzana between", value1, value2, "numManzana");
            return this;
        }

        public Criteria andNumManzanaNotBetween(String value1, String value2) {
            addCriterion("num_manzana not between", value1, value2, "numManzana");
            return this;
        }

        public Criteria andNumLoteIsNull() {
            addCriterion("num_lote is null");
            return this;
        }

        public Criteria andNumLoteIsNotNull() {
            addCriterion("num_lote is not null");
            return this;
        }

        public Criteria andNumLoteEqualTo(String value) {
            addCriterion("num_lote =", value, "numLote");
            return this;
        }

        public Criteria andNumLoteNotEqualTo(String value) {
            addCriterion("num_lote <>", value, "numLote");
            return this;
        }

        public Criteria andNumLoteGreaterThan(String value) {
            addCriterion("num_lote >", value, "numLote");
            return this;
        }

        public Criteria andNumLoteGreaterThanOrEqualTo(String value) {
            addCriterion("num_lote >=", value, "numLote");
            return this;
        }

        public Criteria andNumLoteLessThan(String value) {
            addCriterion("num_lote <", value, "numLote");
            return this;
        }

        public Criteria andNumLoteLessThanOrEqualTo(String value) {
            addCriterion("num_lote <=", value, "numLote");
            return this;
        }

        public Criteria andNumLoteLike(String value) {
            addCriterion("num_lote like", value, "numLote");
            return this;
        }

        public Criteria andNumLoteNotLike(String value) {
            addCriterion("num_lote not like", value, "numLote");
            return this;
        }

        public Criteria andNumLoteIn(List<String> values) {
            addCriterion("num_lote in", values, "numLote");
            return this;
        }

        public Criteria andNumLoteNotIn(List<String> values) {
            addCriterion("num_lote not in", values, "numLote");
            return this;
        }

        public Criteria andNumLoteBetween(String value1, String value2) {
            addCriterion("num_lote between", value1, value2, "numLote");
            return this;
        }

        public Criteria andNumLoteNotBetween(String value1, String value2) {
            addCriterion("num_lote not between", value1, value2, "numLote");
            return this;
        }

        public Criteria andCodBlockIsNull() {
            addCriterion("cod_block is null");
            return this;
        }

        public Criteria andCodBlockIsNotNull() {
            addCriterion("cod_block is not null");
            return this;
        }

        public Criteria andCodBlockEqualTo(String value) {
            addCriterion("cod_block =", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockNotEqualTo(String value) {
            addCriterion("cod_block <>", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockGreaterThan(String value) {
            addCriterion("cod_block >", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockGreaterThanOrEqualTo(String value) {
            addCriterion("cod_block >=", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockLessThan(String value) {
            addCriterion("cod_block <", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockLessThanOrEqualTo(String value) {
            addCriterion("cod_block <=", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockLike(String value) {
            addCriterion("cod_block like", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockNotLike(String value) {
            addCriterion("cod_block not like", value, "codBlock");
            return this;
        }

        public Criteria andCodBlockIn(List<String> values) {
            addCriterion("cod_block in", values, "codBlock");
            return this;
        }

        public Criteria andCodBlockNotIn(List<String> values) {
            addCriterion("cod_block not in", values, "codBlock");
            return this;
        }

        public Criteria andCodBlockBetween(String value1, String value2) {
            addCriterion("cod_block between", value1, value2, "codBlock");
            return this;
        }

        public Criteria andCodBlockNotBetween(String value1, String value2) {
            addCriterion("cod_block not between", value1, value2, "codBlock");
            return this;
        }

        public Criteria andCodInteriorIsNull() {
            addCriterion("cod_interior is null");
            return this;
        }

        public Criteria andCodInteriorIsNotNull() {
            addCriterion("cod_interior is not null");
            return this;
        }

        public Criteria andCodInteriorEqualTo(String value) {
            addCriterion("cod_interior =", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorNotEqualTo(String value) {
            addCriterion("cod_interior <>", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorGreaterThan(String value) {
            addCriterion("cod_interior >", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorGreaterThanOrEqualTo(String value) {
            addCriterion("cod_interior >=", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorLessThan(String value) {
            addCriterion("cod_interior <", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorLessThanOrEqualTo(String value) {
            addCriterion("cod_interior <=", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorLike(String value) {
            addCriterion("cod_interior like", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorNotLike(String value) {
            addCriterion("cod_interior not like", value, "codInterior");
            return this;
        }

        public Criteria andCodInteriorIn(List<String> values) {
            addCriterion("cod_interior in", values, "codInterior");
            return this;
        }

        public Criteria andCodInteriorNotIn(List<String> values) {
            addCriterion("cod_interior not in", values, "codInterior");
            return this;
        }

        public Criteria andCodInteriorBetween(String value1, String value2) {
            addCriterion("cod_interior between", value1, value2, "codInterior");
            return this;
        }

        public Criteria andCodInteriorNotBetween(String value1, String value2) {
            addCriterion("cod_interior not between", value1, value2, "codInterior");
            return this;
        }

        public Criteria andCodZonaIsNull() {
            addCriterion("cod_zona is null");
            return this;
        }

        public Criteria andCodZonaIsNotNull() {
            addCriterion("cod_zona is not null");
            return this;
        }

        public Criteria andCodZonaEqualTo(String value) {
            addCriterion("cod_zona =", value, "codZona");
            return this;
        }

        public Criteria andCodZonaNotEqualTo(String value) {
            addCriterion("cod_zona <>", value, "codZona");
            return this;
        }

        public Criteria andCodZonaGreaterThan(String value) {
            addCriterion("cod_zona >", value, "codZona");
            return this;
        }

        public Criteria andCodZonaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona >=", value, "codZona");
            return this;
        }

        public Criteria andCodZonaLessThan(String value) {
            addCriterion("cod_zona <", value, "codZona");
            return this;
        }

        public Criteria andCodZonaLessThanOrEqualTo(String value) {
            addCriterion("cod_zona <=", value, "codZona");
            return this;
        }

        public Criteria andCodZonaLike(String value) {
            addCriterion("cod_zona like", value, "codZona");
            return this;
        }

        public Criteria andCodZonaNotLike(String value) {
            addCriterion("cod_zona not like", value, "codZona");
            return this;
        }

        public Criteria andCodZonaIn(List<String> values) {
            addCriterion("cod_zona in", values, "codZona");
            return this;
        }

        public Criteria andCodZonaNotIn(List<String> values) {
            addCriterion("cod_zona not in", values, "codZona");
            return this;
        }

        public Criteria andCodZonaBetween(String value1, String value2) {
            addCriterion("cod_zona between", value1, value2, "codZona");
            return this;
        }

        public Criteria andCodZonaNotBetween(String value1, String value2) {
            addCriterion("cod_zona not between", value1, value2, "codZona");
            return this;
        }
    }
}