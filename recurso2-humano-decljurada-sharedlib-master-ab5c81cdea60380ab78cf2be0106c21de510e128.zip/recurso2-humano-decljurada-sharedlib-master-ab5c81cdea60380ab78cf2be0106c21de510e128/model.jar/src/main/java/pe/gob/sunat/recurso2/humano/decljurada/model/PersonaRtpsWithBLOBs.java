package pe.gob.sunat.recurso2.humano.decljurada.model;

public class PersonaRtpsWithBLOBs extends PersonaRtps {
    private byte[] imgFoto;

    private byte[] imgFirma;

    public byte[] getImgFoto() {
        return imgFoto;
    }

    public void setImgFoto(byte[] imgFoto) {
        this.imgFoto = imgFoto;
    }

    public byte[] getImgFirma() {
        return imgFirma;
    }

    public void setImgFirma(byte[] imgFirma) {
        this.imgFirma = imgFirma;
    }
}