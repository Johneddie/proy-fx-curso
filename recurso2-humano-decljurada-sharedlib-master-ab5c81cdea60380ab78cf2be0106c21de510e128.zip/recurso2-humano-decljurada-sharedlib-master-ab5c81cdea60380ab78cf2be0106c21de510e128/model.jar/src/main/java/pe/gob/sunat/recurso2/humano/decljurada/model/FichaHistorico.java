package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.math.BigDecimal;
import java.util.Date;

public class FichaHistorico extends FichaHistoricoKey {
    private String codTipoDoc;

    private String numDocId;

    private String nomEmail;

    private String nomPostulante;

    private String apePaterno;

    private String apeMaterno;

    private Date fecNacimiento;

    private String codEstcivil;

    private String codUbigeonac;

    private String codUbigeodom;

    private String codTipzona;

    private String nomZona;

    private String codTipvia;

    private String nomVia;

    private String numDom;

    private String numTelcasa;

    private String numTelcelular;

    private String indAnterior;

    private String numLicencia;

    private String dirCarpetaarchivo;

    private BigDecimal mtoPretensionecon;

    private String indSunatId;

    private String desFamilSunat;

    private String indSunat;

    private String indDiscapacitado;

    private String codExamen;

    private String codEstado;

    private String desDiscapacidad;

    private String indLabor;

    private String indSexo;

    private String indSede1;

    private String indSede2;

    private String numRuc;

    private String codCatLicencia;

    private String numColegiatura;

    private String indColegiatura;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    private String codUsuproc;

    private Date fecProceso;

    private Integer numArcLicffaa;

    private Integer numArcDiscapacid;

    private String indLicffaa;

    private String codPaisnac;

    private String codEstColegiatur;

    private String numDepaDir;

    private String numInteriorDir;

    private String numManzDir;

    private String numLoteDir;

    private String numKilomDir;

    private String numBlockDir;

    private String numEtapaDir;

    private String desReferDir;

    private Integer numArcPostula;

    private String indFamsunat;

    private Date fecInicontrato;
    
    private String indDerechohab;

    public String getCodTipoDoc() {
        return codTipoDoc;
    }

    public void setCodTipoDoc(String codTipoDoc) {
        this.codTipoDoc = codTipoDoc == null ? null : codTipoDoc.trim();
    }

    public String getNumDocId() {
        return numDocId;
    }

    public void setNumDocId(String numDocId) {
        this.numDocId = numDocId == null ? null : numDocId.trim();
    }

    public String getNomEmail() {
        return nomEmail;
    }

    public void setNomEmail(String nomEmail) {
        this.nomEmail = nomEmail == null ? null : nomEmail.trim();
    }

    public String getNomPostulante() {
        return nomPostulante;
    }

    public void setNomPostulante(String nomPostulante) {
        this.nomPostulante = nomPostulante == null ? null : nomPostulante.trim();
    }

    public String getApePaterno() {
        return apePaterno;
    }

    public void setApePaterno(String apePaterno) {
        this.apePaterno = apePaterno == null ? null : apePaterno.trim();
    }

    public String getApeMaterno() {
        return apeMaterno;
    }

    public void setApeMaterno(String apeMaterno) {
        this.apeMaterno = apeMaterno == null ? null : apeMaterno.trim();
    }

    public Date getFecNacimiento() {
        return fecNacimiento;
    }

    public void setFecNacimiento(Date fecNacimiento) {
        this.fecNacimiento = fecNacimiento;
    }

    public String getCodEstcivil() {
        return codEstcivil;
    }

    public void setCodEstcivil(String codEstcivil) {
        this.codEstcivil = codEstcivil == null ? null : codEstcivil.trim();
    }

    public String getCodUbigeonac() {
        return codUbigeonac;
    }

    public void setCodUbigeonac(String codUbigeonac) {
        this.codUbigeonac = codUbigeonac == null ? null : codUbigeonac.trim();
    }

    public String getCodUbigeodom() {
        return codUbigeodom;
    }

    public void setCodUbigeodom(String codUbigeodom) {
        this.codUbigeodom = codUbigeodom == null ? null : codUbigeodom.trim();
    }

    public String getCodTipzona() {
        return codTipzona;
    }

    public void setCodTipzona(String codTipzona) {
        this.codTipzona = codTipzona == null ? null : codTipzona.trim();
    }

    public String getNomZona() {
        return nomZona;
    }

    public void setNomZona(String nomZona) {
        this.nomZona = nomZona == null ? null : nomZona.trim();
    }

    public String getCodTipvia() {
        return codTipvia;
    }

    public void setCodTipvia(String codTipvia) {
        this.codTipvia = codTipvia == null ? null : codTipvia.trim();
    }

    public String getNomVia() {
        return nomVia;
    }

    public void setNomVia(String nomVia) {
        this.nomVia = nomVia == null ? null : nomVia.trim();
    }

    public String getNumDom() {
        return numDom;
    }

    public void setNumDom(String numDom) {
        this.numDom = numDom == null ? null : numDom.trim();
    }

    public String getNumTelcasa() {
        return numTelcasa;
    }

    public void setNumTelcasa(String numTelcasa) {
        this.numTelcasa = numTelcasa == null ? null : numTelcasa.trim();
    }

    public String getNumTelcelular() {
        return numTelcelular;
    }

    public void setNumTelcelular(String numTelcelular) {
        this.numTelcelular = numTelcelular == null ? null : numTelcelular.trim();
    }

    public String getIndAnterior() {
        return indAnterior;
    }

    public void setIndAnterior(String indAnterior) {
        this.indAnterior = indAnterior == null ? null : indAnterior.trim();
    }

    public String getNumLicencia() {
        return numLicencia;
    }

    public void setNumLicencia(String numLicencia) {
        this.numLicencia = numLicencia == null ? null : numLicencia.trim();
    }

    public String getDirCarpetaarchivo() {
        return dirCarpetaarchivo;
    }

    public void setDirCarpetaarchivo(String dirCarpetaarchivo) {
        this.dirCarpetaarchivo = dirCarpetaarchivo == null ? null : dirCarpetaarchivo.trim();
    }

    public BigDecimal getMtoPretensionecon() {
        return mtoPretensionecon;
    }

    public void setMtoPretensionecon(BigDecimal mtoPretensionecon) {
        this.mtoPretensionecon = mtoPretensionecon;
    }

    public String getIndSunatId() {
        return indSunatId;
    }

    public void setIndSunatId(String indSunatId) {
        this.indSunatId = indSunatId == null ? null : indSunatId.trim();
    }

    public String getDesFamilSunat() {
        return desFamilSunat;
    }

    public void setDesFamilSunat(String desFamilSunat) {
        this.desFamilSunat = desFamilSunat == null ? null : desFamilSunat.trim();
    }

    public String getIndSunat() {
        return indSunat;
    }

    public void setIndSunat(String indSunat) {
        this.indSunat = indSunat == null ? null : indSunat.trim();
    }

    public String getIndDiscapacitado() {
        return indDiscapacitado;
    }

    public void setIndDiscapacitado(String indDiscapacitado) {
        this.indDiscapacitado = indDiscapacitado == null ? null : indDiscapacitado.trim();
    }

    public String getCodExamen() {
        return codExamen;
    }

    public void setCodExamen(String codExamen) {
        this.codExamen = codExamen == null ? null : codExamen.trim();
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public String getDesDiscapacidad() {
        return desDiscapacidad;
    }

    public void setDesDiscapacidad(String desDiscapacidad) {
        this.desDiscapacidad = desDiscapacidad == null ? null : desDiscapacidad.trim();
    }

    public String getIndLabor() {
        return indLabor;
    }

    public void setIndLabor(String indLabor) {
        this.indLabor = indLabor == null ? null : indLabor.trim();
    }

    public String getIndSexo() {
        return indSexo;
    }

    public void setIndSexo(String indSexo) {
        this.indSexo = indSexo == null ? null : indSexo.trim();
    }

    public String getIndSede1() {
        return indSede1;
    }

    public void setIndSede1(String indSede1) {
        this.indSede1 = indSede1 == null ? null : indSede1.trim();
    }

    public String getIndSede2() {
        return indSede2;
    }

    public void setIndSede2(String indSede2) {
        this.indSede2 = indSede2 == null ? null : indSede2.trim();
    }

    public String getNumRuc() {
        return numRuc;
    }

    public void setNumRuc(String numRuc) {
        this.numRuc = numRuc == null ? null : numRuc.trim();
    }

    public String getCodCatLicencia() {
        return codCatLicencia;
    }

    public void setCodCatLicencia(String codCatLicencia) {
        this.codCatLicencia = codCatLicencia == null ? null : codCatLicencia.trim();
    }

    public String getNumColegiatura() {
        return numColegiatura;
    }

    public void setNumColegiatura(String numColegiatura) {
        this.numColegiatura = numColegiatura == null ? null : numColegiatura.trim();
    }

    public String getIndColegiatura() {
        return indColegiatura;
    }

    public void setIndColegiatura(String indColegiatura) {
        this.indColegiatura = indColegiatura == null ? null : indColegiatura.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getCodUsuproc() {
        return codUsuproc;
    }

    public void setCodUsuproc(String codUsuproc) {
        this.codUsuproc = codUsuproc == null ? null : codUsuproc.trim();
    }

    public Date getFecProceso() {
        return fecProceso;
    }

    public void setFecProceso(Date fecProceso) {
        this.fecProceso = fecProceso;
    }

    public Integer getNumArcLicffaa() {
        return numArcLicffaa;
    }

    public void setNumArcLicffaa(Integer numArcLicffaa) {
        this.numArcLicffaa = numArcLicffaa;
    }

    public Integer getNumArcDiscapacid() {
        return numArcDiscapacid;
    }

    public void setNumArcDiscapacid(Integer numArcDiscapacid) {
        this.numArcDiscapacid = numArcDiscapacid;
    }

    public String getIndLicffaa() {
        return indLicffaa;
    }

    public void setIndLicffaa(String indLicffaa) {
        this.indLicffaa = indLicffaa == null ? null : indLicffaa.trim();
    }

    public String getCodPaisnac() {
        return codPaisnac;
    }

    public void setCodPaisnac(String codPaisnac) {
        this.codPaisnac = codPaisnac == null ? null : codPaisnac.trim();
    }

    public String getCodEstColegiatur() {
        return codEstColegiatur;
    }

    public void setCodEstColegiatur(String codEstColegiatur) {
        this.codEstColegiatur = codEstColegiatur == null ? null : codEstColegiatur.trim();
    }

    public String getNumDepaDir() {
        return numDepaDir;
    }

    public void setNumDepaDir(String numDepaDir) {
        this.numDepaDir = numDepaDir == null ? null : numDepaDir.trim();
    }

    public String getNumInteriorDir() {
        return numInteriorDir;
    }

    public void setNumInteriorDir(String numInteriorDir) {
        this.numInteriorDir = numInteriorDir == null ? null : numInteriorDir.trim();
    }

    public String getNumManzDir() {
        return numManzDir;
    }

    public void setNumManzDir(String numManzDir) {
        this.numManzDir = numManzDir == null ? null : numManzDir.trim();
    }

    public String getNumLoteDir() {
        return numLoteDir;
    }

    public void setNumLoteDir(String numLoteDir) {
        this.numLoteDir = numLoteDir == null ? null : numLoteDir.trim();
    }

    public String getNumKilomDir() {
        return numKilomDir;
    }

    public void setNumKilomDir(String numKilomDir) {
        this.numKilomDir = numKilomDir == null ? null : numKilomDir.trim();
    }

    public String getNumBlockDir() {
        return numBlockDir;
    }

    public void setNumBlockDir(String numBlockDir) {
        this.numBlockDir = numBlockDir == null ? null : numBlockDir.trim();
    }

    public String getNumEtapaDir() {
        return numEtapaDir;
    }

    public void setNumEtapaDir(String numEtapaDir) {
        this.numEtapaDir = numEtapaDir == null ? null : numEtapaDir.trim();
    }

    public String getDesReferDir() {
        return desReferDir;
    }

    public void setDesReferDir(String desReferDir) {
        this.desReferDir = desReferDir == null ? null : desReferDir.trim();
    }

    public Integer getNumArcPostula() {
        return numArcPostula;
    }

    public void setNumArcPostula(Integer numArcPostula) {
        this.numArcPostula = numArcPostula;
    }

    public String getIndFamsunat() {
        return indFamsunat;
    }

    public void setIndFamsunat(String indFamsunat) {
        this.indFamsunat = indFamsunat == null ? null : indFamsunat.trim();
    }

    public Date getFecInicontrato() {
        return fecInicontrato;
    }

    public void setFecInicontrato(Date fecInicontrato) {
        this.fecInicontrato = fecInicontrato;
    }

	public String getIndDerechohab() {
		return indDerechohab;
	}

	public void setIndDerechohab(String indDerechohab) {
		this.indDerechohab = indDerechohab;
	}
    
}