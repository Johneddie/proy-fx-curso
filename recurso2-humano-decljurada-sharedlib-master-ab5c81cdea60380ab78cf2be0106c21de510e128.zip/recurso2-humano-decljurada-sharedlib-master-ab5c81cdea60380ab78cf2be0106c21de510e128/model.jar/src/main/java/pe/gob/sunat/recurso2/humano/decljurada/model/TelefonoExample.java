package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelefonoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public TelefonoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected TelefonoExample(TelefonoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andT28codPersIsNull() {
            addCriterion("t28cod_pers is null");
            return this;
        }

        public Criteria andT28codPersIsNotNull() {
            addCriterion("t28cod_pers is not null");
            return this;
        }

        public Criteria andT28codPersEqualTo(String value) {
            addCriterion("t28cod_pers =", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersNotEqualTo(String value) {
            addCriterion("t28cod_pers <>", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersGreaterThan(String value) {
            addCriterion("t28cod_pers >", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersGreaterThanOrEqualTo(String value) {
            addCriterion("t28cod_pers >=", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersLessThan(String value) {
            addCriterion("t28cod_pers <", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersLessThanOrEqualTo(String value) {
            addCriterion("t28cod_pers <=", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersLike(String value) {
            addCriterion("t28cod_pers like", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersNotLike(String value) {
            addCriterion("t28cod_pers not like", value, "t28codPers");
            return this;
        }

        public Criteria andT28codPersIn(List<String> values) {
            addCriterion("t28cod_pers in", values, "t28codPers");
            return this;
        }

        public Criteria andT28codPersNotIn(List<String> values) {
            addCriterion("t28cod_pers not in", values, "t28codPers");
            return this;
        }

        public Criteria andT28codPersBetween(String value1, String value2) {
            addCriterion("t28cod_pers between", value1, value2, "t28codPers");
            return this;
        }

        public Criteria andT28codPersNotBetween(String value1, String value2) {
            addCriterion("t28cod_pers not between", value1, value2, "t28codPers");
            return this;
        }

        public Criteria andT28tipTelIsNull() {
            addCriterion("t28tip_tel is null");
            return this;
        }

        public Criteria andT28tipTelIsNotNull() {
            addCriterion("t28tip_tel is not null");
            return this;
        }

        public Criteria andT28tipTelEqualTo(String value) {
            addCriterion("t28tip_tel =", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelNotEqualTo(String value) {
            addCriterion("t28tip_tel <>", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelGreaterThan(String value) {
            addCriterion("t28tip_tel >", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelGreaterThanOrEqualTo(String value) {
            addCriterion("t28tip_tel >=", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelLessThan(String value) {
            addCriterion("t28tip_tel <", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelLessThanOrEqualTo(String value) {
            addCriterion("t28tip_tel <=", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelLike(String value) {
            addCriterion("t28tip_tel like", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelNotLike(String value) {
            addCriterion("t28tip_tel not like", value, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelIn(List<String> values) {
            addCriterion("t28tip_tel in", values, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelNotIn(List<String> values) {
            addCriterion("t28tip_tel not in", values, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelBetween(String value1, String value2) {
            addCriterion("t28tip_tel between", value1, value2, "t28tipTel");
            return this;
        }

        public Criteria andT28tipTelNotBetween(String value1, String value2) {
            addCriterion("t28tip_tel not between", value1, value2, "t28tipTel");
            return this;
        }

        public Criteria andT28numDdnIsNull() {
            addCriterion("t28num_ddn is null");
            return this;
        }

        public Criteria andT28numDdnIsNotNull() {
            addCriterion("t28num_ddn is not null");
            return this;
        }

        public Criteria andT28numDdnEqualTo(String value) {
            addCriterion("t28num_ddn =", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnNotEqualTo(String value) {
            addCriterion("t28num_ddn <>", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnGreaterThan(String value) {
            addCriterion("t28num_ddn >", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnGreaterThanOrEqualTo(String value) {
            addCriterion("t28num_ddn >=", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnLessThan(String value) {
            addCriterion("t28num_ddn <", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnLessThanOrEqualTo(String value) {
            addCriterion("t28num_ddn <=", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnLike(String value) {
            addCriterion("t28num_ddn like", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnNotLike(String value) {
            addCriterion("t28num_ddn not like", value, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnIn(List<String> values) {
            addCriterion("t28num_ddn in", values, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnNotIn(List<String> values) {
            addCriterion("t28num_ddn not in", values, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnBetween(String value1, String value2) {
            addCriterion("t28num_ddn between", value1, value2, "t28numDdn");
            return this;
        }

        public Criteria andT28numDdnNotBetween(String value1, String value2) {
            addCriterion("t28num_ddn not between", value1, value2, "t28numDdn");
            return this;
        }

        public Criteria andT28numTelIsNull() {
            addCriterion("t28num_tel is null");
            return this;
        }

        public Criteria andT28numTelIsNotNull() {
            addCriterion("t28num_tel is not null");
            return this;
        }

        public Criteria andT28numTelEqualTo(String value) {
            addCriterion("t28num_tel =", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelNotEqualTo(String value) {
            addCriterion("t28num_tel <>", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelGreaterThan(String value) {
            addCriterion("t28num_tel >", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelGreaterThanOrEqualTo(String value) {
            addCriterion("t28num_tel >=", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelLessThan(String value) {
            addCriterion("t28num_tel <", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelLessThanOrEqualTo(String value) {
            addCriterion("t28num_tel <=", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelLike(String value) {
            addCriterion("t28num_tel like", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelNotLike(String value) {
            addCriterion("t28num_tel not like", value, "t28numTel");
            return this;
        }

        public Criteria andT28numTelIn(List<String> values) {
            addCriterion("t28num_tel in", values, "t28numTel");
            return this;
        }

        public Criteria andT28numTelNotIn(List<String> values) {
            addCriterion("t28num_tel not in", values, "t28numTel");
            return this;
        }

        public Criteria andT28numTelBetween(String value1, String value2) {
            addCriterion("t28num_tel between", value1, value2, "t28numTel");
            return this;
        }

        public Criteria andT28numTelNotBetween(String value1, String value2) {
            addCriterion("t28num_tel not between", value1, value2, "t28numTel");
            return this;
        }

        public Criteria andT28numAneIsNull() {
            addCriterion("t28num_ane is null");
            return this;
        }

        public Criteria andT28numAneIsNotNull() {
            addCriterion("t28num_ane is not null");
            return this;
        }

        public Criteria andT28numAneEqualTo(String value) {
            addCriterion("t28num_ane =", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneNotEqualTo(String value) {
            addCriterion("t28num_ane <>", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneGreaterThan(String value) {
            addCriterion("t28num_ane >", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneGreaterThanOrEqualTo(String value) {
            addCriterion("t28num_ane >=", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneLessThan(String value) {
            addCriterion("t28num_ane <", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneLessThanOrEqualTo(String value) {
            addCriterion("t28num_ane <=", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneLike(String value) {
            addCriterion("t28num_ane like", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneNotLike(String value) {
            addCriterion("t28num_ane not like", value, "t28numAne");
            return this;
        }

        public Criteria andT28numAneIn(List<String> values) {
            addCriterion("t28num_ane in", values, "t28numAne");
            return this;
        }

        public Criteria andT28numAneNotIn(List<String> values) {
            addCriterion("t28num_ane not in", values, "t28numAne");
            return this;
        }

        public Criteria andT28numAneBetween(String value1, String value2) {
            addCriterion("t28num_ane between", value1, value2, "t28numAne");
            return this;
        }

        public Criteria andT28numAneNotBetween(String value1, String value2) {
            addCriterion("t28num_ane not between", value1, value2, "t28numAne");
            return this;
        }

        public Criteria andT28fGrabaIsNull() {
            addCriterion("t28f_graba is null");
            return this;
        }

        public Criteria andT28fGrabaIsNotNull() {
            addCriterion("t28f_graba is not null");
            return this;
        }

        public Criteria andT28fGrabaEqualTo(Date value) {
            addCriterion("t28f_graba =", value, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaNotEqualTo(Date value) {
            addCriterion("t28f_graba <>", value, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaGreaterThan(Date value) {
            addCriterion("t28f_graba >", value, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t28f_graba >=", value, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaLessThan(Date value) {
            addCriterion("t28f_graba <", value, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t28f_graba <=", value, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaIn(List<Date> values) {
            addCriterion("t28f_graba in", values, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaNotIn(List<Date> values) {
            addCriterion("t28f_graba not in", values, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaBetween(Date value1, Date value2) {
            addCriterion("t28f_graba between", value1, value2, "t28fGraba");
            return this;
        }

        public Criteria andT28fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t28f_graba not between", value1, value2, "t28fGraba");
            return this;
        }

        public Criteria andT28codUserIsNull() {
            addCriterion("t28cod_user is null");
            return this;
        }

        public Criteria andT28codUserIsNotNull() {
            addCriterion("t28cod_user is not null");
            return this;
        }

        public Criteria andT28codUserEqualTo(String value) {
            addCriterion("t28cod_user =", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserNotEqualTo(String value) {
            addCriterion("t28cod_user <>", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserGreaterThan(String value) {
            addCriterion("t28cod_user >", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t28cod_user >=", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserLessThan(String value) {
            addCriterion("t28cod_user <", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserLessThanOrEqualTo(String value) {
            addCriterion("t28cod_user <=", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserLike(String value) {
            addCriterion("t28cod_user like", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserNotLike(String value) {
            addCriterion("t28cod_user not like", value, "t28codUser");
            return this;
        }

        public Criteria andT28codUserIn(List<String> values) {
            addCriterion("t28cod_user in", values, "t28codUser");
            return this;
        }

        public Criteria andT28codUserNotIn(List<String> values) {
            addCriterion("t28cod_user not in", values, "t28codUser");
            return this;
        }

        public Criteria andT28codUserBetween(String value1, String value2) {
            addCriterion("t28cod_user between", value1, value2, "t28codUser");
            return this;
        }

        public Criteria andT28codUserNotBetween(String value1, String value2) {
            addCriterion("t28cod_user not between", value1, value2, "t28codUser");
            return this;
        }
    }
}