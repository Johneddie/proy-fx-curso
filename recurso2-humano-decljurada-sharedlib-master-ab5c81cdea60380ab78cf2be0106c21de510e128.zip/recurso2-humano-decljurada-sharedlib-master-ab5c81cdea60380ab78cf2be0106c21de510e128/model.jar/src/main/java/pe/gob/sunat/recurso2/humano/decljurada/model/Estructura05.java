package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.math.BigDecimal;
import java.util.Date;

public class Estructura05 {
    private Date fecProceso;

    private String codDocum;

    private String numDocum;

    private String codPaisEmiDoc;

    private String codRegLab;

    private String codNvlEdu;

    private String codOcup;

    private String indDiscapacidad;

    private String desCussp;

    private String indSctr;

    private String codTipContrato;

    private String indReg;

    private String indJorTraMax;

    private String indHorNoct;

    private String indSindical;

    private String indPeriodicidad;

    private BigDecimal numMontoRem;

    private String codSitu;

    private String indRentQuinta;

    private String indSituEspTra;

    private String indTipPago;

    private String codCatOcup;

    private String indConv;

    private String numRuc;

    private String estProceso;

    private Date fecCreacion;

    private String accCreacion;

    public Date getFecProceso() {
        return fecProceso;
    }

    public void setFecProceso(Date fecProceso) {
        this.fecProceso = fecProceso;
    }

    public String getCodDocum() {
        return codDocum;
    }

    public void setCodDocum(String codDocum) {
        this.codDocum = codDocum == null ? null : codDocum.trim();
    }

    public String getNumDocum() {
        return numDocum;
    }

    public void setNumDocum(String numDocum) {
        this.numDocum = numDocum == null ? null : numDocum.trim();
    }

    public String getCodPaisEmiDoc() {
        return codPaisEmiDoc;
    }

    public void setCodPaisEmiDoc(String codPaisEmiDoc) {
        this.codPaisEmiDoc = codPaisEmiDoc == null ? null : codPaisEmiDoc.trim();
    }

    public String getCodRegLab() {
        return codRegLab;
    }

    public void setCodRegLab(String codRegLab) {
        this.codRegLab = codRegLab == null ? null : codRegLab.trim();
    }

    public String getCodNvlEdu() {
        return codNvlEdu;
    }

    public void setCodNvlEdu(String codNvlEdu) {
        this.codNvlEdu = codNvlEdu == null ? null : codNvlEdu.trim();
    }

    public String getCodOcup() {
        return codOcup;
    }

    public void setCodOcup(String codOcup) {
        this.codOcup = codOcup == null ? null : codOcup.trim();
    }

    public String getIndDiscapacidad() {
        return indDiscapacidad;
    }

    public void setIndDiscapacidad(String indDiscapacidad) {
        this.indDiscapacidad = indDiscapacidad == null ? null : indDiscapacidad.trim();
    }

    public String getDesCussp() {
        return desCussp;
    }

    public void setDesCussp(String desCussp) {
        this.desCussp = desCussp == null ? null : desCussp.trim();
    }

    public String getIndSctr() {
        return indSctr;
    }

    public void setIndSctr(String indSctr) {
        this.indSctr = indSctr == null ? null : indSctr.trim();
    }

    public String getCodTipContrato() {
        return codTipContrato;
    }

    public void setCodTipContrato(String codTipContrato) {
        this.codTipContrato = codTipContrato == null ? null : codTipContrato.trim();
    }

    public String getIndReg() {
        return indReg;
    }

    public void setIndReg(String indReg) {
        this.indReg = indReg == null ? null : indReg.trim();
    }

    public String getIndJorTraMax() {
        return indJorTraMax;
    }

    public void setIndJorTraMax(String indJorTraMax) {
        this.indJorTraMax = indJorTraMax == null ? null : indJorTraMax.trim();
    }

    public String getIndHorNoct() {
        return indHorNoct;
    }

    public void setIndHorNoct(String indHorNoct) {
        this.indHorNoct = indHorNoct == null ? null : indHorNoct.trim();
    }

    public String getIndSindical() {
        return indSindical;
    }

    public void setIndSindical(String indSindical) {
        this.indSindical = indSindical == null ? null : indSindical.trim();
    }

    public String getIndPeriodicidad() {
        return indPeriodicidad;
    }

    public void setIndPeriodicidad(String indPeriodicidad) {
        this.indPeriodicidad = indPeriodicidad == null ? null : indPeriodicidad.trim();
    }

    public BigDecimal getNumMontoRem() {
        return numMontoRem;
    }

    public void setNumMontoRem(BigDecimal numMontoRem) {
        this.numMontoRem = numMontoRem;
    }

    public String getCodSitu() {
        return codSitu;
    }

    public void setCodSitu(String codSitu) {
        this.codSitu = codSitu == null ? null : codSitu.trim();
    }

    public String getIndRentQuinta() {
        return indRentQuinta;
    }

    public void setIndRentQuinta(String indRentQuinta) {
        this.indRentQuinta = indRentQuinta == null ? null : indRentQuinta.trim();
    }

    public String getIndSituEspTra() {
        return indSituEspTra;
    }

    public void setIndSituEspTra(String indSituEspTra) {
        this.indSituEspTra = indSituEspTra == null ? null : indSituEspTra.trim();
    }

    public String getIndTipPago() {
        return indTipPago;
    }

    public void setIndTipPago(String indTipPago) {
        this.indTipPago = indTipPago == null ? null : indTipPago.trim();
    }

    public String getCodCatOcup() {
        return codCatOcup;
    }

    public void setCodCatOcup(String codCatOcup) {
        this.codCatOcup = codCatOcup == null ? null : codCatOcup.trim();
    }

    public String getIndConv() {
        return indConv;
    }

    public void setIndConv(String indConv) {
        this.indConv = indConv == null ? null : indConv.trim();
    }

    public String getNumRuc() {
        return numRuc;
    }

    public void setNumRuc(String numRuc) {
        this.numRuc = numRuc == null ? null : numRuc.trim();
    }

    public String getEstProceso() {
        return estProceso;
    }

    public void setEstProceso(String estProceso) {
        this.estProceso = estProceso == null ? null : estProceso.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getAccCreacion() {
        return accCreacion;
    }

    public void setAccCreacion(String accCreacion) {
        this.accCreacion = accCreacion == null ? null : accCreacion.trim();
    }
}