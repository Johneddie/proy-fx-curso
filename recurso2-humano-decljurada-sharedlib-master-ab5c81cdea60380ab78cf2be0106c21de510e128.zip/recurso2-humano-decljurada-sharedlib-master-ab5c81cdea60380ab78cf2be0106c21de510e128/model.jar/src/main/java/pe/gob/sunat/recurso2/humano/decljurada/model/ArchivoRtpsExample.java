package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArchivoRtpsExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ArchivoRtpsExample() {
        oredCriteria = new ArrayList<>();
    }

    protected ArchivoRtpsExample(ArchivoRtpsExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andFecProcesoIsNull() {
            addCriterion("fec_proceso is null");
            return this;
        }

        public Criteria andFecProcesoIsNotNull() {
            addCriterion("fec_proceso is not null");
            return this;
        }

        public Criteria andFecProcesoEqualTo(Date value) {
            addCriterion("fec_proceso =", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotEqualTo(Date value) {
            addCriterion("fec_proceso <>", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThan(Date value) {
            addCriterion("fec_proceso >", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_proceso >=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThan(Date value) {
            addCriterion("fec_proceso <", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThanOrEqualTo(Date value) {
            addCriterion("fec_proceso <=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoIn(List<Date> values) {
            addCriterion("fec_proceso in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotIn(List<Date> values) {
            addCriterion("fec_proceso not in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoBetween(Date value1, Date value2) {
            addCriterion("fec_proceso between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotBetween(Date value1, Date value2) {
            addCriterion("fec_proceso not between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andIndArchTrabIsNull() {
            addCriterion("ind_arch_trab is null");
            return this;
        }

        public Criteria andIndArchTrabIsNotNull() {
            addCriterion("ind_arch_trab is not null");
            return this;
        }

        public Criteria andIndArchTrabEqualTo(String value) {
            addCriterion("ind_arch_trab =", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabNotEqualTo(String value) {
            addCriterion("ind_arch_trab <>", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabGreaterThan(String value) {
            addCriterion("ind_arch_trab >", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabGreaterThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab >=", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabLessThan(String value) {
            addCriterion("ind_arch_trab <", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabLessThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab <=", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabLike(String value) {
            addCriterion("ind_arch_trab like", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabNotLike(String value) {
            addCriterion("ind_arch_trab not like", value, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabIn(List<String> values) {
            addCriterion("ind_arch_trab in", values, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabNotIn(List<String> values) {
            addCriterion("ind_arch_trab not in", values, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabBetween(String value1, String value2) {
            addCriterion("ind_arch_trab between", value1, value2, "indArchTrab");
            return this;
        }

        public Criteria andIndArchTrabNotBetween(String value1, String value2) {
            addCriterion("ind_arch_trab not between", value1, value2, "indArchTrab");
            return this;
        }

        public Criteria andIndArchDerhabIsNull() {
            addCriterion("ind_arch_derhab is null");
            return this;
        }

        public Criteria andIndArchDerhabIsNotNull() {
            addCriterion("ind_arch_derhab is not null");
            return this;
        }

        public Criteria andIndArchDerhabEqualTo(String value) {
            addCriterion("ind_arch_derhab =", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabNotEqualTo(String value) {
            addCriterion("ind_arch_derhab <>", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabGreaterThan(String value) {
            addCriterion("ind_arch_derhab >", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabGreaterThanOrEqualTo(String value) {
            addCriterion("ind_arch_derhab >=", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabLessThan(String value) {
            addCriterion("ind_arch_derhab <", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabLessThanOrEqualTo(String value) {
            addCriterion("ind_arch_derhab <=", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabLike(String value) {
            addCriterion("ind_arch_derhab like", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabNotLike(String value) {
            addCriterion("ind_arch_derhab not like", value, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabIn(List<String> values) {
            addCriterion("ind_arch_derhab in", values, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabNotIn(List<String> values) {
            addCriterion("ind_arch_derhab not in", values, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabBetween(String value1, String value2) {
            addCriterion("ind_arch_derhab between", value1, value2, "indArchDerhab");
            return this;
        }

        public Criteria andIndArchDerhabNotBetween(String value1, String value2) {
            addCriterion("ind_arch_derhab not between", value1, value2, "indArchDerhab");
            return this;
        }

        public Criteria andIndExitoProcIsNull() {
            addCriterion("ind_exito_proc is null");
            return this;
        }

        public Criteria andIndExitoProcIsNotNull() {
            addCriterion("ind_exito_proc is not null");
            return this;
        }

        public Criteria andIndExitoProcEqualTo(String value) {
            addCriterion("ind_exito_proc =", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcNotEqualTo(String value) {
            addCriterion("ind_exito_proc <>", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcGreaterThan(String value) {
            addCriterion("ind_exito_proc >", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcGreaterThanOrEqualTo(String value) {
            addCriterion("ind_exito_proc >=", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcLessThan(String value) {
            addCriterion("ind_exito_proc <", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcLessThanOrEqualTo(String value) {
            addCriterion("ind_exito_proc <=", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcLike(String value) {
            addCriterion("ind_exito_proc like", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcNotLike(String value) {
            addCriterion("ind_exito_proc not like", value, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcIn(List<String> values) {
            addCriterion("ind_exito_proc in", values, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcNotIn(List<String> values) {
            addCriterion("ind_exito_proc not in", values, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcBetween(String value1, String value2) {
            addCriterion("ind_exito_proc between", value1, value2, "indExitoProc");
            return this;
        }

        public Criteria andIndExitoProcNotBetween(String value1, String value2) {
            addCriterion("ind_exito_proc not between", value1, value2, "indExitoProc");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andIndArchTrabAltaIsNull() {
            addCriterion("ind_arch_trab_alta is null");
            return this;
        }

        public Criteria andIndArchTrabAltaIsNotNull() {
            addCriterion("ind_arch_trab_alta is not null");
            return this;
        }

        public Criteria andIndArchTrabAltaEqualTo(String value) {
            addCriterion("ind_arch_trab_alta =", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaNotEqualTo(String value) {
            addCriterion("ind_arch_trab_alta <>", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaGreaterThan(String value) {
            addCriterion("ind_arch_trab_alta >", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab_alta >=", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaLessThan(String value) {
            addCriterion("ind_arch_trab_alta <", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaLessThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab_alta <=", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaLike(String value) {
            addCriterion("ind_arch_trab_alta like", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaNotLike(String value) {
            addCriterion("ind_arch_trab_alta not like", value, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaIn(List<String> values) {
            addCriterion("ind_arch_trab_alta in", values, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaNotIn(List<String> values) {
            addCriterion("ind_arch_trab_alta not in", values, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaBetween(String value1, String value2) {
            addCriterion("ind_arch_trab_alta between", value1, value2, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabAltaNotBetween(String value1, String value2) {
            addCriterion("ind_arch_trab_alta not between", value1, value2, "indArchTrabAlta");
            return this;
        }

        public Criteria andIndArchTrabBajaIsNull() {
            addCriterion("ind_arch_trab_baja is null");
            return this;
        }

        public Criteria andIndArchTrabBajaIsNotNull() {
            addCriterion("ind_arch_trab_baja is not null");
            return this;
        }

        public Criteria andIndArchTrabBajaEqualTo(String value) {
            addCriterion("ind_arch_trab_baja =", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaNotEqualTo(String value) {
            addCriterion("ind_arch_trab_baja <>", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaGreaterThan(String value) {
            addCriterion("ind_arch_trab_baja >", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab_baja >=", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaLessThan(String value) {
            addCriterion("ind_arch_trab_baja <", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaLessThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab_baja <=", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaLike(String value) {
            addCriterion("ind_arch_trab_baja like", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaNotLike(String value) {
            addCriterion("ind_arch_trab_baja not like", value, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaIn(List<String> values) {
            addCriterion("ind_arch_trab_baja in", values, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaNotIn(List<String> values) {
            addCriterion("ind_arch_trab_baja not in", values, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaBetween(String value1, String value2) {
            addCriterion("ind_arch_trab_baja between", value1, value2, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabBajaNotBetween(String value1, String value2) {
            addCriterion("ind_arch_trab_baja not between", value1, value2, "indArchTrabBaja");
            return this;
        }

        public Criteria andIndArchTrabModIsNull() {
            addCriterion("ind_arch_trab_mod is null");
            return this;
        }

        public Criteria andIndArchTrabModIsNotNull() {
            addCriterion("ind_arch_trab_mod is not null");
            return this;
        }

        public Criteria andIndArchTrabModEqualTo(String value) {
            addCriterion("ind_arch_trab_mod =", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModNotEqualTo(String value) {
            addCriterion("ind_arch_trab_mod <>", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModGreaterThan(String value) {
            addCriterion("ind_arch_trab_mod >", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModGreaterThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab_mod >=", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModLessThan(String value) {
            addCriterion("ind_arch_trab_mod <", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModLessThanOrEqualTo(String value) {
            addCriterion("ind_arch_trab_mod <=", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModLike(String value) {
            addCriterion("ind_arch_trab_mod like", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModNotLike(String value) {
            addCriterion("ind_arch_trab_mod not like", value, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModIn(List<String> values) {
            addCriterion("ind_arch_trab_mod in", values, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModNotIn(List<String> values) {
            addCriterion("ind_arch_trab_mod not in", values, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModBetween(String value1, String value2) {
            addCriterion("ind_arch_trab_mod between", value1, value2, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchTrabModNotBetween(String value1, String value2) {
            addCriterion("ind_arch_trab_mod not between", value1, value2, "indArchTrabMod");
            return this;
        }

        public Criteria andIndArchDerhabAltaIsNull() {
            addCriterion("ind_arch_derhab_alta is null");
            return this;
        }

        public Criteria andIndArchDerhabAltaIsNotNull() {
            addCriterion("ind_arch_derhab_alta is not null");
            return this;
        }

        public Criteria andIndArchDerhabAltaEqualTo(String value) {
            addCriterion("ind_arch_derhab_alta =", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaNotEqualTo(String value) {
            addCriterion("ind_arch_derhab_alta <>", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaGreaterThan(String value) {
            addCriterion("ind_arch_derhab_alta >", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_arch_derhab_alta >=", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaLessThan(String value) {
            addCriterion("ind_arch_derhab_alta <", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaLessThanOrEqualTo(String value) {
            addCriterion("ind_arch_derhab_alta <=", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaLike(String value) {
            addCriterion("ind_arch_derhab_alta like", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaNotLike(String value) {
            addCriterion("ind_arch_derhab_alta not like", value, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaIn(List<String> values) {
            addCriterion("ind_arch_derhab_alta in", values, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaNotIn(List<String> values) {
            addCriterion("ind_arch_derhab_alta not in", values, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaBetween(String value1, String value2) {
            addCriterion("ind_arch_derhab_alta between", value1, value2, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabAltaNotBetween(String value1, String value2) {
            addCriterion("ind_arch_derhab_alta not between", value1, value2, "indArchDerhabAlta");
            return this;
        }

        public Criteria andIndArchDerhabBajaIsNull() {
            addCriterion("ind_arch_derhab_baja is null");
            return this;
        }

        public Criteria andIndArchDerhabBajaIsNotNull() {
            addCriterion("ind_arch_derhab_baja is not null");
            return this;
        }

        public Criteria andIndArchDerhabBajaEqualTo(String value) {
            addCriterion("ind_arch_derhab_baja =", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaNotEqualTo(String value) {
            addCriterion("ind_arch_derhab_baja <>", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaGreaterThan(String value) {
            addCriterion("ind_arch_derhab_baja >", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_arch_derhab_baja >=", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaLessThan(String value) {
            addCriterion("ind_arch_derhab_baja <", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaLessThanOrEqualTo(String value) {
            addCriterion("ind_arch_derhab_baja <=", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaLike(String value) {
            addCriterion("ind_arch_derhab_baja like", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaNotLike(String value) {
            addCriterion("ind_arch_derhab_baja not like", value, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaIn(List<String> values) {
            addCriterion("ind_arch_derhab_baja in", values, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaNotIn(List<String> values) {
            addCriterion("ind_arch_derhab_baja not in", values, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaBetween(String value1, String value2) {
            addCriterion("ind_arch_derhab_baja between", value1, value2, "indArchDerhabBaja");
            return this;
        }

        public Criteria andIndArchDerhabBajaNotBetween(String value1, String value2) {
            addCriterion("ind_arch_derhab_baja not between", value1, value2, "indArchDerhabBaja");
            return this;
        }
    }
}