package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArchivoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ArchivoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected ArchivoExample(ArchivoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andAnnDdjjIsNull() {
            addCriterion("ann_ddjj is null");
            return this;
        }

        public Criteria andAnnDdjjIsNotNull() {
            addCriterion("ann_ddjj is not null");
            return this;
        }

        public Criteria andAnnDdjjEqualTo(String value) {
            addCriterion("ann_ddjj =", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotEqualTo(String value) {
            addCriterion("ann_ddjj <>", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThan(String value) {
            addCriterion("ann_ddjj >", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThanOrEqualTo(String value) {
            addCriterion("ann_ddjj >=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThan(String value) {
            addCriterion("ann_ddjj <", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThanOrEqualTo(String value) {
            addCriterion("ann_ddjj <=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLike(String value) {
            addCriterion("ann_ddjj like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotLike(String value) {
            addCriterion("ann_ddjj not like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjIn(List<String> values) {
            addCriterion("ann_ddjj in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotIn(List<String> values) {
            addCriterion("ann_ddjj not in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjBetween(String value1, String value2) {
            addCriterion("ann_ddjj between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotBetween(String value1, String value2) {
            addCriterion("ann_ddjj not between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andCodTipIsNull() {
            addCriterion("cod_tip is null");
            return this;
        }

        public Criteria andCodTipIsNotNull() {
            addCriterion("cod_tip is not null");
            return this;
        }

        public Criteria andCodTipEqualTo(String value) {
            addCriterion("cod_tip =", value, "codTip");
            return this;
        }

        public Criteria andCodTipNotEqualTo(String value) {
            addCriterion("cod_tip <>", value, "codTip");
            return this;
        }

        public Criteria andCodTipGreaterThan(String value) {
            addCriterion("cod_tip >", value, "codTip");
            return this;
        }

        public Criteria andCodTipGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip >=", value, "codTip");
            return this;
        }

        public Criteria andCodTipLessThan(String value) {
            addCriterion("cod_tip <", value, "codTip");
            return this;
        }

        public Criteria andCodTipLessThanOrEqualTo(String value) {
            addCriterion("cod_tip <=", value, "codTip");
            return this;
        }

        public Criteria andCodTipLike(String value) {
            addCriterion("cod_tip like", value, "codTip");
            return this;
        }

        public Criteria andCodTipNotLike(String value) {
            addCriterion("cod_tip not like", value, "codTip");
            return this;
        }

        public Criteria andCodTipIn(List<String> values) {
            addCriterion("cod_tip in", values, "codTip");
            return this;
        }

        public Criteria andCodTipNotIn(List<String> values) {
            addCriterion("cod_tip not in", values, "codTip");
            return this;
        }

        public Criteria andCodTipBetween(String value1, String value2) {
            addCriterion("cod_tip between", value1, value2, "codTip");
            return this;
        }

        public Criteria andCodTipNotBetween(String value1, String value2) {
            addCriterion("cod_tip not between", value1, value2, "codTip");
            return this;
        }

        public Criteria andIndCorrelIsNull() {
            addCriterion("ind_correl is null");
            return this;
        }

        public Criteria andIndCorrelIsNotNull() {
            addCriterion("ind_correl is not null");
            return this;
        }

        public Criteria andIndCorrelEqualTo(Short value) {
            addCriterion("ind_correl =", value, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelNotEqualTo(Short value) {
            addCriterion("ind_correl <>", value, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelGreaterThan(Short value) {
            addCriterion("ind_correl >", value, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelGreaterThanOrEqualTo(Short value) {
            addCriterion("ind_correl >=", value, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelLessThan(Short value) {
            addCriterion("ind_correl <", value, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelLessThanOrEqualTo(Short value) {
            addCriterion("ind_correl <=", value, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelIn(List<Short> values) {
            addCriterion("ind_correl in", values, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelNotIn(List<Short> values) {
            addCriterion("ind_correl not in", values, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelBetween(Short value1, Short value2) {
            addCriterion("ind_correl between", value1, value2, "indCorrel");
            return this;
        }

        public Criteria andIndCorrelNotBetween(Short value1, Short value2) {
            addCriterion("ind_correl not between", value1, value2, "indCorrel");
            return this;
        }

        public Criteria andNumDdjjIsNull() {
            addCriterion("num_ddjj is null");
            return this;
        }

        public Criteria andNumDdjjIsNotNull() {
            addCriterion("num_ddjj is not null");
            return this;
        }

        public Criteria andNumDdjjEqualTo(Integer value) {
            addCriterion("num_ddjj =", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotEqualTo(Integer value) {
            addCriterion("num_ddjj <>", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThan(Integer value) {
            addCriterion("num_ddjj >", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj >=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThan(Integer value) {
            addCriterion("num_ddjj <", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj <=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjIn(List<Integer> values) {
            addCriterion("num_ddjj in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotIn(List<Integer> values) {
            addCriterion("num_ddjj not in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj not between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andDesNombreIsNull() {
            addCriterion("des_nombre is null");
            return this;
        }

        public Criteria andDesNombreIsNotNull() {
            addCriterion("des_nombre is not null");
            return this;
        }

        public Criteria andDesNombreEqualTo(String value) {
            addCriterion("des_nombre =", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreNotEqualTo(String value) {
            addCriterion("des_nombre <>", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreGreaterThan(String value) {
            addCriterion("des_nombre >", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreGreaterThanOrEqualTo(String value) {
            addCriterion("des_nombre >=", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreLessThan(String value) {
            addCriterion("des_nombre <", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreLessThanOrEqualTo(String value) {
            addCriterion("des_nombre <=", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreLike(String value) {
            addCriterion("des_nombre like", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreNotLike(String value) {
            addCriterion("des_nombre not like", value, "desNombre");
            return this;
        }

        public Criteria andDesNombreIn(List<String> values) {
            addCriterion("des_nombre in", values, "desNombre");
            return this;
        }

        public Criteria andDesNombreNotIn(List<String> values) {
            addCriterion("des_nombre not in", values, "desNombre");
            return this;
        }

        public Criteria andDesNombreBetween(String value1, String value2) {
            addCriterion("des_nombre between", value1, value2, "desNombre");
            return this;
        }

        public Criteria andDesNombreNotBetween(String value1, String value2) {
            addCriterion("des_nombre not between", value1, value2, "desNombre");
            return this;
        }

        public Criteria andDesComentarioIsNull() {
            addCriterion("des_comentario is null");
            return this;
        }

        public Criteria andDesComentarioIsNotNull() {
            addCriterion("des_comentario is not null");
            return this;
        }

        public Criteria andDesComentarioEqualTo(String value) {
            addCriterion("des_comentario =", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioNotEqualTo(String value) {
            addCriterion("des_comentario <>", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioGreaterThan(String value) {
            addCriterion("des_comentario >", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioGreaterThanOrEqualTo(String value) {
            addCriterion("des_comentario >=", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioLessThan(String value) {
            addCriterion("des_comentario <", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioLessThanOrEqualTo(String value) {
            addCriterion("des_comentario <=", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioLike(String value) {
            addCriterion("des_comentario like", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioNotLike(String value) {
            addCriterion("des_comentario not like", value, "desComentario");
            return this;
        }

        public Criteria andDesComentarioIn(List<String> values) {
            addCriterion("des_comentario in", values, "desComentario");
            return this;
        }

        public Criteria andDesComentarioNotIn(List<String> values) {
            addCriterion("des_comentario not in", values, "desComentario");
            return this;
        }

        public Criteria andDesComentarioBetween(String value1, String value2) {
            addCriterion("des_comentario between", value1, value2, "desComentario");
            return this;
        }

        public Criteria andDesComentarioNotBetween(String value1, String value2) {
            addCriterion("des_comentario not between", value1, value2, "desComentario");
            return this;
        }
    }
}