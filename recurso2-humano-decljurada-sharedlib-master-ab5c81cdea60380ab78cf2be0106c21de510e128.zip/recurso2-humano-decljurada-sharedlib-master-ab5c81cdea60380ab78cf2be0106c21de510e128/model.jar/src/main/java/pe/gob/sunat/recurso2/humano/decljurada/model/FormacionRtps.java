package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class FormacionRtps extends FormacionRtpsKey {
    private String codGraAca;

    private String codInst;

    private String codEspe;

    private String codOrdMer;

    private Date fecIni;

    private Date fecFin;

    private String desNota;

    private String codUsucrea;

    private Date fecCreacion;

    private String codUsumodif;

    private Date fecModif;

    public String getCodGraAca() {
        return codGraAca;
    }

    public void setCodGraAca(String codGraAca) {
        this.codGraAca = codGraAca == null ? null : codGraAca.trim();
    }

    public String getCodInst() {
        return codInst;
    }

    public void setCodInst(String codInst) {
        this.codInst = codInst == null ? null : codInst.trim();
    }

    public String getCodEspe() {
        return codEspe;
    }

    public void setCodEspe(String codEspe) {
        this.codEspe = codEspe == null ? null : codEspe.trim();
    }

    public String getCodOrdMer() {
        return codOrdMer;
    }

    public void setCodOrdMer(String codOrdMer) {
        this.codOrdMer = codOrdMer == null ? null : codOrdMer.trim();
    }

    public Date getFecIni() {
        return fecIni;
    }

    public void setFecIni(Date fecIni) {
        this.fecIni = fecIni;
    }

    public Date getFecFin() {
        return fecFin;
    }

    public void setFecFin(Date fecFin) {
        this.fecFin = fecFin;
    }

    public String getDesNota() {
        return desNota;
    }

    public void setDesNota(String desNota) {
        this.desNota = desNota == null ? null : desNota.trim();
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }
}