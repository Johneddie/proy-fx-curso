package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Estructura17 {
    private Date fecProceso;

    private String codDocum;

    private String numDocum;

    private String codPaisEmiDoc;

    private String numRucEmpl;

    private String codEstable;

    private String estProceso;

    private Date fecCreacion;

    private String accCreacion;

    public Date getFecProceso() {
        return fecProceso;
    }

    public void setFecProceso(Date fecProceso) {
        this.fecProceso = fecProceso;
    }

    public String getCodDocum() {
        return codDocum;
    }

    public void setCodDocum(String codDocum) {
        this.codDocum = codDocum == null ? null : codDocum.trim();
    }

    public String getNumDocum() {
        return numDocum;
    }

    public void setNumDocum(String numDocum) {
        this.numDocum = numDocum == null ? null : numDocum.trim();
    }

    public String getCodPaisEmiDoc() {
        return codPaisEmiDoc;
    }

    public void setCodPaisEmiDoc(String codPaisEmiDoc) {
        this.codPaisEmiDoc = codPaisEmiDoc == null ? null : codPaisEmiDoc.trim();
    }

    public String getNumRucEmpl() {
        return numRucEmpl;
    }

    public void setNumRucEmpl(String numRucEmpl) {
        this.numRucEmpl = numRucEmpl == null ? null : numRucEmpl.trim();
    }

    public String getCodEstable() {
        return codEstable;
    }

    public void setCodEstable(String codEstable) {
        this.codEstable = codEstable == null ? null : codEstable.trim();
    }

    public String getEstProceso() {
        return estProceso;
    }

    public void setEstProceso(String estProceso) {
        this.estProceso = estProceso == null ? null : estProceso.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getAccCreacion() {
        return accCreacion;
    }

    public void setAccCreacion(String accCreacion) {
        this.accCreacion = accCreacion == null ? null : accCreacion.trim();
    }
}