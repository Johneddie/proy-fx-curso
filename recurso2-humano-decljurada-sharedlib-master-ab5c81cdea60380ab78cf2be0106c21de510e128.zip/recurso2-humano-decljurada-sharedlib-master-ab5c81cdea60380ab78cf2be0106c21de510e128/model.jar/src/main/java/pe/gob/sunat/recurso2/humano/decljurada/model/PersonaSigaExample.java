package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class PersonaSigaExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public PersonaSigaExample() {
        oredCriteria = new ArrayList<>();
    }

    protected PersonaSigaExample(PersonaSigaExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andCodiEmplPerIsNull() {
            addCriterion("CODI_EMPL_PER is null");
            return this;
        }

        public Criteria andCodiEmplPerIsNotNull() {
            addCriterion("CODI_EMPL_PER is not null");
            return this;
        }

        public Criteria andCodiEmplPerEqualTo(String value) {
            addCriterion("CODI_EMPL_PER =", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerNotEqualTo(String value) {
            addCriterion("CODI_EMPL_PER <>", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerGreaterThan(String value) {
            addCriterion("CODI_EMPL_PER >", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_EMPL_PER >=", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerLessThan(String value) {
            addCriterion("CODI_EMPL_PER <", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerLessThanOrEqualTo(String value) {
            addCriterion("CODI_EMPL_PER <=", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerLike(String value) {
            addCriterion("CODI_EMPL_PER like", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerNotLike(String value) {
            addCriterion("CODI_EMPL_PER not like", value, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerIn(List<String> values) {
            addCriterion("CODI_EMPL_PER in", values, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerNotIn(List<String> values) {
            addCriterion("CODI_EMPL_PER not in", values, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerBetween(String value1, String value2) {
            addCriterion("CODI_EMPL_PER between", value1, value2, "codiEmplPer");
            return this;
        }

        public Criteria andCodiEmplPerNotBetween(String value1, String value2) {
            addCriterion("CODI_EMPL_PER not between", value1, value2, "codiEmplPer");
            return this;
        }

        public Criteria andApePatPerIsNull() {
            addCriterion("APE_PAT_PER is null");
            return this;
        }

        public Criteria andApePatPerIsNotNull() {
            addCriterion("APE_PAT_PER is not null");
            return this;
        }

        public Criteria andApePatPerEqualTo(String value) {
            addCriterion("APE_PAT_PER =", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerNotEqualTo(String value) {
            addCriterion("APE_PAT_PER <>", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerGreaterThan(String value) {
            addCriterion("APE_PAT_PER >", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerGreaterThanOrEqualTo(String value) {
            addCriterion("APE_PAT_PER >=", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerLessThan(String value) {
            addCriterion("APE_PAT_PER <", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerLessThanOrEqualTo(String value) {
            addCriterion("APE_PAT_PER <=", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerLike(String value) {
            addCriterion("APE_PAT_PER like", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerNotLike(String value) {
            addCriterion("APE_PAT_PER not like", value, "apePatPer");
            return this;
        }

        public Criteria andApePatPerIn(List<String> values) {
            addCriterion("APE_PAT_PER in", values, "apePatPer");
            return this;
        }

        public Criteria andApePatPerNotIn(List<String> values) {
            addCriterion("APE_PAT_PER not in", values, "apePatPer");
            return this;
        }

        public Criteria andApePatPerBetween(String value1, String value2) {
            addCriterion("APE_PAT_PER between", value1, value2, "apePatPer");
            return this;
        }

        public Criteria andApePatPerNotBetween(String value1, String value2) {
            addCriterion("APE_PAT_PER not between", value1, value2, "apePatPer");
            return this;
        }

        public Criteria andApeMatPerIsNull() {
            addCriterion("APE_MAT_PER is null");
            return this;
        }

        public Criteria andApeMatPerIsNotNull() {
            addCriterion("APE_MAT_PER is not null");
            return this;
        }

        public Criteria andApeMatPerEqualTo(String value) {
            addCriterion("APE_MAT_PER =", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerNotEqualTo(String value) {
            addCriterion("APE_MAT_PER <>", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerGreaterThan(String value) {
            addCriterion("APE_MAT_PER >", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerGreaterThanOrEqualTo(String value) {
            addCriterion("APE_MAT_PER >=", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerLessThan(String value) {
            addCriterion("APE_MAT_PER <", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerLessThanOrEqualTo(String value) {
            addCriterion("APE_MAT_PER <=", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerLike(String value) {
            addCriterion("APE_MAT_PER like", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerNotLike(String value) {
            addCriterion("APE_MAT_PER not like", value, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerIn(List<String> values) {
            addCriterion("APE_MAT_PER in", values, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerNotIn(List<String> values) {
            addCriterion("APE_MAT_PER not in", values, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerBetween(String value1, String value2) {
            addCriterion("APE_MAT_PER between", value1, value2, "apeMatPer");
            return this;
        }

        public Criteria andApeMatPerNotBetween(String value1, String value2) {
            addCriterion("APE_MAT_PER not between", value1, value2, "apeMatPer");
            return this;
        }

        public Criteria andNomEmpPerIsNull() {
            addCriterion("NOM_EMP_PER is null");
            return this;
        }

        public Criteria andNomEmpPerIsNotNull() {
            addCriterion("NOM_EMP_PER is not null");
            return this;
        }

        public Criteria andNomEmpPerEqualTo(String value) {
            addCriterion("NOM_EMP_PER =", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerNotEqualTo(String value) {
            addCriterion("NOM_EMP_PER <>", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerGreaterThan(String value) {
            addCriterion("NOM_EMP_PER >", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerGreaterThanOrEqualTo(String value) {
            addCriterion("NOM_EMP_PER >=", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerLessThan(String value) {
            addCriterion("NOM_EMP_PER <", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerLessThanOrEqualTo(String value) {
            addCriterion("NOM_EMP_PER <=", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerLike(String value) {
            addCriterion("NOM_EMP_PER like", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerNotLike(String value) {
            addCriterion("NOM_EMP_PER not like", value, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerIn(List<String> values) {
            addCriterion("NOM_EMP_PER in", values, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerNotIn(List<String> values) {
            addCriterion("NOM_EMP_PER not in", values, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerBetween(String value1, String value2) {
            addCriterion("NOM_EMP_PER between", value1, value2, "nomEmpPer");
            return this;
        }

        public Criteria andNomEmpPerNotBetween(String value1, String value2) {
            addCriterion("NOM_EMP_PER not between", value1, value2, "nomEmpPer");
            return this;
        }

        public Criteria andNombCortPerIsNull() {
            addCriterion("NOMB_CORT_PER is null");
            return this;
        }

        public Criteria andNombCortPerIsNotNull() {
            addCriterion("NOMB_CORT_PER is not null");
            return this;
        }

        public Criteria andNombCortPerEqualTo(String value) {
            addCriterion("NOMB_CORT_PER =", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerNotEqualTo(String value) {
            addCriterion("NOMB_CORT_PER <>", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerGreaterThan(String value) {
            addCriterion("NOMB_CORT_PER >", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerGreaterThanOrEqualTo(String value) {
            addCriterion("NOMB_CORT_PER >=", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerLessThan(String value) {
            addCriterion("NOMB_CORT_PER <", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerLessThanOrEqualTo(String value) {
            addCriterion("NOMB_CORT_PER <=", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerLike(String value) {
            addCriterion("NOMB_CORT_PER like", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerNotLike(String value) {
            addCriterion("NOMB_CORT_PER not like", value, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerIn(List<String> values) {
            addCriterion("NOMB_CORT_PER in", values, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerNotIn(List<String> values) {
            addCriterion("NOMB_CORT_PER not in", values, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerBetween(String value1, String value2) {
            addCriterion("NOMB_CORT_PER between", value1, value2, "nombCortPer");
            return this;
        }

        public Criteria andNombCortPerNotBetween(String value1, String value2) {
            addCriterion("NOMB_CORT_PER not between", value1, value2, "nombCortPer");
            return this;
        }

        public Criteria andDirEmpPerIsNull() {
            addCriterion("DIR_EMP_PER is null");
            return this;
        }

        public Criteria andDirEmpPerIsNotNull() {
            addCriterion("DIR_EMP_PER is not null");
            return this;
        }

        public Criteria andDirEmpPerEqualTo(String value) {
            addCriterion("DIR_EMP_PER =", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerNotEqualTo(String value) {
            addCriterion("DIR_EMP_PER <>", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerGreaterThan(String value) {
            addCriterion("DIR_EMP_PER >", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerGreaterThanOrEqualTo(String value) {
            addCriterion("DIR_EMP_PER >=", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerLessThan(String value) {
            addCriterion("DIR_EMP_PER <", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerLessThanOrEqualTo(String value) {
            addCriterion("DIR_EMP_PER <=", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerLike(String value) {
            addCriterion("DIR_EMP_PER like", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerNotLike(String value) {
            addCriterion("DIR_EMP_PER not like", value, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerIn(List<String> values) {
            addCriterion("DIR_EMP_PER in", values, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerNotIn(List<String> values) {
            addCriterion("DIR_EMP_PER not in", values, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerBetween(String value1, String value2) {
            addCriterion("DIR_EMP_PER between", value1, value2, "dirEmpPer");
            return this;
        }

        public Criteria andDirEmpPerNotBetween(String value1, String value2) {
            addCriterion("DIR_EMP_PER not between", value1, value2, "dirEmpPer");
            return this;
        }

        public Criteria andCodiDepaDptIsNull() {
            addCriterion("CODI_DEPA_DPT is null");
            return this;
        }

        public Criteria andCodiDepaDptIsNotNull() {
            addCriterion("CODI_DEPA_DPT is not null");
            return this;
        }

        public Criteria andCodiDepaDptEqualTo(String value) {
            addCriterion("CODI_DEPA_DPT =", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptNotEqualTo(String value) {
            addCriterion("CODI_DEPA_DPT <>", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptGreaterThan(String value) {
            addCriterion("CODI_DEPA_DPT >", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_DEPA_DPT >=", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptLessThan(String value) {
            addCriterion("CODI_DEPA_DPT <", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptLessThanOrEqualTo(String value) {
            addCriterion("CODI_DEPA_DPT <=", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptLike(String value) {
            addCriterion("CODI_DEPA_DPT like", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptNotLike(String value) {
            addCriterion("CODI_DEPA_DPT not like", value, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptIn(List<String> values) {
            addCriterion("CODI_DEPA_DPT in", values, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptNotIn(List<String> values) {
            addCriterion("CODI_DEPA_DPT not in", values, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptBetween(String value1, String value2) {
            addCriterion("CODI_DEPA_DPT between", value1, value2, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiDepaDptNotBetween(String value1, String value2) {
            addCriterion("CODI_DEPA_DPT not between", value1, value2, "codiDepaDpt");
            return this;
        }

        public Criteria andCodiProvTprIsNull() {
            addCriterion("CODI_PROV_TPR is null");
            return this;
        }

        public Criteria andCodiProvTprIsNotNull() {
            addCriterion("CODI_PROV_TPR is not null");
            return this;
        }

        public Criteria andCodiProvTprEqualTo(String value) {
            addCriterion("CODI_PROV_TPR =", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprNotEqualTo(String value) {
            addCriterion("CODI_PROV_TPR <>", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprGreaterThan(String value) {
            addCriterion("CODI_PROV_TPR >", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_PROV_TPR >=", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprLessThan(String value) {
            addCriterion("CODI_PROV_TPR <", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprLessThanOrEqualTo(String value) {
            addCriterion("CODI_PROV_TPR <=", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprLike(String value) {
            addCriterion("CODI_PROV_TPR like", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprNotLike(String value) {
            addCriterion("CODI_PROV_TPR not like", value, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprIn(List<String> values) {
            addCriterion("CODI_PROV_TPR in", values, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprNotIn(List<String> values) {
            addCriterion("CODI_PROV_TPR not in", values, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprBetween(String value1, String value2) {
            addCriterion("CODI_PROV_TPR between", value1, value2, "codiProvTpr");
            return this;
        }

        public Criteria andCodiProvTprNotBetween(String value1, String value2) {
            addCriterion("CODI_PROV_TPR not between", value1, value2, "codiProvTpr");
            return this;
        }

        public Criteria andCodiDistTdiIsNull() {
            addCriterion("CODI_DIST_TDI is null");
            return this;
        }

        public Criteria andCodiDistTdiIsNotNull() {
            addCriterion("CODI_DIST_TDI is not null");
            return this;
        }

        public Criteria andCodiDistTdiEqualTo(String value) {
            addCriterion("CODI_DIST_TDI =", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiNotEqualTo(String value) {
            addCriterion("CODI_DIST_TDI <>", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiGreaterThan(String value) {
            addCriterion("CODI_DIST_TDI >", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_DIST_TDI >=", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiLessThan(String value) {
            addCriterion("CODI_DIST_TDI <", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiLessThanOrEqualTo(String value) {
            addCriterion("CODI_DIST_TDI <=", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiLike(String value) {
            addCriterion("CODI_DIST_TDI like", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiNotLike(String value) {
            addCriterion("CODI_DIST_TDI not like", value, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiIn(List<String> values) {
            addCriterion("CODI_DIST_TDI in", values, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiNotIn(List<String> values) {
            addCriterion("CODI_DIST_TDI not in", values, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiBetween(String value1, String value2) {
            addCriterion("CODI_DIST_TDI between", value1, value2, "codiDistTdi");
            return this;
        }

        public Criteria andCodiDistTdiNotBetween(String value1, String value2) {
            addCriterion("CODI_DIST_TDI not between", value1, value2, "codiDistTdi");
            return this;
        }

        public Criteria andNumTelPerIsNull() {
            addCriterion("NUM_TEL_PER is null");
            return this;
        }

        public Criteria andNumTelPerIsNotNull() {
            addCriterion("NUM_TEL_PER is not null");
            return this;
        }

        public Criteria andNumTelPerEqualTo(String value) {
            addCriterion("NUM_TEL_PER =", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerNotEqualTo(String value) {
            addCriterion("NUM_TEL_PER <>", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerGreaterThan(String value) {
            addCriterion("NUM_TEL_PER >", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerGreaterThanOrEqualTo(String value) {
            addCriterion("NUM_TEL_PER >=", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerLessThan(String value) {
            addCriterion("NUM_TEL_PER <", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerLessThanOrEqualTo(String value) {
            addCriterion("NUM_TEL_PER <=", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerLike(String value) {
            addCriterion("NUM_TEL_PER like", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerNotLike(String value) {
            addCriterion("NUM_TEL_PER not like", value, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerIn(List<String> values) {
            addCriterion("NUM_TEL_PER in", values, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerNotIn(List<String> values) {
            addCriterion("NUM_TEL_PER not in", values, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerBetween(String value1, String value2) {
            addCriterion("NUM_TEL_PER between", value1, value2, "numTelPer");
            return this;
        }

        public Criteria andNumTelPerNotBetween(String value1, String value2) {
            addCriterion("NUM_TEL_PER not between", value1, value2, "numTelPer");
            return this;
        }

        public Criteria andFecIngPerIsNull() {
            addCriterion("FEC_ING_PER is null");
            return this;
        }

        public Criteria andFecIngPerIsNotNull() {
            addCriterion("FEC_ING_PER is not null");
            return this;
        }

        public Criteria andFecIngPerEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_ING_PER =", value, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_ING_PER <>", value, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerGreaterThan(Date value) {
            addCriterionForJDBCDate("FEC_ING_PER >", value, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_ING_PER >=", value, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerLessThan(Date value) {
            addCriterionForJDBCDate("FEC_ING_PER <", value, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_ING_PER <=", value, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerIn(List<Date> values) {
            addCriterionForJDBCDate("FEC_ING_PER in", values, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FEC_ING_PER not in", values, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FEC_ING_PER between", value1, value2, "fecIngPer");
            return this;
        }

        public Criteria andFecIngPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FEC_ING_PER not between", value1, value2, "fecIngPer");
            return this;
        }

        public Criteria andTipoPlanTplIsNull() {
            addCriterion("TIPO_PLAN_TPL is null");
            return this;
        }

        public Criteria andTipoPlanTplIsNotNull() {
            addCriterion("TIPO_PLAN_TPL is not null");
            return this;
        }

        public Criteria andTipoPlanTplEqualTo(String value) {
            addCriterion("TIPO_PLAN_TPL =", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplNotEqualTo(String value) {
            addCriterion("TIPO_PLAN_TPL <>", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplGreaterThan(String value) {
            addCriterion("TIPO_PLAN_TPL >", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplGreaterThanOrEqualTo(String value) {
            addCriterion("TIPO_PLAN_TPL >=", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplLessThan(String value) {
            addCriterion("TIPO_PLAN_TPL <", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplLessThanOrEqualTo(String value) {
            addCriterion("TIPO_PLAN_TPL <=", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplLike(String value) {
            addCriterion("TIPO_PLAN_TPL like", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplNotLike(String value) {
            addCriterion("TIPO_PLAN_TPL not like", value, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplIn(List<String> values) {
            addCriterion("TIPO_PLAN_TPL in", values, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplNotIn(List<String> values) {
            addCriterion("TIPO_PLAN_TPL not in", values, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplBetween(String value1, String value2) {
            addCriterion("TIPO_PLAN_TPL between", value1, value2, "tipoPlanTpl");
            return this;
        }

        public Criteria andTipoPlanTplNotBetween(String value1, String value2) {
            addCriterion("TIPO_PLAN_TPL not between", value1, value2, "tipoPlanTpl");
            return this;
        }

        public Criteria andEstCivPerIsNull() {
            addCriterion("EST_CIV_PER is null");
            return this;
        }

        public Criteria andEstCivPerIsNotNull() {
            addCriterion("EST_CIV_PER is not null");
            return this;
        }

        public Criteria andEstCivPerEqualTo(String value) {
            addCriterion("EST_CIV_PER =", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerNotEqualTo(String value) {
            addCriterion("EST_CIV_PER <>", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerGreaterThan(String value) {
            addCriterion("EST_CIV_PER >", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerGreaterThanOrEqualTo(String value) {
            addCriterion("EST_CIV_PER >=", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerLessThan(String value) {
            addCriterion("EST_CIV_PER <", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerLessThanOrEqualTo(String value) {
            addCriterion("EST_CIV_PER <=", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerLike(String value) {
            addCriterion("EST_CIV_PER like", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerNotLike(String value) {
            addCriterion("EST_CIV_PER not like", value, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerIn(List<String> values) {
            addCriterion("EST_CIV_PER in", values, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerNotIn(List<String> values) {
            addCriterion("EST_CIV_PER not in", values, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerBetween(String value1, String value2) {
            addCriterion("EST_CIV_PER between", value1, value2, "estCivPer");
            return this;
        }

        public Criteria andEstCivPerNotBetween(String value1, String value2) {
            addCriterion("EST_CIV_PER not between", value1, value2, "estCivPer");
            return this;
        }

        public Criteria andSexEmpPerIsNull() {
            addCriterion("SEX_EMP_PER is null");
            return this;
        }

        public Criteria andSexEmpPerIsNotNull() {
            addCriterion("SEX_EMP_PER is not null");
            return this;
        }

        public Criteria andSexEmpPerEqualTo(String value) {
            addCriterion("SEX_EMP_PER =", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerNotEqualTo(String value) {
            addCriterion("SEX_EMP_PER <>", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerGreaterThan(String value) {
            addCriterion("SEX_EMP_PER >", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerGreaterThanOrEqualTo(String value) {
            addCriterion("SEX_EMP_PER >=", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerLessThan(String value) {
            addCriterion("SEX_EMP_PER <", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerLessThanOrEqualTo(String value) {
            addCriterion("SEX_EMP_PER <=", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerLike(String value) {
            addCriterion("SEX_EMP_PER like", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerNotLike(String value) {
            addCriterion("SEX_EMP_PER not like", value, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerIn(List<String> values) {
            addCriterion("SEX_EMP_PER in", values, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerNotIn(List<String> values) {
            addCriterion("SEX_EMP_PER not in", values, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerBetween(String value1, String value2) {
            addCriterion("SEX_EMP_PER between", value1, value2, "sexEmpPer");
            return this;
        }

        public Criteria andSexEmpPerNotBetween(String value1, String value2) {
            addCriterion("SEX_EMP_PER not between", value1, value2, "sexEmpPer");
            return this;
        }

        public Criteria andGraInsPerIsNull() {
            addCriterion("GRA_INS_PER is null");
            return this;
        }

        public Criteria andGraInsPerIsNotNull() {
            addCriterion("GRA_INS_PER is not null");
            return this;
        }

        public Criteria andGraInsPerEqualTo(String value) {
            addCriterion("GRA_INS_PER =", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerNotEqualTo(String value) {
            addCriterion("GRA_INS_PER <>", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerGreaterThan(String value) {
            addCriterion("GRA_INS_PER >", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerGreaterThanOrEqualTo(String value) {
            addCriterion("GRA_INS_PER >=", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerLessThan(String value) {
            addCriterion("GRA_INS_PER <", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerLessThanOrEqualTo(String value) {
            addCriterion("GRA_INS_PER <=", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerLike(String value) {
            addCriterion("GRA_INS_PER like", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerNotLike(String value) {
            addCriterion("GRA_INS_PER not like", value, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerIn(List<String> values) {
            addCriterion("GRA_INS_PER in", values, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerNotIn(List<String> values) {
            addCriterion("GRA_INS_PER not in", values, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerBetween(String value1, String value2) {
            addCriterion("GRA_INS_PER between", value1, value2, "graInsPer");
            return this;
        }

        public Criteria andGraInsPerNotBetween(String value1, String value2) {
            addCriterion("GRA_INS_PER not between", value1, value2, "graInsPer");
            return this;
        }

        public Criteria andFecNacPerIsNull() {
            addCriterion("FEC_NAC_PER is null");
            return this;
        }

        public Criteria andFecNacPerIsNotNull() {
            addCriterion("FEC_NAC_PER is not null");
            return this;
        }

        public Criteria andFecNacPerEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_NAC_PER =", value, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_NAC_PER <>", value, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerGreaterThan(Date value) {
            addCriterionForJDBCDate("FEC_NAC_PER >", value, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_NAC_PER >=", value, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerLessThan(Date value) {
            addCriterionForJDBCDate("FEC_NAC_PER <", value, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_NAC_PER <=", value, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerIn(List<Date> values) {
            addCriterionForJDBCDate("FEC_NAC_PER in", values, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FEC_NAC_PER not in", values, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FEC_NAC_PER between", value1, value2, "fecNacPer");
            return this;
        }

        public Criteria andFecNacPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FEC_NAC_PER not between", value1, value2, "fecNacPer");
            return this;
        }

        public Criteria andPaisNaciTpaIsNull() {
            addCriterion("PAIS_NACI_TPA is null");
            return this;
        }

        public Criteria andPaisNaciTpaIsNotNull() {
            addCriterion("PAIS_NACI_TPA is not null");
            return this;
        }

        public Criteria andPaisNaciTpaEqualTo(String value) {
            addCriterion("PAIS_NACI_TPA =", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaNotEqualTo(String value) {
            addCriterion("PAIS_NACI_TPA <>", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaGreaterThan(String value) {
            addCriterion("PAIS_NACI_TPA >", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaGreaterThanOrEqualTo(String value) {
            addCriterion("PAIS_NACI_TPA >=", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaLessThan(String value) {
            addCriterion("PAIS_NACI_TPA <", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaLessThanOrEqualTo(String value) {
            addCriterion("PAIS_NACI_TPA <=", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaLike(String value) {
            addCriterion("PAIS_NACI_TPA like", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaNotLike(String value) {
            addCriterion("PAIS_NACI_TPA not like", value, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaIn(List<String> values) {
            addCriterion("PAIS_NACI_TPA in", values, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaNotIn(List<String> values) {
            addCriterion("PAIS_NACI_TPA not in", values, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaBetween(String value1, String value2) {
            addCriterion("PAIS_NACI_TPA between", value1, value2, "paisNaciTpa");
            return this;
        }

        public Criteria andPaisNaciTpaNotBetween(String value1, String value2) {
            addCriterion("PAIS_NACI_TPA not between", value1, value2, "paisNaciTpa");
            return this;
        }

        public Criteria andDepaNaciDptIsNull() {
            addCriterion("DEPA_NACI_DPT is null");
            return this;
        }

        public Criteria andDepaNaciDptIsNotNull() {
            addCriterion("DEPA_NACI_DPT is not null");
            return this;
        }

        public Criteria andDepaNaciDptEqualTo(String value) {
            addCriterion("DEPA_NACI_DPT =", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptNotEqualTo(String value) {
            addCriterion("DEPA_NACI_DPT <>", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptGreaterThan(String value) {
            addCriterion("DEPA_NACI_DPT >", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptGreaterThanOrEqualTo(String value) {
            addCriterion("DEPA_NACI_DPT >=", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptLessThan(String value) {
            addCriterion("DEPA_NACI_DPT <", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptLessThanOrEqualTo(String value) {
            addCriterion("DEPA_NACI_DPT <=", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptLike(String value) {
            addCriterion("DEPA_NACI_DPT like", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptNotLike(String value) {
            addCriterion("DEPA_NACI_DPT not like", value, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptIn(List<String> values) {
            addCriterion("DEPA_NACI_DPT in", values, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptNotIn(List<String> values) {
            addCriterion("DEPA_NACI_DPT not in", values, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptBetween(String value1, String value2) {
            addCriterion("DEPA_NACI_DPT between", value1, value2, "depaNaciDpt");
            return this;
        }

        public Criteria andDepaNaciDptNotBetween(String value1, String value2) {
            addCriterion("DEPA_NACI_DPT not between", value1, value2, "depaNaciDpt");
            return this;
        }

        public Criteria andProvNaciTprIsNull() {
            addCriterion("PROV_NACI_TPR is null");
            return this;
        }

        public Criteria andProvNaciTprIsNotNull() {
            addCriterion("PROV_NACI_TPR is not null");
            return this;
        }

        public Criteria andProvNaciTprEqualTo(String value) {
            addCriterion("PROV_NACI_TPR =", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprNotEqualTo(String value) {
            addCriterion("PROV_NACI_TPR <>", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprGreaterThan(String value) {
            addCriterion("PROV_NACI_TPR >", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprGreaterThanOrEqualTo(String value) {
            addCriterion("PROV_NACI_TPR >=", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprLessThan(String value) {
            addCriterion("PROV_NACI_TPR <", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprLessThanOrEqualTo(String value) {
            addCriterion("PROV_NACI_TPR <=", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprLike(String value) {
            addCriterion("PROV_NACI_TPR like", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprNotLike(String value) {
            addCriterion("PROV_NACI_TPR not like", value, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprIn(List<String> values) {
            addCriterion("PROV_NACI_TPR in", values, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprNotIn(List<String> values) {
            addCriterion("PROV_NACI_TPR not in", values, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprBetween(String value1, String value2) {
            addCriterion("PROV_NACI_TPR between", value1, value2, "provNaciTpr");
            return this;
        }

        public Criteria andProvNaciTprNotBetween(String value1, String value2) {
            addCriterion("PROV_NACI_TPR not between", value1, value2, "provNaciTpr");
            return this;
        }

        public Criteria andDistNaciTdiIsNull() {
            addCriterion("DIST_NACI_TDI is null");
            return this;
        }

        public Criteria andDistNaciTdiIsNotNull() {
            addCriterion("DIST_NACI_TDI is not null");
            return this;
        }

        public Criteria andDistNaciTdiEqualTo(String value) {
            addCriterion("DIST_NACI_TDI =", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiNotEqualTo(String value) {
            addCriterion("DIST_NACI_TDI <>", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiGreaterThan(String value) {
            addCriterion("DIST_NACI_TDI >", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiGreaterThanOrEqualTo(String value) {
            addCriterion("DIST_NACI_TDI >=", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiLessThan(String value) {
            addCriterion("DIST_NACI_TDI <", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiLessThanOrEqualTo(String value) {
            addCriterion("DIST_NACI_TDI <=", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiLike(String value) {
            addCriterion("DIST_NACI_TDI like", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiNotLike(String value) {
            addCriterion("DIST_NACI_TDI not like", value, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiIn(List<String> values) {
            addCriterion("DIST_NACI_TDI in", values, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiNotIn(List<String> values) {
            addCriterion("DIST_NACI_TDI not in", values, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiBetween(String value1, String value2) {
            addCriterion("DIST_NACI_TDI between", value1, value2, "distNaciTdi");
            return this;
        }

        public Criteria andDistNaciTdiNotBetween(String value1, String value2) {
            addCriterion("DIST_NACI_TDI not between", value1, value2, "distNaciTdi");
            return this;
        }

        public Criteria andCodiDepeTdeIsNull() {
            addCriterion("CODI_DEPE_TDE is null");
            return this;
        }

        public Criteria andCodiDepeTdeIsNotNull() {
            addCriterion("CODI_DEPE_TDE is not null");
            return this;
        }

        public Criteria andCodiDepeTdeEqualTo(String value) {
            addCriterion("CODI_DEPE_TDE =", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeNotEqualTo(String value) {
            addCriterion("CODI_DEPE_TDE <>", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeGreaterThan(String value) {
            addCriterion("CODI_DEPE_TDE >", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_DEPE_TDE >=", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeLessThan(String value) {
            addCriterion("CODI_DEPE_TDE <", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeLessThanOrEqualTo(String value) {
            addCriterion("CODI_DEPE_TDE <=", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeLike(String value) {
            addCriterion("CODI_DEPE_TDE like", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeNotLike(String value) {
            addCriterion("CODI_DEPE_TDE not like", value, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeIn(List<String> values) {
            addCriterion("CODI_DEPE_TDE in", values, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeNotIn(List<String> values) {
            addCriterion("CODI_DEPE_TDE not in", values, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeBetween(String value1, String value2) {
            addCriterion("CODI_DEPE_TDE between", value1, value2, "codiDepeTde");
            return this;
        }

        public Criteria andCodiDepeTdeNotBetween(String value1, String value2) {
            addCriterion("CODI_DEPE_TDE not between", value1, value2, "codiDepeTde");
            return this;
        }

        public Criteria andUbicFisiTdeIsNull() {
            addCriterion("UBIC_FISI_TDE is null");
            return this;
        }

        public Criteria andUbicFisiTdeIsNotNull() {
            addCriterion("UBIC_FISI_TDE is not null");
            return this;
        }

        public Criteria andUbicFisiTdeEqualTo(String value) {
            addCriterion("UBIC_FISI_TDE =", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeNotEqualTo(String value) {
            addCriterion("UBIC_FISI_TDE <>", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeGreaterThan(String value) {
            addCriterion("UBIC_FISI_TDE >", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeGreaterThanOrEqualTo(String value) {
            addCriterion("UBIC_FISI_TDE >=", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeLessThan(String value) {
            addCriterion("UBIC_FISI_TDE <", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeLessThanOrEqualTo(String value) {
            addCriterion("UBIC_FISI_TDE <=", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeLike(String value) {
            addCriterion("UBIC_FISI_TDE like", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeNotLike(String value) {
            addCriterion("UBIC_FISI_TDE not like", value, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeIn(List<String> values) {
            addCriterion("UBIC_FISI_TDE in", values, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeNotIn(List<String> values) {
            addCriterion("UBIC_FISI_TDE not in", values, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeBetween(String value1, String value2) {
            addCriterion("UBIC_FISI_TDE between", value1, value2, "ubicFisiTde");
            return this;
        }

        public Criteria andUbicFisiTdeNotBetween(String value1, String value2) {
            addCriterion("UBIC_FISI_TDE not between", value1, value2, "ubicFisiTde");
            return this;
        }

        public Criteria andCodiNiveTniIsNull() {
            addCriterion("CODI_NIVE_TNI is null");
            return this;
        }

        public Criteria andCodiNiveTniIsNotNull() {
            addCriterion("CODI_NIVE_TNI is not null");
            return this;
        }

        public Criteria andCodiNiveTniEqualTo(String value) {
            addCriterion("CODI_NIVE_TNI =", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniNotEqualTo(String value) {
            addCriterion("CODI_NIVE_TNI <>", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniGreaterThan(String value) {
            addCriterion("CODI_NIVE_TNI >", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_NIVE_TNI >=", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniLessThan(String value) {
            addCriterion("CODI_NIVE_TNI <", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniLessThanOrEqualTo(String value) {
            addCriterion("CODI_NIVE_TNI <=", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniLike(String value) {
            addCriterion("CODI_NIVE_TNI like", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniNotLike(String value) {
            addCriterion("CODI_NIVE_TNI not like", value, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniIn(List<String> values) {
            addCriterion("CODI_NIVE_TNI in", values, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniNotIn(List<String> values) {
            addCriterion("CODI_NIVE_TNI not in", values, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniBetween(String value1, String value2) {
            addCriterion("CODI_NIVE_TNI between", value1, value2, "codiNiveTni");
            return this;
        }

        public Criteria andCodiNiveTniNotBetween(String value1, String value2) {
            addCriterion("CODI_NIVE_TNI not between", value1, value2, "codiNiveTni");
            return this;
        }

        public Criteria andNiveEncTniIsNull() {
            addCriterion("NIVE_ENC_TNI is null");
            return this;
        }

        public Criteria andNiveEncTniIsNotNull() {
            addCriterion("NIVE_ENC_TNI is not null");
            return this;
        }

        public Criteria andNiveEncTniEqualTo(String value) {
            addCriterion("NIVE_ENC_TNI =", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniNotEqualTo(String value) {
            addCriterion("NIVE_ENC_TNI <>", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniGreaterThan(String value) {
            addCriterion("NIVE_ENC_TNI >", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniGreaterThanOrEqualTo(String value) {
            addCriterion("NIVE_ENC_TNI >=", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniLessThan(String value) {
            addCriterion("NIVE_ENC_TNI <", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniLessThanOrEqualTo(String value) {
            addCriterion("NIVE_ENC_TNI <=", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniLike(String value) {
            addCriterion("NIVE_ENC_TNI like", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniNotLike(String value) {
            addCriterion("NIVE_ENC_TNI not like", value, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniIn(List<String> values) {
            addCriterion("NIVE_ENC_TNI in", values, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniNotIn(List<String> values) {
            addCriterion("NIVE_ENC_TNI not in", values, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniBetween(String value1, String value2) {
            addCriterion("NIVE_ENC_TNI between", value1, value2, "niveEncTni");
            return this;
        }

        public Criteria andNiveEncTniNotBetween(String value1, String value2) {
            addCriterion("NIVE_ENC_TNI not between", value1, value2, "niveEncTni");
            return this;
        }

        public Criteria andEstaTrabPerIsNull() {
            addCriterion("ESTA_TRAB_PER is null");
            return this;
        }

        public Criteria andEstaTrabPerIsNotNull() {
            addCriterion("ESTA_TRAB_PER is not null");
            return this;
        }

        public Criteria andEstaTrabPerEqualTo(String value) {
            addCriterion("ESTA_TRAB_PER =", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerNotEqualTo(String value) {
            addCriterion("ESTA_TRAB_PER <>", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerGreaterThan(String value) {
            addCriterion("ESTA_TRAB_PER >", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerGreaterThanOrEqualTo(String value) {
            addCriterion("ESTA_TRAB_PER >=", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerLessThan(String value) {
            addCriterion("ESTA_TRAB_PER <", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerLessThanOrEqualTo(String value) {
            addCriterion("ESTA_TRAB_PER <=", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerLike(String value) {
            addCriterion("ESTA_TRAB_PER like", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerNotLike(String value) {
            addCriterion("ESTA_TRAB_PER not like", value, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerIn(List<String> values) {
            addCriterion("ESTA_TRAB_PER in", values, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerNotIn(List<String> values) {
            addCriterion("ESTA_TRAB_PER not in", values, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerBetween(String value1, String value2) {
            addCriterion("ESTA_TRAB_PER between", value1, value2, "estaTrabPer");
            return this;
        }

        public Criteria andEstaTrabPerNotBetween(String value1, String value2) {
            addCriterion("ESTA_TRAB_PER not between", value1, value2, "estaTrabPer");
            return this;
        }

        public Criteria andConTraPerIsNull() {
            addCriterion("CON_TRA_PER is null");
            return this;
        }

        public Criteria andConTraPerIsNotNull() {
            addCriterion("CON_TRA_PER is not null");
            return this;
        }

        public Criteria andConTraPerEqualTo(String value) {
            addCriterion("CON_TRA_PER =", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerNotEqualTo(String value) {
            addCriterion("CON_TRA_PER <>", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerGreaterThan(String value) {
            addCriterion("CON_TRA_PER >", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerGreaterThanOrEqualTo(String value) {
            addCriterion("CON_TRA_PER >=", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerLessThan(String value) {
            addCriterion("CON_TRA_PER <", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerLessThanOrEqualTo(String value) {
            addCriterion("CON_TRA_PER <=", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerLike(String value) {
            addCriterion("CON_TRA_PER like", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerNotLike(String value) {
            addCriterion("CON_TRA_PER not like", value, "conTraPer");
            return this;
        }

        public Criteria andConTraPerIn(List<String> values) {
            addCriterion("CON_TRA_PER in", values, "conTraPer");
            return this;
        }

        public Criteria andConTraPerNotIn(List<String> values) {
            addCriterion("CON_TRA_PER not in", values, "conTraPer");
            return this;
        }

        public Criteria andConTraPerBetween(String value1, String value2) {
            addCriterion("CON_TRA_PER between", value1, value2, "conTraPer");
            return this;
        }

        public Criteria andConTraPerNotBetween(String value1, String value2) {
            addCriterion("CON_TRA_PER not between", value1, value2, "conTraPer");
            return this;
        }

        public Criteria andRegLabPerIsNull() {
            addCriterion("REG_LAB_PER is null");
            return this;
        }

        public Criteria andRegLabPerIsNotNull() {
            addCriterion("REG_LAB_PER is not null");
            return this;
        }

        public Criteria andRegLabPerEqualTo(String value) {
            addCriterion("REG_LAB_PER =", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerNotEqualTo(String value) {
            addCriterion("REG_LAB_PER <>", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerGreaterThan(String value) {
            addCriterion("REG_LAB_PER >", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerGreaterThanOrEqualTo(String value) {
            addCriterion("REG_LAB_PER >=", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerLessThan(String value) {
            addCriterion("REG_LAB_PER <", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerLessThanOrEqualTo(String value) {
            addCriterion("REG_LAB_PER <=", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerLike(String value) {
            addCriterion("REG_LAB_PER like", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerNotLike(String value) {
            addCriterion("REG_LAB_PER not like", value, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerIn(List<String> values) {
            addCriterion("REG_LAB_PER in", values, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerNotIn(List<String> values) {
            addCriterion("REG_LAB_PER not in", values, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerBetween(String value1, String value2) {
            addCriterion("REG_LAB_PER between", value1, value2, "regLabPer");
            return this;
        }

        public Criteria andRegLabPerNotBetween(String value1, String value2) {
            addCriterion("REG_LAB_PER not between", value1, value2, "regLabPer");
            return this;
        }

        public Criteria andRegPenPerIsNull() {
            addCriterion("REG_PEN_PER is null");
            return this;
        }

        public Criteria andRegPenPerIsNotNull() {
            addCriterion("REG_PEN_PER is not null");
            return this;
        }

        public Criteria andRegPenPerEqualTo(String value) {
            addCriterion("REG_PEN_PER =", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerNotEqualTo(String value) {
            addCriterion("REG_PEN_PER <>", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerGreaterThan(String value) {
            addCriterion("REG_PEN_PER >", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerGreaterThanOrEqualTo(String value) {
            addCriterion("REG_PEN_PER >=", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerLessThan(String value) {
            addCriterion("REG_PEN_PER <", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerLessThanOrEqualTo(String value) {
            addCriterion("REG_PEN_PER <=", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerLike(String value) {
            addCriterion("REG_PEN_PER like", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerNotLike(String value) {
            addCriterion("REG_PEN_PER not like", value, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerIn(List<String> values) {
            addCriterion("REG_PEN_PER in", values, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerNotIn(List<String> values) {
            addCriterion("REG_PEN_PER not in", values, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerBetween(String value1, String value2) {
            addCriterion("REG_PEN_PER between", value1, value2, "regPenPer");
            return this;
        }

        public Criteria andRegPenPerNotBetween(String value1, String value2) {
            addCriterion("REG_PEN_PER not between", value1, value2, "regPenPer");
            return this;
        }

        public Criteria andCodiCargTcaIsNull() {
            addCriterion("CODI_CARG_TCA is null");
            return this;
        }

        public Criteria andCodiCargTcaIsNotNull() {
            addCriterion("CODI_CARG_TCA is not null");
            return this;
        }

        public Criteria andCodiCargTcaEqualTo(String value) {
            addCriterion("CODI_CARG_TCA =", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaNotEqualTo(String value) {
            addCriterion("CODI_CARG_TCA <>", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaGreaterThan(String value) {
            addCriterion("CODI_CARG_TCA >", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_CARG_TCA >=", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaLessThan(String value) {
            addCriterion("CODI_CARG_TCA <", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaLessThanOrEqualTo(String value) {
            addCriterion("CODI_CARG_TCA <=", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaLike(String value) {
            addCriterion("CODI_CARG_TCA like", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaNotLike(String value) {
            addCriterion("CODI_CARG_TCA not like", value, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaIn(List<String> values) {
            addCriterion("CODI_CARG_TCA in", values, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaNotIn(List<String> values) {
            addCriterion("CODI_CARG_TCA not in", values, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaBetween(String value1, String value2) {
            addCriterion("CODI_CARG_TCA between", value1, value2, "codiCargTca");
            return this;
        }

        public Criteria andCodiCargTcaNotBetween(String value1, String value2) {
            addCriterion("CODI_CARG_TCA not between", value1, value2, "codiCargTca");
            return this;
        }

        public Criteria andCargEncTcaIsNull() {
            addCriterion("CARG_ENC_TCA is null");
            return this;
        }

        public Criteria andCargEncTcaIsNotNull() {
            addCriterion("CARG_ENC_TCA is not null");
            return this;
        }

        public Criteria andCargEncTcaEqualTo(String value) {
            addCriterion("CARG_ENC_TCA =", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaNotEqualTo(String value) {
            addCriterion("CARG_ENC_TCA <>", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaGreaterThan(String value) {
            addCriterion("CARG_ENC_TCA >", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaGreaterThanOrEqualTo(String value) {
            addCriterion("CARG_ENC_TCA >=", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaLessThan(String value) {
            addCriterion("CARG_ENC_TCA <", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaLessThanOrEqualTo(String value) {
            addCriterion("CARG_ENC_TCA <=", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaLike(String value) {
            addCriterion("CARG_ENC_TCA like", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaNotLike(String value) {
            addCriterion("CARG_ENC_TCA not like", value, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaIn(List<String> values) {
            addCriterion("CARG_ENC_TCA in", values, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaNotIn(List<String> values) {
            addCriterion("CARG_ENC_TCA not in", values, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaBetween(String value1, String value2) {
            addCriterion("CARG_ENC_TCA between", value1, value2, "cargEncTca");
            return this;
        }

        public Criteria andCargEncTcaNotBetween(String value1, String value2) {
            addCriterion("CARG_ENC_TCA not between", value1, value2, "cargEncTca");
            return this;
        }

        public Criteria andFlagAfpPerIsNull() {
            addCriterion("FLAG_AFP_PER is null");
            return this;
        }

        public Criteria andFlagAfpPerIsNotNull() {
            addCriterion("FLAG_AFP_PER is not null");
            return this;
        }

        public Criteria andFlagAfpPerEqualTo(String value) {
            addCriterion("FLAG_AFP_PER =", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerNotEqualTo(String value) {
            addCriterion("FLAG_AFP_PER <>", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerGreaterThan(String value) {
            addCriterion("FLAG_AFP_PER >", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerGreaterThanOrEqualTo(String value) {
            addCriterion("FLAG_AFP_PER >=", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerLessThan(String value) {
            addCriterion("FLAG_AFP_PER <", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerLessThanOrEqualTo(String value) {
            addCriterion("FLAG_AFP_PER <=", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerLike(String value) {
            addCriterion("FLAG_AFP_PER like", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerNotLike(String value) {
            addCriterion("FLAG_AFP_PER not like", value, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerIn(List<String> values) {
            addCriterion("FLAG_AFP_PER in", values, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerNotIn(List<String> values) {
            addCriterion("FLAG_AFP_PER not in", values, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerBetween(String value1, String value2) {
            addCriterion("FLAG_AFP_PER between", value1, value2, "flagAfpPer");
            return this;
        }

        public Criteria andFlagAfpPerNotBetween(String value1, String value2) {
            addCriterion("FLAG_AFP_PER not between", value1, value2, "flagAfpPer");
            return this;
        }

        public Criteria andCodiAfpIsNull() {
            addCriterion("CODI_AFP is null");
            return this;
        }

        public Criteria andCodiAfpIsNotNull() {
            addCriterion("CODI_AFP is not null");
            return this;
        }

        public Criteria andCodiAfpEqualTo(String value) {
            addCriterion("CODI_AFP =", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpNotEqualTo(String value) {
            addCriterion("CODI_AFP <>", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpGreaterThan(String value) {
            addCriterion("CODI_AFP >", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_AFP >=", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpLessThan(String value) {
            addCriterion("CODI_AFP <", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpLessThanOrEqualTo(String value) {
            addCriterion("CODI_AFP <=", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpLike(String value) {
            addCriterion("CODI_AFP like", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpNotLike(String value) {
            addCriterion("CODI_AFP not like", value, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpIn(List<String> values) {
            addCriterion("CODI_AFP in", values, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpNotIn(List<String> values) {
            addCriterion("CODI_AFP not in", values, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpBetween(String value1, String value2) {
            addCriterion("CODI_AFP between", value1, value2, "codiAfp");
            return this;
        }

        public Criteria andCodiAfpNotBetween(String value1, String value2) {
            addCriterion("CODI_AFP not between", value1, value2, "codiAfp");
            return this;
        }

        public Criteria andFechAfpPerIsNull() {
            addCriterion("FECH_AFP_PER is null");
            return this;
        }

        public Criteria andFechAfpPerIsNotNull() {
            addCriterion("FECH_AFP_PER is not null");
            return this;
        }

        public Criteria andFechAfpPerEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_AFP_PER =", value, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_AFP_PER <>", value, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerGreaterThan(Date value) {
            addCriterionForJDBCDate("FECH_AFP_PER >", value, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_AFP_PER >=", value, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerLessThan(Date value) {
            addCriterionForJDBCDate("FECH_AFP_PER <", value, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_AFP_PER <=", value, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_AFP_PER in", values, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_AFP_PER not in", values, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_AFP_PER between", value1, value2, "fechAfpPer");
            return this;
        }

        public Criteria andFechAfpPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_AFP_PER not between", value1, value2, "fechAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerIsNull() {
            addCriterion("CODI_AFP_PER is null");
            return this;
        }

        public Criteria andCodiAfpPerIsNotNull() {
            addCriterion("CODI_AFP_PER is not null");
            return this;
        }

        public Criteria andCodiAfpPerEqualTo(String value) {
            addCriterion("CODI_AFP_PER =", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerNotEqualTo(String value) {
            addCriterion("CODI_AFP_PER <>", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerGreaterThan(String value) {
            addCriterion("CODI_AFP_PER >", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_AFP_PER >=", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerLessThan(String value) {
            addCriterion("CODI_AFP_PER <", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerLessThanOrEqualTo(String value) {
            addCriterion("CODI_AFP_PER <=", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerLike(String value) {
            addCriterion("CODI_AFP_PER like", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerNotLike(String value) {
            addCriterion("CODI_AFP_PER not like", value, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerIn(List<String> values) {
            addCriterion("CODI_AFP_PER in", values, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerNotIn(List<String> values) {
            addCriterion("CODI_AFP_PER not in", values, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerBetween(String value1, String value2) {
            addCriterion("CODI_AFP_PER between", value1, value2, "codiAfpPer");
            return this;
        }

        public Criteria andCodiAfpPerNotBetween(String value1, String value2) {
            addCriterion("CODI_AFP_PER not between", value1, value2, "codiAfpPer");
            return this;
        }

        public Criteria andLibrElecPerIsNull() {
            addCriterion("LIBR_ELEC_PER is null");
            return this;
        }

        public Criteria andLibrElecPerIsNotNull() {
            addCriterion("LIBR_ELEC_PER is not null");
            return this;
        }

        public Criteria andLibrElecPerEqualTo(String value) {
            addCriterion("LIBR_ELEC_PER =", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerNotEqualTo(String value) {
            addCriterion("LIBR_ELEC_PER <>", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerGreaterThan(String value) {
            addCriterion("LIBR_ELEC_PER >", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerGreaterThanOrEqualTo(String value) {
            addCriterion("LIBR_ELEC_PER >=", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerLessThan(String value) {
            addCriterion("LIBR_ELEC_PER <", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerLessThanOrEqualTo(String value) {
            addCriterion("LIBR_ELEC_PER <=", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerLike(String value) {
            addCriterion("LIBR_ELEC_PER like", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerNotLike(String value) {
            addCriterion("LIBR_ELEC_PER not like", value, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerIn(List<String> values) {
            addCriterion("LIBR_ELEC_PER in", values, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerNotIn(List<String> values) {
            addCriterion("LIBR_ELEC_PER not in", values, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerBetween(String value1, String value2) {
            addCriterion("LIBR_ELEC_PER between", value1, value2, "librElecPer");
            return this;
        }

        public Criteria andLibrElecPerNotBetween(String value1, String value2) {
            addCriterion("LIBR_ELEC_PER not between", value1, value2, "librElecPer");
            return this;
        }

        public Criteria andLibrMiliPerIsNull() {
            addCriterion("LIBR_MILI_PER is null");
            return this;
        }

        public Criteria andLibrMiliPerIsNotNull() {
            addCriterion("LIBR_MILI_PER is not null");
            return this;
        }

        public Criteria andLibrMiliPerEqualTo(String value) {
            addCriterion("LIBR_MILI_PER =", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerNotEqualTo(String value) {
            addCriterion("LIBR_MILI_PER <>", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerGreaterThan(String value) {
            addCriterion("LIBR_MILI_PER >", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerGreaterThanOrEqualTo(String value) {
            addCriterion("LIBR_MILI_PER >=", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerLessThan(String value) {
            addCriterion("LIBR_MILI_PER <", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerLessThanOrEqualTo(String value) {
            addCriterion("LIBR_MILI_PER <=", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerLike(String value) {
            addCriterion("LIBR_MILI_PER like", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerNotLike(String value) {
            addCriterion("LIBR_MILI_PER not like", value, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerIn(List<String> values) {
            addCriterion("LIBR_MILI_PER in", values, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerNotIn(List<String> values) {
            addCriterion("LIBR_MILI_PER not in", values, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerBetween(String value1, String value2) {
            addCriterion("LIBR_MILI_PER between", value1, value2, "librMiliPer");
            return this;
        }

        public Criteria andLibrMiliPerNotBetween(String value1, String value2) {
            addCriterion("LIBR_MILI_PER not between", value1, value2, "librMiliPer");
            return this;
        }

        public Criteria andCodiIpssPerIsNull() {
            addCriterion("CODI_IPSS_PER is null");
            return this;
        }

        public Criteria andCodiIpssPerIsNotNull() {
            addCriterion("CODI_IPSS_PER is not null");
            return this;
        }

        public Criteria andCodiIpssPerEqualTo(String value) {
            addCriterion("CODI_IPSS_PER =", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerNotEqualTo(String value) {
            addCriterion("CODI_IPSS_PER <>", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerGreaterThan(String value) {
            addCriterion("CODI_IPSS_PER >", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_IPSS_PER >=", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerLessThan(String value) {
            addCriterion("CODI_IPSS_PER <", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerLessThanOrEqualTo(String value) {
            addCriterion("CODI_IPSS_PER <=", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerLike(String value) {
            addCriterion("CODI_IPSS_PER like", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerNotLike(String value) {
            addCriterion("CODI_IPSS_PER not like", value, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerIn(List<String> values) {
            addCriterion("CODI_IPSS_PER in", values, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerNotIn(List<String> values) {
            addCriterion("CODI_IPSS_PER not in", values, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerBetween(String value1, String value2) {
            addCriterion("CODI_IPSS_PER between", value1, value2, "codiIpssPer");
            return this;
        }

        public Criteria andCodiIpssPerNotBetween(String value1, String value2) {
            addCriterion("CODI_IPSS_PER not between", value1, value2, "codiIpssPer");
            return this;
        }

        public Criteria andNumeBrevPerIsNull() {
            addCriterion("NUME_BREV_PER is null");
            return this;
        }

        public Criteria andNumeBrevPerIsNotNull() {
            addCriterion("NUME_BREV_PER is not null");
            return this;
        }

        public Criteria andNumeBrevPerEqualTo(String value) {
            addCriterion("NUME_BREV_PER =", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerNotEqualTo(String value) {
            addCriterion("NUME_BREV_PER <>", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerGreaterThan(String value) {
            addCriterion("NUME_BREV_PER >", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerGreaterThanOrEqualTo(String value) {
            addCriterion("NUME_BREV_PER >=", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerLessThan(String value) {
            addCriterion("NUME_BREV_PER <", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerLessThanOrEqualTo(String value) {
            addCriterion("NUME_BREV_PER <=", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerLike(String value) {
            addCriterion("NUME_BREV_PER like", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerNotLike(String value) {
            addCriterion("NUME_BREV_PER not like", value, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerIn(List<String> values) {
            addCriterion("NUME_BREV_PER in", values, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerNotIn(List<String> values) {
            addCriterion("NUME_BREV_PER not in", values, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerBetween(String value1, String value2) {
            addCriterion("NUME_BREV_PER between", value1, value2, "numeBrevPer");
            return this;
        }

        public Criteria andNumeBrevPerNotBetween(String value1, String value2) {
            addCriterion("NUME_BREV_PER not between", value1, value2, "numeBrevPer");
            return this;
        }

        public Criteria andGruSangPerIsNull() {
            addCriterion("GRU_SANG_PER is null");
            return this;
        }

        public Criteria andGruSangPerIsNotNull() {
            addCriterion("GRU_SANG_PER is not null");
            return this;
        }

        public Criteria andGruSangPerEqualTo(String value) {
            addCriterion("GRU_SANG_PER =", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerNotEqualTo(String value) {
            addCriterion("GRU_SANG_PER <>", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerGreaterThan(String value) {
            addCriterion("GRU_SANG_PER >", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerGreaterThanOrEqualTo(String value) {
            addCriterion("GRU_SANG_PER >=", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerLessThan(String value) {
            addCriterion("GRU_SANG_PER <", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerLessThanOrEqualTo(String value) {
            addCriterion("GRU_SANG_PER <=", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerLike(String value) {
            addCriterion("GRU_SANG_PER like", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerNotLike(String value) {
            addCriterion("GRU_SANG_PER not like", value, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerIn(List<String> values) {
            addCriterion("GRU_SANG_PER in", values, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerNotIn(List<String> values) {
            addCriterion("GRU_SANG_PER not in", values, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerBetween(String value1, String value2) {
            addCriterion("GRU_SANG_PER between", value1, value2, "gruSangPer");
            return this;
        }

        public Criteria andGruSangPerNotBetween(String value1, String value2) {
            addCriterion("GRU_SANG_PER not between", value1, value2, "gruSangPer");
            return this;
        }

        public Criteria andCodMonSuelPerIsNull() {
            addCriterion("COD_MON_SUEL_PER is null");
            return this;
        }

        public Criteria andCodMonSuelPerIsNotNull() {
            addCriterion("COD_MON_SUEL_PER is not null");
            return this;
        }

        public Criteria andCodMonSuelPerEqualTo(String value) {
            addCriterion("COD_MON_SUEL_PER =", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerNotEqualTo(String value) {
            addCriterion("COD_MON_SUEL_PER <>", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerGreaterThan(String value) {
            addCriterion("COD_MON_SUEL_PER >", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerGreaterThanOrEqualTo(String value) {
            addCriterion("COD_MON_SUEL_PER >=", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerLessThan(String value) {
            addCriterion("COD_MON_SUEL_PER <", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerLessThanOrEqualTo(String value) {
            addCriterion("COD_MON_SUEL_PER <=", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerLike(String value) {
            addCriterion("COD_MON_SUEL_PER like", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerNotLike(String value) {
            addCriterion("COD_MON_SUEL_PER not like", value, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerIn(List<String> values) {
            addCriterion("COD_MON_SUEL_PER in", values, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerNotIn(List<String> values) {
            addCriterion("COD_MON_SUEL_PER not in", values, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerBetween(String value1, String value2) {
            addCriterion("COD_MON_SUEL_PER between", value1, value2, "codMonSuelPer");
            return this;
        }

        public Criteria andCodMonSuelPerNotBetween(String value1, String value2) {
            addCriterion("COD_MON_SUEL_PER not between", value1, value2, "codMonSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerIsNull() {
            addCriterion("FLAG_SUEL_PER is null");
            return this;
        }

        public Criteria andFlagSuelPerIsNotNull() {
            addCriterion("FLAG_SUEL_PER is not null");
            return this;
        }

        public Criteria andFlagSuelPerEqualTo(String value) {
            addCriterion("FLAG_SUEL_PER =", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerNotEqualTo(String value) {
            addCriterion("FLAG_SUEL_PER <>", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerGreaterThan(String value) {
            addCriterion("FLAG_SUEL_PER >", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerGreaterThanOrEqualTo(String value) {
            addCriterion("FLAG_SUEL_PER >=", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerLessThan(String value) {
            addCriterion("FLAG_SUEL_PER <", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerLessThanOrEqualTo(String value) {
            addCriterion("FLAG_SUEL_PER <=", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerLike(String value) {
            addCriterion("FLAG_SUEL_PER like", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerNotLike(String value) {
            addCriterion("FLAG_SUEL_PER not like", value, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerIn(List<String> values) {
            addCriterion("FLAG_SUEL_PER in", values, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerNotIn(List<String> values) {
            addCriterion("FLAG_SUEL_PER not in", values, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerBetween(String value1, String value2) {
            addCriterion("FLAG_SUEL_PER between", value1, value2, "flagSuelPer");
            return this;
        }

        public Criteria andFlagSuelPerNotBetween(String value1, String value2) {
            addCriterion("FLAG_SUEL_PER not between", value1, value2, "flagSuelPer");
            return this;
        }

        public Criteria andBancSuelTbcIsNull() {
            addCriterion("BANC_SUEL_TBC is null");
            return this;
        }

        public Criteria andBancSuelTbcIsNotNull() {
            addCriterion("BANC_SUEL_TBC is not null");
            return this;
        }

        public Criteria andBancSuelTbcEqualTo(String value) {
            addCriterion("BANC_SUEL_TBC =", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcNotEqualTo(String value) {
            addCriterion("BANC_SUEL_TBC <>", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcGreaterThan(String value) {
            addCriterion("BANC_SUEL_TBC >", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcGreaterThanOrEqualTo(String value) {
            addCriterion("BANC_SUEL_TBC >=", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcLessThan(String value) {
            addCriterion("BANC_SUEL_TBC <", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcLessThanOrEqualTo(String value) {
            addCriterion("BANC_SUEL_TBC <=", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcLike(String value) {
            addCriterion("BANC_SUEL_TBC like", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcNotLike(String value) {
            addCriterion("BANC_SUEL_TBC not like", value, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcIn(List<String> values) {
            addCriterion("BANC_SUEL_TBC in", values, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcNotIn(List<String> values) {
            addCriterion("BANC_SUEL_TBC not in", values, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcBetween(String value1, String value2) {
            addCriterion("BANC_SUEL_TBC between", value1, value2, "bancSuelTbc");
            return this;
        }

        public Criteria andBancSuelTbcNotBetween(String value1, String value2) {
            addCriterion("BANC_SUEL_TBC not between", value1, value2, "bancSuelTbc");
            return this;
        }

        public Criteria andSuelCtaPerIsNull() {
            addCriterion("SUEL_CTA_PER is null");
            return this;
        }

        public Criteria andSuelCtaPerIsNotNull() {
            addCriterion("SUEL_CTA_PER is not null");
            return this;
        }

        public Criteria andSuelCtaPerEqualTo(String value) {
            addCriterion("SUEL_CTA_PER =", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerNotEqualTo(String value) {
            addCriterion("SUEL_CTA_PER <>", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerGreaterThan(String value) {
            addCriterion("SUEL_CTA_PER >", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerGreaterThanOrEqualTo(String value) {
            addCriterion("SUEL_CTA_PER >=", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerLessThan(String value) {
            addCriterion("SUEL_CTA_PER <", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerLessThanOrEqualTo(String value) {
            addCriterion("SUEL_CTA_PER <=", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerLike(String value) {
            addCriterion("SUEL_CTA_PER like", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerNotLike(String value) {
            addCriterion("SUEL_CTA_PER not like", value, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerIn(List<String> values) {
            addCriterion("SUEL_CTA_PER in", values, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerNotIn(List<String> values) {
            addCriterion("SUEL_CTA_PER not in", values, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerBetween(String value1, String value2) {
            addCriterion("SUEL_CTA_PER between", value1, value2, "suelCtaPer");
            return this;
        }

        public Criteria andSuelCtaPerNotBetween(String value1, String value2) {
            addCriterion("SUEL_CTA_PER not between", value1, value2, "suelCtaPer");
            return this;
        }

        public Criteria andBancCtsTbcIsNull() {
            addCriterion("BANC_CTS_TBC is null");
            return this;
        }

        public Criteria andBancCtsTbcIsNotNull() {
            addCriterion("BANC_CTS_TBC is not null");
            return this;
        }

        public Criteria andBancCtsTbcEqualTo(String value) {
            addCriterion("BANC_CTS_TBC =", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcNotEqualTo(String value) {
            addCriterion("BANC_CTS_TBC <>", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcGreaterThan(String value) {
            addCriterion("BANC_CTS_TBC >", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcGreaterThanOrEqualTo(String value) {
            addCriterion("BANC_CTS_TBC >=", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcLessThan(String value) {
            addCriterion("BANC_CTS_TBC <", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcLessThanOrEqualTo(String value) {
            addCriterion("BANC_CTS_TBC <=", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcLike(String value) {
            addCriterion("BANC_CTS_TBC like", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcNotLike(String value) {
            addCriterion("BANC_CTS_TBC not like", value, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcIn(List<String> values) {
            addCriterion("BANC_CTS_TBC in", values, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcNotIn(List<String> values) {
            addCriterion("BANC_CTS_TBC not in", values, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcBetween(String value1, String value2) {
            addCriterion("BANC_CTS_TBC between", value1, value2, "bancCtsTbc");
            return this;
        }

        public Criteria andBancCtsTbcNotBetween(String value1, String value2) {
            addCriterion("BANC_CTS_TBC not between", value1, value2, "bancCtsTbc");
            return this;
        }

        public Criteria andCtsCtaPerIsNull() {
            addCriterion("CTS_CTA_PER is null");
            return this;
        }

        public Criteria andCtsCtaPerIsNotNull() {
            addCriterion("CTS_CTA_PER is not null");
            return this;
        }

        public Criteria andCtsCtaPerEqualTo(String value) {
            addCriterion("CTS_CTA_PER =", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerNotEqualTo(String value) {
            addCriterion("CTS_CTA_PER <>", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerGreaterThan(String value) {
            addCriterion("CTS_CTA_PER >", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerGreaterThanOrEqualTo(String value) {
            addCriterion("CTS_CTA_PER >=", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerLessThan(String value) {
            addCriterion("CTS_CTA_PER <", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerLessThanOrEqualTo(String value) {
            addCriterion("CTS_CTA_PER <=", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerLike(String value) {
            addCriterion("CTS_CTA_PER like", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerNotLike(String value) {
            addCriterion("CTS_CTA_PER not like", value, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerIn(List<String> values) {
            addCriterion("CTS_CTA_PER in", values, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerNotIn(List<String> values) {
            addCriterion("CTS_CTA_PER not in", values, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerBetween(String value1, String value2) {
            addCriterion("CTS_CTA_PER between", value1, value2, "ctsCtaPer");
            return this;
        }

        public Criteria andCtsCtaPerNotBetween(String value1, String value2) {
            addCriterion("CTS_CTA_PER not between", value1, value2, "ctsCtaPer");
            return this;
        }

        public Criteria andCodMonCtsPerIsNull() {
            addCriterion("COD_MON_CTS_PER is null");
            return this;
        }

        public Criteria andCodMonCtsPerIsNotNull() {
            addCriterion("COD_MON_CTS_PER is not null");
            return this;
        }

        public Criteria andCodMonCtsPerEqualTo(String value) {
            addCriterion("COD_MON_CTS_PER =", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerNotEqualTo(String value) {
            addCriterion("COD_MON_CTS_PER <>", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerGreaterThan(String value) {
            addCriterion("COD_MON_CTS_PER >", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerGreaterThanOrEqualTo(String value) {
            addCriterion("COD_MON_CTS_PER >=", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerLessThan(String value) {
            addCriterion("COD_MON_CTS_PER <", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerLessThanOrEqualTo(String value) {
            addCriterion("COD_MON_CTS_PER <=", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerLike(String value) {
            addCriterion("COD_MON_CTS_PER like", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerNotLike(String value) {
            addCriterion("COD_MON_CTS_PER not like", value, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerIn(List<String> values) {
            addCriterion("COD_MON_CTS_PER in", values, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerNotIn(List<String> values) {
            addCriterion("COD_MON_CTS_PER not in", values, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerBetween(String value1, String value2) {
            addCriterion("COD_MON_CTS_PER between", value1, value2, "codMonCtsPer");
            return this;
        }

        public Criteria andCodMonCtsPerNotBetween(String value1, String value2) {
            addCriterion("COD_MON_CTS_PER not between", value1, value2, "codMonCtsPer");
            return this;
        }

        public Criteria andNumePlazPerIsNull() {
            addCriterion("NUME_PLAZ_PER is null");
            return this;
        }

        public Criteria andNumePlazPerIsNotNull() {
            addCriterion("NUME_PLAZ_PER is not null");
            return this;
        }

        public Criteria andNumePlazPerEqualTo(String value) {
            addCriterion("NUME_PLAZ_PER =", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerNotEqualTo(String value) {
            addCriterion("NUME_PLAZ_PER <>", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerGreaterThan(String value) {
            addCriterion("NUME_PLAZ_PER >", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerGreaterThanOrEqualTo(String value) {
            addCriterion("NUME_PLAZ_PER >=", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerLessThan(String value) {
            addCriterion("NUME_PLAZ_PER <", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerLessThanOrEqualTo(String value) {
            addCriterion("NUME_PLAZ_PER <=", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerLike(String value) {
            addCriterion("NUME_PLAZ_PER like", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerNotLike(String value) {
            addCriterion("NUME_PLAZ_PER not like", value, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerIn(List<String> values) {
            addCriterion("NUME_PLAZ_PER in", values, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerNotIn(List<String> values) {
            addCriterion("NUME_PLAZ_PER not in", values, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerBetween(String value1, String value2) {
            addCriterion("NUME_PLAZ_PER between", value1, value2, "numePlazPer");
            return this;
        }

        public Criteria andNumePlazPerNotBetween(String value1, String value2) {
            addCriterion("NUME_PLAZ_PER not between", value1, value2, "numePlazPer");
            return this;
        }

        public Criteria andFechRnomPerIsNull() {
            addCriterion("FECH_RNOM_PER is null");
            return this;
        }

        public Criteria andFechRnomPerIsNotNull() {
            addCriterion("FECH_RNOM_PER is not null");
            return this;
        }

        public Criteria andFechRnomPerEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_RNOM_PER =", value, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_RNOM_PER <>", value, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerGreaterThan(Date value) {
            addCriterionForJDBCDate("FECH_RNOM_PER >", value, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_RNOM_PER >=", value, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerLessThan(Date value) {
            addCriterionForJDBCDate("FECH_RNOM_PER <", value, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_RNOM_PER <=", value, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_RNOM_PER in", values, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_RNOM_PER not in", values, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_RNOM_PER between", value1, value2, "fechRnomPer");
            return this;
        }

        public Criteria andFechRnomPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_RNOM_PER not between", value1, value2, "fechRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerIsNull() {
            addCriterion("NUME_RNOM_PER is null");
            return this;
        }

        public Criteria andNumeRnomPerIsNotNull() {
            addCriterion("NUME_RNOM_PER is not null");
            return this;
        }

        public Criteria andNumeRnomPerEqualTo(String value) {
            addCriterion("NUME_RNOM_PER =", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerNotEqualTo(String value) {
            addCriterion("NUME_RNOM_PER <>", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerGreaterThan(String value) {
            addCriterion("NUME_RNOM_PER >", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerGreaterThanOrEqualTo(String value) {
            addCriterion("NUME_RNOM_PER >=", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerLessThan(String value) {
            addCriterion("NUME_RNOM_PER <", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerLessThanOrEqualTo(String value) {
            addCriterion("NUME_RNOM_PER <=", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerLike(String value) {
            addCriterion("NUME_RNOM_PER like", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerNotLike(String value) {
            addCriterion("NUME_RNOM_PER not like", value, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerIn(List<String> values) {
            addCriterion("NUME_RNOM_PER in", values, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerNotIn(List<String> values) {
            addCriterion("NUME_RNOM_PER not in", values, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerBetween(String value1, String value2) {
            addCriterion("NUME_RNOM_PER between", value1, value2, "numeRnomPer");
            return this;
        }

        public Criteria andNumeRnomPerNotBetween(String value1, String value2) {
            addCriterion("NUME_RNOM_PER not between", value1, value2, "numeRnomPer");
            return this;
        }

        public Criteria andSedeActuPerIsNull() {
            addCriterion("SEDE_ACTU_PER is null");
            return this;
        }

        public Criteria andSedeActuPerIsNotNull() {
            addCriterion("SEDE_ACTU_PER is not null");
            return this;
        }

        public Criteria andSedeActuPerEqualTo(String value) {
            addCriterion("SEDE_ACTU_PER =", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerNotEqualTo(String value) {
            addCriterion("SEDE_ACTU_PER <>", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerGreaterThan(String value) {
            addCriterion("SEDE_ACTU_PER >", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerGreaterThanOrEqualTo(String value) {
            addCriterion("SEDE_ACTU_PER >=", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerLessThan(String value) {
            addCriterion("SEDE_ACTU_PER <", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerLessThanOrEqualTo(String value) {
            addCriterion("SEDE_ACTU_PER <=", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerLike(String value) {
            addCriterion("SEDE_ACTU_PER like", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerNotLike(String value) {
            addCriterion("SEDE_ACTU_PER not like", value, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerIn(List<String> values) {
            addCriterion("SEDE_ACTU_PER in", values, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerNotIn(List<String> values) {
            addCriterion("SEDE_ACTU_PER not in", values, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerBetween(String value1, String value2) {
            addCriterion("SEDE_ACTU_PER between", value1, value2, "sedeActuPer");
            return this;
        }

        public Criteria andSedeActuPerNotBetween(String value1, String value2) {
            addCriterion("SEDE_ACTU_PER not between", value1, value2, "sedeActuPer");
            return this;
        }

        public Criteria andFingAdmPerIsNull() {
            addCriterion("FING_ADM_PER is null");
            return this;
        }

        public Criteria andFingAdmPerIsNotNull() {
            addCriterion("FING_ADM_PER is not null");
            return this;
        }

        public Criteria andFingAdmPerEqualTo(Date value) {
            addCriterionForJDBCDate("FING_ADM_PER =", value, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FING_ADM_PER <>", value, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerGreaterThan(Date value) {
            addCriterionForJDBCDate("FING_ADM_PER >", value, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FING_ADM_PER >=", value, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerLessThan(Date value) {
            addCriterionForJDBCDate("FING_ADM_PER <", value, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FING_ADM_PER <=", value, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerIn(List<Date> values) {
            addCriterionForJDBCDate("FING_ADM_PER in", values, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FING_ADM_PER not in", values, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FING_ADM_PER between", value1, value2, "fingAdmPer");
            return this;
        }

        public Criteria andFingAdmPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FING_ADM_PER not between", value1, value2, "fingAdmPer");
            return this;
        }

        public Criteria andFingCarrpPerIsNull() {
            addCriterion("FING_CARRP_PER is null");
            return this;
        }

        public Criteria andFingCarrpPerIsNotNull() {
            addCriterion("FING_CARRP_PER is not null");
            return this;
        }

        public Criteria andFingCarrpPerEqualTo(Date value) {
            addCriterionForJDBCDate("FING_CARRP_PER =", value, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FING_CARRP_PER <>", value, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerGreaterThan(Date value) {
            addCriterionForJDBCDate("FING_CARRP_PER >", value, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FING_CARRP_PER >=", value, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerLessThan(Date value) {
            addCriterionForJDBCDate("FING_CARRP_PER <", value, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FING_CARRP_PER <=", value, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerIn(List<Date> values) {
            addCriterionForJDBCDate("FING_CARRP_PER in", values, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FING_CARRP_PER not in", values, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FING_CARRP_PER between", value1, value2, "fingCarrpPer");
            return this;
        }

        public Criteria andFingCarrpPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FING_CARRP_PER not between", value1, value2, "fingCarrpPer");
            return this;
        }

        public Criteria andOtroDocuPerIsNull() {
            addCriterion("OTRO_DOCU_PER is null");
            return this;
        }

        public Criteria andOtroDocuPerIsNotNull() {
            addCriterion("OTRO_DOCU_PER is not null");
            return this;
        }

        public Criteria andOtroDocuPerEqualTo(String value) {
            addCriterion("OTRO_DOCU_PER =", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerNotEqualTo(String value) {
            addCriterion("OTRO_DOCU_PER <>", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerGreaterThan(String value) {
            addCriterion("OTRO_DOCU_PER >", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerGreaterThanOrEqualTo(String value) {
            addCriterion("OTRO_DOCU_PER >=", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerLessThan(String value) {
            addCriterion("OTRO_DOCU_PER <", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerLessThanOrEqualTo(String value) {
            addCriterion("OTRO_DOCU_PER <=", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerLike(String value) {
            addCriterion("OTRO_DOCU_PER like", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerNotLike(String value) {
            addCriterion("OTRO_DOCU_PER not like", value, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerIn(List<String> values) {
            addCriterion("OTRO_DOCU_PER in", values, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerNotIn(List<String> values) {
            addCriterion("OTRO_DOCU_PER not in", values, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerBetween(String value1, String value2) {
            addCriterion("OTRO_DOCU_PER between", value1, value2, "otroDocuPer");
            return this;
        }

        public Criteria andOtroDocuPerNotBetween(String value1, String value2) {
            addCriterion("OTRO_DOCU_PER not between", value1, value2, "otroDocuPer");
            return this;
        }

        public Criteria andObservaPerIsNull() {
            addCriterion("OBSERVA_PER is null");
            return this;
        }

        public Criteria andObservaPerIsNotNull() {
            addCriterion("OBSERVA_PER is not null");
            return this;
        }

        public Criteria andObservaPerEqualTo(String value) {
            addCriterion("OBSERVA_PER =", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerNotEqualTo(String value) {
            addCriterion("OBSERVA_PER <>", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerGreaterThan(String value) {
            addCriterion("OBSERVA_PER >", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerGreaterThanOrEqualTo(String value) {
            addCriterion("OBSERVA_PER >=", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerLessThan(String value) {
            addCriterion("OBSERVA_PER <", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerLessThanOrEqualTo(String value) {
            addCriterion("OBSERVA_PER <=", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerLike(String value) {
            addCriterion("OBSERVA_PER like", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerNotLike(String value) {
            addCriterion("OBSERVA_PER not like", value, "observaPer");
            return this;
        }

        public Criteria andObservaPerIn(List<String> values) {
            addCriterion("OBSERVA_PER in", values, "observaPer");
            return this;
        }

        public Criteria andObservaPerNotIn(List<String> values) {
            addCriterion("OBSERVA_PER not in", values, "observaPer");
            return this;
        }

        public Criteria andObservaPerBetween(String value1, String value2) {
            addCriterion("OBSERVA_PER between", value1, value2, "observaPer");
            return this;
        }

        public Criteria andObservaPerNotBetween(String value1, String value2) {
            addCriterion("OBSERVA_PER not between", value1, value2, "observaPer");
            return this;
        }

        public Criteria andCargoRemuPerIsNull() {
            addCriterion("CARGO_REMU_PER is null");
            return this;
        }

        public Criteria andCargoRemuPerIsNotNull() {
            addCriterion("CARGO_REMU_PER is not null");
            return this;
        }

        public Criteria andCargoRemuPerEqualTo(String value) {
            addCriterion("CARGO_REMU_PER =", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerNotEqualTo(String value) {
            addCriterion("CARGO_REMU_PER <>", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerGreaterThan(String value) {
            addCriterion("CARGO_REMU_PER >", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerGreaterThanOrEqualTo(String value) {
            addCriterion("CARGO_REMU_PER >=", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerLessThan(String value) {
            addCriterion("CARGO_REMU_PER <", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerLessThanOrEqualTo(String value) {
            addCriterion("CARGO_REMU_PER <=", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerLike(String value) {
            addCriterion("CARGO_REMU_PER like", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerNotLike(String value) {
            addCriterion("CARGO_REMU_PER not like", value, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerIn(List<String> values) {
            addCriterion("CARGO_REMU_PER in", values, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerNotIn(List<String> values) {
            addCriterion("CARGO_REMU_PER not in", values, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerBetween(String value1, String value2) {
            addCriterion("CARGO_REMU_PER between", value1, value2, "cargoRemuPer");
            return this;
        }

        public Criteria andCargoRemuPerNotBetween(String value1, String value2) {
            addCriterion("CARGO_REMU_PER not between", value1, value2, "cargoRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerIsNull() {
            addCriterion("NIVEL_REMU_PER is null");
            return this;
        }

        public Criteria andNivelRemuPerIsNotNull() {
            addCriterion("NIVEL_REMU_PER is not null");
            return this;
        }

        public Criteria andNivelRemuPerEqualTo(String value) {
            addCriterion("NIVEL_REMU_PER =", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerNotEqualTo(String value) {
            addCriterion("NIVEL_REMU_PER <>", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerGreaterThan(String value) {
            addCriterion("NIVEL_REMU_PER >", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerGreaterThanOrEqualTo(String value) {
            addCriterion("NIVEL_REMU_PER >=", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerLessThan(String value) {
            addCriterion("NIVEL_REMU_PER <", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerLessThanOrEqualTo(String value) {
            addCriterion("NIVEL_REMU_PER <=", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerLike(String value) {
            addCriterion("NIVEL_REMU_PER like", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerNotLike(String value) {
            addCriterion("NIVEL_REMU_PER not like", value, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerIn(List<String> values) {
            addCriterion("NIVEL_REMU_PER in", values, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerNotIn(List<String> values) {
            addCriterion("NIVEL_REMU_PER not in", values, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerBetween(String value1, String value2) {
            addCriterion("NIVEL_REMU_PER between", value1, value2, "nivelRemuPer");
            return this;
        }

        public Criteria andNivelRemuPerNotBetween(String value1, String value2) {
            addCriterion("NIVEL_REMU_PER not between", value1, value2, "nivelRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerIsNull() {
            addCriterion("PLAZA_REMU_PER is null");
            return this;
        }

        public Criteria andPlazaRemuPerIsNotNull() {
            addCriterion("PLAZA_REMU_PER is not null");
            return this;
        }

        public Criteria andPlazaRemuPerEqualTo(String value) {
            addCriterion("PLAZA_REMU_PER =", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerNotEqualTo(String value) {
            addCriterion("PLAZA_REMU_PER <>", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerGreaterThan(String value) {
            addCriterion("PLAZA_REMU_PER >", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerGreaterThanOrEqualTo(String value) {
            addCriterion("PLAZA_REMU_PER >=", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerLessThan(String value) {
            addCriterion("PLAZA_REMU_PER <", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerLessThanOrEqualTo(String value) {
            addCriterion("PLAZA_REMU_PER <=", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerLike(String value) {
            addCriterion("PLAZA_REMU_PER like", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerNotLike(String value) {
            addCriterion("PLAZA_REMU_PER not like", value, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerIn(List<String> values) {
            addCriterion("PLAZA_REMU_PER in", values, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerNotIn(List<String> values) {
            addCriterion("PLAZA_REMU_PER not in", values, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerBetween(String value1, String value2) {
            addCriterion("PLAZA_REMU_PER between", value1, value2, "plazaRemuPer");
            return this;
        }

        public Criteria andPlazaRemuPerNotBetween(String value1, String value2) {
            addCriterion("PLAZA_REMU_PER not between", value1, value2, "plazaRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerIsNull() {
            addCriterion("DEPE_REMU_PER is null");
            return this;
        }

        public Criteria andDepeRemuPerIsNotNull() {
            addCriterion("DEPE_REMU_PER is not null");
            return this;
        }

        public Criteria andDepeRemuPerEqualTo(String value) {
            addCriterion("DEPE_REMU_PER =", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerNotEqualTo(String value) {
            addCriterion("DEPE_REMU_PER <>", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerGreaterThan(String value) {
            addCriterion("DEPE_REMU_PER >", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerGreaterThanOrEqualTo(String value) {
            addCriterion("DEPE_REMU_PER >=", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerLessThan(String value) {
            addCriterion("DEPE_REMU_PER <", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerLessThanOrEqualTo(String value) {
            addCriterion("DEPE_REMU_PER <=", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerLike(String value) {
            addCriterion("DEPE_REMU_PER like", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerNotLike(String value) {
            addCriterion("DEPE_REMU_PER not like", value, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerIn(List<String> values) {
            addCriterion("DEPE_REMU_PER in", values, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerNotIn(List<String> values) {
            addCriterion("DEPE_REMU_PER not in", values, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerBetween(String value1, String value2) {
            addCriterion("DEPE_REMU_PER between", value1, value2, "depeRemuPer");
            return this;
        }

        public Criteria andDepeRemuPerNotBetween(String value1, String value2) {
            addCriterion("DEPE_REMU_PER not between", value1, value2, "depeRemuPer");
            return this;
        }

        public Criteria andObserRemuPerIsNull() {
            addCriterion("OBSER_REMU_PER is null");
            return this;
        }

        public Criteria andObserRemuPerIsNotNull() {
            addCriterion("OBSER_REMU_PER is not null");
            return this;
        }

        public Criteria andObserRemuPerEqualTo(String value) {
            addCriterion("OBSER_REMU_PER =", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerNotEqualTo(String value) {
            addCriterion("OBSER_REMU_PER <>", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerGreaterThan(String value) {
            addCriterion("OBSER_REMU_PER >", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerGreaterThanOrEqualTo(String value) {
            addCriterion("OBSER_REMU_PER >=", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerLessThan(String value) {
            addCriterion("OBSER_REMU_PER <", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerLessThanOrEqualTo(String value) {
            addCriterion("OBSER_REMU_PER <=", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerLike(String value) {
            addCriterion("OBSER_REMU_PER like", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerNotLike(String value) {
            addCriterion("OBSER_REMU_PER not like", value, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerIn(List<String> values) {
            addCriterion("OBSER_REMU_PER in", values, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerNotIn(List<String> values) {
            addCriterion("OBSER_REMU_PER not in", values, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerBetween(String value1, String value2) {
            addCriterion("OBSER_REMU_PER between", value1, value2, "obserRemuPer");
            return this;
        }

        public Criteria andObserRemuPerNotBetween(String value1, String value2) {
            addCriterion("OBSER_REMU_PER not between", value1, value2, "obserRemuPer");
            return this;
        }

        public Criteria andTipoCuenPerIsNull() {
            addCriterion("TIPO_CUEN_PER is null");
            return this;
        }

        public Criteria andTipoCuenPerIsNotNull() {
            addCriterion("TIPO_CUEN_PER is not null");
            return this;
        }

        public Criteria andTipoCuenPerEqualTo(String value) {
            addCriterion("TIPO_CUEN_PER =", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerNotEqualTo(String value) {
            addCriterion("TIPO_CUEN_PER <>", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerGreaterThan(String value) {
            addCriterion("TIPO_CUEN_PER >", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerGreaterThanOrEqualTo(String value) {
            addCriterion("TIPO_CUEN_PER >=", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerLessThan(String value) {
            addCriterion("TIPO_CUEN_PER <", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerLessThanOrEqualTo(String value) {
            addCriterion("TIPO_CUEN_PER <=", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerLike(String value) {
            addCriterion("TIPO_CUEN_PER like", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerNotLike(String value) {
            addCriterion("TIPO_CUEN_PER not like", value, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerIn(List<String> values) {
            addCriterion("TIPO_CUEN_PER in", values, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerNotIn(List<String> values) {
            addCriterion("TIPO_CUEN_PER not in", values, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerBetween(String value1, String value2) {
            addCriterion("TIPO_CUEN_PER between", value1, value2, "tipoCuenPer");
            return this;
        }

        public Criteria andTipoCuenPerNotBetween(String value1, String value2) {
            addCriterion("TIPO_CUEN_PER not between", value1, value2, "tipoCuenPer");
            return this;
        }

        public Criteria andSeguMediPerIsNull() {
            addCriterion("SEGU_MEDI_PER is null");
            return this;
        }

        public Criteria andSeguMediPerIsNotNull() {
            addCriterion("SEGU_MEDI_PER is not null");
            return this;
        }

        public Criteria andSeguMediPerEqualTo(String value) {
            addCriterion("SEGU_MEDI_PER =", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerNotEqualTo(String value) {
            addCriterion("SEGU_MEDI_PER <>", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerGreaterThan(String value) {
            addCriterion("SEGU_MEDI_PER >", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerGreaterThanOrEqualTo(String value) {
            addCriterion("SEGU_MEDI_PER >=", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerLessThan(String value) {
            addCriterion("SEGU_MEDI_PER <", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerLessThanOrEqualTo(String value) {
            addCriterion("SEGU_MEDI_PER <=", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerLike(String value) {
            addCriterion("SEGU_MEDI_PER like", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerNotLike(String value) {
            addCriterion("SEGU_MEDI_PER not like", value, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerIn(List<String> values) {
            addCriterion("SEGU_MEDI_PER in", values, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerNotIn(List<String> values) {
            addCriterion("SEGU_MEDI_PER not in", values, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerBetween(String value1, String value2) {
            addCriterion("SEGU_MEDI_PER between", value1, value2, "seguMediPer");
            return this;
        }

        public Criteria andSeguMediPerNotBetween(String value1, String value2) {
            addCriterion("SEGU_MEDI_PER not between", value1, value2, "seguMediPer");
            return this;
        }

        public Criteria andSedeRemuPerIsNull() {
            addCriterion("SEDE_REMU_PER is null");
            return this;
        }

        public Criteria andSedeRemuPerIsNotNull() {
            addCriterion("SEDE_REMU_PER is not null");
            return this;
        }

        public Criteria andSedeRemuPerEqualTo(String value) {
            addCriterion("SEDE_REMU_PER =", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerNotEqualTo(String value) {
            addCriterion("SEDE_REMU_PER <>", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerGreaterThan(String value) {
            addCriterion("SEDE_REMU_PER >", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerGreaterThanOrEqualTo(String value) {
            addCriterion("SEDE_REMU_PER >=", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerLessThan(String value) {
            addCriterion("SEDE_REMU_PER <", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerLessThanOrEqualTo(String value) {
            addCriterion("SEDE_REMU_PER <=", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerLike(String value) {
            addCriterion("SEDE_REMU_PER like", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerNotLike(String value) {
            addCriterion("SEDE_REMU_PER not like", value, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerIn(List<String> values) {
            addCriterion("SEDE_REMU_PER in", values, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerNotIn(List<String> values) {
            addCriterion("SEDE_REMU_PER not in", values, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerBetween(String value1, String value2) {
            addCriterion("SEDE_REMU_PER between", value1, value2, "sedeRemuPer");
            return this;
        }

        public Criteria andSedeRemuPerNotBetween(String value1, String value2) {
            addCriterion("SEDE_REMU_PER not between", value1, value2, "sedeRemuPer");
            return this;
        }

        public Criteria andApepSoltPerIsNull() {
            addCriterion("APEP_SOLT_PER is null");
            return this;
        }

        public Criteria andApepSoltPerIsNotNull() {
            addCriterion("APEP_SOLT_PER is not null");
            return this;
        }

        public Criteria andApepSoltPerEqualTo(String value) {
            addCriterion("APEP_SOLT_PER =", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerNotEqualTo(String value) {
            addCriterion("APEP_SOLT_PER <>", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerGreaterThan(String value) {
            addCriterion("APEP_SOLT_PER >", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerGreaterThanOrEqualTo(String value) {
            addCriterion("APEP_SOLT_PER >=", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerLessThan(String value) {
            addCriterion("APEP_SOLT_PER <", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerLessThanOrEqualTo(String value) {
            addCriterion("APEP_SOLT_PER <=", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerLike(String value) {
            addCriterion("APEP_SOLT_PER like", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerNotLike(String value) {
            addCriterion("APEP_SOLT_PER not like", value, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerIn(List<String> values) {
            addCriterion("APEP_SOLT_PER in", values, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerNotIn(List<String> values) {
            addCriterion("APEP_SOLT_PER not in", values, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerBetween(String value1, String value2) {
            addCriterion("APEP_SOLT_PER between", value1, value2, "apepSoltPer");
            return this;
        }

        public Criteria andApepSoltPerNotBetween(String value1, String value2) {
            addCriterion("APEP_SOLT_PER not between", value1, value2, "apepSoltPer");
            return this;
        }

        public Criteria andApemSoltPerIsNull() {
            addCriterion("APEM_SOLT_PER is null");
            return this;
        }

        public Criteria andApemSoltPerIsNotNull() {
            addCriterion("APEM_SOLT_PER is not null");
            return this;
        }

        public Criteria andApemSoltPerEqualTo(String value) {
            addCriterion("APEM_SOLT_PER =", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerNotEqualTo(String value) {
            addCriterion("APEM_SOLT_PER <>", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerGreaterThan(String value) {
            addCriterion("APEM_SOLT_PER >", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerGreaterThanOrEqualTo(String value) {
            addCriterion("APEM_SOLT_PER >=", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerLessThan(String value) {
            addCriterion("APEM_SOLT_PER <", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerLessThanOrEqualTo(String value) {
            addCriterion("APEM_SOLT_PER <=", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerLike(String value) {
            addCriterion("APEM_SOLT_PER like", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerNotLike(String value) {
            addCriterion("APEM_SOLT_PER not like", value, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerIn(List<String> values) {
            addCriterion("APEM_SOLT_PER in", values, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerNotIn(List<String> values) {
            addCriterion("APEM_SOLT_PER not in", values, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerBetween(String value1, String value2) {
            addCriterion("APEM_SOLT_PER between", value1, value2, "apemSoltPer");
            return this;
        }

        public Criteria andApemSoltPerNotBetween(String value1, String value2) {
            addCriterion("APEM_SOLT_PER not between", value1, value2, "apemSoltPer");
            return this;
        }

        public Criteria andNombSoltErIsNull() {
            addCriterion("NOMB_SOLT_ER is null");
            return this;
        }

        public Criteria andNombSoltErIsNotNull() {
            addCriterion("NOMB_SOLT_ER is not null");
            return this;
        }

        public Criteria andNombSoltErEqualTo(String value) {
            addCriterion("NOMB_SOLT_ER =", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErNotEqualTo(String value) {
            addCriterion("NOMB_SOLT_ER <>", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErGreaterThan(String value) {
            addCriterion("NOMB_SOLT_ER >", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErGreaterThanOrEqualTo(String value) {
            addCriterion("NOMB_SOLT_ER >=", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErLessThan(String value) {
            addCriterion("NOMB_SOLT_ER <", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErLessThanOrEqualTo(String value) {
            addCriterion("NOMB_SOLT_ER <=", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErLike(String value) {
            addCriterion("NOMB_SOLT_ER like", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErNotLike(String value) {
            addCriterion("NOMB_SOLT_ER not like", value, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErIn(List<String> values) {
            addCriterion("NOMB_SOLT_ER in", values, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErNotIn(List<String> values) {
            addCriterion("NOMB_SOLT_ER not in", values, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErBetween(String value1, String value2) {
            addCriterion("NOMB_SOLT_ER between", value1, value2, "nombSoltEr");
            return this;
        }

        public Criteria andNombSoltErNotBetween(String value1, String value2) {
            addCriterion("NOMB_SOLT_ER not between", value1, value2, "nombSoltEr");
            return this;
        }

        public Criteria andCodiProfTprIsNull() {
            addCriterion("CODI_PROF_TPR is null");
            return this;
        }

        public Criteria andCodiProfTprIsNotNull() {
            addCriterion("CODI_PROF_TPR is not null");
            return this;
        }

        public Criteria andCodiProfTprEqualTo(String value) {
            addCriterion("CODI_PROF_TPR =", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprNotEqualTo(String value) {
            addCriterion("CODI_PROF_TPR <>", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprGreaterThan(String value) {
            addCriterion("CODI_PROF_TPR >", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_PROF_TPR >=", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprLessThan(String value) {
            addCriterion("CODI_PROF_TPR <", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprLessThanOrEqualTo(String value) {
            addCriterion("CODI_PROF_TPR <=", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprLike(String value) {
            addCriterion("CODI_PROF_TPR like", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprNotLike(String value) {
            addCriterion("CODI_PROF_TPR not like", value, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprIn(List<String> values) {
            addCriterion("CODI_PROF_TPR in", values, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprNotIn(List<String> values) {
            addCriterion("CODI_PROF_TPR not in", values, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprBetween(String value1, String value2) {
            addCriterion("CODI_PROF_TPR between", value1, value2, "codiProfTpr");
            return this;
        }

        public Criteria andCodiProfTprNotBetween(String value1, String value2) {
            addCriterion("CODI_PROF_TPR not between", value1, value2, "codiProfTpr");
            return this;
        }

        public Criteria andFechCesePerIsNull() {
            addCriterion("FECH_CESE_PER is null");
            return this;
        }

        public Criteria andFechCesePerIsNotNull() {
            addCriterion("FECH_CESE_PER is not null");
            return this;
        }

        public Criteria andFechCesePerEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CESE_PER =", value, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CESE_PER <>", value, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerGreaterThan(Date value) {
            addCriterionForJDBCDate("FECH_CESE_PER >", value, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CESE_PER >=", value, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerLessThan(Date value) {
            addCriterionForJDBCDate("FECH_CESE_PER <", value, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CESE_PER <=", value, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_CESE_PER in", values, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_CESE_PER not in", values, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_CESE_PER between", value1, value2, "fechCesePer");
            return this;
        }

        public Criteria andFechCesePerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_CESE_PER not between", value1, value2, "fechCesePer");
            return this;
        }

        public Criteria andNumePasaPerIsNull() {
            addCriterion("NUME_PASA_PER is null");
            return this;
        }

        public Criteria andNumePasaPerIsNotNull() {
            addCriterion("NUME_PASA_PER is not null");
            return this;
        }

        public Criteria andNumePasaPerEqualTo(String value) {
            addCriterion("NUME_PASA_PER =", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerNotEqualTo(String value) {
            addCriterion("NUME_PASA_PER <>", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerGreaterThan(String value) {
            addCriterion("NUME_PASA_PER >", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerGreaterThanOrEqualTo(String value) {
            addCriterion("NUME_PASA_PER >=", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerLessThan(String value) {
            addCriterion("NUME_PASA_PER <", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerLessThanOrEqualTo(String value) {
            addCriterion("NUME_PASA_PER <=", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerLike(String value) {
            addCriterion("NUME_PASA_PER like", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerNotLike(String value) {
            addCriterion("NUME_PASA_PER not like", value, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerIn(List<String> values) {
            addCriterion("NUME_PASA_PER in", values, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerNotIn(List<String> values) {
            addCriterion("NUME_PASA_PER not in", values, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerBetween(String value1, String value2) {
            addCriterion("NUME_PASA_PER between", value1, value2, "numePasaPer");
            return this;
        }

        public Criteria andNumePasaPerNotBetween(String value1, String value2) {
            addCriterion("NUME_PASA_PER not between", value1, value2, "numePasaPer");
            return this;
        }

        public Criteria andAnnoProgPlaIsNull() {
            addCriterion("ANNO_PROG_PLA is null");
            return this;
        }

        public Criteria andAnnoProgPlaIsNotNull() {
            addCriterion("ANNO_PROG_PLA is not null");
            return this;
        }

        public Criteria andAnnoProgPlaEqualTo(String value) {
            addCriterion("ANNO_PROG_PLA =", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaNotEqualTo(String value) {
            addCriterion("ANNO_PROG_PLA <>", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaGreaterThan(String value) {
            addCriterion("ANNO_PROG_PLA >", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaGreaterThanOrEqualTo(String value) {
            addCriterion("ANNO_PROG_PLA >=", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaLessThan(String value) {
            addCriterion("ANNO_PROG_PLA <", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaLessThanOrEqualTo(String value) {
            addCriterion("ANNO_PROG_PLA <=", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaLike(String value) {
            addCriterion("ANNO_PROG_PLA like", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaNotLike(String value) {
            addCriterion("ANNO_PROG_PLA not like", value, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaIn(List<String> values) {
            addCriterion("ANNO_PROG_PLA in", values, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaNotIn(List<String> values) {
            addCriterion("ANNO_PROG_PLA not in", values, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaBetween(String value1, String value2) {
            addCriterion("ANNO_PROG_PLA between", value1, value2, "annoProgPla");
            return this;
        }

        public Criteria andAnnoProgPlaNotBetween(String value1, String value2) {
            addCriterion("ANNO_PROG_PLA not between", value1, value2, "annoProgPla");
            return this;
        }

        public Criteria andCodiPlazPlaIsNull() {
            addCriterion("CODI_PLAZ_PLA is null");
            return this;
        }

        public Criteria andCodiPlazPlaIsNotNull() {
            addCriterion("CODI_PLAZ_PLA is not null");
            return this;
        }

        public Criteria andCodiPlazPlaEqualTo(String value) {
            addCriterion("CODI_PLAZ_PLA =", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaNotEqualTo(String value) {
            addCriterion("CODI_PLAZ_PLA <>", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaGreaterThan(String value) {
            addCriterion("CODI_PLAZ_PLA >", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_PLAZ_PLA >=", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaLessThan(String value) {
            addCriterion("CODI_PLAZ_PLA <", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaLessThanOrEqualTo(String value) {
            addCriterion("CODI_PLAZ_PLA <=", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaLike(String value) {
            addCriterion("CODI_PLAZ_PLA like", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaNotLike(String value) {
            addCriterion("CODI_PLAZ_PLA not like", value, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaIn(List<String> values) {
            addCriterion("CODI_PLAZ_PLA in", values, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaNotIn(List<String> values) {
            addCriterion("CODI_PLAZ_PLA not in", values, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaBetween(String value1, String value2) {
            addCriterion("CODI_PLAZ_PLA between", value1, value2, "codiPlazPla");
            return this;
        }

        public Criteria andCodiPlazPlaNotBetween(String value1, String value2) {
            addCriterion("CODI_PLAZ_PLA not between", value1, value2, "codiPlazPla");
            return this;
        }

        public Criteria andCodiAntePerIsNull() {
            addCriterion("CODI_ANTE_PER is null");
            return this;
        }

        public Criteria andCodiAntePerIsNotNull() {
            addCriterion("CODI_ANTE_PER is not null");
            return this;
        }

        public Criteria andCodiAntePerEqualTo(String value) {
            addCriterion("CODI_ANTE_PER =", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerNotEqualTo(String value) {
            addCriterion("CODI_ANTE_PER <>", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerGreaterThan(String value) {
            addCriterion("CODI_ANTE_PER >", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_ANTE_PER >=", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerLessThan(String value) {
            addCriterion("CODI_ANTE_PER <", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerLessThanOrEqualTo(String value) {
            addCriterion("CODI_ANTE_PER <=", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerLike(String value) {
            addCriterion("CODI_ANTE_PER like", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerNotLike(String value) {
            addCriterion("CODI_ANTE_PER not like", value, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerIn(List<String> values) {
            addCriterion("CODI_ANTE_PER in", values, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerNotIn(List<String> values) {
            addCriterion("CODI_ANTE_PER not in", values, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerBetween(String value1, String value2) {
            addCriterion("CODI_ANTE_PER between", value1, value2, "codiAntePer");
            return this;
        }

        public Criteria andCodiAntePerNotBetween(String value1, String value2) {
            addCriterion("CODI_ANTE_PER not between", value1, value2, "codiAntePer");
            return this;
        }

        public Criteria andNiveViatNviIsNull() {
            addCriterion("NIVE_VIAT_NVI is null");
            return this;
        }

        public Criteria andNiveViatNviIsNotNull() {
            addCriterion("NIVE_VIAT_NVI is not null");
            return this;
        }

        public Criteria andNiveViatNviEqualTo(String value) {
            addCriterion("NIVE_VIAT_NVI =", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviNotEqualTo(String value) {
            addCriterion("NIVE_VIAT_NVI <>", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviGreaterThan(String value) {
            addCriterion("NIVE_VIAT_NVI >", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviGreaterThanOrEqualTo(String value) {
            addCriterion("NIVE_VIAT_NVI >=", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviLessThan(String value) {
            addCriterion("NIVE_VIAT_NVI <", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviLessThanOrEqualTo(String value) {
            addCriterion("NIVE_VIAT_NVI <=", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviLike(String value) {
            addCriterion("NIVE_VIAT_NVI like", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviNotLike(String value) {
            addCriterion("NIVE_VIAT_NVI not like", value, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviIn(List<String> values) {
            addCriterion("NIVE_VIAT_NVI in", values, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviNotIn(List<String> values) {
            addCriterion("NIVE_VIAT_NVI not in", values, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviBetween(String value1, String value2) {
            addCriterion("NIVE_VIAT_NVI between", value1, value2, "niveViatNvi");
            return this;
        }

        public Criteria andNiveViatNviNotBetween(String value1, String value2) {
            addCriterion("NIVE_VIAT_NVI not between", value1, value2, "niveViatNvi");
            return this;
        }

        public Criteria andCodiCondLabIsNull() {
            addCriterion("CODI_COND_LAB is null");
            return this;
        }

        public Criteria andCodiCondLabIsNotNull() {
            addCriterion("CODI_COND_LAB is not null");
            return this;
        }

        public Criteria andCodiCondLabEqualTo(String value) {
            addCriterion("CODI_COND_LAB =", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabNotEqualTo(String value) {
            addCriterion("CODI_COND_LAB <>", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabGreaterThan(String value) {
            addCriterion("CODI_COND_LAB >", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_COND_LAB >=", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabLessThan(String value) {
            addCriterion("CODI_COND_LAB <", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabLessThanOrEqualTo(String value) {
            addCriterion("CODI_COND_LAB <=", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabLike(String value) {
            addCriterion("CODI_COND_LAB like", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabNotLike(String value) {
            addCriterion("CODI_COND_LAB not like", value, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabIn(List<String> values) {
            addCriterion("CODI_COND_LAB in", values, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabNotIn(List<String> values) {
            addCriterion("CODI_COND_LAB not in", values, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabBetween(String value1, String value2) {
            addCriterion("CODI_COND_LAB between", value1, value2, "codiCondLab");
            return this;
        }

        public Criteria andCodiCondLabNotBetween(String value1, String value2) {
            addCriterion("CODI_COND_LAB not between", value1, value2, "codiCondLab");
            return this;
        }

        public Criteria andFlagMoscPerIsNull() {
            addCriterion("FLAG_MOSC_PER is null");
            return this;
        }

        public Criteria andFlagMoscPerIsNotNull() {
            addCriterion("FLAG_MOSC_PER is not null");
            return this;
        }

        public Criteria andFlagMoscPerEqualTo(String value) {
            addCriterion("FLAG_MOSC_PER =", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerNotEqualTo(String value) {
            addCriterion("FLAG_MOSC_PER <>", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerGreaterThan(String value) {
            addCriterion("FLAG_MOSC_PER >", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerGreaterThanOrEqualTo(String value) {
            addCriterion("FLAG_MOSC_PER >=", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerLessThan(String value) {
            addCriterion("FLAG_MOSC_PER <", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerLessThanOrEqualTo(String value) {
            addCriterion("FLAG_MOSC_PER <=", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerLike(String value) {
            addCriterion("FLAG_MOSC_PER like", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerNotLike(String value) {
            addCriterion("FLAG_MOSC_PER not like", value, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerIn(List<String> values) {
            addCriterion("FLAG_MOSC_PER in", values, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerNotIn(List<String> values) {
            addCriterion("FLAG_MOSC_PER not in", values, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerBetween(String value1, String value2) {
            addCriterion("FLAG_MOSC_PER between", value1, value2, "flagMoscPer");
            return this;
        }

        public Criteria andFlagMoscPerNotBetween(String value1, String value2) {
            addCriterion("FLAG_MOSC_PER not between", value1, value2, "flagMoscPer");
            return this;
        }

        public Criteria andTipoDocuPerIsNull() {
            addCriterion("TIPO_DOCU_PER is null");
            return this;
        }

        public Criteria andTipoDocuPerIsNotNull() {
            addCriterion("TIPO_DOCU_PER is not null");
            return this;
        }

        public Criteria andTipoDocuPerEqualTo(String value) {
            addCriterion("TIPO_DOCU_PER =", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerNotEqualTo(String value) {
            addCriterion("TIPO_DOCU_PER <>", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerGreaterThan(String value) {
            addCriterion("TIPO_DOCU_PER >", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerGreaterThanOrEqualTo(String value) {
            addCriterion("TIPO_DOCU_PER >=", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerLessThan(String value) {
            addCriterion("TIPO_DOCU_PER <", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerLessThanOrEqualTo(String value) {
            addCriterion("TIPO_DOCU_PER <=", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerLike(String value) {
            addCriterion("TIPO_DOCU_PER like", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerNotLike(String value) {
            addCriterion("TIPO_DOCU_PER not like", value, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerIn(List<String> values) {
            addCriterion("TIPO_DOCU_PER in", values, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerNotIn(List<String> values) {
            addCriterion("TIPO_DOCU_PER not in", values, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerBetween(String value1, String value2) {
            addCriterion("TIPO_DOCU_PER between", value1, value2, "tipoDocuPer");
            return this;
        }

        public Criteria andTipoDocuPerNotBetween(String value1, String value2) {
            addCriterion("TIPO_DOCU_PER not between", value1, value2, "tipoDocuPer");
            return this;
        }

        public Criteria andNumeCeluPerIsNull() {
            addCriterion("NUME_CELU_PER is null");
            return this;
        }

        public Criteria andNumeCeluPerIsNotNull() {
            addCriterion("NUME_CELU_PER is not null");
            return this;
        }

        public Criteria andNumeCeluPerEqualTo(String value) {
            addCriterion("NUME_CELU_PER =", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerNotEqualTo(String value) {
            addCriterion("NUME_CELU_PER <>", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerGreaterThan(String value) {
            addCriterion("NUME_CELU_PER >", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerGreaterThanOrEqualTo(String value) {
            addCriterion("NUME_CELU_PER >=", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerLessThan(String value) {
            addCriterion("NUME_CELU_PER <", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerLessThanOrEqualTo(String value) {
            addCriterion("NUME_CELU_PER <=", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerLike(String value) {
            addCriterion("NUME_CELU_PER like", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerNotLike(String value) {
            addCriterion("NUME_CELU_PER not like", value, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerIn(List<String> values) {
            addCriterion("NUME_CELU_PER in", values, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerNotIn(List<String> values) {
            addCriterion("NUME_CELU_PER not in", values, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerBetween(String value1, String value2) {
            addCriterion("NUME_CELU_PER between", value1, value2, "numeCeluPer");
            return this;
        }

        public Criteria andNumeCeluPerNotBetween(String value1, String value2) {
            addCriterion("NUME_CELU_PER not between", value1, value2, "numeCeluPer");
            return this;
        }

        public Criteria andCodiNiveNvlIsNull() {
            addCriterion("CODI_NIVE_NVL is null");
            return this;
        }

        public Criteria andCodiNiveNvlIsNotNull() {
            addCriterion("CODI_NIVE_NVL is not null");
            return this;
        }

        public Criteria andCodiNiveNvlEqualTo(String value) {
            addCriterion("CODI_NIVE_NVL =", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlNotEqualTo(String value) {
            addCriterion("CODI_NIVE_NVL <>", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlGreaterThan(String value) {
            addCriterion("CODI_NIVE_NVL >", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_NIVE_NVL >=", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlLessThan(String value) {
            addCriterion("CODI_NIVE_NVL <", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlLessThanOrEqualTo(String value) {
            addCriterion("CODI_NIVE_NVL <=", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlLike(String value) {
            addCriterion("CODI_NIVE_NVL like", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlNotLike(String value) {
            addCriterion("CODI_NIVE_NVL not like", value, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlIn(List<String> values) {
            addCriterion("CODI_NIVE_NVL in", values, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlNotIn(List<String> values) {
            addCriterion("CODI_NIVE_NVL not in", values, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlBetween(String value1, String value2) {
            addCriterion("CODI_NIVE_NVL between", value1, value2, "codiNiveNvl");
            return this;
        }

        public Criteria andCodiNiveNvlNotBetween(String value1, String value2) {
            addCriterion("CODI_NIVE_NVL not between", value1, value2, "codiNiveNvl");
            return this;
        }

        public Criteria andCantAnnoExpIsNull() {
            addCriterion("CANT_ANNO_EXP is null");
            return this;
        }

        public Criteria andCantAnnoExpIsNotNull() {
            addCriterion("CANT_ANNO_EXP is not null");
            return this;
        }

        public Criteria andCantAnnoExpEqualTo(Integer value) {
            addCriterion("CANT_ANNO_EXP =", value, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpNotEqualTo(Integer value) {
            addCriterion("CANT_ANNO_EXP <>", value, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpGreaterThan(Integer value) {
            addCriterion("CANT_ANNO_EXP >", value, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpGreaterThanOrEqualTo(Integer value) {
            addCriterion("CANT_ANNO_EXP >=", value, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpLessThan(Integer value) {
            addCriterion("CANT_ANNO_EXP <", value, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpLessThanOrEqualTo(Integer value) {
            addCriterion("CANT_ANNO_EXP <=", value, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpIn(List<Integer> values) {
            addCriterion("CANT_ANNO_EXP in", values, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpNotIn(List<Integer> values) {
            addCriterion("CANT_ANNO_EXP not in", values, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpBetween(Integer value1, Integer value2) {
            addCriterion("CANT_ANNO_EXP between", value1, value2, "cantAnnoExp");
            return this;
        }

        public Criteria andCantAnnoExpNotBetween(Integer value1, Integer value2) {
            addCriterion("CANT_ANNO_EXP not between", value1, value2, "cantAnnoExp");
            return this;
        }

        public Criteria andCantMeseExpIsNull() {
            addCriterion("CANT_MESE_EXP is null");
            return this;
        }

        public Criteria andCantMeseExpIsNotNull() {
            addCriterion("CANT_MESE_EXP is not null");
            return this;
        }

        public Criteria andCantMeseExpEqualTo(Integer value) {
            addCriterion("CANT_MESE_EXP =", value, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpNotEqualTo(Integer value) {
            addCriterion("CANT_MESE_EXP <>", value, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpGreaterThan(Integer value) {
            addCriterion("CANT_MESE_EXP >", value, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpGreaterThanOrEqualTo(Integer value) {
            addCriterion("CANT_MESE_EXP >=", value, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpLessThan(Integer value) {
            addCriterion("CANT_MESE_EXP <", value, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpLessThanOrEqualTo(Integer value) {
            addCriterion("CANT_MESE_EXP <=", value, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpIn(List<Integer> values) {
            addCriterion("CANT_MESE_EXP in", values, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpNotIn(List<Integer> values) {
            addCriterion("CANT_MESE_EXP not in", values, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpBetween(Integer value1, Integer value2) {
            addCriterion("CANT_MESE_EXP between", value1, value2, "cantMeseExp");
            return this;
        }

        public Criteria andCantMeseExpNotBetween(Integer value1, Integer value2) {
            addCriterion("CANT_MESE_EXP not between", value1, value2, "cantMeseExp");
            return this;
        }

        public Criteria andPlazEncaPerIsNull() {
            addCriterion("PLAZ_ENCA_PER is null");
            return this;
        }

        public Criteria andPlazEncaPerIsNotNull() {
            addCriterion("PLAZ_ENCA_PER is not null");
            return this;
        }

        public Criteria andPlazEncaPerEqualTo(String value) {
            addCriterion("PLAZ_ENCA_PER =", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerNotEqualTo(String value) {
            addCriterion("PLAZ_ENCA_PER <>", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerGreaterThan(String value) {
            addCriterion("PLAZ_ENCA_PER >", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerGreaterThanOrEqualTo(String value) {
            addCriterion("PLAZ_ENCA_PER >=", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerLessThan(String value) {
            addCriterion("PLAZ_ENCA_PER <", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerLessThanOrEqualTo(String value) {
            addCriterion("PLAZ_ENCA_PER <=", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerLike(String value) {
            addCriterion("PLAZ_ENCA_PER like", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerNotLike(String value) {
            addCriterion("PLAZ_ENCA_PER not like", value, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerIn(List<String> values) {
            addCriterion("PLAZ_ENCA_PER in", values, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerNotIn(List<String> values) {
            addCriterion("PLAZ_ENCA_PER not in", values, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerBetween(String value1, String value2) {
            addCriterion("PLAZ_ENCA_PER between", value1, value2, "plazEncaPer");
            return this;
        }

        public Criteria andPlazEncaPerNotBetween(String value1, String value2) {
            addCriterion("PLAZ_ENCA_PER not between", value1, value2, "plazEncaPer");
            return this;
        }

        public Criteria andNumeDepePerIsNull() {
            addCriterion("NUME_DEPE_PER is null");
            return this;
        }

        public Criteria andNumeDepePerIsNotNull() {
            addCriterion("NUME_DEPE_PER is not null");
            return this;
        }

        public Criteria andNumeDepePerEqualTo(Short value) {
            addCriterion("NUME_DEPE_PER =", value, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerNotEqualTo(Short value) {
            addCriterion("NUME_DEPE_PER <>", value, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerGreaterThan(Short value) {
            addCriterion("NUME_DEPE_PER >", value, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerGreaterThanOrEqualTo(Short value) {
            addCriterion("NUME_DEPE_PER >=", value, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerLessThan(Short value) {
            addCriterion("NUME_DEPE_PER <", value, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerLessThanOrEqualTo(Short value) {
            addCriterion("NUME_DEPE_PER <=", value, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerIn(List<Short> values) {
            addCriterion("NUME_DEPE_PER in", values, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerNotIn(List<Short> values) {
            addCriterion("NUME_DEPE_PER not in", values, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerBetween(Short value1, Short value2) {
            addCriterion("NUME_DEPE_PER between", value1, value2, "numeDepePer");
            return this;
        }

        public Criteria andNumeDepePerNotBetween(Short value1, Short value2) {
            addCriterion("NUME_DEPE_PER not between", value1, value2, "numeDepePer");
            return this;
        }

        public Criteria andFlagAfilEpsIsNull() {
            addCriterion("FLAG_AFIL_EPS is null");
            return this;
        }

        public Criteria andFlagAfilEpsIsNotNull() {
            addCriterion("FLAG_AFIL_EPS is not null");
            return this;
        }

        public Criteria andFlagAfilEpsEqualTo(String value) {
            addCriterion("FLAG_AFIL_EPS =", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsNotEqualTo(String value) {
            addCriterion("FLAG_AFIL_EPS <>", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsGreaterThan(String value) {
            addCriterion("FLAG_AFIL_EPS >", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsGreaterThanOrEqualTo(String value) {
            addCriterion("FLAG_AFIL_EPS >=", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsLessThan(String value) {
            addCriterion("FLAG_AFIL_EPS <", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsLessThanOrEqualTo(String value) {
            addCriterion("FLAG_AFIL_EPS <=", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsLike(String value) {
            addCriterion("FLAG_AFIL_EPS like", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsNotLike(String value) {
            addCriterion("FLAG_AFIL_EPS not like", value, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsIn(List<String> values) {
            addCriterion("FLAG_AFIL_EPS in", values, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsNotIn(List<String> values) {
            addCriterion("FLAG_AFIL_EPS not in", values, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsBetween(String value1, String value2) {
            addCriterion("FLAG_AFIL_EPS between", value1, value2, "flagAfilEps");
            return this;
        }

        public Criteria andFlagAfilEpsNotBetween(String value1, String value2) {
            addCriterion("FLAG_AFIL_EPS not between", value1, value2, "flagAfilEps");
            return this;
        }

        public Criteria andCodiJefePerIsNull() {
            addCriterion("CODI_JEFE_PER is null");
            return this;
        }

        public Criteria andCodiJefePerIsNotNull() {
            addCriterion("CODI_JEFE_PER is not null");
            return this;
        }

        public Criteria andCodiJefePerEqualTo(String value) {
            addCriterion("CODI_JEFE_PER =", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerNotEqualTo(String value) {
            addCriterion("CODI_JEFE_PER <>", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerGreaterThan(String value) {
            addCriterion("CODI_JEFE_PER >", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_JEFE_PER >=", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerLessThan(String value) {
            addCriterion("CODI_JEFE_PER <", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerLessThanOrEqualTo(String value) {
            addCriterion("CODI_JEFE_PER <=", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerLike(String value) {
            addCriterion("CODI_JEFE_PER like", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerNotLike(String value) {
            addCriterion("CODI_JEFE_PER not like", value, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerIn(List<String> values) {
            addCriterion("CODI_JEFE_PER in", values, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerNotIn(List<String> values) {
            addCriterion("CODI_JEFE_PER not in", values, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerBetween(String value1, String value2) {
            addCriterion("CODI_JEFE_PER between", value1, value2, "codiJefePer");
            return this;
        }

        public Criteria andCodiJefePerNotBetween(String value1, String value2) {
            addCriterion("CODI_JEFE_PER not between", value1, value2, "codiJefePer");
            return this;
        }

        public Criteria andIngrEntiPerIsNull() {
            addCriterion("INGR_ENTI_PER is null");
            return this;
        }

        public Criteria andIngrEntiPerIsNotNull() {
            addCriterion("INGR_ENTI_PER is not null");
            return this;
        }

        public Criteria andIngrEntiPerEqualTo(Date value) {
            addCriterionForJDBCDate("INGR_ENTI_PER =", value, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("INGR_ENTI_PER <>", value, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerGreaterThan(Date value) {
            addCriterionForJDBCDate("INGR_ENTI_PER >", value, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("INGR_ENTI_PER >=", value, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerLessThan(Date value) {
            addCriterionForJDBCDate("INGR_ENTI_PER <", value, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("INGR_ENTI_PER <=", value, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerIn(List<Date> values) {
            addCriterionForJDBCDate("INGR_ENTI_PER in", values, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("INGR_ENTI_PER not in", values, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("INGR_ENTI_PER between", value1, value2, "ingrEntiPer");
            return this;
        }

        public Criteria andIngrEntiPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("INGR_ENTI_PER not between", value1, value2, "ingrEntiPer");
            return this;
        }

        public Criteria andInicContPerIsNull() {
            addCriterion("INIC_CONT_PER is null");
            return this;
        }

        public Criteria andInicContPerIsNotNull() {
            addCriterion("INIC_CONT_PER is not null");
            return this;
        }

        public Criteria andInicContPerEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_CONT_PER =", value, "inicContPer");
            return this;
        }

        public Criteria andInicContPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_CONT_PER <>", value, "inicContPer");
            return this;
        }

        public Criteria andInicContPerGreaterThan(Date value) {
            addCriterionForJDBCDate("INIC_CONT_PER >", value, "inicContPer");
            return this;
        }

        public Criteria andInicContPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_CONT_PER >=", value, "inicContPer");
            return this;
        }

        public Criteria andInicContPerLessThan(Date value) {
            addCriterionForJDBCDate("INIC_CONT_PER <", value, "inicContPer");
            return this;
        }

        public Criteria andInicContPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_CONT_PER <=", value, "inicContPer");
            return this;
        }

        public Criteria andInicContPerIn(List<Date> values) {
            addCriterionForJDBCDate("INIC_CONT_PER in", values, "inicContPer");
            return this;
        }

        public Criteria andInicContPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("INIC_CONT_PER not in", values, "inicContPer");
            return this;
        }

        public Criteria andInicContPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("INIC_CONT_PER between", value1, value2, "inicContPer");
            return this;
        }

        public Criteria andInicContPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("INIC_CONT_PER not between", value1, value2, "inicContPer");
            return this;
        }

        public Criteria andFinaContPerIsNull() {
            addCriterion("FINA_CONT_PER is null");
            return this;
        }

        public Criteria andFinaContPerIsNotNull() {
            addCriterion("FINA_CONT_PER is not null");
            return this;
        }

        public Criteria andFinaContPerEqualTo(Date value) {
            addCriterionForJDBCDate("FINA_CONT_PER =", value, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("FINA_CONT_PER <>", value, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerGreaterThan(Date value) {
            addCriterionForJDBCDate("FINA_CONT_PER >", value, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FINA_CONT_PER >=", value, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerLessThan(Date value) {
            addCriterionForJDBCDate("FINA_CONT_PER <", value, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FINA_CONT_PER <=", value, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerIn(List<Date> values) {
            addCriterionForJDBCDate("FINA_CONT_PER in", values, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("FINA_CONT_PER not in", values, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FINA_CONT_PER between", value1, value2, "finaContPer");
            return this;
        }

        public Criteria andFinaContPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FINA_CONT_PER not between", value1, value2, "finaContPer");
            return this;
        }

        public Criteria andInicLaboPerIsNull() {
            addCriterion("INIC_LABO_PER is null");
            return this;
        }

        public Criteria andInicLaboPerIsNotNull() {
            addCriterion("INIC_LABO_PER is not null");
            return this;
        }

        public Criteria andInicLaboPerEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_LABO_PER =", value, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerNotEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_LABO_PER <>", value, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerGreaterThan(Date value) {
            addCriterionForJDBCDate("INIC_LABO_PER >", value, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_LABO_PER >=", value, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerLessThan(Date value) {
            addCriterionForJDBCDate("INIC_LABO_PER <", value, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("INIC_LABO_PER <=", value, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerIn(List<Date> values) {
            addCriterionForJDBCDate("INIC_LABO_PER in", values, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerNotIn(List<Date> values) {
            addCriterionForJDBCDate("INIC_LABO_PER not in", values, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("INIC_LABO_PER between", value1, value2, "inicLaboPer");
            return this;
        }

        public Criteria andInicLaboPerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("INIC_LABO_PER not between", value1, value2, "inicLaboPer");
            return this;
        }

        public Criteria andCodiPlazCapIsNull() {
            addCriterion("CODI_PLAZ_CAP is null");
            return this;
        }

        public Criteria andCodiPlazCapIsNotNull() {
            addCriterion("CODI_PLAZ_CAP is not null");
            return this;
        }

        public Criteria andCodiPlazCapEqualTo(String value) {
            addCriterion("CODI_PLAZ_CAP =", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapNotEqualTo(String value) {
            addCriterion("CODI_PLAZ_CAP <>", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapGreaterThan(String value) {
            addCriterion("CODI_PLAZ_CAP >", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapGreaterThanOrEqualTo(String value) {
            addCriterion("CODI_PLAZ_CAP >=", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapLessThan(String value) {
            addCriterion("CODI_PLAZ_CAP <", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapLessThanOrEqualTo(String value) {
            addCriterion("CODI_PLAZ_CAP <=", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapLike(String value) {
            addCriterion("CODI_PLAZ_CAP like", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapNotLike(String value) {
            addCriterion("CODI_PLAZ_CAP not like", value, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapIn(List<String> values) {
            addCriterion("CODI_PLAZ_CAP in", values, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapNotIn(List<String> values) {
            addCriterion("CODI_PLAZ_CAP not in", values, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapBetween(String value1, String value2) {
            addCriterion("CODI_PLAZ_CAP between", value1, value2, "codiPlazCap");
            return this;
        }

        public Criteria andCodiPlazCapNotBetween(String value1, String value2) {
            addCriterion("CODI_PLAZ_CAP not between", value1, value2, "codiPlazCap");
            return this;
        }

        public Criteria andUnidLocaUloIsNull() {
            addCriterion("UNID_LOCA_ULO is null");
            return this;
        }

        public Criteria andUnidLocaUloIsNotNull() {
            addCriterion("UNID_LOCA_ULO is not null");
            return this;
        }

        public Criteria andUnidLocaUloEqualTo(String value) {
            addCriterion("UNID_LOCA_ULO =", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloNotEqualTo(String value) {
            addCriterion("UNID_LOCA_ULO <>", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloGreaterThan(String value) {
            addCriterion("UNID_LOCA_ULO >", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloGreaterThanOrEqualTo(String value) {
            addCriterion("UNID_LOCA_ULO >=", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloLessThan(String value) {
            addCriterion("UNID_LOCA_ULO <", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloLessThanOrEqualTo(String value) {
            addCriterion("UNID_LOCA_ULO <=", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloLike(String value) {
            addCriterion("UNID_LOCA_ULO like", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloNotLike(String value) {
            addCriterion("UNID_LOCA_ULO not like", value, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloIn(List<String> values) {
            addCriterion("UNID_LOCA_ULO in", values, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloNotIn(List<String> values) {
            addCriterion("UNID_LOCA_ULO not in", values, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloBetween(String value1, String value2) {
            addCriterion("UNID_LOCA_ULO between", value1, value2, "unidLocaUlo");
            return this;
        }

        public Criteria andUnidLocaUloNotBetween(String value1, String value2) {
            addCriterion("UNID_LOCA_ULO not between", value1, value2, "unidLocaUlo");
            return this;
        }

        public Criteria andEssaludVidaIsNull() {
            addCriterion("ESSALUD_VIDA is null");
            return this;
        }

        public Criteria andEssaludVidaIsNotNull() {
            addCriterion("ESSALUD_VIDA is not null");
            return this;
        }

        public Criteria andEssaludVidaEqualTo(String value) {
            addCriterion("ESSALUD_VIDA =", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaNotEqualTo(String value) {
            addCriterion("ESSALUD_VIDA <>", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaGreaterThan(String value) {
            addCriterion("ESSALUD_VIDA >", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaGreaterThanOrEqualTo(String value) {
            addCriterion("ESSALUD_VIDA >=", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaLessThan(String value) {
            addCriterion("ESSALUD_VIDA <", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaLessThanOrEqualTo(String value) {
            addCriterion("ESSALUD_VIDA <=", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaLike(String value) {
            addCriterion("ESSALUD_VIDA like", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaNotLike(String value) {
            addCriterion("ESSALUD_VIDA not like", value, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaIn(List<String> values) {
            addCriterion("ESSALUD_VIDA in", values, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaNotIn(List<String> values) {
            addCriterion("ESSALUD_VIDA not in", values, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaBetween(String value1, String value2) {
            addCriterion("ESSALUD_VIDA between", value1, value2, "essaludVida");
            return this;
        }

        public Criteria andEssaludVidaNotBetween(String value1, String value2) {
            addCriterion("ESSALUD_VIDA not between", value1, value2, "essaludVida");
            return this;
        }

        public Criteria andDomiciliadoIsNull() {
            addCriterion("DOMICILIADO is null");
            return this;
        }

        public Criteria andDomiciliadoIsNotNull() {
            addCriterion("DOMICILIADO is not null");
            return this;
        }

        public Criteria andDomiciliadoEqualTo(String value) {
            addCriterion("DOMICILIADO =", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoNotEqualTo(String value) {
            addCriterion("DOMICILIADO <>", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoGreaterThan(String value) {
            addCriterion("DOMICILIADO >", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoGreaterThanOrEqualTo(String value) {
            addCriterion("DOMICILIADO >=", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoLessThan(String value) {
            addCriterion("DOMICILIADO <", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoLessThanOrEqualTo(String value) {
            addCriterion("DOMICILIADO <=", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoLike(String value) {
            addCriterion("DOMICILIADO like", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoNotLike(String value) {
            addCriterion("DOMICILIADO not like", value, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoIn(List<String> values) {
            addCriterion("DOMICILIADO in", values, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoNotIn(List<String> values) {
            addCriterion("DOMICILIADO not in", values, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoBetween(String value1, String value2) {
            addCriterion("DOMICILIADO between", value1, value2, "domiciliado");
            return this;
        }

        public Criteria andDomiciliadoNotBetween(String value1, String value2) {
            addCriterion("DOMICILIADO not between", value1, value2, "domiciliado");
            return this;
        }

        public Criteria andCodigoTipoViaIsNull() {
            addCriterion("CODIGO_TIPO_VIA is null");
            return this;
        }

        public Criteria andCodigoTipoViaIsNotNull() {
            addCriterion("CODIGO_TIPO_VIA is not null");
            return this;
        }

        public Criteria andCodigoTipoViaEqualTo(String value) {
            addCriterion("CODIGO_TIPO_VIA =", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaNotEqualTo(String value) {
            addCriterion("CODIGO_TIPO_VIA <>", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaGreaterThan(String value) {
            addCriterion("CODIGO_TIPO_VIA >", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_VIA >=", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaLessThan(String value) {
            addCriterion("CODIGO_TIPO_VIA <", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_VIA <=", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaLike(String value) {
            addCriterion("CODIGO_TIPO_VIA like", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaNotLike(String value) {
            addCriterion("CODIGO_TIPO_VIA not like", value, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaIn(List<String> values) {
            addCriterion("CODIGO_TIPO_VIA in", values, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaNotIn(List<String> values) {
            addCriterion("CODIGO_TIPO_VIA not in", values, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_VIA between", value1, value2, "codigoTipoVia");
            return this;
        }

        public Criteria andCodigoTipoViaNotBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_VIA not between", value1, value2, "codigoTipoVia");
            return this;
        }

        public Criteria andDomicilioNombreViaIsNull() {
            addCriterion("DOMICILIO_NOMBRE_VIA is null");
            return this;
        }

        public Criteria andDomicilioNombreViaIsNotNull() {
            addCriterion("DOMICILIO_NOMBRE_VIA is not null");
            return this;
        }

        public Criteria andDomicilioNombreViaEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA =", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaNotEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA <>", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaGreaterThan(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA >", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaGreaterThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA >=", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaLessThan(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA <", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaLessThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA <=", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaLike(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA like", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaNotLike(String value) {
            addCriterion("DOMICILIO_NOMBRE_VIA not like", value, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaIn(List<String> values) {
            addCriterion("DOMICILIO_NOMBRE_VIA in", values, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaNotIn(List<String> values) {
            addCriterion("DOMICILIO_NOMBRE_VIA not in", values, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaBetween(String value1, String value2) {
            addCriterion("DOMICILIO_NOMBRE_VIA between", value1, value2, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNombreViaNotBetween(String value1, String value2) {
            addCriterion("DOMICILIO_NOMBRE_VIA not between", value1, value2, "domicilioNombreVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaIsNull() {
            addCriterion("DOMICILIO_NUMERO_VIA is null");
            return this;
        }

        public Criteria andDomicilioNumeroViaIsNotNull() {
            addCriterion("DOMICILIO_NUMERO_VIA is not null");
            return this;
        }

        public Criteria andDomicilioNumeroViaEqualTo(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA =", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaNotEqualTo(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA <>", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaGreaterThan(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA >", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaGreaterThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA >=", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaLessThan(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA <", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaLessThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA <=", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaLike(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA like", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaNotLike(String value) {
            addCriterion("DOMICILIO_NUMERO_VIA not like", value, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaIn(List<String> values) {
            addCriterion("DOMICILIO_NUMERO_VIA in", values, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaNotIn(List<String> values) {
            addCriterion("DOMICILIO_NUMERO_VIA not in", values, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaBetween(String value1, String value2) {
            addCriterion("DOMICILIO_NUMERO_VIA between", value1, value2, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioNumeroViaNotBetween(String value1, String value2) {
            addCriterion("DOMICILIO_NUMERO_VIA not between", value1, value2, "domicilioNumeroVia");
            return this;
        }

        public Criteria andDomicilioInteriorIsNull() {
            addCriterion("DOMICILIO_INTERIOR is null");
            return this;
        }

        public Criteria andDomicilioInteriorIsNotNull() {
            addCriterion("DOMICILIO_INTERIOR is not null");
            return this;
        }

        public Criteria andDomicilioInteriorEqualTo(String value) {
            addCriterion("DOMICILIO_INTERIOR =", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorNotEqualTo(String value) {
            addCriterion("DOMICILIO_INTERIOR <>", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorGreaterThan(String value) {
            addCriterion("DOMICILIO_INTERIOR >", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorGreaterThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_INTERIOR >=", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorLessThan(String value) {
            addCriterion("DOMICILIO_INTERIOR <", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorLessThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_INTERIOR <=", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorLike(String value) {
            addCriterion("DOMICILIO_INTERIOR like", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorNotLike(String value) {
            addCriterion("DOMICILIO_INTERIOR not like", value, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorIn(List<String> values) {
            addCriterion("DOMICILIO_INTERIOR in", values, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorNotIn(List<String> values) {
            addCriterion("DOMICILIO_INTERIOR not in", values, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorBetween(String value1, String value2) {
            addCriterion("DOMICILIO_INTERIOR between", value1, value2, "domicilioInterior");
            return this;
        }

        public Criteria andDomicilioInteriorNotBetween(String value1, String value2) {
            addCriterion("DOMICILIO_INTERIOR not between", value1, value2, "domicilioInterior");
            return this;
        }

        public Criteria andCodigoTipoZonaIsNull() {
            addCriterion("CODIGO_TIPO_ZONA is null");
            return this;
        }

        public Criteria andCodigoTipoZonaIsNotNull() {
            addCriterion("CODIGO_TIPO_ZONA is not null");
            return this;
        }

        public Criteria andCodigoTipoZonaEqualTo(String value) {
            addCriterion("CODIGO_TIPO_ZONA =", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaNotEqualTo(String value) {
            addCriterion("CODIGO_TIPO_ZONA <>", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaGreaterThan(String value) {
            addCriterion("CODIGO_TIPO_ZONA >", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_ZONA >=", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaLessThan(String value) {
            addCriterion("CODIGO_TIPO_ZONA <", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_ZONA <=", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaLike(String value) {
            addCriterion("CODIGO_TIPO_ZONA like", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaNotLike(String value) {
            addCriterion("CODIGO_TIPO_ZONA not like", value, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaIn(List<String> values) {
            addCriterion("CODIGO_TIPO_ZONA in", values, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaNotIn(List<String> values) {
            addCriterion("CODIGO_TIPO_ZONA not in", values, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_ZONA between", value1, value2, "codigoTipoZona");
            return this;
        }

        public Criteria andCodigoTipoZonaNotBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_ZONA not between", value1, value2, "codigoTipoZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaIsNull() {
            addCriterion("DOMICILIO_NOMBRE_ZONA is null");
            return this;
        }

        public Criteria andDomicilioNombreZonaIsNotNull() {
            addCriterion("DOMICILIO_NOMBRE_ZONA is not null");
            return this;
        }

        public Criteria andDomicilioNombreZonaEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA =", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaNotEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA <>", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaGreaterThan(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA >", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaGreaterThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA >=", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaLessThan(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA <", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaLessThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA <=", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaLike(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA like", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaNotLike(String value) {
            addCriterion("DOMICILIO_NOMBRE_ZONA not like", value, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaIn(List<String> values) {
            addCriterion("DOMICILIO_NOMBRE_ZONA in", values, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaNotIn(List<String> values) {
            addCriterion("DOMICILIO_NOMBRE_ZONA not in", values, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaBetween(String value1, String value2) {
            addCriterion("DOMICILIO_NOMBRE_ZONA between", value1, value2, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioNombreZonaNotBetween(String value1, String value2) {
            addCriterion("DOMICILIO_NOMBRE_ZONA not between", value1, value2, "domicilioNombreZona");
            return this;
        }

        public Criteria andDomicilioReferenciaIsNull() {
            addCriterion("DOMICILIO_REFERENCIA is null");
            return this;
        }

        public Criteria andDomicilioReferenciaIsNotNull() {
            addCriterion("DOMICILIO_REFERENCIA is not null");
            return this;
        }

        public Criteria andDomicilioReferenciaEqualTo(String value) {
            addCriterion("DOMICILIO_REFERENCIA =", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaNotEqualTo(String value) {
            addCriterion("DOMICILIO_REFERENCIA <>", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaGreaterThan(String value) {
            addCriterion("DOMICILIO_REFERENCIA >", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaGreaterThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_REFERENCIA >=", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaLessThan(String value) {
            addCriterion("DOMICILIO_REFERENCIA <", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaLessThanOrEqualTo(String value) {
            addCriterion("DOMICILIO_REFERENCIA <=", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaLike(String value) {
            addCriterion("DOMICILIO_REFERENCIA like", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaNotLike(String value) {
            addCriterion("DOMICILIO_REFERENCIA not like", value, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaIn(List<String> values) {
            addCriterion("DOMICILIO_REFERENCIA in", values, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaNotIn(List<String> values) {
            addCriterion("DOMICILIO_REFERENCIA not in", values, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaBetween(String value1, String value2) {
            addCriterion("DOMICILIO_REFERENCIA between", value1, value2, "domicilioReferencia");
            return this;
        }

        public Criteria andDomicilioReferenciaNotBetween(String value1, String value2) {
            addCriterion("DOMICILIO_REFERENCIA not between", value1, value2, "domicilioReferencia");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorIsNull() {
            addCriterion("CODIGO_TIPO_TRABAJADOR is null");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorIsNotNull() {
            addCriterion("CODIGO_TIPO_TRABAJADOR is not null");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorEqualTo(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR =", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorNotEqualTo(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR <>", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorGreaterThan(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR >", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR >=", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorLessThan(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR <", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR <=", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorLike(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR like", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorNotLike(String value) {
            addCriterion("CODIGO_TIPO_TRABAJADOR not like", value, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorIn(List<String> values) {
            addCriterion("CODIGO_TIPO_TRABAJADOR in", values, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorNotIn(List<String> values) {
            addCriterion("CODIGO_TIPO_TRABAJADOR not in", values, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_TRABAJADOR between", value1, value2, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoTipoTrabajadorNotBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_TRABAJADOR not between", value1, value2, "codigoTipoTrabajador");
            return this;
        }

        public Criteria andCodigoNivelEducativoIsNull() {
            addCriterion("CODIGO_NIVEL_EDUCATIVO is null");
            return this;
        }

        public Criteria andCodigoNivelEducativoIsNotNull() {
            addCriterion("CODIGO_NIVEL_EDUCATIVO is not null");
            return this;
        }

        public Criteria andCodigoNivelEducativoEqualTo(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO =", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoNotEqualTo(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO <>", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoGreaterThan(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO >", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO >=", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoLessThan(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO <", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO <=", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoLike(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO like", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoNotLike(String value) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO not like", value, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoIn(List<String> values) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO in", values, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoNotIn(List<String> values) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO not in", values, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoBetween(String value1, String value2) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO between", value1, value2, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoNivelEducativoNotBetween(String value1, String value2) {
            addCriterion("CODIGO_NIVEL_EDUCATIVO not between", value1, value2, "codigoNivelEducativo");
            return this;
        }

        public Criteria andCodigoOcupacionIsNull() {
            addCriterion("CODIGO_OCUPACION is null");
            return this;
        }

        public Criteria andCodigoOcupacionIsNotNull() {
            addCriterion("CODIGO_OCUPACION is not null");
            return this;
        }

        public Criteria andCodigoOcupacionEqualTo(String value) {
            addCriterion("CODIGO_OCUPACION =", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionNotEqualTo(String value) {
            addCriterion("CODIGO_OCUPACION <>", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionGreaterThan(String value) {
            addCriterion("CODIGO_OCUPACION >", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_OCUPACION >=", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionLessThan(String value) {
            addCriterion("CODIGO_OCUPACION <", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_OCUPACION <=", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionLike(String value) {
            addCriterion("CODIGO_OCUPACION like", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionNotLike(String value) {
            addCriterion("CODIGO_OCUPACION not like", value, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionIn(List<String> values) {
            addCriterion("CODIGO_OCUPACION in", values, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionNotIn(List<String> values) {
            addCriterion("CODIGO_OCUPACION not in", values, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionBetween(String value1, String value2) {
            addCriterion("CODIGO_OCUPACION between", value1, value2, "codigoOcupacion");
            return this;
        }

        public Criteria andCodigoOcupacionNotBetween(String value1, String value2) {
            addCriterion("CODIGO_OCUPACION not between", value1, value2, "codigoOcupacion");
            return this;
        }

        public Criteria andDiscapacidadIsNull() {
            addCriterion("DISCAPACIDAD is null");
            return this;
        }

        public Criteria andDiscapacidadIsNotNull() {
            addCriterion("DISCAPACIDAD is not null");
            return this;
        }

        public Criteria andDiscapacidadEqualTo(String value) {
            addCriterion("DISCAPACIDAD =", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadNotEqualTo(String value) {
            addCriterion("DISCAPACIDAD <>", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadGreaterThan(String value) {
            addCriterion("DISCAPACIDAD >", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadGreaterThanOrEqualTo(String value) {
            addCriterion("DISCAPACIDAD >=", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadLessThan(String value) {
            addCriterion("DISCAPACIDAD <", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadLessThanOrEqualTo(String value) {
            addCriterion("DISCAPACIDAD <=", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadLike(String value) {
            addCriterion("DISCAPACIDAD like", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadNotLike(String value) {
            addCriterion("DISCAPACIDAD not like", value, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadIn(List<String> values) {
            addCriterion("DISCAPACIDAD in", values, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadNotIn(List<String> values) {
            addCriterion("DISCAPACIDAD not in", values, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadBetween(String value1, String value2) {
            addCriterion("DISCAPACIDAD between", value1, value2, "discapacidad");
            return this;
        }

        public Criteria andDiscapacidadNotBetween(String value1, String value2) {
            addCriterion("DISCAPACIDAD not between", value1, value2, "discapacidad");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioIsNull() {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO is null");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioIsNotNull() {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO is not null");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioEqualTo(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO =", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioNotEqualTo(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO <>", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioGreaterThan(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO >", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO >=", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioLessThan(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO <", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO <=", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioLike(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO like", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioNotLike(String value) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO not like", value, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioIn(List<String> values) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO in", values, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioNotIn(List<String> values) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO not in", values, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioBetween(String value1, String value2) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO between", value1, value2, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andCodigoRegimenPensionarioNotBetween(String value1, String value2) {
            addCriterion("CODIGO_REGIMEN_PENSIONARIO not between", value1, value2, "codigoRegimenPensionario");
            return this;
        }

        public Criteria andSctrSaludIsNull() {
            addCriterion("SCTR_SALUD is null");
            return this;
        }

        public Criteria andSctrSaludIsNotNull() {
            addCriterion("SCTR_SALUD is not null");
            return this;
        }

        public Criteria andSctrSaludEqualTo(String value) {
            addCriterion("SCTR_SALUD =", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludNotEqualTo(String value) {
            addCriterion("SCTR_SALUD <>", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludGreaterThan(String value) {
            addCriterion("SCTR_SALUD >", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludGreaterThanOrEqualTo(String value) {
            addCriterion("SCTR_SALUD >=", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludLessThan(String value) {
            addCriterion("SCTR_SALUD <", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludLessThanOrEqualTo(String value) {
            addCriterion("SCTR_SALUD <=", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludLike(String value) {
            addCriterion("SCTR_SALUD like", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludNotLike(String value) {
            addCriterion("SCTR_SALUD not like", value, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludIn(List<String> values) {
            addCriterion("SCTR_SALUD in", values, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludNotIn(List<String> values) {
            addCriterion("SCTR_SALUD not in", values, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludBetween(String value1, String value2) {
            addCriterion("SCTR_SALUD between", value1, value2, "sctrSalud");
            return this;
        }

        public Criteria andSctrSaludNotBetween(String value1, String value2) {
            addCriterion("SCTR_SALUD not between", value1, value2, "sctrSalud");
            return this;
        }

        public Criteria andSctrPensionIsNull() {
            addCriterion("SCTR_PENSION is null");
            return this;
        }

        public Criteria andSctrPensionIsNotNull() {
            addCriterion("SCTR_PENSION is not null");
            return this;
        }

        public Criteria andSctrPensionEqualTo(String value) {
            addCriterion("SCTR_PENSION =", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionNotEqualTo(String value) {
            addCriterion("SCTR_PENSION <>", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionGreaterThan(String value) {
            addCriterion("SCTR_PENSION >", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionGreaterThanOrEqualTo(String value) {
            addCriterion("SCTR_PENSION >=", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionLessThan(String value) {
            addCriterion("SCTR_PENSION <", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionLessThanOrEqualTo(String value) {
            addCriterion("SCTR_PENSION <=", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionLike(String value) {
            addCriterion("SCTR_PENSION like", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionNotLike(String value) {
            addCriterion("SCTR_PENSION not like", value, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionIn(List<String> values) {
            addCriterion("SCTR_PENSION in", values, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionNotIn(List<String> values) {
            addCriterion("SCTR_PENSION not in", values, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionBetween(String value1, String value2) {
            addCriterion("SCTR_PENSION between", value1, value2, "sctrPension");
            return this;
        }

        public Criteria andSctrPensionNotBetween(String value1, String value2) {
            addCriterion("SCTR_PENSION not between", value1, value2, "sctrPension");
            return this;
        }

        public Criteria andCodigoTipoContratoIsNull() {
            addCriterion("CODIGO_TIPO_CONTRATO is null");
            return this;
        }

        public Criteria andCodigoTipoContratoIsNotNull() {
            addCriterion("CODIGO_TIPO_CONTRATO is not null");
            return this;
        }

        public Criteria andCodigoTipoContratoEqualTo(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO =", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoNotEqualTo(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO <>", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoGreaterThan(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO >", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO >=", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoLessThan(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO <", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO <=", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoLike(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO like", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoNotLike(String value) {
            addCriterion("CODIGO_TIPO_CONTRATO not like", value, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoIn(List<String> values) {
            addCriterion("CODIGO_TIPO_CONTRATO in", values, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoNotIn(List<String> values) {
            addCriterion("CODIGO_TIPO_CONTRATO not in", values, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_CONTRATO between", value1, value2, "codigoTipoContrato");
            return this;
        }

        public Criteria andCodigoTipoContratoNotBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_CONTRATO not between", value1, value2, "codigoTipoContrato");
            return this;
        }

        public Criteria andRegimenAlternativoIsNull() {
            addCriterion("REGIMEN_ALTERNATIVO is null");
            return this;
        }

        public Criteria andRegimenAlternativoIsNotNull() {
            addCriterion("REGIMEN_ALTERNATIVO is not null");
            return this;
        }

        public Criteria andRegimenAlternativoEqualTo(String value) {
            addCriterion("REGIMEN_ALTERNATIVO =", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoNotEqualTo(String value) {
            addCriterion("REGIMEN_ALTERNATIVO <>", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoGreaterThan(String value) {
            addCriterion("REGIMEN_ALTERNATIVO >", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoGreaterThanOrEqualTo(String value) {
            addCriterion("REGIMEN_ALTERNATIVO >=", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoLessThan(String value) {
            addCriterion("REGIMEN_ALTERNATIVO <", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoLessThanOrEqualTo(String value) {
            addCriterion("REGIMEN_ALTERNATIVO <=", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoLike(String value) {
            addCriterion("REGIMEN_ALTERNATIVO like", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoNotLike(String value) {
            addCriterion("REGIMEN_ALTERNATIVO not like", value, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoIn(List<String> values) {
            addCriterion("REGIMEN_ALTERNATIVO in", values, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoNotIn(List<String> values) {
            addCriterion("REGIMEN_ALTERNATIVO not in", values, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoBetween(String value1, String value2) {
            addCriterion("REGIMEN_ALTERNATIVO between", value1, value2, "regimenAlternativo");
            return this;
        }

        public Criteria andRegimenAlternativoNotBetween(String value1, String value2) {
            addCriterion("REGIMEN_ALTERNATIVO not between", value1, value2, "regimenAlternativo");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaIsNull() {
            addCriterion("JORNADA_TRABAJO_MAXIMA is null");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaIsNotNull() {
            addCriterion("JORNADA_TRABAJO_MAXIMA is not null");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaEqualTo(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA =", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaNotEqualTo(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA <>", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaGreaterThan(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA >", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaGreaterThanOrEqualTo(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA >=", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaLessThan(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA <", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaLessThanOrEqualTo(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA <=", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaLike(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA like", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaNotLike(String value) {
            addCriterion("JORNADA_TRABAJO_MAXIMA not like", value, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaIn(List<String> values) {
            addCriterion("JORNADA_TRABAJO_MAXIMA in", values, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaNotIn(List<String> values) {
            addCriterion("JORNADA_TRABAJO_MAXIMA not in", values, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaBetween(String value1, String value2) {
            addCriterion("JORNADA_TRABAJO_MAXIMA between", value1, value2, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andJornadaTrabajoMaximaNotBetween(String value1, String value2) {
            addCriterion("JORNADA_TRABAJO_MAXIMA not between", value1, value2, "jornadaTrabajoMaxima");
            return this;
        }

        public Criteria andHorarioNocturnoIsNull() {
            addCriterion("HORARIO_NOCTURNO is null");
            return this;
        }

        public Criteria andHorarioNocturnoIsNotNull() {
            addCriterion("HORARIO_NOCTURNO is not null");
            return this;
        }

        public Criteria andHorarioNocturnoEqualTo(String value) {
            addCriterion("HORARIO_NOCTURNO =", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoNotEqualTo(String value) {
            addCriterion("HORARIO_NOCTURNO <>", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoGreaterThan(String value) {
            addCriterion("HORARIO_NOCTURNO >", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoGreaterThanOrEqualTo(String value) {
            addCriterion("HORARIO_NOCTURNO >=", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoLessThan(String value) {
            addCriterion("HORARIO_NOCTURNO <", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoLessThanOrEqualTo(String value) {
            addCriterion("HORARIO_NOCTURNO <=", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoLike(String value) {
            addCriterion("HORARIO_NOCTURNO like", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoNotLike(String value) {
            addCriterion("HORARIO_NOCTURNO not like", value, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoIn(List<String> values) {
            addCriterion("HORARIO_NOCTURNO in", values, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoNotIn(List<String> values) {
            addCriterion("HORARIO_NOCTURNO not in", values, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoBetween(String value1, String value2) {
            addCriterion("HORARIO_NOCTURNO between", value1, value2, "horarioNocturno");
            return this;
        }

        public Criteria andHorarioNocturnoNotBetween(String value1, String value2) {
            addCriterion("HORARIO_NOCTURNO not between", value1, value2, "horarioNocturno");
            return this;
        }

        public Criteria andOtrosIngresosQuintaIsNull() {
            addCriterion("OTROS_INGRESOS_QUINTA is null");
            return this;
        }

        public Criteria andOtrosIngresosQuintaIsNotNull() {
            addCriterion("OTROS_INGRESOS_QUINTA is not null");
            return this;
        }

        public Criteria andOtrosIngresosQuintaEqualTo(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA =", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaNotEqualTo(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA <>", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaGreaterThan(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA >", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaGreaterThanOrEqualTo(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA >=", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaLessThan(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA <", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaLessThanOrEqualTo(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA <=", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaLike(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA like", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaNotLike(String value) {
            addCriterion("OTROS_INGRESOS_QUINTA not like", value, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaIn(List<String> values) {
            addCriterion("OTROS_INGRESOS_QUINTA in", values, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaNotIn(List<String> values) {
            addCriterion("OTROS_INGRESOS_QUINTA not in", values, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaBetween(String value1, String value2) {
            addCriterion("OTROS_INGRESOS_QUINTA between", value1, value2, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andOtrosIngresosQuintaNotBetween(String value1, String value2) {
            addCriterion("OTROS_INGRESOS_QUINTA not between", value1, value2, "otrosIngresosQuinta");
            return this;
        }

        public Criteria andSindicalizadoIsNull() {
            addCriterion("SINDICALIZADO is null");
            return this;
        }

        public Criteria andSindicalizadoIsNotNull() {
            addCriterion("SINDICALIZADO is not null");
            return this;
        }

        public Criteria andSindicalizadoEqualTo(String value) {
            addCriterion("SINDICALIZADO =", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoNotEqualTo(String value) {
            addCriterion("SINDICALIZADO <>", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoGreaterThan(String value) {
            addCriterion("SINDICALIZADO >", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoGreaterThanOrEqualTo(String value) {
            addCriterion("SINDICALIZADO >=", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoLessThan(String value) {
            addCriterion("SINDICALIZADO <", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoLessThanOrEqualTo(String value) {
            addCriterion("SINDICALIZADO <=", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoLike(String value) {
            addCriterion("SINDICALIZADO like", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoNotLike(String value) {
            addCriterion("SINDICALIZADO not like", value, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoIn(List<String> values) {
            addCriterion("SINDICALIZADO in", values, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoNotIn(List<String> values) {
            addCriterion("SINDICALIZADO not in", values, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoBetween(String value1, String value2) {
            addCriterion("SINDICALIZADO between", value1, value2, "sindicalizado");
            return this;
        }

        public Criteria andSindicalizadoNotBetween(String value1, String value2) {
            addCriterion("SINDICALIZADO not between", value1, value2, "sindicalizado");
            return this;
        }

        public Criteria andCodigoPeriodicidadIsNull() {
            addCriterion("CODIGO_PERIODICIDAD is null");
            return this;
        }

        public Criteria andCodigoPeriodicidadIsNotNull() {
            addCriterion("CODIGO_PERIODICIDAD is not null");
            return this;
        }

        public Criteria andCodigoPeriodicidadEqualTo(String value) {
            addCriterion("CODIGO_PERIODICIDAD =", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadNotEqualTo(String value) {
            addCriterion("CODIGO_PERIODICIDAD <>", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadGreaterThan(String value) {
            addCriterion("CODIGO_PERIODICIDAD >", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_PERIODICIDAD >=", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadLessThan(String value) {
            addCriterion("CODIGO_PERIODICIDAD <", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_PERIODICIDAD <=", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadLike(String value) {
            addCriterion("CODIGO_PERIODICIDAD like", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadNotLike(String value) {
            addCriterion("CODIGO_PERIODICIDAD not like", value, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadIn(List<String> values) {
            addCriterion("CODIGO_PERIODICIDAD in", values, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadNotIn(List<String> values) {
            addCriterion("CODIGO_PERIODICIDAD not in", values, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadBetween(String value1, String value2) {
            addCriterion("CODIGO_PERIODICIDAD between", value1, value2, "codigoPeriodicidad");
            return this;
        }

        public Criteria andCodigoPeriodicidadNotBetween(String value1, String value2) {
            addCriterion("CODIGO_PERIODICIDAD not between", value1, value2, "codigoPeriodicidad");
            return this;
        }

        public Criteria andAfiliadoEpsIsNull() {
            addCriterion("AFILIADO_EPS is null");
            return this;
        }

        public Criteria andAfiliadoEpsIsNotNull() {
            addCriterion("AFILIADO_EPS is not null");
            return this;
        }

        public Criteria andAfiliadoEpsEqualTo(String value) {
            addCriterion("AFILIADO_EPS =", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsNotEqualTo(String value) {
            addCriterion("AFILIADO_EPS <>", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsGreaterThan(String value) {
            addCriterion("AFILIADO_EPS >", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsGreaterThanOrEqualTo(String value) {
            addCriterion("AFILIADO_EPS >=", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsLessThan(String value) {
            addCriterion("AFILIADO_EPS <", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsLessThanOrEqualTo(String value) {
            addCriterion("AFILIADO_EPS <=", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsLike(String value) {
            addCriterion("AFILIADO_EPS like", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsNotLike(String value) {
            addCriterion("AFILIADO_EPS not like", value, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsIn(List<String> values) {
            addCriterion("AFILIADO_EPS in", values, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsNotIn(List<String> values) {
            addCriterion("AFILIADO_EPS not in", values, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsBetween(String value1, String value2) {
            addCriterion("AFILIADO_EPS between", value1, value2, "afiliadoEps");
            return this;
        }

        public Criteria andAfiliadoEpsNotBetween(String value1, String value2) {
            addCriterion("AFILIADO_EPS not between", value1, value2, "afiliadoEps");
            return this;
        }

        public Criteria andCodigoEpsIsNull() {
            addCriterion("CODIGO_EPS is null");
            return this;
        }

        public Criteria andCodigoEpsIsNotNull() {
            addCriterion("CODIGO_EPS is not null");
            return this;
        }

        public Criteria andCodigoEpsEqualTo(String value) {
            addCriterion("CODIGO_EPS =", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsNotEqualTo(String value) {
            addCriterion("CODIGO_EPS <>", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsGreaterThan(String value) {
            addCriterion("CODIGO_EPS >", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_EPS >=", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsLessThan(String value) {
            addCriterion("CODIGO_EPS <", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_EPS <=", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsLike(String value) {
            addCriterion("CODIGO_EPS like", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsNotLike(String value) {
            addCriterion("CODIGO_EPS not like", value, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsIn(List<String> values) {
            addCriterion("CODIGO_EPS in", values, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsNotIn(List<String> values) {
            addCriterion("CODIGO_EPS not in", values, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsBetween(String value1, String value2) {
            addCriterion("CODIGO_EPS between", value1, value2, "codigoEps");
            return this;
        }

        public Criteria andCodigoEpsNotBetween(String value1, String value2) {
            addCriterion("CODIGO_EPS not between", value1, value2, "codigoEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsIsNull() {
            addCriterion("CODIGO_SITUACION_EPS is null");
            return this;
        }

        public Criteria andCodigoSituacionEpsIsNotNull() {
            addCriterion("CODIGO_SITUACION_EPS is not null");
            return this;
        }

        public Criteria andCodigoSituacionEpsEqualTo(String value) {
            addCriterion("CODIGO_SITUACION_EPS =", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsNotEqualTo(String value) {
            addCriterion("CODIGO_SITUACION_EPS <>", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsGreaterThan(String value) {
            addCriterion("CODIGO_SITUACION_EPS >", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_SITUACION_EPS >=", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsLessThan(String value) {
            addCriterion("CODIGO_SITUACION_EPS <", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_SITUACION_EPS <=", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsLike(String value) {
            addCriterion("CODIGO_SITUACION_EPS like", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsNotLike(String value) {
            addCriterion("CODIGO_SITUACION_EPS not like", value, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsIn(List<String> values) {
            addCriterion("CODIGO_SITUACION_EPS in", values, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsNotIn(List<String> values) {
            addCriterion("CODIGO_SITUACION_EPS not in", values, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsBetween(String value1, String value2) {
            addCriterion("CODIGO_SITUACION_EPS between", value1, value2, "codigoSituacionEps");
            return this;
        }

        public Criteria andCodigoSituacionEpsNotBetween(String value1, String value2) {
            addCriterion("CODIGO_SITUACION_EPS not between", value1, value2, "codigoSituacionEps");
            return this;
        }

        public Criteria andRentaQuintaExoneradaIsNull() {
            addCriterion("RENTA_QUINTA_EXONERADA is null");
            return this;
        }

        public Criteria andRentaQuintaExoneradaIsNotNull() {
            addCriterion("RENTA_QUINTA_EXONERADA is not null");
            return this;
        }

        public Criteria andRentaQuintaExoneradaEqualTo(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA =", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaNotEqualTo(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA <>", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaGreaterThan(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA >", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaGreaterThanOrEqualTo(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA >=", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaLessThan(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA <", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaLessThanOrEqualTo(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA <=", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaLike(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA like", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaNotLike(String value) {
            addCriterion("RENTA_QUINTA_EXONERADA not like", value, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaIn(List<String> values) {
            addCriterion("RENTA_QUINTA_EXONERADA in", values, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaNotIn(List<String> values) {
            addCriterion("RENTA_QUINTA_EXONERADA not in", values, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaBetween(String value1, String value2) {
            addCriterion("RENTA_QUINTA_EXONERADA between", value1, value2, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andRentaQuintaExoneradaNotBetween(String value1, String value2) {
            addCriterion("RENTA_QUINTA_EXONERADA not between", value1, value2, "rentaQuintaExonerada");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorIsNull() {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR is null");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorIsNotNull() {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR is not null");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorEqualTo(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR =", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorNotEqualTo(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR <>", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorGreaterThan(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR >", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorGreaterThanOrEqualTo(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR >=", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorLessThan(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR <", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorLessThanOrEqualTo(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR <=", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorLike(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR like", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorNotLike(String value) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR not like", value, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorIn(List<String> values) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR in", values, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorNotIn(List<String> values) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR not in", values, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorBetween(String value1, String value2) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR between", value1, value2, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andSituacionEspecialTrabajadorNotBetween(String value1, String value2) {
            addCriterion("SITUACION_ESPECIAL_TRABAJADOR not between", value1, value2, "situacionEspecialTrabajador");
            return this;
        }

        public Criteria andCodigoTipoPagoIsNull() {
            addCriterion("CODIGO_TIPO_PAGO is null");
            return this;
        }

        public Criteria andCodigoTipoPagoIsNotNull() {
            addCriterion("CODIGO_TIPO_PAGO is not null");
            return this;
        }

        public Criteria andCodigoTipoPagoEqualTo(String value) {
            addCriterion("CODIGO_TIPO_PAGO =", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoNotEqualTo(String value) {
            addCriterion("CODIGO_TIPO_PAGO <>", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoGreaterThan(String value) {
            addCriterion("CODIGO_TIPO_PAGO >", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_PAGO >=", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoLessThan(String value) {
            addCriterion("CODIGO_TIPO_PAGO <", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_TIPO_PAGO <=", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoLike(String value) {
            addCriterion("CODIGO_TIPO_PAGO like", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoNotLike(String value) {
            addCriterion("CODIGO_TIPO_PAGO not like", value, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoIn(List<String> values) {
            addCriterion("CODIGO_TIPO_PAGO in", values, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoNotIn(List<String> values) {
            addCriterion("CODIGO_TIPO_PAGO not in", values, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_PAGO between", value1, value2, "codigoTipoPago");
            return this;
        }

        public Criteria andCodigoTipoPagoNotBetween(String value1, String value2) {
            addCriterion("CODIGO_TIPO_PAGO not between", value1, value2, "codigoTipoPago");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoIsNull() {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO is null");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoIsNotNull() {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO is not null");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO =", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoNotEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO <>", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoGreaterThan(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO >", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoGreaterThanOrEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO >=", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoLessThan(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO <", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoLessThanOrEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO <=", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoLike(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO like", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoNotLike(String value) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO not like", value, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoIn(List<String> values) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO in", values, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoNotIn(List<String> values) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO not in", values, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoBetween(String value1, String value2) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO between", value1, value2, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaSeguroMedicoNotBetween(String value1, String value2) {
            addCriterion("MOD_FORMATIVA_SEGURO_MEDICO not between", value1, value2, "modFormativaSeguroMedico");
            return this;
        }

        public Criteria andModFormativaMadreResponIsNull() {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON is null");
            return this;
        }

        public Criteria andModFormativaMadreResponIsNotNull() {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON is not null");
            return this;
        }

        public Criteria andModFormativaMadreResponEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON =", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponNotEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON <>", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponGreaterThan(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON >", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponGreaterThanOrEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON >=", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponLessThan(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON <", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponLessThanOrEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON <=", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponLike(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON like", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponNotLike(String value) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON not like", value, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponIn(List<String> values) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON in", values, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponNotIn(List<String> values) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON not in", values, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponBetween(String value1, String value2) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON between", value1, value2, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaMadreResponNotBetween(String value1, String value2) {
            addCriterion("MOD_FORMATIVA_MADRE_RESPON not between", value1, value2, "modFormativaMadreRespon");
            return this;
        }

        public Criteria andModFormativaCentroFormacionIsNull() {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION is null");
            return this;
        }

        public Criteria andModFormativaCentroFormacionIsNotNull() {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION is not null");
            return this;
        }

        public Criteria andModFormativaCentroFormacionEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION =", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionNotEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION <>", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionGreaterThan(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION >", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionGreaterThanOrEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION >=", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionLessThan(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION <", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionLessThanOrEqualTo(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION <=", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionLike(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION like", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionNotLike(String value) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION not like", value, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionIn(List<String> values) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION in", values, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionNotIn(List<String> values) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION not in", values, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionBetween(String value1, String value2) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION between", value1, value2, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andModFormativaCentroFormacionNotBetween(String value1, String value2) {
            addCriterion("MOD_FORMATIVA_CENTRO_FORMACION not between", value1, value2, "modFormativaCentroFormacion");
            return this;
        }

        public Criteria andCodigoFinPeriodoIsNull() {
            addCriterion("CODIGO_FIN_PERIODO is null");
            return this;
        }

        public Criteria andCodigoFinPeriodoIsNotNull() {
            addCriterion("CODIGO_FIN_PERIODO is not null");
            return this;
        }

        public Criteria andCodigoFinPeriodoEqualTo(String value) {
            addCriterion("CODIGO_FIN_PERIODO =", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoNotEqualTo(String value) {
            addCriterion("CODIGO_FIN_PERIODO <>", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoGreaterThan(String value) {
            addCriterion("CODIGO_FIN_PERIODO >", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_FIN_PERIODO >=", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoLessThan(String value) {
            addCriterion("CODIGO_FIN_PERIODO <", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_FIN_PERIODO <=", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoLike(String value) {
            addCriterion("CODIGO_FIN_PERIODO like", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoNotLike(String value) {
            addCriterion("CODIGO_FIN_PERIODO not like", value, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoIn(List<String> values) {
            addCriterion("CODIGO_FIN_PERIODO in", values, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoNotIn(List<String> values) {
            addCriterion("CODIGO_FIN_PERIODO not in", values, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoBetween(String value1, String value2) {
            addCriterion("CODIGO_FIN_PERIODO between", value1, value2, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoFinPeriodoNotBetween(String value1, String value2) {
            addCriterion("CODIGO_FIN_PERIODO not between", value1, value2, "codigoFinPeriodo");
            return this;
        }

        public Criteria andCodigoModalidadFormativaIsNull() {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA is null");
            return this;
        }

        public Criteria andCodigoModalidadFormativaIsNotNull() {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA is not null");
            return this;
        }

        public Criteria andCodigoModalidadFormativaEqualTo(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA =", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaNotEqualTo(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA <>", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaGreaterThan(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA >", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaGreaterThanOrEqualTo(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA >=", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaLessThan(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA <", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaLessThanOrEqualTo(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA <=", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaLike(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA like", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaNotLike(String value) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA not like", value, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaIn(List<String> values) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA in", values, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaNotIn(List<String> values) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA not in", values, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaBetween(String value1, String value2) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA between", value1, value2, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andCodigoModalidadFormativaNotBetween(String value1, String value2) {
            addCriterion("CODIGO_MODALIDAD_FORMATIVA not between", value1, value2, "codigoModalidadFormativa");
            return this;
        }

        public Criteria andNacionalidadIsNull() {
            addCriterion("NACIONALIDAD is null");
            return this;
        }

        public Criteria andNacionalidadIsNotNull() {
            addCriterion("NACIONALIDAD is not null");
            return this;
        }

        public Criteria andNacionalidadEqualTo(String value) {
            addCriterion("NACIONALIDAD =", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadNotEqualTo(String value) {
            addCriterion("NACIONALIDAD <>", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadGreaterThan(String value) {
            addCriterion("NACIONALIDAD >", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadGreaterThanOrEqualTo(String value) {
            addCriterion("NACIONALIDAD >=", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadLessThan(String value) {
            addCriterion("NACIONALIDAD <", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadLessThanOrEqualTo(String value) {
            addCriterion("NACIONALIDAD <=", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadLike(String value) {
            addCriterion("NACIONALIDAD like", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadNotLike(String value) {
            addCriterion("NACIONALIDAD not like", value, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadIn(List<String> values) {
            addCriterion("NACIONALIDAD in", values, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadNotIn(List<String> values) {
            addCriterion("NACIONALIDAD not in", values, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadBetween(String value1, String value2) {
            addCriterion("NACIONALIDAD between", value1, value2, "nacionalidad");
            return this;
        }

        public Criteria andNacionalidadNotBetween(String value1, String value2) {
            addCriterion("NACIONALIDAD not between", value1, value2, "nacionalidad");
            return this;
        }

        public Criteria andCategoriaIsNull() {
            addCriterion("CATEGORIA is null");
            return this;
        }

        public Criteria andCategoriaIsNotNull() {
            addCriterion("CATEGORIA is not null");
            return this;
        }

        public Criteria andCategoriaEqualTo(String value) {
            addCriterion("CATEGORIA =", value, "categoria");
            return this;
        }

        public Criteria andCategoriaNotEqualTo(String value) {
            addCriterion("CATEGORIA <>", value, "categoria");
            return this;
        }

        public Criteria andCategoriaGreaterThan(String value) {
            addCriterion("CATEGORIA >", value, "categoria");
            return this;
        }

        public Criteria andCategoriaGreaterThanOrEqualTo(String value) {
            addCriterion("CATEGORIA >=", value, "categoria");
            return this;
        }

        public Criteria andCategoriaLessThan(String value) {
            addCriterion("CATEGORIA <", value, "categoria");
            return this;
        }

        public Criteria andCategoriaLessThanOrEqualTo(String value) {
            addCriterion("CATEGORIA <=", value, "categoria");
            return this;
        }

        public Criteria andCategoriaLike(String value) {
            addCriterion("CATEGORIA like", value, "categoria");
            return this;
        }

        public Criteria andCategoriaNotLike(String value) {
            addCriterion("CATEGORIA not like", value, "categoria");
            return this;
        }

        public Criteria andCategoriaIn(List<String> values) {
            addCriterion("CATEGORIA in", values, "categoria");
            return this;
        }

        public Criteria andCategoriaNotIn(List<String> values) {
            addCriterion("CATEGORIA not in", values, "categoria");
            return this;
        }

        public Criteria andCategoriaBetween(String value1, String value2) {
            addCriterion("CATEGORIA between", value1, value2, "categoria");
            return this;
        }

        public Criteria andCategoriaNotBetween(String value1, String value2) {
            addCriterion("CATEGORIA not between", value1, value2, "categoria");
            return this;
        }

        public Criteria andFechaInicioIsNull() {
            addCriterion("FECHA_INICIO is null");
            return this;
        }

        public Criteria andFechaInicioIsNotNull() {
            addCriterion("FECHA_INICIO is not null");
            return this;
        }

        public Criteria andFechaInicioEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_INICIO =", value, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_INICIO <>", value, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioGreaterThan(Date value) {
            addCriterionForJDBCDate("FECHA_INICIO >", value, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_INICIO >=", value, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioLessThan(Date value) {
            addCriterionForJDBCDate("FECHA_INICIO <", value, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_INICIO <=", value, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_INICIO in", values, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_INICIO not in", values, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_INICIO between", value1, value2, "fechaInicio");
            return this;
        }

        public Criteria andFechaInicioNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_INICIO not between", value1, value2, "fechaInicio");
            return this;
        }

        public Criteria andFechaFinIsNull() {
            addCriterion("FECHA_FIN is null");
            return this;
        }

        public Criteria andFechaFinIsNotNull() {
            addCriterion("FECHA_FIN is not null");
            return this;
        }

        public Criteria andFechaFinEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FIN =", value, "fechaFin");
            return this;
        }

        public Criteria andFechaFinNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FIN <>", value, "fechaFin");
            return this;
        }

        public Criteria andFechaFinGreaterThan(Date value) {
            addCriterionForJDBCDate("FECHA_FIN >", value, "fechaFin");
            return this;
        }

        public Criteria andFechaFinGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FIN >=", value, "fechaFin");
            return this;
        }

        public Criteria andFechaFinLessThan(Date value) {
            addCriterionForJDBCDate("FECHA_FIN <", value, "fechaFin");
            return this;
        }

        public Criteria andFechaFinLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FIN <=", value, "fechaFin");
            return this;
        }

        public Criteria andFechaFinIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_FIN in", values, "fechaFin");
            return this;
        }

        public Criteria andFechaFinNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_FIN not in", values, "fechaFin");
            return this;
        }

        public Criteria andFechaFinBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_FIN between", value1, value2, "fechaFin");
            return this;
        }

        public Criteria andFechaFinNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_FIN not between", value1, value2, "fechaFin");
            return this;
        }

        public Criteria andUserCreaIsNull() {
            addCriterion("USER_CREA is null");
            return this;
        }

        public Criteria andUserCreaIsNotNull() {
            addCriterion("USER_CREA is not null");
            return this;
        }

        public Criteria andUserCreaEqualTo(String value) {
            addCriterion("USER_CREA =", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotEqualTo(String value) {
            addCriterion("USER_CREA <>", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaGreaterThan(String value) {
            addCriterion("USER_CREA >", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaGreaterThanOrEqualTo(String value) {
            addCriterion("USER_CREA >=", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaLessThan(String value) {
            addCriterion("USER_CREA <", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaLessThanOrEqualTo(String value) {
            addCriterion("USER_CREA <=", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaLike(String value) {
            addCriterion("USER_CREA like", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotLike(String value) {
            addCriterion("USER_CREA not like", value, "userCrea");
            return this;
        }

        public Criteria andUserCreaIn(List<String> values) {
            addCriterion("USER_CREA in", values, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotIn(List<String> values) {
            addCriterion("USER_CREA not in", values, "userCrea");
            return this;
        }

        public Criteria andUserCreaBetween(String value1, String value2) {
            addCriterion("USER_CREA between", value1, value2, "userCrea");
            return this;
        }

        public Criteria andUserCreaNotBetween(String value1, String value2) {
            addCriterion("USER_CREA not between", value1, value2, "userCrea");
            return this;
        }

        public Criteria andFechCreaIsNull() {
            addCriterion("FECH_CREA is null");
            return this;
        }

        public Criteria andFechCreaIsNotNull() {
            addCriterion("FECH_CREA is not null");
            return this;
        }

        public Criteria andFechCreaEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA =", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA <>", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaGreaterThan(Date value) {
            addCriterionForJDBCDate("FECH_CREA >", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA >=", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaLessThan(Date value) {
            addCriterionForJDBCDate("FECH_CREA <", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_CREA <=", value, "fechCrea");
            return this;
        }

        public Criteria andFechCreaIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_CREA in", values, "fechCrea");
            return this;
        }

        public Criteria andFechCreaNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_CREA not in", values, "fechCrea");
            return this;
        }

        public Criteria andFechCreaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_CREA between", value1, value2, "fechCrea");
            return this;
        }

        public Criteria andFechCreaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_CREA not between", value1, value2, "fechCrea");
            return this;
        }

        public Criteria andUserModiIsNull() {
            addCriterion("USER_MODI is null");
            return this;
        }

        public Criteria andUserModiIsNotNull() {
            addCriterion("USER_MODI is not null");
            return this;
        }

        public Criteria andUserModiEqualTo(String value) {
            addCriterion("USER_MODI =", value, "userModi");
            return this;
        }

        public Criteria andUserModiNotEqualTo(String value) {
            addCriterion("USER_MODI <>", value, "userModi");
            return this;
        }

        public Criteria andUserModiGreaterThan(String value) {
            addCriterion("USER_MODI >", value, "userModi");
            return this;
        }

        public Criteria andUserModiGreaterThanOrEqualTo(String value) {
            addCriterion("USER_MODI >=", value, "userModi");
            return this;
        }

        public Criteria andUserModiLessThan(String value) {
            addCriterion("USER_MODI <", value, "userModi");
            return this;
        }

        public Criteria andUserModiLessThanOrEqualTo(String value) {
            addCriterion("USER_MODI <=", value, "userModi");
            return this;
        }

        public Criteria andUserModiLike(String value) {
            addCriterion("USER_MODI like", value, "userModi");
            return this;
        }

        public Criteria andUserModiNotLike(String value) {
            addCriterion("USER_MODI not like", value, "userModi");
            return this;
        }

        public Criteria andUserModiIn(List<String> values) {
            addCriterion("USER_MODI in", values, "userModi");
            return this;
        }

        public Criteria andUserModiNotIn(List<String> values) {
            addCriterion("USER_MODI not in", values, "userModi");
            return this;
        }

        public Criteria andUserModiBetween(String value1, String value2) {
            addCriterion("USER_MODI between", value1, value2, "userModi");
            return this;
        }

        public Criteria andUserModiNotBetween(String value1, String value2) {
            addCriterion("USER_MODI not between", value1, value2, "userModi");
            return this;
        }

        public Criteria andFechModiIsNull() {
            addCriterion("FECH_MODI is null");
            return this;
        }

        public Criteria andFechModiIsNotNull() {
            addCriterion("FECH_MODI is not null");
            return this;
        }

        public Criteria andFechModiEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI =", value, "fechModi");
            return this;
        }

        public Criteria andFechModiNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI <>", value, "fechModi");
            return this;
        }

        public Criteria andFechModiGreaterThan(Date value) {
            addCriterionForJDBCDate("FECH_MODI >", value, "fechModi");
            return this;
        }

        public Criteria andFechModiGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI >=", value, "fechModi");
            return this;
        }

        public Criteria andFechModiLessThan(Date value) {
            addCriterionForJDBCDate("FECH_MODI <", value, "fechModi");
            return this;
        }

        public Criteria andFechModiLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECH_MODI <=", value, "fechModi");
            return this;
        }

        public Criteria andFechModiIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_MODI in", values, "fechModi");
            return this;
        }

        public Criteria andFechModiNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECH_MODI not in", values, "fechModi");
            return this;
        }

        public Criteria andFechModiBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_MODI between", value1, value2, "fechModi");
            return this;
        }

        public Criteria andFechModiNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECH_MODI not between", value1, value2, "fechModi");
            return this;
        }

        public Criteria andJefeAnteriorIsNull() {
            addCriterion("JEFE_ANTERIOR is null");
            return this;
        }

        public Criteria andJefeAnteriorIsNotNull() {
            addCriterion("JEFE_ANTERIOR is not null");
            return this;
        }

        public Criteria andJefeAnteriorEqualTo(String value) {
            addCriterion("JEFE_ANTERIOR =", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorNotEqualTo(String value) {
            addCriterion("JEFE_ANTERIOR <>", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorGreaterThan(String value) {
            addCriterion("JEFE_ANTERIOR >", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorGreaterThanOrEqualTo(String value) {
            addCriterion("JEFE_ANTERIOR >=", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorLessThan(String value) {
            addCriterion("JEFE_ANTERIOR <", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorLessThanOrEqualTo(String value) {
            addCriterion("JEFE_ANTERIOR <=", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorLike(String value) {
            addCriterion("JEFE_ANTERIOR like", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorNotLike(String value) {
            addCriterion("JEFE_ANTERIOR not like", value, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorIn(List<String> values) {
            addCriterion("JEFE_ANTERIOR in", values, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorNotIn(List<String> values) {
            addCriterion("JEFE_ANTERIOR not in", values, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorBetween(String value1, String value2) {
            addCriterion("JEFE_ANTERIOR between", value1, value2, "jefeAnterior");
            return this;
        }

        public Criteria andJefeAnteriorNotBetween(String value1, String value2) {
            addCriterion("JEFE_ANTERIOR not between", value1, value2, "jefeAnterior");
            return this;
        }

        public Criteria andNumeRegiArcIsNull() {
            addCriterion("NUME_REGI_ARC is null");
            return this;
        }

        public Criteria andNumeRegiArcIsNotNull() {
            addCriterion("NUME_REGI_ARC is not null");
            return this;
        }

        public Criteria andNumeRegiArcEqualTo(String value) {
            addCriterion("NUME_REGI_ARC =", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcNotEqualTo(String value) {
            addCriterion("NUME_REGI_ARC <>", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcGreaterThan(String value) {
            addCriterion("NUME_REGI_ARC >", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcGreaterThanOrEqualTo(String value) {
            addCriterion("NUME_REGI_ARC >=", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcLessThan(String value) {
            addCriterion("NUME_REGI_ARC <", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcLessThanOrEqualTo(String value) {
            addCriterion("NUME_REGI_ARC <=", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcLike(String value) {
            addCriterion("NUME_REGI_ARC like", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcNotLike(String value) {
            addCriterion("NUME_REGI_ARC not like", value, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcIn(List<String> values) {
            addCriterion("NUME_REGI_ARC in", values, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcNotIn(List<String> values) {
            addCriterion("NUME_REGI_ARC not in", values, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcBetween(String value1, String value2) {
            addCriterion("NUME_REGI_ARC between", value1, value2, "numeRegiArc");
            return this;
        }

        public Criteria andNumeRegiArcNotBetween(String value1, String value2) {
            addCriterion("NUME_REGI_ARC not between", value1, value2, "numeRegiArc");
            return this;
        }

        public Criteria andNumeroRegistroAlternoIsNull() {
            addCriterion("NUMERO_REGISTRO_ALTERNO is null");
            return this;
        }

        public Criteria andNumeroRegistroAlternoIsNotNull() {
            addCriterion("NUMERO_REGISTRO_ALTERNO is not null");
            return this;
        }

        public Criteria andNumeroRegistroAlternoEqualTo(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO =", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoNotEqualTo(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO <>", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoGreaterThan(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO >", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoGreaterThanOrEqualTo(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO >=", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoLessThan(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO <", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoLessThanOrEqualTo(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO <=", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoLike(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO like", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoNotLike(String value) {
            addCriterion("NUMERO_REGISTRO_ALTERNO not like", value, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoIn(List<String> values) {
            addCriterion("NUMERO_REGISTRO_ALTERNO in", values, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoNotIn(List<String> values) {
            addCriterion("NUMERO_REGISTRO_ALTERNO not in", values, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoBetween(String value1, String value2) {
            addCriterion("NUMERO_REGISTRO_ALTERNO between", value1, value2, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andNumeroRegistroAlternoNotBetween(String value1, String value2) {
            addCriterion("NUMERO_REGISTRO_ALTERNO not between", value1, value2, "numeroRegistroAlterno");
            return this;
        }

        public Criteria andVersionFotocheckIsNull() {
            addCriterion("VERSION_FOTOCHECK is null");
            return this;
        }

        public Criteria andVersionFotocheckIsNotNull() {
            addCriterion("VERSION_FOTOCHECK is not null");
            return this;
        }

        public Criteria andVersionFotocheckEqualTo(Short value) {
            addCriterion("VERSION_FOTOCHECK =", value, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckNotEqualTo(Short value) {
            addCriterion("VERSION_FOTOCHECK <>", value, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckGreaterThan(Short value) {
            addCriterion("VERSION_FOTOCHECK >", value, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckGreaterThanOrEqualTo(Short value) {
            addCriterion("VERSION_FOTOCHECK >=", value, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckLessThan(Short value) {
            addCriterion("VERSION_FOTOCHECK <", value, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckLessThanOrEqualTo(Short value) {
            addCriterion("VERSION_FOTOCHECK <=", value, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckIn(List<Short> values) {
            addCriterion("VERSION_FOTOCHECK in", values, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckNotIn(List<Short> values) {
            addCriterion("VERSION_FOTOCHECK not in", values, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckBetween(Short value1, Short value2) {
            addCriterion("VERSION_FOTOCHECK between", value1, value2, "versionFotocheck");
            return this;
        }

        public Criteria andVersionFotocheckNotBetween(Short value1, Short value2) {
            addCriterion("VERSION_FOTOCHECK not between", value1, value2, "versionFotocheck");
            return this;
        }

        public Criteria andIndicadorMigracionIsNull() {
            addCriterion("INDICADOR_MIGRACION is null");
            return this;
        }

        public Criteria andIndicadorMigracionIsNotNull() {
            addCriterion("INDICADOR_MIGRACION is not null");
            return this;
        }

        public Criteria andIndicadorMigracionEqualTo(Short value) {
            addCriterion("INDICADOR_MIGRACION =", value, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionNotEqualTo(Short value) {
            addCriterion("INDICADOR_MIGRACION <>", value, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionGreaterThan(Short value) {
            addCriterion("INDICADOR_MIGRACION >", value, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionGreaterThanOrEqualTo(Short value) {
            addCriterion("INDICADOR_MIGRACION >=", value, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionLessThan(Short value) {
            addCriterion("INDICADOR_MIGRACION <", value, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionLessThanOrEqualTo(Short value) {
            addCriterion("INDICADOR_MIGRACION <=", value, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionIn(List<Short> values) {
            addCriterion("INDICADOR_MIGRACION in", values, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionNotIn(List<Short> values) {
            addCriterion("INDICADOR_MIGRACION not in", values, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionBetween(Short value1, Short value2) {
            addCriterion("INDICADOR_MIGRACION between", value1, value2, "indicadorMigracion");
            return this;
        }

        public Criteria andIndicadorMigracionNotBetween(Short value1, Short value2) {
            addCriterion("INDICADOR_MIGRACION not between", value1, value2, "indicadorMigracion");
            return this;
        }

        public Criteria andNumeroCarnetIsNull() {
            addCriterion("NUMERO_CARNET is null");
            return this;
        }

        public Criteria andNumeroCarnetIsNotNull() {
            addCriterion("NUMERO_CARNET is not null");
            return this;
        }

        public Criteria andNumeroCarnetEqualTo(String value) {
            addCriterion("NUMERO_CARNET =", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetNotEqualTo(String value) {
            addCriterion("NUMERO_CARNET <>", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetGreaterThan(String value) {
            addCriterion("NUMERO_CARNET >", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetGreaterThanOrEqualTo(String value) {
            addCriterion("NUMERO_CARNET >=", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetLessThan(String value) {
            addCriterion("NUMERO_CARNET <", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetLessThanOrEqualTo(String value) {
            addCriterion("NUMERO_CARNET <=", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetLike(String value) {
            addCriterion("NUMERO_CARNET like", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetNotLike(String value) {
            addCriterion("NUMERO_CARNET not like", value, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetIn(List<String> values) {
            addCriterion("NUMERO_CARNET in", values, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetNotIn(List<String> values) {
            addCriterion("NUMERO_CARNET not in", values, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetBetween(String value1, String value2) {
            addCriterion("NUMERO_CARNET between", value1, value2, "numeroCarnet");
            return this;
        }

        public Criteria andNumeroCarnetNotBetween(String value1, String value2) {
            addCriterion("NUMERO_CARNET not between", value1, value2, "numeroCarnet");
            return this;
        }

        public Criteria andGradoEfectivoIsNull() {
            addCriterion("GRADO_EFECTIVO is null");
            return this;
        }

        public Criteria andGradoEfectivoIsNotNull() {
            addCriterion("GRADO_EFECTIVO is not null");
            return this;
        }

        public Criteria andGradoEfectivoEqualTo(String value) {
            addCriterion("GRADO_EFECTIVO =", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoNotEqualTo(String value) {
            addCriterion("GRADO_EFECTIVO <>", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoGreaterThan(String value) {
            addCriterion("GRADO_EFECTIVO >", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoGreaterThanOrEqualTo(String value) {
            addCriterion("GRADO_EFECTIVO >=", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoLessThan(String value) {
            addCriterion("GRADO_EFECTIVO <", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoLessThanOrEqualTo(String value) {
            addCriterion("GRADO_EFECTIVO <=", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoLike(String value) {
            addCriterion("GRADO_EFECTIVO like", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoNotLike(String value) {
            addCriterion("GRADO_EFECTIVO not like", value, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoIn(List<String> values) {
            addCriterion("GRADO_EFECTIVO in", values, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoNotIn(List<String> values) {
            addCriterion("GRADO_EFECTIVO not in", values, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoBetween(String value1, String value2) {
            addCriterion("GRADO_EFECTIVO between", value1, value2, "gradoEfectivo");
            return this;
        }

        public Criteria andGradoEfectivoNotBetween(String value1, String value2) {
            addCriterion("GRADO_EFECTIVO not between", value1, value2, "gradoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoIsNull() {
            addCriterion("TIPO_EFECTIVO is null");
            return this;
        }

        public Criteria andTipoEfectivoIsNotNull() {
            addCriterion("TIPO_EFECTIVO is not null");
            return this;
        }

        public Criteria andTipoEfectivoEqualTo(String value) {
            addCriterion("TIPO_EFECTIVO =", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoNotEqualTo(String value) {
            addCriterion("TIPO_EFECTIVO <>", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoGreaterThan(String value) {
            addCriterion("TIPO_EFECTIVO >", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoGreaterThanOrEqualTo(String value) {
            addCriterion("TIPO_EFECTIVO >=", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoLessThan(String value) {
            addCriterion("TIPO_EFECTIVO <", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoLessThanOrEqualTo(String value) {
            addCriterion("TIPO_EFECTIVO <=", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoLike(String value) {
            addCriterion("TIPO_EFECTIVO like", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoNotLike(String value) {
            addCriterion("TIPO_EFECTIVO not like", value, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoIn(List<String> values) {
            addCriterion("TIPO_EFECTIVO in", values, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoNotIn(List<String> values) {
            addCriterion("TIPO_EFECTIVO not in", values, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoBetween(String value1, String value2) {
            addCriterion("TIPO_EFECTIVO between", value1, value2, "tipoEfectivo");
            return this;
        }

        public Criteria andTipoEfectivoNotBetween(String value1, String value2) {
            addCriterion("TIPO_EFECTIVO not between", value1, value2, "tipoEfectivo");
            return this;
        }

        public Criteria andIndicadorFallecimientoIsNull() {
            addCriterion("INDICADOR_FALLECIMIENTO is null");
            return this;
        }

        public Criteria andIndicadorFallecimientoIsNotNull() {
            addCriterion("INDICADOR_FALLECIMIENTO is not null");
            return this;
        }

        public Criteria andIndicadorFallecimientoEqualTo(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO =", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoNotEqualTo(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO <>", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoGreaterThan(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO >", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoGreaterThanOrEqualTo(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO >=", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoLessThan(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO <", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoLessThanOrEqualTo(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO <=", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoLike(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO like", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoNotLike(String value) {
            addCriterion("INDICADOR_FALLECIMIENTO not like", value, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoIn(List<String> values) {
            addCriterion("INDICADOR_FALLECIMIENTO in", values, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoNotIn(List<String> values) {
            addCriterion("INDICADOR_FALLECIMIENTO not in", values, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoBetween(String value1, String value2) {
            addCriterion("INDICADOR_FALLECIMIENTO between", value1, value2, "indicadorFallecimiento");
            return this;
        }

        public Criteria andIndicadorFallecimientoNotBetween(String value1, String value2) {
            addCriterion("INDICADOR_FALLECIMIENTO not between", value1, value2, "indicadorFallecimiento");
            return this;
        }

        public Criteria andPartidaDefuncionIsNull() {
            addCriterion("PARTIDA_DEFUNCION is null");
            return this;
        }

        public Criteria andPartidaDefuncionIsNotNull() {
            addCriterion("PARTIDA_DEFUNCION is not null");
            return this;
        }

        public Criteria andPartidaDefuncionEqualTo(String value) {
            addCriterion("PARTIDA_DEFUNCION =", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionNotEqualTo(String value) {
            addCriterion("PARTIDA_DEFUNCION <>", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionGreaterThan(String value) {
            addCriterion("PARTIDA_DEFUNCION >", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionGreaterThanOrEqualTo(String value) {
            addCriterion("PARTIDA_DEFUNCION >=", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionLessThan(String value) {
            addCriterion("PARTIDA_DEFUNCION <", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionLessThanOrEqualTo(String value) {
            addCriterion("PARTIDA_DEFUNCION <=", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionLike(String value) {
            addCriterion("PARTIDA_DEFUNCION like", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionNotLike(String value) {
            addCriterion("PARTIDA_DEFUNCION not like", value, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionIn(List<String> values) {
            addCriterion("PARTIDA_DEFUNCION in", values, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionNotIn(List<String> values) {
            addCriterion("PARTIDA_DEFUNCION not in", values, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionBetween(String value1, String value2) {
            addCriterion("PARTIDA_DEFUNCION between", value1, value2, "partidaDefuncion");
            return this;
        }

        public Criteria andPartidaDefuncionNotBetween(String value1, String value2) {
            addCriterion("PARTIDA_DEFUNCION not between", value1, value2, "partidaDefuncion");
            return this;
        }

        public Criteria andFechaPensionIsNull() {
            addCriterion("FECHA_PENSION is null");
            return this;
        }

        public Criteria andFechaPensionIsNotNull() {
            addCriterion("FECHA_PENSION is not null");
            return this;
        }

        public Criteria andFechaPensionEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_PENSION =", value, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_PENSION <>", value, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionGreaterThan(Date value) {
            addCriterionForJDBCDate("FECHA_PENSION >", value, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_PENSION >=", value, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionLessThan(Date value) {
            addCriterionForJDBCDate("FECHA_PENSION <", value, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_PENSION <=", value, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_PENSION in", values, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_PENSION not in", values, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_PENSION between", value1, value2, "fechaPension");
            return this;
        }

        public Criteria andFechaPensionNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_PENSION not between", value1, value2, "fechaPension");
            return this;
        }

        public Criteria andFechaFallecimientoIsNull() {
            addCriterion("FECHA_FALLECIMIENTO is null");
            return this;
        }

        public Criteria andFechaFallecimientoIsNotNull() {
            addCriterion("FECHA_FALLECIMIENTO is not null");
            return this;
        }

        public Criteria andFechaFallecimientoEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO =", value, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoNotEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO <>", value, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoGreaterThan(Date value) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO >", value, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO >=", value, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoLessThan(Date value) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO <", value, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO <=", value, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO in", values, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoNotIn(List<Date> values) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO not in", values, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO between", value1, value2, "fechaFallecimiento");
            return this;
        }

        public Criteria andFechaFallecimientoNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FECHA_FALLECIMIENTO not between", value1, value2, "fechaFallecimiento");
            return this;
        }

        public Criteria andTiempoServicioAniosIsNull() {
            addCriterion("TIEMPO_SERVICIO_ANIOS is null");
            return this;
        }

        public Criteria andTiempoServicioAniosIsNotNull() {
            addCriterion("TIEMPO_SERVICIO_ANIOS is not null");
            return this;
        }

        public Criteria andTiempoServicioAniosEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_ANIOS =", value, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosNotEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_ANIOS <>", value, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosGreaterThan(Short value) {
            addCriterion("TIEMPO_SERVICIO_ANIOS >", value, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosGreaterThanOrEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_ANIOS >=", value, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosLessThan(Short value) {
            addCriterion("TIEMPO_SERVICIO_ANIOS <", value, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosLessThanOrEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_ANIOS <=", value, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosIn(List<Short> values) {
            addCriterion("TIEMPO_SERVICIO_ANIOS in", values, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosNotIn(List<Short> values) {
            addCriterion("TIEMPO_SERVICIO_ANIOS not in", values, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosBetween(Short value1, Short value2) {
            addCriterion("TIEMPO_SERVICIO_ANIOS between", value1, value2, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioAniosNotBetween(Short value1, Short value2) {
            addCriterion("TIEMPO_SERVICIO_ANIOS not between", value1, value2, "tiempoServicioAnios");
            return this;
        }

        public Criteria andTiempoServicioMesesIsNull() {
            addCriterion("TIEMPO_SERVICIO_MESES is null");
            return this;
        }

        public Criteria andTiempoServicioMesesIsNotNull() {
            addCriterion("TIEMPO_SERVICIO_MESES is not null");
            return this;
        }

        public Criteria andTiempoServicioMesesEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_MESES =", value, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesNotEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_MESES <>", value, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesGreaterThan(Short value) {
            addCriterion("TIEMPO_SERVICIO_MESES >", value, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesGreaterThanOrEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_MESES >=", value, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesLessThan(Short value) {
            addCriterion("TIEMPO_SERVICIO_MESES <", value, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesLessThanOrEqualTo(Short value) {
            addCriterion("TIEMPO_SERVICIO_MESES <=", value, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesIn(List<Short> values) {
            addCriterion("TIEMPO_SERVICIO_MESES in", values, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesNotIn(List<Short> values) {
            addCriterion("TIEMPO_SERVICIO_MESES not in", values, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesBetween(Short value1, Short value2) {
            addCriterion("TIEMPO_SERVICIO_MESES between", value1, value2, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioMesesNotBetween(Short value1, Short value2) {
            addCriterion("TIEMPO_SERVICIO_MESES not between", value1, value2, "tiempoServicioMeses");
            return this;
        }

        public Criteria andTiempoServicioDiasIsNull() {
            addCriterion("TIEMPO_SERVICIO_DIAS is null");
            return this;
        }

        public Criteria andTiempoServicioDiasIsNotNull() {
            addCriterion("TIEMPO_SERVICIO_DIAS is not null");
            return this;
        }

        public Criteria andTiempoServicioDiasEqualTo(Integer value) {
            addCriterion("TIEMPO_SERVICIO_DIAS =", value, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasNotEqualTo(Integer value) {
            addCriterion("TIEMPO_SERVICIO_DIAS <>", value, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasGreaterThan(Integer value) {
            addCriterion("TIEMPO_SERVICIO_DIAS >", value, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasGreaterThanOrEqualTo(Integer value) {
            addCriterion("TIEMPO_SERVICIO_DIAS >=", value, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasLessThan(Integer value) {
            addCriterion("TIEMPO_SERVICIO_DIAS <", value, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasLessThanOrEqualTo(Integer value) {
            addCriterion("TIEMPO_SERVICIO_DIAS <=", value, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasIn(List<Integer> values) {
            addCriterion("TIEMPO_SERVICIO_DIAS in", values, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasNotIn(List<Integer> values) {
            addCriterion("TIEMPO_SERVICIO_DIAS not in", values, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasBetween(Integer value1, Integer value2) {
            addCriterion("TIEMPO_SERVICIO_DIAS between", value1, value2, "tiempoServicioDias");
            return this;
        }

        public Criteria andTiempoServicioDiasNotBetween(Integer value1, Integer value2) {
            addCriterion("TIEMPO_SERVICIO_DIAS not between", value1, value2, "tiempoServicioDias");
            return this;
        }

        public Criteria andCodTelefCiudadIsNull() {
            addCriterion("COD_TELEF_CIUDAD is null");
            return this;
        }

        public Criteria andCodTelefCiudadIsNotNull() {
            addCriterion("COD_TELEF_CIUDAD is not null");
            return this;
        }

        public Criteria andCodTelefCiudadEqualTo(String value) {
            addCriterion("COD_TELEF_CIUDAD =", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadNotEqualTo(String value) {
            addCriterion("COD_TELEF_CIUDAD <>", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadGreaterThan(String value) {
            addCriterion("COD_TELEF_CIUDAD >", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadGreaterThanOrEqualTo(String value) {
            addCriterion("COD_TELEF_CIUDAD >=", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadLessThan(String value) {
            addCriterion("COD_TELEF_CIUDAD <", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadLessThanOrEqualTo(String value) {
            addCriterion("COD_TELEF_CIUDAD <=", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadLike(String value) {
            addCriterion("COD_TELEF_CIUDAD like", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadNotLike(String value) {
            addCriterion("COD_TELEF_CIUDAD not like", value, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadIn(List<String> values) {
            addCriterion("COD_TELEF_CIUDAD in", values, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadNotIn(List<String> values) {
            addCriterion("COD_TELEF_CIUDAD not in", values, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadBetween(String value1, String value2) {
            addCriterion("COD_TELEF_CIUDAD between", value1, value2, "codTelefCiudad");
            return this;
        }

        public Criteria andCodTelefCiudadNotBetween(String value1, String value2) {
            addCriterion("COD_TELEF_CIUDAD not between", value1, value2, "codTelefCiudad");
            return this;
        }

        public Criteria andCodPdtDepartaIsNull() {
            addCriterion("COD_PDT_DEPARTA is null");
            return this;
        }

        public Criteria andCodPdtDepartaIsNotNull() {
            addCriterion("COD_PDT_DEPARTA is not null");
            return this;
        }

        public Criteria andCodPdtDepartaEqualTo(String value) {
            addCriterion("COD_PDT_DEPARTA =", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaNotEqualTo(String value) {
            addCriterion("COD_PDT_DEPARTA <>", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaGreaterThan(String value) {
            addCriterion("COD_PDT_DEPARTA >", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaGreaterThanOrEqualTo(String value) {
            addCriterion("COD_PDT_DEPARTA >=", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaLessThan(String value) {
            addCriterion("COD_PDT_DEPARTA <", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaLessThanOrEqualTo(String value) {
            addCriterion("COD_PDT_DEPARTA <=", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaLike(String value) {
            addCriterion("COD_PDT_DEPARTA like", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaNotLike(String value) {
            addCriterion("COD_PDT_DEPARTA not like", value, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaIn(List<String> values) {
            addCriterion("COD_PDT_DEPARTA in", values, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaNotIn(List<String> values) {
            addCriterion("COD_PDT_DEPARTA not in", values, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaBetween(String value1, String value2) {
            addCriterion("COD_PDT_DEPARTA between", value1, value2, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtDepartaNotBetween(String value1, String value2) {
            addCriterion("COD_PDT_DEPARTA not between", value1, value2, "codPdtDeparta");
            return this;
        }

        public Criteria andCodPdtManzanaIsNull() {
            addCriterion("COD_PDT_MANZANA is null");
            return this;
        }

        public Criteria andCodPdtManzanaIsNotNull() {
            addCriterion("COD_PDT_MANZANA is not null");
            return this;
        }

        public Criteria andCodPdtManzanaEqualTo(String value) {
            addCriterion("COD_PDT_MANZANA =", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaNotEqualTo(String value) {
            addCriterion("COD_PDT_MANZANA <>", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaGreaterThan(String value) {
            addCriterion("COD_PDT_MANZANA >", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaGreaterThanOrEqualTo(String value) {
            addCriterion("COD_PDT_MANZANA >=", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaLessThan(String value) {
            addCriterion("COD_PDT_MANZANA <", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaLessThanOrEqualTo(String value) {
            addCriterion("COD_PDT_MANZANA <=", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaLike(String value) {
            addCriterion("COD_PDT_MANZANA like", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaNotLike(String value) {
            addCriterion("COD_PDT_MANZANA not like", value, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaIn(List<String> values) {
            addCriterion("COD_PDT_MANZANA in", values, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaNotIn(List<String> values) {
            addCriterion("COD_PDT_MANZANA not in", values, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaBetween(String value1, String value2) {
            addCriterion("COD_PDT_MANZANA between", value1, value2, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtManzanaNotBetween(String value1, String value2) {
            addCriterion("COD_PDT_MANZANA not between", value1, value2, "codPdtManzana");
            return this;
        }

        public Criteria andCodPdtLoteIsNull() {
            addCriterion("COD_PDT_LOTE is null");
            return this;
        }

        public Criteria andCodPdtLoteIsNotNull() {
            addCriterion("COD_PDT_LOTE is not null");
            return this;
        }

        public Criteria andCodPdtLoteEqualTo(String value) {
            addCriterion("COD_PDT_LOTE =", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteNotEqualTo(String value) {
            addCriterion("COD_PDT_LOTE <>", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteGreaterThan(String value) {
            addCriterion("COD_PDT_LOTE >", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteGreaterThanOrEqualTo(String value) {
            addCriterion("COD_PDT_LOTE >=", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteLessThan(String value) {
            addCriterion("COD_PDT_LOTE <", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteLessThanOrEqualTo(String value) {
            addCriterion("COD_PDT_LOTE <=", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteLike(String value) {
            addCriterion("COD_PDT_LOTE like", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteNotLike(String value) {
            addCriterion("COD_PDT_LOTE not like", value, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteIn(List<String> values) {
            addCriterion("COD_PDT_LOTE in", values, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteNotIn(List<String> values) {
            addCriterion("COD_PDT_LOTE not in", values, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteBetween(String value1, String value2) {
            addCriterion("COD_PDT_LOTE between", value1, value2, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtLoteNotBetween(String value1, String value2) {
            addCriterion("COD_PDT_LOTE not between", value1, value2, "codPdtLote");
            return this;
        }

        public Criteria andCodPdtKilometroIsNull() {
            addCriterion("COD_PDT_KILOMETRO is null");
            return this;
        }

        public Criteria andCodPdtKilometroIsNotNull() {
            addCriterion("COD_PDT_KILOMETRO is not null");
            return this;
        }

        public Criteria andCodPdtKilometroEqualTo(String value) {
            addCriterion("COD_PDT_KILOMETRO =", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroNotEqualTo(String value) {
            addCriterion("COD_PDT_KILOMETRO <>", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroGreaterThan(String value) {
            addCriterion("COD_PDT_KILOMETRO >", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroGreaterThanOrEqualTo(String value) {
            addCriterion("COD_PDT_KILOMETRO >=", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroLessThan(String value) {
            addCriterion("COD_PDT_KILOMETRO <", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroLessThanOrEqualTo(String value) {
            addCriterion("COD_PDT_KILOMETRO <=", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroLike(String value) {
            addCriterion("COD_PDT_KILOMETRO like", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroNotLike(String value) {
            addCriterion("COD_PDT_KILOMETRO not like", value, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroIn(List<String> values) {
            addCriterion("COD_PDT_KILOMETRO in", values, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroNotIn(List<String> values) {
            addCriterion("COD_PDT_KILOMETRO not in", values, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroBetween(String value1, String value2) {
            addCriterion("COD_PDT_KILOMETRO between", value1, value2, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtKilometroNotBetween(String value1, String value2) {
            addCriterion("COD_PDT_KILOMETRO not between", value1, value2, "codPdtKilometro");
            return this;
        }

        public Criteria andCodPdtBlockIsNull() {
            addCriterion("COD_PDT_BLOCK is null");
            return this;
        }

        public Criteria andCodPdtBlockIsNotNull() {
            addCriterion("COD_PDT_BLOCK is not null");
            return this;
        }

        public Criteria andCodPdtBlockEqualTo(String value) {
            addCriterion("COD_PDT_BLOCK =", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockNotEqualTo(String value) {
            addCriterion("COD_PDT_BLOCK <>", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockGreaterThan(String value) {
            addCriterion("COD_PDT_BLOCK >", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockGreaterThanOrEqualTo(String value) {
            addCriterion("COD_PDT_BLOCK >=", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockLessThan(String value) {
            addCriterion("COD_PDT_BLOCK <", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockLessThanOrEqualTo(String value) {
            addCriterion("COD_PDT_BLOCK <=", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockLike(String value) {
            addCriterion("COD_PDT_BLOCK like", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockNotLike(String value) {
            addCriterion("COD_PDT_BLOCK not like", value, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockIn(List<String> values) {
            addCriterion("COD_PDT_BLOCK in", values, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockNotIn(List<String> values) {
            addCriterion("COD_PDT_BLOCK not in", values, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockBetween(String value1, String value2) {
            addCriterion("COD_PDT_BLOCK between", value1, value2, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtBlockNotBetween(String value1, String value2) {
            addCriterion("COD_PDT_BLOCK not between", value1, value2, "codPdtBlock");
            return this;
        }

        public Criteria andCodPdtEtapaIsNull() {
            addCriterion("COD_PDT_ETAPA is null");
            return this;
        }

        public Criteria andCodPdtEtapaIsNotNull() {
            addCriterion("COD_PDT_ETAPA is not null");
            return this;
        }

        public Criteria andCodPdtEtapaEqualTo(String value) {
            addCriterion("COD_PDT_ETAPA =", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaNotEqualTo(String value) {
            addCriterion("COD_PDT_ETAPA <>", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaGreaterThan(String value) {
            addCriterion("COD_PDT_ETAPA >", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaGreaterThanOrEqualTo(String value) {
            addCriterion("COD_PDT_ETAPA >=", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaLessThan(String value) {
            addCriterion("COD_PDT_ETAPA <", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaLessThanOrEqualTo(String value) {
            addCriterion("COD_PDT_ETAPA <=", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaLike(String value) {
            addCriterion("COD_PDT_ETAPA like", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaNotLike(String value) {
            addCriterion("COD_PDT_ETAPA not like", value, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaIn(List<String> values) {
            addCriterion("COD_PDT_ETAPA in", values, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaNotIn(List<String> values) {
            addCriterion("COD_PDT_ETAPA not in", values, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaBetween(String value1, String value2) {
            addCriterion("COD_PDT_ETAPA between", value1, value2, "codPdtEtapa");
            return this;
        }

        public Criteria andCodPdtEtapaNotBetween(String value1, String value2) {
            addCriterion("COD_PDT_ETAPA not between", value1, value2, "codPdtEtapa");
            return this;
        }

        public Criteria andIndAfectoAfpIsNull() {
            addCriterion("IND_AFECTO_AFP is null");
            return this;
        }

        public Criteria andIndAfectoAfpIsNotNull() {
            addCriterion("IND_AFECTO_AFP is not null");
            return this;
        }

        public Criteria andIndAfectoAfpEqualTo(String value) {
            addCriterion("IND_AFECTO_AFP =", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpNotEqualTo(String value) {
            addCriterion("IND_AFECTO_AFP <>", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpGreaterThan(String value) {
            addCriterion("IND_AFECTO_AFP >", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpGreaterThanOrEqualTo(String value) {
            addCriterion("IND_AFECTO_AFP >=", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpLessThan(String value) {
            addCriterion("IND_AFECTO_AFP <", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpLessThanOrEqualTo(String value) {
            addCriterion("IND_AFECTO_AFP <=", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpLike(String value) {
            addCriterion("IND_AFECTO_AFP like", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpNotLike(String value) {
            addCriterion("IND_AFECTO_AFP not like", value, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpIn(List<String> values) {
            addCriterion("IND_AFECTO_AFP in", values, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpNotIn(List<String> values) {
            addCriterion("IND_AFECTO_AFP not in", values, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpBetween(String value1, String value2) {
            addCriterion("IND_AFECTO_AFP between", value1, value2, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfectoAfpNotBetween(String value1, String value2) {
            addCriterion("IND_AFECTO_AFP not between", value1, value2, "indAfectoAfp");
            return this;
        }

        public Criteria andIndAfiliadoEpsIsNull() {
            addCriterion("IND_AFILIADO_EPS is null");
            return this;
        }

        public Criteria andIndAfiliadoEpsIsNotNull() {
            addCriterion("IND_AFILIADO_EPS is not null");
            return this;
        }

        public Criteria andIndAfiliadoEpsEqualTo(String value) {
            addCriterion("IND_AFILIADO_EPS =", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsNotEqualTo(String value) {
            addCriterion("IND_AFILIADO_EPS <>", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsGreaterThan(String value) {
            addCriterion("IND_AFILIADO_EPS >", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsGreaterThanOrEqualTo(String value) {
            addCriterion("IND_AFILIADO_EPS >=", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsLessThan(String value) {
            addCriterion("IND_AFILIADO_EPS <", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsLessThanOrEqualTo(String value) {
            addCriterion("IND_AFILIADO_EPS <=", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsLike(String value) {
            addCriterion("IND_AFILIADO_EPS like", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsNotLike(String value) {
            addCriterion("IND_AFILIADO_EPS not like", value, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsIn(List<String> values) {
            addCriterion("IND_AFILIADO_EPS in", values, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsNotIn(List<String> values) {
            addCriterion("IND_AFILIADO_EPS not in", values, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsBetween(String value1, String value2) {
            addCriterion("IND_AFILIADO_EPS between", value1, value2, "indAfiliadoEps");
            return this;
        }

        public Criteria andIndAfiliadoEpsNotBetween(String value1, String value2) {
            addCriterion("IND_AFILIADO_EPS not between", value1, value2, "indAfiliadoEps");
            return this;
        }

        public Criteria andNumAnexoIsNull() {
            addCriterion("NUM_ANEXO is null");
            return this;
        }

        public Criteria andNumAnexoIsNotNull() {
            addCriterion("NUM_ANEXO is not null");
            return this;
        }

        public Criteria andNumAnexoEqualTo(String value) {
            addCriterion("NUM_ANEXO =", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoNotEqualTo(String value) {
            addCriterion("NUM_ANEXO <>", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoGreaterThan(String value) {
            addCriterion("NUM_ANEXO >", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoGreaterThanOrEqualTo(String value) {
            addCriterion("NUM_ANEXO >=", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoLessThan(String value) {
            addCriterion("NUM_ANEXO <", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoLessThanOrEqualTo(String value) {
            addCriterion("NUM_ANEXO <=", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoLike(String value) {
            addCriterion("NUM_ANEXO like", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoNotLike(String value) {
            addCriterion("NUM_ANEXO not like", value, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoIn(List<String> values) {
            addCriterion("NUM_ANEXO in", values, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoNotIn(List<String> values) {
            addCriterion("NUM_ANEXO not in", values, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoBetween(String value1, String value2) {
            addCriterion("NUM_ANEXO between", value1, value2, "numAnexo");
            return this;
        }

        public Criteria andNumAnexoNotBetween(String value1, String value2) {
            addCriterion("NUM_ANEXO not between", value1, value2, "numAnexo");
            return this;
        }

        public Criteria andNroCertArmaIsNull() {
            addCriterion("NRO_CERT_ARMA is null");
            return this;
        }

        public Criteria andNroCertArmaIsNotNull() {
            addCriterion("NRO_CERT_ARMA is not null");
            return this;
        }

        public Criteria andNroCertArmaEqualTo(String value) {
            addCriterion("NRO_CERT_ARMA =", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaNotEqualTo(String value) {
            addCriterion("NRO_CERT_ARMA <>", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaGreaterThan(String value) {
            addCriterion("NRO_CERT_ARMA >", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaGreaterThanOrEqualTo(String value) {
            addCriterion("NRO_CERT_ARMA >=", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaLessThan(String value) {
            addCriterion("NRO_CERT_ARMA <", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaLessThanOrEqualTo(String value) {
            addCriterion("NRO_CERT_ARMA <=", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaLike(String value) {
            addCriterion("NRO_CERT_ARMA like", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaNotLike(String value) {
            addCriterion("NRO_CERT_ARMA not like", value, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaIn(List<String> values) {
            addCriterion("NRO_CERT_ARMA in", values, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaNotIn(List<String> values) {
            addCriterion("NRO_CERT_ARMA not in", values, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaBetween(String value1, String value2) {
            addCriterion("NRO_CERT_ARMA between", value1, value2, "nroCertArma");
            return this;
        }

        public Criteria andNroCertArmaNotBetween(String value1, String value2) {
            addCriterion("NRO_CERT_ARMA not between", value1, value2, "nroCertArma");
            return this;
        }

        public Criteria andSerieCertArmaIsNull() {
            addCriterion("SERIE_CERT_ARMA is null");
            return this;
        }

        public Criteria andSerieCertArmaIsNotNull() {
            addCriterion("SERIE_CERT_ARMA is not null");
            return this;
        }

        public Criteria andSerieCertArmaEqualTo(String value) {
            addCriterion("SERIE_CERT_ARMA =", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaNotEqualTo(String value) {
            addCriterion("SERIE_CERT_ARMA <>", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaGreaterThan(String value) {
            addCriterion("SERIE_CERT_ARMA >", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaGreaterThanOrEqualTo(String value) {
            addCriterion("SERIE_CERT_ARMA >=", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaLessThan(String value) {
            addCriterion("SERIE_CERT_ARMA <", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaLessThanOrEqualTo(String value) {
            addCriterion("SERIE_CERT_ARMA <=", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaLike(String value) {
            addCriterion("SERIE_CERT_ARMA like", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaNotLike(String value) {
            addCriterion("SERIE_CERT_ARMA not like", value, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaIn(List<String> values) {
            addCriterion("SERIE_CERT_ARMA in", values, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaNotIn(List<String> values) {
            addCriterion("SERIE_CERT_ARMA not in", values, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaBetween(String value1, String value2) {
            addCriterion("SERIE_CERT_ARMA between", value1, value2, "serieCertArma");
            return this;
        }

        public Criteria andSerieCertArmaNotBetween(String value1, String value2) {
            addCriterion("SERIE_CERT_ARMA not between", value1, value2, "serieCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaIsNull() {
            addCriterion("FEC_CAD_CERT_ARMA is null");
            return this;
        }

        public Criteria andFecCadCertArmaIsNotNull() {
            addCriterion("FEC_CAD_CERT_ARMA is not null");
            return this;
        }

        public Criteria andFecCadCertArmaEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA =", value, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaNotEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA <>", value, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaGreaterThan(Date value) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA >", value, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA >=", value, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaLessThan(Date value) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA <", value, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA <=", value, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaIn(List<Date> values) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA in", values, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaNotIn(List<Date> values) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA not in", values, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA between", value1, value2, "fecCadCertArma");
            return this;
        }

        public Criteria andFecCadCertArmaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("FEC_CAD_CERT_ARMA not between", value1, value2, "fecCadCertArma");
            return this;
        }

        public Criteria andIndAfpComIsNull() {
            addCriterion("IND_AFP_COM is null");
            return this;
        }

        public Criteria andIndAfpComIsNotNull() {
            addCriterion("IND_AFP_COM is not null");
            return this;
        }

        public Criteria andIndAfpComEqualTo(String value) {
            addCriterion("IND_AFP_COM =", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComNotEqualTo(String value) {
            addCriterion("IND_AFP_COM <>", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComGreaterThan(String value) {
            addCriterion("IND_AFP_COM >", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComGreaterThanOrEqualTo(String value) {
            addCriterion("IND_AFP_COM >=", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComLessThan(String value) {
            addCriterion("IND_AFP_COM <", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComLessThanOrEqualTo(String value) {
            addCriterion("IND_AFP_COM <=", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComLike(String value) {
            addCriterion("IND_AFP_COM like", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComNotLike(String value) {
            addCriterion("IND_AFP_COM not like", value, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComIn(List<String> values) {
            addCriterion("IND_AFP_COM in", values, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComNotIn(List<String> values) {
            addCriterion("IND_AFP_COM not in", values, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComBetween(String value1, String value2) {
            addCriterion("IND_AFP_COM between", value1, value2, "indAfpCom");
            return this;
        }

        public Criteria andIndAfpComNotBetween(String value1, String value2) {
            addCriterion("IND_AFP_COM not between", value1, value2, "indAfpCom");
            return this;
        }

        public Criteria andCodofinIsNull() {
            addCriterion("CODOFIN is null");
            return this;
        }

        public Criteria andCodofinIsNotNull() {
            addCriterion("CODOFIN is not null");
            return this;
        }

        public Criteria andCodofinEqualTo(String value) {
            addCriterion("CODOFIN =", value, "codofin");
            return this;
        }

        public Criteria andCodofinNotEqualTo(String value) {
            addCriterion("CODOFIN <>", value, "codofin");
            return this;
        }

        public Criteria andCodofinGreaterThan(String value) {
            addCriterion("CODOFIN >", value, "codofin");
            return this;
        }

        public Criteria andCodofinGreaterThanOrEqualTo(String value) {
            addCriterion("CODOFIN >=", value, "codofin");
            return this;
        }

        public Criteria andCodofinLessThan(String value) {
            addCriterion("CODOFIN <", value, "codofin");
            return this;
        }

        public Criteria andCodofinLessThanOrEqualTo(String value) {
            addCriterion("CODOFIN <=", value, "codofin");
            return this;
        }

        public Criteria andCodofinLike(String value) {
            addCriterion("CODOFIN like", value, "codofin");
            return this;
        }

        public Criteria andCodofinNotLike(String value) {
            addCriterion("CODOFIN not like", value, "codofin");
            return this;
        }

        public Criteria andCodofinIn(List<String> values) {
            addCriterion("CODOFIN in", values, "codofin");
            return this;
        }

        public Criteria andCodofinNotIn(List<String> values) {
            addCriterion("CODOFIN not in", values, "codofin");
            return this;
        }

        public Criteria andCodofinBetween(String value1, String value2) {
            addCriterion("CODOFIN between", value1, value2, "codofin");
            return this;
        }

        public Criteria andCodofinNotBetween(String value1, String value2) {
            addCriterion("CODOFIN not between", value1, value2, "codofin");
            return this;
        }

        public Criteria andTarifaDefPoliIsNull() {
            addCriterion("TARIFA_DEF_POLI is null");
            return this;
        }

        public Criteria andTarifaDefPoliIsNotNull() {
            addCriterion("TARIFA_DEF_POLI is not null");
            return this;
        }

        public Criteria andTarifaDefPoliEqualTo(String value) {
            addCriterion("TARIFA_DEF_POLI =", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliNotEqualTo(String value) {
            addCriterion("TARIFA_DEF_POLI <>", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliGreaterThan(String value) {
            addCriterion("TARIFA_DEF_POLI >", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliGreaterThanOrEqualTo(String value) {
            addCriterion("TARIFA_DEF_POLI >=", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliLessThan(String value) {
            addCriterion("TARIFA_DEF_POLI <", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliLessThanOrEqualTo(String value) {
            addCriterion("TARIFA_DEF_POLI <=", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliLike(String value) {
            addCriterion("TARIFA_DEF_POLI like", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliNotLike(String value) {
            addCriterion("TARIFA_DEF_POLI not like", value, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliIn(List<String> values) {
            addCriterion("TARIFA_DEF_POLI in", values, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliNotIn(List<String> values) {
            addCriterion("TARIFA_DEF_POLI not in", values, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliBetween(String value1, String value2) {
            addCriterion("TARIFA_DEF_POLI between", value1, value2, "tarifaDefPoli");
            return this;
        }

        public Criteria andTarifaDefPoliNotBetween(String value1, String value2) {
            addCriterion("TARIFA_DEF_POLI not between", value1, value2, "tarifaDefPoli");
            return this;
        }
    }
}