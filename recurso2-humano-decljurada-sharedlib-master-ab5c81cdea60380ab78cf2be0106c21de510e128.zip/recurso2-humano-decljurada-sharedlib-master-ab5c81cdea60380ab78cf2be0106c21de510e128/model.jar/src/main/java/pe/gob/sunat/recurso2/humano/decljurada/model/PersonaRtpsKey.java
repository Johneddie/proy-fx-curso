package pe.gob.sunat.recurso2.humano.decljurada.model;

public class PersonaRtpsKey {
    private String numDocidePnat;

    private String tipDocidePnat;

    public String getNumDocidePnat() {
        return numDocidePnat;
    }

    public void setNumDocidePnat(String numDocidePnat) {
        this.numDocidePnat = numDocidePnat == null ? null : numDocidePnat.trim();
    }

    public String getTipDocidePnat() {
        return tipDocidePnat;
    }

    public void setTipDocidePnat(String tipDocidePnat) {
        this.tipDocidePnat = tipDocidePnat == null ? null : tipDocidePnat.trim();
    }
}