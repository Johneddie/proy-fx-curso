package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PersonaDatoSecExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public PersonaDatoSecExample() {
        oredCriteria = new ArrayList<>();
    }

    protected PersonaDatoSecExample(PersonaDatoSecExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andT03codPersIsNull() {
            addCriterion("t03cod_pers is null");
            return this;
        }

        public Criteria andT03codPersIsNotNull() {
            addCriterion("t03cod_pers is not null");
            return this;
        }

        public Criteria andT03codPersEqualTo(String value) {
            addCriterion("t03cod_pers =", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersNotEqualTo(String value) {
            addCriterion("t03cod_pers <>", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersGreaterThan(String value) {
            addCriterion("t03cod_pers >", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersGreaterThanOrEqualTo(String value) {
            addCriterion("t03cod_pers >=", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersLessThan(String value) {
            addCriterion("t03cod_pers <", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersLessThanOrEqualTo(String value) {
            addCriterion("t03cod_pers <=", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersLike(String value) {
            addCriterion("t03cod_pers like", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersNotLike(String value) {
            addCriterion("t03cod_pers not like", value, "t03codPers");
            return this;
        }

        public Criteria andT03codPersIn(List<String> values) {
            addCriterion("t03cod_pers in", values, "t03codPers");
            return this;
        }

        public Criteria andT03codPersNotIn(List<String> values) {
            addCriterion("t03cod_pers not in", values, "t03codPers");
            return this;
        }

        public Criteria andT03codPersBetween(String value1, String value2) {
            addCriterion("t03cod_pers between", value1, value2, "t03codPers");
            return this;
        }

        public Criteria andT03codPersNotBetween(String value1, String value2) {
            addCriterion("t03cod_pers not between", value1, value2, "t03codPers");
            return this;
        }

        public Criteria andT03grpSangIsNull() {
            addCriterion("t03grp_sang is null");
            return this;
        }

        public Criteria andT03grpSangIsNotNull() {
            addCriterion("t03grp_sang is not null");
            return this;
        }

        public Criteria andT03grpSangEqualTo(String value) {
            addCriterion("t03grp_sang =", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangNotEqualTo(String value) {
            addCriterion("t03grp_sang <>", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangGreaterThan(String value) {
            addCriterion("t03grp_sang >", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangGreaterThanOrEqualTo(String value) {
            addCriterion("t03grp_sang >=", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangLessThan(String value) {
            addCriterion("t03grp_sang <", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangLessThanOrEqualTo(String value) {
            addCriterion("t03grp_sang <=", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangLike(String value) {
            addCriterion("t03grp_sang like", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangNotLike(String value) {
            addCriterion("t03grp_sang not like", value, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangIn(List<String> values) {
            addCriterion("t03grp_sang in", values, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangNotIn(List<String> values) {
            addCriterion("t03grp_sang not in", values, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangBetween(String value1, String value2) {
            addCriterion("t03grp_sang between", value1, value2, "t03grpSang");
            return this;
        }

        public Criteria andT03grpSangNotBetween(String value1, String value2) {
            addCriterion("t03grp_sang not between", value1, value2, "t03grpSang");
            return this;
        }

        public Criteria andT03sexoIsNull() {
            addCriterion("t03sexo is null");
            return this;
        }

        public Criteria andT03sexoIsNotNull() {
            addCriterion("t03sexo is not null");
            return this;
        }

        public Criteria andT03sexoEqualTo(String value) {
            addCriterion("t03sexo =", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoNotEqualTo(String value) {
            addCriterion("t03sexo <>", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoGreaterThan(String value) {
            addCriterion("t03sexo >", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoGreaterThanOrEqualTo(String value) {
            addCriterion("t03sexo >=", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoLessThan(String value) {
            addCriterion("t03sexo <", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoLessThanOrEqualTo(String value) {
            addCriterion("t03sexo <=", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoLike(String value) {
            addCriterion("t03sexo like", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoNotLike(String value) {
            addCriterion("t03sexo not like", value, "t03sexo");
            return this;
        }

        public Criteria andT03sexoIn(List<String> values) {
            addCriterion("t03sexo in", values, "t03sexo");
            return this;
        }

        public Criteria andT03sexoNotIn(List<String> values) {
            addCriterion("t03sexo not in", values, "t03sexo");
            return this;
        }

        public Criteria andT03sexoBetween(String value1, String value2) {
            addCriterion("t03sexo between", value1, value2, "t03sexo");
            return this;
        }

        public Criteria andT03sexoNotBetween(String value1, String value2) {
            addCriterion("t03sexo not between", value1, value2, "t03sexo");
            return this;
        }

        public Criteria andT03codUbinIsNull() {
            addCriterion("t03cod_ubin is null");
            return this;
        }

        public Criteria andT03codUbinIsNotNull() {
            addCriterion("t03cod_ubin is not null");
            return this;
        }

        public Criteria andT03codUbinEqualTo(String value) {
            addCriterion("t03cod_ubin =", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinNotEqualTo(String value) {
            addCriterion("t03cod_ubin <>", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinGreaterThan(String value) {
            addCriterion("t03cod_ubin >", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinGreaterThanOrEqualTo(String value) {
            addCriterion("t03cod_ubin >=", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinLessThan(String value) {
            addCriterion("t03cod_ubin <", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinLessThanOrEqualTo(String value) {
            addCriterion("t03cod_ubin <=", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinLike(String value) {
            addCriterion("t03cod_ubin like", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinNotLike(String value) {
            addCriterion("t03cod_ubin not like", value, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinIn(List<String> values) {
            addCriterion("t03cod_ubin in", values, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinNotIn(List<String> values) {
            addCriterion("t03cod_ubin not in", values, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinBetween(String value1, String value2) {
            addCriterion("t03cod_ubin between", value1, value2, "t03codUbin");
            return this;
        }

        public Criteria andT03codUbinNotBetween(String value1, String value2) {
            addCriterion("t03cod_ubin not between", value1, value2, "t03codUbin");
            return this;
        }

        public Criteria andT03estCivIsNull() {
            addCriterion("t03est_civ is null");
            return this;
        }

        public Criteria andT03estCivIsNotNull() {
            addCriterion("t03est_civ is not null");
            return this;
        }

        public Criteria andT03estCivEqualTo(String value) {
            addCriterion("t03est_civ =", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivNotEqualTo(String value) {
            addCriterion("t03est_civ <>", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivGreaterThan(String value) {
            addCriterion("t03est_civ >", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivGreaterThanOrEqualTo(String value) {
            addCriterion("t03est_civ >=", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivLessThan(String value) {
            addCriterion("t03est_civ <", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivLessThanOrEqualTo(String value) {
            addCriterion("t03est_civ <=", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivLike(String value) {
            addCriterion("t03est_civ like", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivNotLike(String value) {
            addCriterion("t03est_civ not like", value, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivIn(List<String> values) {
            addCriterion("t03est_civ in", values, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivNotIn(List<String> values) {
            addCriterion("t03est_civ not in", values, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivBetween(String value1, String value2) {
            addCriterion("t03est_civ between", value1, value2, "t03estCiv");
            return this;
        }

        public Criteria andT03estCivNotBetween(String value1, String value2) {
            addCriterion("t03est_civ not between", value1, value2, "t03estCiv");
            return this;
        }

        public Criteria andT03pamfIsNull() {
            addCriterion("t03pamf is null");
            return this;
        }

        public Criteria andT03pamfIsNotNull() {
            addCriterion("t03pamf is not null");
            return this;
        }

        public Criteria andT03pamfEqualTo(String value) {
            addCriterion("t03pamf =", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfNotEqualTo(String value) {
            addCriterion("t03pamf <>", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfGreaterThan(String value) {
            addCriterion("t03pamf >", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfGreaterThanOrEqualTo(String value) {
            addCriterion("t03pamf >=", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfLessThan(String value) {
            addCriterion("t03pamf <", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfLessThanOrEqualTo(String value) {
            addCriterion("t03pamf <=", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfLike(String value) {
            addCriterion("t03pamf like", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfNotLike(String value) {
            addCriterion("t03pamf not like", value, "t03pamf");
            return this;
        }

        public Criteria andT03pamfIn(List<String> values) {
            addCriterion("t03pamf in", values, "t03pamf");
            return this;
        }

        public Criteria andT03pamfNotIn(List<String> values) {
            addCriterion("t03pamf not in", values, "t03pamf");
            return this;
        }

        public Criteria andT03pamfBetween(String value1, String value2) {
            addCriterion("t03pamf between", value1, value2, "t03pamf");
            return this;
        }

        public Criteria andT03pamfNotBetween(String value1, String value2) {
            addCriterion("t03pamf not between", value1, value2, "t03pamf");
            return this;
        }

        public Criteria andT03nFotochIsNull() {
            addCriterion("t03n_fotoch is null");
            return this;
        }

        public Criteria andT03nFotochIsNotNull() {
            addCriterion("t03n_fotoch is not null");
            return this;
        }

        public Criteria andT03nFotochEqualTo(Short value) {
            addCriterion("t03n_fotoch =", value, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochNotEqualTo(Short value) {
            addCriterion("t03n_fotoch <>", value, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochGreaterThan(Short value) {
            addCriterion("t03n_fotoch >", value, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochGreaterThanOrEqualTo(Short value) {
            addCriterion("t03n_fotoch >=", value, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochLessThan(Short value) {
            addCriterion("t03n_fotoch <", value, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochLessThanOrEqualTo(Short value) {
            addCriterion("t03n_fotoch <=", value, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochIn(List<Short> values) {
            addCriterion("t03n_fotoch in", values, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochNotIn(List<Short> values) {
            addCriterion("t03n_fotoch not in", values, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochBetween(Short value1, Short value2) {
            addCriterion("t03n_fotoch between", value1, value2, "t03nFotoch");
            return this;
        }

        public Criteria andT03nFotochNotBetween(Short value1, Short value2) {
            addCriterion("t03n_fotoch not between", value1, value2, "t03nFotoch");
            return this;
        }

        public Criteria andT03observaIsNull() {
            addCriterion("t03observa is null");
            return this;
        }

        public Criteria andT03observaIsNotNull() {
            addCriterion("t03observa is not null");
            return this;
        }

        public Criteria andT03observaEqualTo(String value) {
            addCriterion("t03observa =", value, "t03observa");
            return this;
        }

        public Criteria andT03observaNotEqualTo(String value) {
            addCriterion("t03observa <>", value, "t03observa");
            return this;
        }

        public Criteria andT03observaGreaterThan(String value) {
            addCriterion("t03observa >", value, "t03observa");
            return this;
        }

        public Criteria andT03observaGreaterThanOrEqualTo(String value) {
            addCriterion("t03observa >=", value, "t03observa");
            return this;
        }

        public Criteria andT03observaLessThan(String value) {
            addCriterion("t03observa <", value, "t03observa");
            return this;
        }

        public Criteria andT03observaLessThanOrEqualTo(String value) {
            addCriterion("t03observa <=", value, "t03observa");
            return this;
        }

        public Criteria andT03observaLike(String value) {
            addCriterion("t03observa like", value, "t03observa");
            return this;
        }

        public Criteria andT03observaNotLike(String value) {
            addCriterion("t03observa not like", value, "t03observa");
            return this;
        }

        public Criteria andT03observaIn(List<String> values) {
            addCriterion("t03observa in", values, "t03observa");
            return this;
        }

        public Criteria andT03observaNotIn(List<String> values) {
            addCriterion("t03observa not in", values, "t03observa");
            return this;
        }

        public Criteria andT03observaBetween(String value1, String value2) {
            addCriterion("t03observa between", value1, value2, "t03observa");
            return this;
        }

        public Criteria andT03observaNotBetween(String value1, String value2) {
            addCriterion("t03observa not between", value1, value2, "t03observa");
            return this;
        }

        public Criteria andT03correoIsNull() {
            addCriterion("t03correo is null");
            return this;
        }

        public Criteria andT03correoIsNotNull() {
            addCriterion("t03correo is not null");
            return this;
        }

        public Criteria andT03correoEqualTo(String value) {
            addCriterion("t03correo =", value, "t03correo");
            return this;
        }

        public Criteria andT03correoNotEqualTo(String value) {
            addCriterion("t03correo <>", value, "t03correo");
            return this;
        }

        public Criteria andT03correoGreaterThan(String value) {
            addCriterion("t03correo >", value, "t03correo");
            return this;
        }

        public Criteria andT03correoGreaterThanOrEqualTo(String value) {
            addCriterion("t03correo >=", value, "t03correo");
            return this;
        }

        public Criteria andT03correoLessThan(String value) {
            addCriterion("t03correo <", value, "t03correo");
            return this;
        }

        public Criteria andT03correoLessThanOrEqualTo(String value) {
            addCriterion("t03correo <=", value, "t03correo");
            return this;
        }

        public Criteria andT03correoLike(String value) {
            addCriterion("t03correo like", value, "t03correo");
            return this;
        }

        public Criteria andT03correoNotLike(String value) {
            addCriterion("t03correo not like", value, "t03correo");
            return this;
        }

        public Criteria andT03correoIn(List<String> values) {
            addCriterion("t03correo in", values, "t03correo");
            return this;
        }

        public Criteria andT03correoNotIn(List<String> values) {
            addCriterion("t03correo not in", values, "t03correo");
            return this;
        }

        public Criteria andT03correoBetween(String value1, String value2) {
            addCriterion("t03correo between", value1, value2, "t03correo");
            return this;
        }

        public Criteria andT03correoNotBetween(String value1, String value2) {
            addCriterion("t03correo not between", value1, value2, "t03correo");
            return this;
        }

        public Criteria andT03fGrabaIsNull() {
            addCriterion("t03f_graba is null");
            return this;
        }

        public Criteria andT03fGrabaIsNotNull() {
            addCriterion("t03f_graba is not null");
            return this;
        }

        public Criteria andT03fGrabaEqualTo(Date value) {
            addCriterion("t03f_graba =", value, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaNotEqualTo(Date value) {
            addCriterion("t03f_graba <>", value, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaGreaterThan(Date value) {
            addCriterion("t03f_graba >", value, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t03f_graba >=", value, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaLessThan(Date value) {
            addCriterion("t03f_graba <", value, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t03f_graba <=", value, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaIn(List<Date> values) {
            addCriterion("t03f_graba in", values, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaNotIn(List<Date> values) {
            addCriterion("t03f_graba not in", values, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaBetween(Date value1, Date value2) {
            addCriterion("t03f_graba between", value1, value2, "t03fGraba");
            return this;
        }

        public Criteria andT03fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t03f_graba not between", value1, value2, "t03fGraba");
            return this;
        }

        public Criteria andT03codUserIsNull() {
            addCriterion("t03cod_user is null");
            return this;
        }

        public Criteria andT03codUserIsNotNull() {
            addCriterion("t03cod_user is not null");
            return this;
        }

        public Criteria andT03codUserEqualTo(String value) {
            addCriterion("t03cod_user =", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserNotEqualTo(String value) {
            addCriterion("t03cod_user <>", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserGreaterThan(String value) {
            addCriterion("t03cod_user >", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t03cod_user >=", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserLessThan(String value) {
            addCriterion("t03cod_user <", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserLessThanOrEqualTo(String value) {
            addCriterion("t03cod_user <=", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserLike(String value) {
            addCriterion("t03cod_user like", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserNotLike(String value) {
            addCriterion("t03cod_user not like", value, "t03codUser");
            return this;
        }

        public Criteria andT03codUserIn(List<String> values) {
            addCriterion("t03cod_user in", values, "t03codUser");
            return this;
        }

        public Criteria andT03codUserNotIn(List<String> values) {
            addCriterion("t03cod_user not in", values, "t03codUser");
            return this;
        }

        public Criteria andT03codUserBetween(String value1, String value2) {
            addCriterion("t03cod_user between", value1, value2, "t03codUser");
            return this;
        }

        public Criteria andT03codUserNotBetween(String value1, String value2) {
            addCriterion("t03cod_user not between", value1, value2, "t03codUser");
            return this;
        }
    }
}