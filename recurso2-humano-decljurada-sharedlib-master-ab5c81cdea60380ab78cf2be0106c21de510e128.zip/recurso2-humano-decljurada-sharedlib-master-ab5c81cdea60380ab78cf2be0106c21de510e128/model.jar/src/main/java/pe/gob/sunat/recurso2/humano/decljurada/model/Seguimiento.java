package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Seguimiento extends SeguimientoKey {
    private String codUorgan;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss",timezone="GMT-5:00")
    private Date fecRecep;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss",timezone="GMT-5:00")
    private Date fecDeriv;

    private String indAccionid;

    private String indEstadoid;

    private String codUserorig;

    private String codUserdest;

    private String obsSeg;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss",timezone="GMT-5:00")
    private Date fecCreacion;

    private String codUsucrea;

    private Date fecModif;

    private String codUsumodif;

    private String tipDdjj;

    private String indUltSeg;
    
    
    private String desTipDdjj;
    
    private String desNombres;
    
    private String desNombresResp;
    
    private String desIndEstadoid;

    public String getCodUorgan() {
        return codUorgan;
    }

    public void setCodUorgan(String codUorgan) {
        this.codUorgan = codUorgan == null ? null : codUorgan.trim();
    }

    public Date getFecRecep() {
        return fecRecep;
    }

    public void setFecRecep(Date fecRecep) {
        this.fecRecep = fecRecep;
    }

    public Date getFecDeriv() {
        return fecDeriv;
    }

    public void setFecDeriv(Date fecDeriv) {
        this.fecDeriv = fecDeriv;
    }

    public String getIndAccionid() {
        return indAccionid;
    }

    public void setIndAccionid(String indAccionid) {
        this.indAccionid = indAccionid == null ? null : indAccionid.trim();
    }

    public String getIndEstadoid() {
        return indEstadoid;
    }

    public void setIndEstadoid(String indEstadoid) {
        this.indEstadoid = indEstadoid == null ? null : indEstadoid.trim();
    }

    public String getCodUserorig() {
        return codUserorig;
    }

    public void setCodUserorig(String codUserorig) {
        this.codUserorig = codUserorig == null ? null : codUserorig.trim();
    }

    public String getCodUserdest() {
        return codUserdest;
    }

    public void setCodUserdest(String codUserdest) {
        this.codUserdest = codUserdest == null ? null : codUserdest.trim();
    }

    public String getObsSeg() {
        return obsSeg;
    }

    public void setObsSeg(String obsSeg) {
        this.obsSeg = obsSeg == null ? null : obsSeg.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public String getTipDdjj() {
        return tipDdjj;
    }

    public void setTipDdjj(String tipDdjj) {
        this.tipDdjj = tipDdjj == null ? null : tipDdjj.trim();
    }

    public String getIndUltSeg() {
        return indUltSeg;
    }

    public void setIndUltSeg(String indUltSeg) {
        this.indUltSeg = indUltSeg == null ? null : indUltSeg.trim();
    }

	public String getDesTipDdjj() {
		return desTipDdjj;
	}

	public void setDesTipDdjj(String desTipDdjj) {
		this.desTipDdjj = desTipDdjj;
	}

	public String getDesIndEstadoid() {
		return desIndEstadoid;
	}

	public void setDesIndEstadoid(String desIndEstadoid) {
		this.desIndEstadoid = desIndEstadoid;
	}

	public String getDesNombres() {
		return desNombres;
	}

	public void setDesNombres(String desNombres) {
		this.desNombres = desNombres;
	}

	public String getDesNombresResp() {
		return desNombresResp;
	}

	public void setDesNombresResp(String desNombresResp) {
		this.desNombresResp = desNombresResp;
	}
	
	
    
}