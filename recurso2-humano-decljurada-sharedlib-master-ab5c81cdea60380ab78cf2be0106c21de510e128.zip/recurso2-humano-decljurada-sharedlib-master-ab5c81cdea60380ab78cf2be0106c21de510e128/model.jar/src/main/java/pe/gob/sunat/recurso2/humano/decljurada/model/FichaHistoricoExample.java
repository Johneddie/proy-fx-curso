package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FichaHistoricoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public FichaHistoricoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected FichaHistoricoExample(FichaHistoricoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andCodCatIsNull() {
            addCriterion("cod_cat is null");
            return this;
        }

        public Criteria andCodCatIsNotNull() {
            addCriterion("cod_cat is not null");
            return this;
        }

        public Criteria andCodCatEqualTo(Short value) {
            addCriterion("cod_cat =", value, "codCat");
            return this;
        }

        public Criteria andCodCatNotEqualTo(Short value) {
            addCriterion("cod_cat <>", value, "codCat");
            return this;
        }

        public Criteria andCodCatGreaterThan(Short value) {
            addCriterion("cod_cat >", value, "codCat");
            return this;
        }

        public Criteria andCodCatGreaterThanOrEqualTo(Short value) {
            addCriterion("cod_cat >=", value, "codCat");
            return this;
        }

        public Criteria andCodCatLessThan(Short value) {
            addCriterion("cod_cat <", value, "codCat");
            return this;
        }

        public Criteria andCodCatLessThanOrEqualTo(Short value) {
            addCriterion("cod_cat <=", value, "codCat");
            return this;
        }

        public Criteria andCodCatIn(List<Short> values) {
            addCriterion("cod_cat in", values, "codCat");
            return this;
        }

        public Criteria andCodCatNotIn(List<Short> values) {
            addCriterion("cod_cat not in", values, "codCat");
            return this;
        }

        public Criteria andCodCatBetween(Short value1, Short value2) {
            addCriterion("cod_cat between", value1, value2, "codCat");
            return this;
        }

        public Criteria andCodCatNotBetween(Short value1, Short value2) {
            addCriterion("cod_cat not between", value1, value2, "codCat");
            return this;
        }

        public Criteria andCodPuestoIsNull() {
            addCriterion("cod_puesto is null");
            return this;
        }

        public Criteria andCodPuestoIsNotNull() {
            addCriterion("cod_puesto is not null");
            return this;
        }

        public Criteria andCodPuestoEqualTo(String value) {
            addCriterion("cod_puesto =", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoNotEqualTo(String value) {
            addCriterion("cod_puesto <>", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoGreaterThan(String value) {
            addCriterion("cod_puesto >", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_puesto >=", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoLessThan(String value) {
            addCriterion("cod_puesto <", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoLessThanOrEqualTo(String value) {
            addCriterion("cod_puesto <=", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoLike(String value) {
            addCriterion("cod_puesto like", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoNotLike(String value) {
            addCriterion("cod_puesto not like", value, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoIn(List<String> values) {
            addCriterion("cod_puesto in", values, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoNotIn(List<String> values) {
            addCriterion("cod_puesto not in", values, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoBetween(String value1, String value2) {
            addCriterion("cod_puesto between", value1, value2, "codPuesto");
            return this;
        }

        public Criteria andCodPuestoNotBetween(String value1, String value2) {
            addCriterion("cod_puesto not between", value1, value2, "codPuesto");
            return this;
        }

        public Criteria andNumPostulanteIsNull() {
            addCriterion("num_postulante is null");
            return this;
        }

        public Criteria andNumPostulanteIsNotNull() {
            addCriterion("num_postulante is not null");
            return this;
        }

        public Criteria andNumPostulanteEqualTo(Integer value) {
            addCriterion("num_postulante =", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteNotEqualTo(Integer value) {
            addCriterion("num_postulante <>", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteGreaterThan(Integer value) {
            addCriterion("num_postulante >", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_postulante >=", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteLessThan(Integer value) {
            addCriterion("num_postulante <", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteLessThanOrEqualTo(Integer value) {
            addCriterion("num_postulante <=", value, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteIn(List<Integer> values) {
            addCriterion("num_postulante in", values, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteNotIn(List<Integer> values) {
            addCriterion("num_postulante not in", values, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteBetween(Integer value1, Integer value2) {
            addCriterion("num_postulante between", value1, value2, "numPostulante");
            return this;
        }

        public Criteria andNumPostulanteNotBetween(Integer value1, Integer value2) {
            addCriterion("num_postulante not between", value1, value2, "numPostulante");
            return this;
        }

        public Criteria andCodTipoDocIsNull() {
            addCriterion("cod_tipo_doc is null");
            return this;
        }

        public Criteria andCodTipoDocIsNotNull() {
            addCriterion("cod_tipo_doc is not null");
            return this;
        }

        public Criteria andCodTipoDocEqualTo(String value) {
            addCriterion("cod_tipo_doc =", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocNotEqualTo(String value) {
            addCriterion("cod_tipo_doc <>", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocGreaterThan(String value) {
            addCriterion("cod_tipo_doc >", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tipo_doc >=", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocLessThan(String value) {
            addCriterion("cod_tipo_doc <", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocLessThanOrEqualTo(String value) {
            addCriterion("cod_tipo_doc <=", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocLike(String value) {
            addCriterion("cod_tipo_doc like", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocNotLike(String value) {
            addCriterion("cod_tipo_doc not like", value, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocIn(List<String> values) {
            addCriterion("cod_tipo_doc in", values, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocNotIn(List<String> values) {
            addCriterion("cod_tipo_doc not in", values, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocBetween(String value1, String value2) {
            addCriterion("cod_tipo_doc between", value1, value2, "codTipoDoc");
            return this;
        }

        public Criteria andCodTipoDocNotBetween(String value1, String value2) {
            addCriterion("cod_tipo_doc not between", value1, value2, "codTipoDoc");
            return this;
        }

        public Criteria andNumDocIdIsNull() {
            addCriterion("num_doc_id is null");
            return this;
        }

        public Criteria andNumDocIdIsNotNull() {
            addCriterion("num_doc_id is not null");
            return this;
        }

        public Criteria andNumDocIdEqualTo(String value) {
            addCriterion("num_doc_id =", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdNotEqualTo(String value) {
            addCriterion("num_doc_id <>", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdGreaterThan(String value) {
            addCriterion("num_doc_id >", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdGreaterThanOrEqualTo(String value) {
            addCriterion("num_doc_id >=", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdLessThan(String value) {
            addCriterion("num_doc_id <", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdLessThanOrEqualTo(String value) {
            addCriterion("num_doc_id <=", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdLike(String value) {
            addCriterion("num_doc_id like", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdNotLike(String value) {
            addCriterion("num_doc_id not like", value, "numDocId");
            return this;
        }

        public Criteria andNumDocIdIn(List<String> values) {
            addCriterion("num_doc_id in", values, "numDocId");
            return this;
        }

        public Criteria andNumDocIdNotIn(List<String> values) {
            addCriterion("num_doc_id not in", values, "numDocId");
            return this;
        }

        public Criteria andNumDocIdBetween(String value1, String value2) {
            addCriterion("num_doc_id between", value1, value2, "numDocId");
            return this;
        }

        public Criteria andNumDocIdNotBetween(String value1, String value2) {
            addCriterion("num_doc_id not between", value1, value2, "numDocId");
            return this;
        }

        public Criteria andNomEmailIsNull() {
            addCriterion("nom_email is null");
            return this;
        }

        public Criteria andNomEmailIsNotNull() {
            addCriterion("nom_email is not null");
            return this;
        }

        public Criteria andNomEmailEqualTo(String value) {
            addCriterion("nom_email =", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailNotEqualTo(String value) {
            addCriterion("nom_email <>", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailGreaterThan(String value) {
            addCriterion("nom_email >", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailGreaterThanOrEqualTo(String value) {
            addCriterion("nom_email >=", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailLessThan(String value) {
            addCriterion("nom_email <", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailLessThanOrEqualTo(String value) {
            addCriterion("nom_email <=", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailLike(String value) {
            addCriterion("nom_email like", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailNotLike(String value) {
            addCriterion("nom_email not like", value, "nomEmail");
            return this;
        }

        public Criteria andNomEmailIn(List<String> values) {
            addCriterion("nom_email in", values, "nomEmail");
            return this;
        }

        public Criteria andNomEmailNotIn(List<String> values) {
            addCriterion("nom_email not in", values, "nomEmail");
            return this;
        }

        public Criteria andNomEmailBetween(String value1, String value2) {
            addCriterion("nom_email between", value1, value2, "nomEmail");
            return this;
        }

        public Criteria andNomEmailNotBetween(String value1, String value2) {
            addCriterion("nom_email not between", value1, value2, "nomEmail");
            return this;
        }

        public Criteria andNomPostulanteIsNull() {
            addCriterion("nom_postulante is null");
            return this;
        }

        public Criteria andNomPostulanteIsNotNull() {
            addCriterion("nom_postulante is not null");
            return this;
        }

        public Criteria andNomPostulanteEqualTo(String value) {
            addCriterion("nom_postulante =", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteNotEqualTo(String value) {
            addCriterion("nom_postulante <>", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteGreaterThan(String value) {
            addCriterion("nom_postulante >", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteGreaterThanOrEqualTo(String value) {
            addCriterion("nom_postulante >=", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteLessThan(String value) {
            addCriterion("nom_postulante <", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteLessThanOrEqualTo(String value) {
            addCriterion("nom_postulante <=", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteLike(String value) {
            addCriterion("nom_postulante like", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteNotLike(String value) {
            addCriterion("nom_postulante not like", value, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteIn(List<String> values) {
            addCriterion("nom_postulante in", values, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteNotIn(List<String> values) {
            addCriterion("nom_postulante not in", values, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteBetween(String value1, String value2) {
            addCriterion("nom_postulante between", value1, value2, "nomPostulante");
            return this;
        }

        public Criteria andNomPostulanteNotBetween(String value1, String value2) {
            addCriterion("nom_postulante not between", value1, value2, "nomPostulante");
            return this;
        }

        public Criteria andApePaternoIsNull() {
            addCriterion("ape_paterno is null");
            return this;
        }

        public Criteria andApePaternoIsNotNull() {
            addCriterion("ape_paterno is not null");
            return this;
        }

        public Criteria andApePaternoEqualTo(String value) {
            addCriterion("ape_paterno =", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoNotEqualTo(String value) {
            addCriterion("ape_paterno <>", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoGreaterThan(String value) {
            addCriterion("ape_paterno >", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoGreaterThanOrEqualTo(String value) {
            addCriterion("ape_paterno >=", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoLessThan(String value) {
            addCriterion("ape_paterno <", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoLessThanOrEqualTo(String value) {
            addCriterion("ape_paterno <=", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoLike(String value) {
            addCriterion("ape_paterno like", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoNotLike(String value) {
            addCriterion("ape_paterno not like", value, "apePaterno");
            return this;
        }

        public Criteria andApePaternoIn(List<String> values) {
            addCriterion("ape_paterno in", values, "apePaterno");
            return this;
        }

        public Criteria andApePaternoNotIn(List<String> values) {
            addCriterion("ape_paterno not in", values, "apePaterno");
            return this;
        }

        public Criteria andApePaternoBetween(String value1, String value2) {
            addCriterion("ape_paterno between", value1, value2, "apePaterno");
            return this;
        }

        public Criteria andApePaternoNotBetween(String value1, String value2) {
            addCriterion("ape_paterno not between", value1, value2, "apePaterno");
            return this;
        }

        public Criteria andApeMaternoIsNull() {
            addCriterion("ape_materno is null");
            return this;
        }

        public Criteria andApeMaternoIsNotNull() {
            addCriterion("ape_materno is not null");
            return this;
        }

        public Criteria andApeMaternoEqualTo(String value) {
            addCriterion("ape_materno =", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoNotEqualTo(String value) {
            addCriterion("ape_materno <>", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoGreaterThan(String value) {
            addCriterion("ape_materno >", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoGreaterThanOrEqualTo(String value) {
            addCriterion("ape_materno >=", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoLessThan(String value) {
            addCriterion("ape_materno <", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoLessThanOrEqualTo(String value) {
            addCriterion("ape_materno <=", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoLike(String value) {
            addCriterion("ape_materno like", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoNotLike(String value) {
            addCriterion("ape_materno not like", value, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoIn(List<String> values) {
            addCriterion("ape_materno in", values, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoNotIn(List<String> values) {
            addCriterion("ape_materno not in", values, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoBetween(String value1, String value2) {
            addCriterion("ape_materno between", value1, value2, "apeMaterno");
            return this;
        }

        public Criteria andApeMaternoNotBetween(String value1, String value2) {
            addCriterion("ape_materno not between", value1, value2, "apeMaterno");
            return this;
        }

        public Criteria andFecNacimientoIsNull() {
            addCriterion("fec_nacimiento is null");
            return this;
        }

        public Criteria andFecNacimientoIsNotNull() {
            addCriterion("fec_nacimiento is not null");
            return this;
        }

        public Criteria andFecNacimientoEqualTo(Date value) {
            addCriterion("fec_nacimiento =", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotEqualTo(Date value) {
            addCriterion("fec_nacimiento <>", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoGreaterThan(Date value) {
            addCriterion("fec_nacimiento >", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_nacimiento >=", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoLessThan(Date value) {
            addCriterion("fec_nacimiento <", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoLessThanOrEqualTo(Date value) {
            addCriterion("fec_nacimiento <=", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoIn(List<Date> values) {
            addCriterion("fec_nacimiento in", values, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotIn(List<Date> values) {
            addCriterion("fec_nacimiento not in", values, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoBetween(Date value1, Date value2) {
            addCriterion("fec_nacimiento between", value1, value2, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotBetween(Date value1, Date value2) {
            addCriterion("fec_nacimiento not between", value1, value2, "fecNacimiento");
            return this;
        }

        public Criteria andCodEstcivilIsNull() {
            addCriterion("cod_estcivil is null");
            return this;
        }

        public Criteria andCodEstcivilIsNotNull() {
            addCriterion("cod_estcivil is not null");
            return this;
        }

        public Criteria andCodEstcivilEqualTo(String value) {
            addCriterion("cod_estcivil =", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilNotEqualTo(String value) {
            addCriterion("cod_estcivil <>", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilGreaterThan(String value) {
            addCriterion("cod_estcivil >", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estcivil >=", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilLessThan(String value) {
            addCriterion("cod_estcivil <", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilLessThanOrEqualTo(String value) {
            addCriterion("cod_estcivil <=", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilLike(String value) {
            addCriterion("cod_estcivil like", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilNotLike(String value) {
            addCriterion("cod_estcivil not like", value, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilIn(List<String> values) {
            addCriterion("cod_estcivil in", values, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilNotIn(List<String> values) {
            addCriterion("cod_estcivil not in", values, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilBetween(String value1, String value2) {
            addCriterion("cod_estcivil between", value1, value2, "codEstcivil");
            return this;
        }

        public Criteria andCodEstcivilNotBetween(String value1, String value2) {
            addCriterion("cod_estcivil not between", value1, value2, "codEstcivil");
            return this;
        }

        public Criteria andCodUbigeonacIsNull() {
            addCriterion("cod_ubigeonac is null");
            return this;
        }

        public Criteria andCodUbigeonacIsNotNull() {
            addCriterion("cod_ubigeonac is not null");
            return this;
        }

        public Criteria andCodUbigeonacEqualTo(String value) {
            addCriterion("cod_ubigeonac =", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacNotEqualTo(String value) {
            addCriterion("cod_ubigeonac <>", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacGreaterThan(String value) {
            addCriterion("cod_ubigeonac >", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeonac >=", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacLessThan(String value) {
            addCriterion("cod_ubigeonac <", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacLessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeonac <=", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacLike(String value) {
            addCriterion("cod_ubigeonac like", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacNotLike(String value) {
            addCriterion("cod_ubigeonac not like", value, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacIn(List<String> values) {
            addCriterion("cod_ubigeonac in", values, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacNotIn(List<String> values) {
            addCriterion("cod_ubigeonac not in", values, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacBetween(String value1, String value2) {
            addCriterion("cod_ubigeonac between", value1, value2, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeonacNotBetween(String value1, String value2) {
            addCriterion("cod_ubigeonac not between", value1, value2, "codUbigeonac");
            return this;
        }

        public Criteria andCodUbigeodomIsNull() {
            addCriterion("cod_ubigeodom is null");
            return this;
        }

        public Criteria andCodUbigeodomIsNotNull() {
            addCriterion("cod_ubigeodom is not null");
            return this;
        }

        public Criteria andCodUbigeodomEqualTo(String value) {
            addCriterion("cod_ubigeodom =", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomNotEqualTo(String value) {
            addCriterion("cod_ubigeodom <>", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomGreaterThan(String value) {
            addCriterion("cod_ubigeodom >", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeodom >=", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomLessThan(String value) {
            addCriterion("cod_ubigeodom <", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomLessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeodom <=", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomLike(String value) {
            addCriterion("cod_ubigeodom like", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomNotLike(String value) {
            addCriterion("cod_ubigeodom not like", value, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomIn(List<String> values) {
            addCriterion("cod_ubigeodom in", values, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomNotIn(List<String> values) {
            addCriterion("cod_ubigeodom not in", values, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomBetween(String value1, String value2) {
            addCriterion("cod_ubigeodom between", value1, value2, "codUbigeodom");
            return this;
        }

        public Criteria andCodUbigeodomNotBetween(String value1, String value2) {
            addCriterion("cod_ubigeodom not between", value1, value2, "codUbigeodom");
            return this;
        }

        public Criteria andCodTipzonaIsNull() {
            addCriterion("cod_tipzona is null");
            return this;
        }

        public Criteria andCodTipzonaIsNotNull() {
            addCriterion("cod_tipzona is not null");
            return this;
        }

        public Criteria andCodTipzonaEqualTo(String value) {
            addCriterion("cod_tipzona =", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaNotEqualTo(String value) {
            addCriterion("cod_tipzona <>", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaGreaterThan(String value) {
            addCriterion("cod_tipzona >", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tipzona >=", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaLessThan(String value) {
            addCriterion("cod_tipzona <", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaLessThanOrEqualTo(String value) {
            addCriterion("cod_tipzona <=", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaLike(String value) {
            addCriterion("cod_tipzona like", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaNotLike(String value) {
            addCriterion("cod_tipzona not like", value, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaIn(List<String> values) {
            addCriterion("cod_tipzona in", values, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaNotIn(List<String> values) {
            addCriterion("cod_tipzona not in", values, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaBetween(String value1, String value2) {
            addCriterion("cod_tipzona between", value1, value2, "codTipzona");
            return this;
        }

        public Criteria andCodTipzonaNotBetween(String value1, String value2) {
            addCriterion("cod_tipzona not between", value1, value2, "codTipzona");
            return this;
        }

        public Criteria andNomZonaIsNull() {
            addCriterion("nom_zona is null");
            return this;
        }

        public Criteria andNomZonaIsNotNull() {
            addCriterion("nom_zona is not null");
            return this;
        }

        public Criteria andNomZonaEqualTo(String value) {
            addCriterion("nom_zona =", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaNotEqualTo(String value) {
            addCriterion("nom_zona <>", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaGreaterThan(String value) {
            addCriterion("nom_zona >", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaGreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona >=", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaLessThan(String value) {
            addCriterion("nom_zona <", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaLessThanOrEqualTo(String value) {
            addCriterion("nom_zona <=", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaLike(String value) {
            addCriterion("nom_zona like", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaNotLike(String value) {
            addCriterion("nom_zona not like", value, "nomZona");
            return this;
        }

        public Criteria andNomZonaIn(List<String> values) {
            addCriterion("nom_zona in", values, "nomZona");
            return this;
        }

        public Criteria andNomZonaNotIn(List<String> values) {
            addCriterion("nom_zona not in", values, "nomZona");
            return this;
        }

        public Criteria andNomZonaBetween(String value1, String value2) {
            addCriterion("nom_zona between", value1, value2, "nomZona");
            return this;
        }

        public Criteria andNomZonaNotBetween(String value1, String value2) {
            addCriterion("nom_zona not between", value1, value2, "nomZona");
            return this;
        }

        public Criteria andCodTipviaIsNull() {
            addCriterion("cod_tipvia is null");
            return this;
        }

        public Criteria andCodTipviaIsNotNull() {
            addCriterion("cod_tipvia is not null");
            return this;
        }

        public Criteria andCodTipviaEqualTo(String value) {
            addCriterion("cod_tipvia =", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaNotEqualTo(String value) {
            addCriterion("cod_tipvia <>", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaGreaterThan(String value) {
            addCriterion("cod_tipvia >", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tipvia >=", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaLessThan(String value) {
            addCriterion("cod_tipvia <", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaLessThanOrEqualTo(String value) {
            addCriterion("cod_tipvia <=", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaLike(String value) {
            addCriterion("cod_tipvia like", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaNotLike(String value) {
            addCriterion("cod_tipvia not like", value, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaIn(List<String> values) {
            addCriterion("cod_tipvia in", values, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaNotIn(List<String> values) {
            addCriterion("cod_tipvia not in", values, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaBetween(String value1, String value2) {
            addCriterion("cod_tipvia between", value1, value2, "codTipvia");
            return this;
        }

        public Criteria andCodTipviaNotBetween(String value1, String value2) {
            addCriterion("cod_tipvia not between", value1, value2, "codTipvia");
            return this;
        }

        public Criteria andNomViaIsNull() {
            addCriterion("nom_via is null");
            return this;
        }

        public Criteria andNomViaIsNotNull() {
            addCriterion("nom_via is not null");
            return this;
        }

        public Criteria andNomViaEqualTo(String value) {
            addCriterion("nom_via =", value, "nomVia");
            return this;
        }

        public Criteria andNomViaNotEqualTo(String value) {
            addCriterion("nom_via <>", value, "nomVia");
            return this;
        }

        public Criteria andNomViaGreaterThan(String value) {
            addCriterion("nom_via >", value, "nomVia");
            return this;
        }

        public Criteria andNomViaGreaterThanOrEqualTo(String value) {
            addCriterion("nom_via >=", value, "nomVia");
            return this;
        }

        public Criteria andNomViaLessThan(String value) {
            addCriterion("nom_via <", value, "nomVia");
            return this;
        }

        public Criteria andNomViaLessThanOrEqualTo(String value) {
            addCriterion("nom_via <=", value, "nomVia");
            return this;
        }

        public Criteria andNomViaLike(String value) {
            addCriterion("nom_via like", value, "nomVia");
            return this;
        }

        public Criteria andNomViaNotLike(String value) {
            addCriterion("nom_via not like", value, "nomVia");
            return this;
        }

        public Criteria andNomViaIn(List<String> values) {
            addCriterion("nom_via in", values, "nomVia");
            return this;
        }

        public Criteria andNomViaNotIn(List<String> values) {
            addCriterion("nom_via not in", values, "nomVia");
            return this;
        }

        public Criteria andNomViaBetween(String value1, String value2) {
            addCriterion("nom_via between", value1, value2, "nomVia");
            return this;
        }

        public Criteria andNomViaNotBetween(String value1, String value2) {
            addCriterion("nom_via not between", value1, value2, "nomVia");
            return this;
        }

        public Criteria andNumDomIsNull() {
            addCriterion("num_dom is null");
            return this;
        }

        public Criteria andNumDomIsNotNull() {
            addCriterion("num_dom is not null");
            return this;
        }

        public Criteria andNumDomEqualTo(String value) {
            addCriterion("num_dom =", value, "numDom");
            return this;
        }

        public Criteria andNumDomNotEqualTo(String value) {
            addCriterion("num_dom <>", value, "numDom");
            return this;
        }

        public Criteria andNumDomGreaterThan(String value) {
            addCriterion("num_dom >", value, "numDom");
            return this;
        }

        public Criteria andNumDomGreaterThanOrEqualTo(String value) {
            addCriterion("num_dom >=", value, "numDom");
            return this;
        }

        public Criteria andNumDomLessThan(String value) {
            addCriterion("num_dom <", value, "numDom");
            return this;
        }

        public Criteria andNumDomLessThanOrEqualTo(String value) {
            addCriterion("num_dom <=", value, "numDom");
            return this;
        }

        public Criteria andNumDomLike(String value) {
            addCriterion("num_dom like", value, "numDom");
            return this;
        }

        public Criteria andNumDomNotLike(String value) {
            addCriterion("num_dom not like", value, "numDom");
            return this;
        }

        public Criteria andNumDomIn(List<String> values) {
            addCriterion("num_dom in", values, "numDom");
            return this;
        }

        public Criteria andNumDomNotIn(List<String> values) {
            addCriterion("num_dom not in", values, "numDom");
            return this;
        }

        public Criteria andNumDomBetween(String value1, String value2) {
            addCriterion("num_dom between", value1, value2, "numDom");
            return this;
        }

        public Criteria andNumDomNotBetween(String value1, String value2) {
            addCriterion("num_dom not between", value1, value2, "numDom");
            return this;
        }

        public Criteria andNumTelcasaIsNull() {
            addCriterion("num_telcasa is null");
            return this;
        }

        public Criteria andNumTelcasaIsNotNull() {
            addCriterion("num_telcasa is not null");
            return this;
        }

        public Criteria andNumTelcasaEqualTo(String value) {
            addCriterion("num_telcasa =", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaNotEqualTo(String value) {
            addCriterion("num_telcasa <>", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaGreaterThan(String value) {
            addCriterion("num_telcasa >", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaGreaterThanOrEqualTo(String value) {
            addCriterion("num_telcasa >=", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaLessThan(String value) {
            addCriterion("num_telcasa <", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaLessThanOrEqualTo(String value) {
            addCriterion("num_telcasa <=", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaLike(String value) {
            addCriterion("num_telcasa like", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaNotLike(String value) {
            addCriterion("num_telcasa not like", value, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaIn(List<String> values) {
            addCriterion("num_telcasa in", values, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaNotIn(List<String> values) {
            addCriterion("num_telcasa not in", values, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaBetween(String value1, String value2) {
            addCriterion("num_telcasa between", value1, value2, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcasaNotBetween(String value1, String value2) {
            addCriterion("num_telcasa not between", value1, value2, "numTelcasa");
            return this;
        }

        public Criteria andNumTelcelularIsNull() {
            addCriterion("num_telcelular is null");
            return this;
        }

        public Criteria andNumTelcelularIsNotNull() {
            addCriterion("num_telcelular is not null");
            return this;
        }

        public Criteria andNumTelcelularEqualTo(String value) {
            addCriterion("num_telcelular =", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularNotEqualTo(String value) {
            addCriterion("num_telcelular <>", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularGreaterThan(String value) {
            addCriterion("num_telcelular >", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularGreaterThanOrEqualTo(String value) {
            addCriterion("num_telcelular >=", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularLessThan(String value) {
            addCriterion("num_telcelular <", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularLessThanOrEqualTo(String value) {
            addCriterion("num_telcelular <=", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularLike(String value) {
            addCriterion("num_telcelular like", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularNotLike(String value) {
            addCriterion("num_telcelular not like", value, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularIn(List<String> values) {
            addCriterion("num_telcelular in", values, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularNotIn(List<String> values) {
            addCriterion("num_telcelular not in", values, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularBetween(String value1, String value2) {
            addCriterion("num_telcelular between", value1, value2, "numTelcelular");
            return this;
        }

        public Criteria andNumTelcelularNotBetween(String value1, String value2) {
            addCriterion("num_telcelular not between", value1, value2, "numTelcelular");
            return this;
        }

        public Criteria andIndAnteriorIsNull() {
            addCriterion("ind_anterior is null");
            return this;
        }

        public Criteria andIndAnteriorIsNotNull() {
            addCriterion("ind_anterior is not null");
            return this;
        }

        public Criteria andIndAnteriorEqualTo(String value) {
            addCriterion("ind_anterior =", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorNotEqualTo(String value) {
            addCriterion("ind_anterior <>", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorGreaterThan(String value) {
            addCriterion("ind_anterior >", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorGreaterThanOrEqualTo(String value) {
            addCriterion("ind_anterior >=", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorLessThan(String value) {
            addCriterion("ind_anterior <", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorLessThanOrEqualTo(String value) {
            addCriterion("ind_anterior <=", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorLike(String value) {
            addCriterion("ind_anterior like", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorNotLike(String value) {
            addCriterion("ind_anterior not like", value, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorIn(List<String> values) {
            addCriterion("ind_anterior in", values, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorNotIn(List<String> values) {
            addCriterion("ind_anterior not in", values, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorBetween(String value1, String value2) {
            addCriterion("ind_anterior between", value1, value2, "indAnterior");
            return this;
        }

        public Criteria andIndAnteriorNotBetween(String value1, String value2) {
            addCriterion("ind_anterior not between", value1, value2, "indAnterior");
            return this;
        }

        public Criteria andNumLicenciaIsNull() {
            addCriterion("num_licencia is null");
            return this;
        }

        public Criteria andNumLicenciaIsNotNull() {
            addCriterion("num_licencia is not null");
            return this;
        }

        public Criteria andNumLicenciaEqualTo(String value) {
            addCriterion("num_licencia =", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaNotEqualTo(String value) {
            addCriterion("num_licencia <>", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaGreaterThan(String value) {
            addCriterion("num_licencia >", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaGreaterThanOrEqualTo(String value) {
            addCriterion("num_licencia >=", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaLessThan(String value) {
            addCriterion("num_licencia <", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaLessThanOrEqualTo(String value) {
            addCriterion("num_licencia <=", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaLike(String value) {
            addCriterion("num_licencia like", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaNotLike(String value) {
            addCriterion("num_licencia not like", value, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaIn(List<String> values) {
            addCriterion("num_licencia in", values, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaNotIn(List<String> values) {
            addCriterion("num_licencia not in", values, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaBetween(String value1, String value2) {
            addCriterion("num_licencia between", value1, value2, "numLicencia");
            return this;
        }

        public Criteria andNumLicenciaNotBetween(String value1, String value2) {
            addCriterion("num_licencia not between", value1, value2, "numLicencia");
            return this;
        }

        public Criteria andDirCarpetaarchivoIsNull() {
            addCriterion("dir_carpetaarchivo is null");
            return this;
        }

        public Criteria andDirCarpetaarchivoIsNotNull() {
            addCriterion("dir_carpetaarchivo is not null");
            return this;
        }

        public Criteria andDirCarpetaarchivoEqualTo(String value) {
            addCriterion("dir_carpetaarchivo =", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoNotEqualTo(String value) {
            addCriterion("dir_carpetaarchivo <>", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoGreaterThan(String value) {
            addCriterion("dir_carpetaarchivo >", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoGreaterThanOrEqualTo(String value) {
            addCriterion("dir_carpetaarchivo >=", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoLessThan(String value) {
            addCriterion("dir_carpetaarchivo <", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoLessThanOrEqualTo(String value) {
            addCriterion("dir_carpetaarchivo <=", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoLike(String value) {
            addCriterion("dir_carpetaarchivo like", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoNotLike(String value) {
            addCriterion("dir_carpetaarchivo not like", value, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoIn(List<String> values) {
            addCriterion("dir_carpetaarchivo in", values, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoNotIn(List<String> values) {
            addCriterion("dir_carpetaarchivo not in", values, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoBetween(String value1, String value2) {
            addCriterion("dir_carpetaarchivo between", value1, value2, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andDirCarpetaarchivoNotBetween(String value1, String value2) {
            addCriterion("dir_carpetaarchivo not between", value1, value2, "dirCarpetaarchivo");
            return this;
        }

        public Criteria andMtoPretensioneconIsNull() {
            addCriterion("mto_pretensionecon is null");
            return this;
        }

        public Criteria andMtoPretensioneconIsNotNull() {
            addCriterion("mto_pretensionecon is not null");
            return this;
        }

        public Criteria andMtoPretensioneconEqualTo(BigDecimal value) {
            addCriterion("mto_pretensionecon =", value, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconNotEqualTo(BigDecimal value) {
            addCriterion("mto_pretensionecon <>", value, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconGreaterThan(BigDecimal value) {
            addCriterion("mto_pretensionecon >", value, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("mto_pretensionecon >=", value, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconLessThan(BigDecimal value) {
            addCriterion("mto_pretensionecon <", value, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconLessThanOrEqualTo(BigDecimal value) {
            addCriterion("mto_pretensionecon <=", value, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconIn(List<BigDecimal> values) {
            addCriterion("mto_pretensionecon in", values, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconNotIn(List<BigDecimal> values) {
            addCriterion("mto_pretensionecon not in", values, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("mto_pretensionecon between", value1, value2, "mtoPretensionecon");
            return this;
        }

        public Criteria andMtoPretensioneconNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("mto_pretensionecon not between", value1, value2, "mtoPretensionecon");
            return this;
        }

        public Criteria andIndSunatIdIsNull() {
            addCriterion("ind_sunat_id is null");
            return this;
        }

        public Criteria andIndSunatIdIsNotNull() {
            addCriterion("ind_sunat_id is not null");
            return this;
        }

        public Criteria andIndSunatIdEqualTo(String value) {
            addCriterion("ind_sunat_id =", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdNotEqualTo(String value) {
            addCriterion("ind_sunat_id <>", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdGreaterThan(String value) {
            addCriterion("ind_sunat_id >", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sunat_id >=", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdLessThan(String value) {
            addCriterion("ind_sunat_id <", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdLessThanOrEqualTo(String value) {
            addCriterion("ind_sunat_id <=", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdLike(String value) {
            addCriterion("ind_sunat_id like", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdNotLike(String value) {
            addCriterion("ind_sunat_id not like", value, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdIn(List<String> values) {
            addCriterion("ind_sunat_id in", values, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdNotIn(List<String> values) {
            addCriterion("ind_sunat_id not in", values, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdBetween(String value1, String value2) {
            addCriterion("ind_sunat_id between", value1, value2, "indSunatId");
            return this;
        }

        public Criteria andIndSunatIdNotBetween(String value1, String value2) {
            addCriterion("ind_sunat_id not between", value1, value2, "indSunatId");
            return this;
        }

        public Criteria andDesFamilSunatIsNull() {
            addCriterion("des_famil_sunat is null");
            return this;
        }

        public Criteria andDesFamilSunatIsNotNull() {
            addCriterion("des_famil_sunat is not null");
            return this;
        }

        public Criteria andDesFamilSunatEqualTo(String value) {
            addCriterion("des_famil_sunat =", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatNotEqualTo(String value) {
            addCriterion("des_famil_sunat <>", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatGreaterThan(String value) {
            addCriterion("des_famil_sunat >", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatGreaterThanOrEqualTo(String value) {
            addCriterion("des_famil_sunat >=", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatLessThan(String value) {
            addCriterion("des_famil_sunat <", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatLessThanOrEqualTo(String value) {
            addCriterion("des_famil_sunat <=", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatLike(String value) {
            addCriterion("des_famil_sunat like", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatNotLike(String value) {
            addCriterion("des_famil_sunat not like", value, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatIn(List<String> values) {
            addCriterion("des_famil_sunat in", values, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatNotIn(List<String> values) {
            addCriterion("des_famil_sunat not in", values, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatBetween(String value1, String value2) {
            addCriterion("des_famil_sunat between", value1, value2, "desFamilSunat");
            return this;
        }

        public Criteria andDesFamilSunatNotBetween(String value1, String value2) {
            addCriterion("des_famil_sunat not between", value1, value2, "desFamilSunat");
            return this;
        }

        public Criteria andIndSunatIsNull() {
            addCriterion("ind_sunat is null");
            return this;
        }

        public Criteria andIndSunatIsNotNull() {
            addCriterion("ind_sunat is not null");
            return this;
        }

        public Criteria andIndSunatEqualTo(String value) {
            addCriterion("ind_sunat =", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatNotEqualTo(String value) {
            addCriterion("ind_sunat <>", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatGreaterThan(String value) {
            addCriterion("ind_sunat >", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sunat >=", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatLessThan(String value) {
            addCriterion("ind_sunat <", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatLessThanOrEqualTo(String value) {
            addCriterion("ind_sunat <=", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatLike(String value) {
            addCriterion("ind_sunat like", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatNotLike(String value) {
            addCriterion("ind_sunat not like", value, "indSunat");
            return this;
        }

        public Criteria andIndSunatIn(List<String> values) {
            addCriterion("ind_sunat in", values, "indSunat");
            return this;
        }

        public Criteria andIndSunatNotIn(List<String> values) {
            addCriterion("ind_sunat not in", values, "indSunat");
            return this;
        }

        public Criteria andIndSunatBetween(String value1, String value2) {
            addCriterion("ind_sunat between", value1, value2, "indSunat");
            return this;
        }

        public Criteria andIndSunatNotBetween(String value1, String value2) {
            addCriterion("ind_sunat not between", value1, value2, "indSunat");
            return this;
        }

        public Criteria andIndDiscapacitadoIsNull() {
            addCriterion("ind_discapacitado is null");
            return this;
        }

        public Criteria andIndDiscapacitadoIsNotNull() {
            addCriterion("ind_discapacitado is not null");
            return this;
        }

        public Criteria andIndDiscapacitadoEqualTo(String value) {
            addCriterion("ind_discapacitado =", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoNotEqualTo(String value) {
            addCriterion("ind_discapacitado <>", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoGreaterThan(String value) {
            addCriterion("ind_discapacitado >", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_discapacitado >=", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoLessThan(String value) {
            addCriterion("ind_discapacitado <", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoLessThanOrEqualTo(String value) {
            addCriterion("ind_discapacitado <=", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoLike(String value) {
            addCriterion("ind_discapacitado like", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoNotLike(String value) {
            addCriterion("ind_discapacitado not like", value, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoIn(List<String> values) {
            addCriterion("ind_discapacitado in", values, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoNotIn(List<String> values) {
            addCriterion("ind_discapacitado not in", values, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoBetween(String value1, String value2) {
            addCriterion("ind_discapacitado between", value1, value2, "indDiscapacitado");
            return this;
        }

        public Criteria andIndDiscapacitadoNotBetween(String value1, String value2) {
            addCriterion("ind_discapacitado not between", value1, value2, "indDiscapacitado");
            return this;
        }

        public Criteria andCodExamenIsNull() {
            addCriterion("cod_examen is null");
            return this;
        }

        public Criteria andCodExamenIsNotNull() {
            addCriterion("cod_examen is not null");
            return this;
        }

        public Criteria andCodExamenEqualTo(String value) {
            addCriterion("cod_examen =", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenNotEqualTo(String value) {
            addCriterion("cod_examen <>", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenGreaterThan(String value) {
            addCriterion("cod_examen >", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenGreaterThanOrEqualTo(String value) {
            addCriterion("cod_examen >=", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenLessThan(String value) {
            addCriterion("cod_examen <", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenLessThanOrEqualTo(String value) {
            addCriterion("cod_examen <=", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenLike(String value) {
            addCriterion("cod_examen like", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenNotLike(String value) {
            addCriterion("cod_examen not like", value, "codExamen");
            return this;
        }

        public Criteria andCodExamenIn(List<String> values) {
            addCriterion("cod_examen in", values, "codExamen");
            return this;
        }

        public Criteria andCodExamenNotIn(List<String> values) {
            addCriterion("cod_examen not in", values, "codExamen");
            return this;
        }

        public Criteria andCodExamenBetween(String value1, String value2) {
            addCriterion("cod_examen between", value1, value2, "codExamen");
            return this;
        }

        public Criteria andCodExamenNotBetween(String value1, String value2) {
            addCriterion("cod_examen not between", value1, value2, "codExamen");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andDesDiscapacidadIsNull() {
            addCriterion("des_discapacidad is null");
            return this;
        }

        public Criteria andDesDiscapacidadIsNotNull() {
            addCriterion("des_discapacidad is not null");
            return this;
        }

        public Criteria andDesDiscapacidadEqualTo(String value) {
            addCriterion("des_discapacidad =", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadNotEqualTo(String value) {
            addCriterion("des_discapacidad <>", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadGreaterThan(String value) {
            addCriterion("des_discapacidad >", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadGreaterThanOrEqualTo(String value) {
            addCriterion("des_discapacidad >=", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadLessThan(String value) {
            addCriterion("des_discapacidad <", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadLessThanOrEqualTo(String value) {
            addCriterion("des_discapacidad <=", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadLike(String value) {
            addCriterion("des_discapacidad like", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadNotLike(String value) {
            addCriterion("des_discapacidad not like", value, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadIn(List<String> values) {
            addCriterion("des_discapacidad in", values, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadNotIn(List<String> values) {
            addCriterion("des_discapacidad not in", values, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadBetween(String value1, String value2) {
            addCriterion("des_discapacidad between", value1, value2, "desDiscapacidad");
            return this;
        }

        public Criteria andDesDiscapacidadNotBetween(String value1, String value2) {
            addCriterion("des_discapacidad not between", value1, value2, "desDiscapacidad");
            return this;
        }

        public Criteria andIndLaborIsNull() {
            addCriterion("ind_labor is null");
            return this;
        }

        public Criteria andIndLaborIsNotNull() {
            addCriterion("ind_labor is not null");
            return this;
        }

        public Criteria andIndLaborEqualTo(String value) {
            addCriterion("ind_labor =", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborNotEqualTo(String value) {
            addCriterion("ind_labor <>", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborGreaterThan(String value) {
            addCriterion("ind_labor >", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborGreaterThanOrEqualTo(String value) {
            addCriterion("ind_labor >=", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborLessThan(String value) {
            addCriterion("ind_labor <", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborLessThanOrEqualTo(String value) {
            addCriterion("ind_labor <=", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborLike(String value) {
            addCriterion("ind_labor like", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborNotLike(String value) {
            addCriterion("ind_labor not like", value, "indLabor");
            return this;
        }

        public Criteria andIndLaborIn(List<String> values) {
            addCriterion("ind_labor in", values, "indLabor");
            return this;
        }

        public Criteria andIndLaborNotIn(List<String> values) {
            addCriterion("ind_labor not in", values, "indLabor");
            return this;
        }

        public Criteria andIndLaborBetween(String value1, String value2) {
            addCriterion("ind_labor between", value1, value2, "indLabor");
            return this;
        }

        public Criteria andIndLaborNotBetween(String value1, String value2) {
            addCriterion("ind_labor not between", value1, value2, "indLabor");
            return this;
        }

        public Criteria andIndSexoIsNull() {
            addCriterion("ind_sexo is null");
            return this;
        }

        public Criteria andIndSexoIsNotNull() {
            addCriterion("ind_sexo is not null");
            return this;
        }

        public Criteria andIndSexoEqualTo(String value) {
            addCriterion("ind_sexo =", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotEqualTo(String value) {
            addCriterion("ind_sexo <>", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoGreaterThan(String value) {
            addCriterion("ind_sexo >", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sexo >=", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLessThan(String value) {
            addCriterion("ind_sexo <", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLessThanOrEqualTo(String value) {
            addCriterion("ind_sexo <=", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLike(String value) {
            addCriterion("ind_sexo like", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotLike(String value) {
            addCriterion("ind_sexo not like", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoIn(List<String> values) {
            addCriterion("ind_sexo in", values, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotIn(List<String> values) {
            addCriterion("ind_sexo not in", values, "indSexo");
            return this;
        }

        public Criteria andIndSexoBetween(String value1, String value2) {
            addCriterion("ind_sexo between", value1, value2, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotBetween(String value1, String value2) {
            addCriterion("ind_sexo not between", value1, value2, "indSexo");
            return this;
        }

        public Criteria andIndSede1IsNull() {
            addCriterion("ind_sede1 is null");
            return this;
        }

        public Criteria andIndSede1IsNotNull() {
            addCriterion("ind_sede1 is not null");
            return this;
        }

        public Criteria andIndSede1EqualTo(String value) {
            addCriterion("ind_sede1 =", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1NotEqualTo(String value) {
            addCriterion("ind_sede1 <>", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1GreaterThan(String value) {
            addCriterion("ind_sede1 >", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1GreaterThanOrEqualTo(String value) {
            addCriterion("ind_sede1 >=", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1LessThan(String value) {
            addCriterion("ind_sede1 <", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1LessThanOrEqualTo(String value) {
            addCriterion("ind_sede1 <=", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1Like(String value) {
            addCriterion("ind_sede1 like", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1NotLike(String value) {
            addCriterion("ind_sede1 not like", value, "indSede1");
            return this;
        }

        public Criteria andIndSede1In(List<String> values) {
            addCriterion("ind_sede1 in", values, "indSede1");
            return this;
        }

        public Criteria andIndSede1NotIn(List<String> values) {
            addCriterion("ind_sede1 not in", values, "indSede1");
            return this;
        }

        public Criteria andIndSede1Between(String value1, String value2) {
            addCriterion("ind_sede1 between", value1, value2, "indSede1");
            return this;
        }

        public Criteria andIndSede1NotBetween(String value1, String value2) {
            addCriterion("ind_sede1 not between", value1, value2, "indSede1");
            return this;
        }

        public Criteria andIndSede2IsNull() {
            addCriterion("ind_sede2 is null");
            return this;
        }

        public Criteria andIndSede2IsNotNull() {
            addCriterion("ind_sede2 is not null");
            return this;
        }

        public Criteria andIndSede2EqualTo(String value) {
            addCriterion("ind_sede2 =", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2NotEqualTo(String value) {
            addCriterion("ind_sede2 <>", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2GreaterThan(String value) {
            addCriterion("ind_sede2 >", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2GreaterThanOrEqualTo(String value) {
            addCriterion("ind_sede2 >=", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2LessThan(String value) {
            addCriterion("ind_sede2 <", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2LessThanOrEqualTo(String value) {
            addCriterion("ind_sede2 <=", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2Like(String value) {
            addCriterion("ind_sede2 like", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2NotLike(String value) {
            addCriterion("ind_sede2 not like", value, "indSede2");
            return this;
        }

        public Criteria andIndSede2In(List<String> values) {
            addCriterion("ind_sede2 in", values, "indSede2");
            return this;
        }

        public Criteria andIndSede2NotIn(List<String> values) {
            addCriterion("ind_sede2 not in", values, "indSede2");
            return this;
        }

        public Criteria andIndSede2Between(String value1, String value2) {
            addCriterion("ind_sede2 between", value1, value2, "indSede2");
            return this;
        }

        public Criteria andIndSede2NotBetween(String value1, String value2) {
            addCriterion("ind_sede2 not between", value1, value2, "indSede2");
            return this;
        }

        public Criteria andNumRucIsNull() {
            addCriterion("num_ruc is null");
            return this;
        }

        public Criteria andNumRucIsNotNull() {
            addCriterion("num_ruc is not null");
            return this;
        }

        public Criteria andNumRucEqualTo(String value) {
            addCriterion("num_ruc =", value, "numRuc");
            return this;
        }

        public Criteria andNumRucNotEqualTo(String value) {
            addCriterion("num_ruc <>", value, "numRuc");
            return this;
        }

        public Criteria andNumRucGreaterThan(String value) {
            addCriterion("num_ruc >", value, "numRuc");
            return this;
        }

        public Criteria andNumRucGreaterThanOrEqualTo(String value) {
            addCriterion("num_ruc >=", value, "numRuc");
            return this;
        }

        public Criteria andNumRucLessThan(String value) {
            addCriterion("num_ruc <", value, "numRuc");
            return this;
        }

        public Criteria andNumRucLessThanOrEqualTo(String value) {
            addCriterion("num_ruc <=", value, "numRuc");
            return this;
        }

        public Criteria andNumRucLike(String value) {
            addCriterion("num_ruc like", value, "numRuc");
            return this;
        }

        public Criteria andNumRucNotLike(String value) {
            addCriterion("num_ruc not like", value, "numRuc");
            return this;
        }

        public Criteria andNumRucIn(List<String> values) {
            addCriterion("num_ruc in", values, "numRuc");
            return this;
        }

        public Criteria andNumRucNotIn(List<String> values) {
            addCriterion("num_ruc not in", values, "numRuc");
            return this;
        }

        public Criteria andNumRucBetween(String value1, String value2) {
            addCriterion("num_ruc between", value1, value2, "numRuc");
            return this;
        }

        public Criteria andNumRucNotBetween(String value1, String value2) {
            addCriterion("num_ruc not between", value1, value2, "numRuc");
            return this;
        }

        public Criteria andCodCatLicenciaIsNull() {
            addCriterion("cod_cat_licencia is null");
            return this;
        }

        public Criteria andCodCatLicenciaIsNotNull() {
            addCriterion("cod_cat_licencia is not null");
            return this;
        }

        public Criteria andCodCatLicenciaEqualTo(String value) {
            addCriterion("cod_cat_licencia =", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaNotEqualTo(String value) {
            addCriterion("cod_cat_licencia <>", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaGreaterThan(String value) {
            addCriterion("cod_cat_licencia >", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_cat_licencia >=", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaLessThan(String value) {
            addCriterion("cod_cat_licencia <", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaLessThanOrEqualTo(String value) {
            addCriterion("cod_cat_licencia <=", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaLike(String value) {
            addCriterion("cod_cat_licencia like", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaNotLike(String value) {
            addCriterion("cod_cat_licencia not like", value, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaIn(List<String> values) {
            addCriterion("cod_cat_licencia in", values, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaNotIn(List<String> values) {
            addCriterion("cod_cat_licencia not in", values, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaBetween(String value1, String value2) {
            addCriterion("cod_cat_licencia between", value1, value2, "codCatLicencia");
            return this;
        }

        public Criteria andCodCatLicenciaNotBetween(String value1, String value2) {
            addCriterion("cod_cat_licencia not between", value1, value2, "codCatLicencia");
            return this;
        }

        public Criteria andNumColegiaturaIsNull() {
            addCriterion("num_colegiatura is null");
            return this;
        }

        public Criteria andNumColegiaturaIsNotNull() {
            addCriterion("num_colegiatura is not null");
            return this;
        }

        public Criteria andNumColegiaturaEqualTo(String value) {
            addCriterion("num_colegiatura =", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaNotEqualTo(String value) {
            addCriterion("num_colegiatura <>", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaGreaterThan(String value) {
            addCriterion("num_colegiatura >", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaGreaterThanOrEqualTo(String value) {
            addCriterion("num_colegiatura >=", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaLessThan(String value) {
            addCriterion("num_colegiatura <", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaLessThanOrEqualTo(String value) {
            addCriterion("num_colegiatura <=", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaLike(String value) {
            addCriterion("num_colegiatura like", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaNotLike(String value) {
            addCriterion("num_colegiatura not like", value, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaIn(List<String> values) {
            addCriterion("num_colegiatura in", values, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaNotIn(List<String> values) {
            addCriterion("num_colegiatura not in", values, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaBetween(String value1, String value2) {
            addCriterion("num_colegiatura between", value1, value2, "numColegiatura");
            return this;
        }

        public Criteria andNumColegiaturaNotBetween(String value1, String value2) {
            addCriterion("num_colegiatura not between", value1, value2, "numColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaIsNull() {
            addCriterion("ind_colegiatura is null");
            return this;
        }

        public Criteria andIndColegiaturaIsNotNull() {
            addCriterion("ind_colegiatura is not null");
            return this;
        }

        public Criteria andIndColegiaturaEqualTo(String value) {
            addCriterion("ind_colegiatura =", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaNotEqualTo(String value) {
            addCriterion("ind_colegiatura <>", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaGreaterThan(String value) {
            addCriterion("ind_colegiatura >", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_colegiatura >=", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaLessThan(String value) {
            addCriterion("ind_colegiatura <", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaLessThanOrEqualTo(String value) {
            addCriterion("ind_colegiatura <=", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaLike(String value) {
            addCriterion("ind_colegiatura like", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaNotLike(String value) {
            addCriterion("ind_colegiatura not like", value, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaIn(List<String> values) {
            addCriterion("ind_colegiatura in", values, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaNotIn(List<String> values) {
            addCriterion("ind_colegiatura not in", values, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaBetween(String value1, String value2) {
            addCriterion("ind_colegiatura between", value1, value2, "indColegiatura");
            return this;
        }

        public Criteria andIndColegiaturaNotBetween(String value1, String value2) {
            addCriterion("ind_colegiatura not between", value1, value2, "indColegiatura");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andCodUsuprocIsNull() {
            addCriterion("cod_usuproc is null");
            return this;
        }

        public Criteria andCodUsuprocIsNotNull() {
            addCriterion("cod_usuproc is not null");
            return this;
        }

        public Criteria andCodUsuprocEqualTo(String value) {
            addCriterion("cod_usuproc =", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocNotEqualTo(String value) {
            addCriterion("cod_usuproc <>", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocGreaterThan(String value) {
            addCriterion("cod_usuproc >", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuproc >=", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocLessThan(String value) {
            addCriterion("cod_usuproc <", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocLessThanOrEqualTo(String value) {
            addCriterion("cod_usuproc <=", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocLike(String value) {
            addCriterion("cod_usuproc like", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocNotLike(String value) {
            addCriterion("cod_usuproc not like", value, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocIn(List<String> values) {
            addCriterion("cod_usuproc in", values, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocNotIn(List<String> values) {
            addCriterion("cod_usuproc not in", values, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocBetween(String value1, String value2) {
            addCriterion("cod_usuproc between", value1, value2, "codUsuproc");
            return this;
        }

        public Criteria andCodUsuprocNotBetween(String value1, String value2) {
            addCriterion("cod_usuproc not between", value1, value2, "codUsuproc");
            return this;
        }

        public Criteria andFecProcesoIsNull() {
            addCriterion("fec_proceso is null");
            return this;
        }

        public Criteria andFecProcesoIsNotNull() {
            addCriterion("fec_proceso is not null");
            return this;
        }

        public Criteria andFecProcesoEqualTo(Date value) {
            addCriterion("fec_proceso =", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotEqualTo(Date value) {
            addCriterion("fec_proceso <>", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThan(Date value) {
            addCriterion("fec_proceso >", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_proceso >=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThan(Date value) {
            addCriterion("fec_proceso <", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThanOrEqualTo(Date value) {
            addCriterion("fec_proceso <=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoIn(List<Date> values) {
            addCriterion("fec_proceso in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotIn(List<Date> values) {
            addCriterion("fec_proceso not in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoBetween(Date value1, Date value2) {
            addCriterion("fec_proceso between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotBetween(Date value1, Date value2) {
            addCriterion("fec_proceso not between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andNumArcLicffaaIsNull() {
            addCriterion("num_arc_licffaa is null");
            return this;
        }

        public Criteria andNumArcLicffaaIsNotNull() {
            addCriterion("num_arc_licffaa is not null");
            return this;
        }

        public Criteria andNumArcLicffaaEqualTo(Integer value) {
            addCriterion("num_arc_licffaa =", value, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaNotEqualTo(Integer value) {
            addCriterion("num_arc_licffaa <>", value, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaGreaterThan(Integer value) {
            addCriterion("num_arc_licffaa >", value, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_arc_licffaa >=", value, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaLessThan(Integer value) {
            addCriterion("num_arc_licffaa <", value, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaLessThanOrEqualTo(Integer value) {
            addCriterion("num_arc_licffaa <=", value, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaIn(List<Integer> values) {
            addCriterion("num_arc_licffaa in", values, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaNotIn(List<Integer> values) {
            addCriterion("num_arc_licffaa not in", values, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_licffaa between", value1, value2, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcLicffaaNotBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_licffaa not between", value1, value2, "numArcLicffaa");
            return this;
        }

        public Criteria andNumArcDiscapacidIsNull() {
            addCriterion("num_arc_discapacid is null");
            return this;
        }

        public Criteria andNumArcDiscapacidIsNotNull() {
            addCriterion("num_arc_discapacid is not null");
            return this;
        }

        public Criteria andNumArcDiscapacidEqualTo(Integer value) {
            addCriterion("num_arc_discapacid =", value, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidNotEqualTo(Integer value) {
            addCriterion("num_arc_discapacid <>", value, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidGreaterThan(Integer value) {
            addCriterion("num_arc_discapacid >", value, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_arc_discapacid >=", value, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidLessThan(Integer value) {
            addCriterion("num_arc_discapacid <", value, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidLessThanOrEqualTo(Integer value) {
            addCriterion("num_arc_discapacid <=", value, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidIn(List<Integer> values) {
            addCriterion("num_arc_discapacid in", values, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidNotIn(List<Integer> values) {
            addCriterion("num_arc_discapacid not in", values, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_discapacid between", value1, value2, "numArcDiscapacid");
            return this;
        }

        public Criteria andNumArcDiscapacidNotBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_discapacid not between", value1, value2, "numArcDiscapacid");
            return this;
        }

        public Criteria andIndLicffaaIsNull() {
            addCriterion("ind_licffaa is null");
            return this;
        }

        public Criteria andIndLicffaaIsNotNull() {
            addCriterion("ind_licffaa is not null");
            return this;
        }

        public Criteria andIndLicffaaEqualTo(String value) {
            addCriterion("ind_licffaa =", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaNotEqualTo(String value) {
            addCriterion("ind_licffaa <>", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaGreaterThan(String value) {
            addCriterion("ind_licffaa >", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaGreaterThanOrEqualTo(String value) {
            addCriterion("ind_licffaa >=", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaLessThan(String value) {
            addCriterion("ind_licffaa <", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaLessThanOrEqualTo(String value) {
            addCriterion("ind_licffaa <=", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaLike(String value) {
            addCriterion("ind_licffaa like", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaNotLike(String value) {
            addCriterion("ind_licffaa not like", value, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaIn(List<String> values) {
            addCriterion("ind_licffaa in", values, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaNotIn(List<String> values) {
            addCriterion("ind_licffaa not in", values, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaBetween(String value1, String value2) {
            addCriterion("ind_licffaa between", value1, value2, "indLicffaa");
            return this;
        }

        public Criteria andIndLicffaaNotBetween(String value1, String value2) {
            addCriterion("ind_licffaa not between", value1, value2, "indLicffaa");
            return this;
        }

        public Criteria andCodPaisnacIsNull() {
            addCriterion("cod_paisnac is null");
            return this;
        }

        public Criteria andCodPaisnacIsNotNull() {
            addCriterion("cod_paisnac is not null");
            return this;
        }

        public Criteria andCodPaisnacEqualTo(String value) {
            addCriterion("cod_paisnac =", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacNotEqualTo(String value) {
            addCriterion("cod_paisnac <>", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacGreaterThan(String value) {
            addCriterion("cod_paisnac >", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacGreaterThanOrEqualTo(String value) {
            addCriterion("cod_paisnac >=", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacLessThan(String value) {
            addCriterion("cod_paisnac <", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacLessThanOrEqualTo(String value) {
            addCriterion("cod_paisnac <=", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacLike(String value) {
            addCriterion("cod_paisnac like", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacNotLike(String value) {
            addCriterion("cod_paisnac not like", value, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacIn(List<String> values) {
            addCriterion("cod_paisnac in", values, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacNotIn(List<String> values) {
            addCriterion("cod_paisnac not in", values, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacBetween(String value1, String value2) {
            addCriterion("cod_paisnac between", value1, value2, "codPaisnac");
            return this;
        }

        public Criteria andCodPaisnacNotBetween(String value1, String value2) {
            addCriterion("cod_paisnac not between", value1, value2, "codPaisnac");
            return this;
        }

        public Criteria andCodEstColegiaturIsNull() {
            addCriterion("cod_est_colegiatur is null");
            return this;
        }

        public Criteria andCodEstColegiaturIsNotNull() {
            addCriterion("cod_est_colegiatur is not null");
            return this;
        }

        public Criteria andCodEstColegiaturEqualTo(String value) {
            addCriterion("cod_est_colegiatur =", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturNotEqualTo(String value) {
            addCriterion("cod_est_colegiatur <>", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturGreaterThan(String value) {
            addCriterion("cod_est_colegiatur >", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturGreaterThanOrEqualTo(String value) {
            addCriterion("cod_est_colegiatur >=", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturLessThan(String value) {
            addCriterion("cod_est_colegiatur <", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturLessThanOrEqualTo(String value) {
            addCriterion("cod_est_colegiatur <=", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturLike(String value) {
            addCriterion("cod_est_colegiatur like", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturNotLike(String value) {
            addCriterion("cod_est_colegiatur not like", value, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturIn(List<String> values) {
            addCriterion("cod_est_colegiatur in", values, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturNotIn(List<String> values) {
            addCriterion("cod_est_colegiatur not in", values, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturBetween(String value1, String value2) {
            addCriterion("cod_est_colegiatur between", value1, value2, "codEstColegiatur");
            return this;
        }

        public Criteria andCodEstColegiaturNotBetween(String value1, String value2) {
            addCriterion("cod_est_colegiatur not between", value1, value2, "codEstColegiatur");
            return this;
        }

        public Criteria andNumDepaDirIsNull() {
            addCriterion("num_depa_dir is null");
            return this;
        }

        public Criteria andNumDepaDirIsNotNull() {
            addCriterion("num_depa_dir is not null");
            return this;
        }

        public Criteria andNumDepaDirEqualTo(String value) {
            addCriterion("num_depa_dir =", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirNotEqualTo(String value) {
            addCriterion("num_depa_dir <>", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirGreaterThan(String value) {
            addCriterion("num_depa_dir >", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirGreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir >=", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirLessThan(String value) {
            addCriterion("num_depa_dir <", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirLessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir <=", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirLike(String value) {
            addCriterion("num_depa_dir like", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirNotLike(String value) {
            addCriterion("num_depa_dir not like", value, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirIn(List<String> values) {
            addCriterion("num_depa_dir in", values, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirNotIn(List<String> values) {
            addCriterion("num_depa_dir not in", values, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirBetween(String value1, String value2) {
            addCriterion("num_depa_dir between", value1, value2, "numDepaDir");
            return this;
        }

        public Criteria andNumDepaDirNotBetween(String value1, String value2) {
            addCriterion("num_depa_dir not between", value1, value2, "numDepaDir");
            return this;
        }

        public Criteria andNumInteriorDirIsNull() {
            addCriterion("num_interior_dir is null");
            return this;
        }

        public Criteria andNumInteriorDirIsNotNull() {
            addCriterion("num_interior_dir is not null");
            return this;
        }

        public Criteria andNumInteriorDirEqualTo(String value) {
            addCriterion("num_interior_dir =", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirNotEqualTo(String value) {
            addCriterion("num_interior_dir <>", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirGreaterThan(String value) {
            addCriterion("num_interior_dir >", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirGreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir >=", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirLessThan(String value) {
            addCriterion("num_interior_dir <", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirLessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir <=", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirLike(String value) {
            addCriterion("num_interior_dir like", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirNotLike(String value) {
            addCriterion("num_interior_dir not like", value, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirIn(List<String> values) {
            addCriterion("num_interior_dir in", values, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirNotIn(List<String> values) {
            addCriterion("num_interior_dir not in", values, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirBetween(String value1, String value2) {
            addCriterion("num_interior_dir between", value1, value2, "numInteriorDir");
            return this;
        }

        public Criteria andNumInteriorDirNotBetween(String value1, String value2) {
            addCriterion("num_interior_dir not between", value1, value2, "numInteriorDir");
            return this;
        }

        public Criteria andNumManzDirIsNull() {
            addCriterion("num_manz_dir is null");
            return this;
        }

        public Criteria andNumManzDirIsNotNull() {
            addCriterion("num_manz_dir is not null");
            return this;
        }

        public Criteria andNumManzDirEqualTo(String value) {
            addCriterion("num_manz_dir =", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirNotEqualTo(String value) {
            addCriterion("num_manz_dir <>", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirGreaterThan(String value) {
            addCriterion("num_manz_dir >", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirGreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir >=", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirLessThan(String value) {
            addCriterion("num_manz_dir <", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirLessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir <=", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirLike(String value) {
            addCriterion("num_manz_dir like", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirNotLike(String value) {
            addCriterion("num_manz_dir not like", value, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirIn(List<String> values) {
            addCriterion("num_manz_dir in", values, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirNotIn(List<String> values) {
            addCriterion("num_manz_dir not in", values, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirBetween(String value1, String value2) {
            addCriterion("num_manz_dir between", value1, value2, "numManzDir");
            return this;
        }

        public Criteria andNumManzDirNotBetween(String value1, String value2) {
            addCriterion("num_manz_dir not between", value1, value2, "numManzDir");
            return this;
        }

        public Criteria andNumLoteDirIsNull() {
            addCriterion("num_lote_dir is null");
            return this;
        }

        public Criteria andNumLoteDirIsNotNull() {
            addCriterion("num_lote_dir is not null");
            return this;
        }

        public Criteria andNumLoteDirEqualTo(String value) {
            addCriterion("num_lote_dir =", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirNotEqualTo(String value) {
            addCriterion("num_lote_dir <>", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirGreaterThan(String value) {
            addCriterion("num_lote_dir >", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirGreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir >=", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirLessThan(String value) {
            addCriterion("num_lote_dir <", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirLessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir <=", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirLike(String value) {
            addCriterion("num_lote_dir like", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirNotLike(String value) {
            addCriterion("num_lote_dir not like", value, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirIn(List<String> values) {
            addCriterion("num_lote_dir in", values, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirNotIn(List<String> values) {
            addCriterion("num_lote_dir not in", values, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirBetween(String value1, String value2) {
            addCriterion("num_lote_dir between", value1, value2, "numLoteDir");
            return this;
        }

        public Criteria andNumLoteDirNotBetween(String value1, String value2) {
            addCriterion("num_lote_dir not between", value1, value2, "numLoteDir");
            return this;
        }

        public Criteria andNumKilomDirIsNull() {
            addCriterion("num_kilom_dir is null");
            return this;
        }

        public Criteria andNumKilomDirIsNotNull() {
            addCriterion("num_kilom_dir is not null");
            return this;
        }

        public Criteria andNumKilomDirEqualTo(String value) {
            addCriterion("num_kilom_dir =", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirNotEqualTo(String value) {
            addCriterion("num_kilom_dir <>", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirGreaterThan(String value) {
            addCriterion("num_kilom_dir >", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirGreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir >=", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirLessThan(String value) {
            addCriterion("num_kilom_dir <", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirLessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir <=", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirLike(String value) {
            addCriterion("num_kilom_dir like", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirNotLike(String value) {
            addCriterion("num_kilom_dir not like", value, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirIn(List<String> values) {
            addCriterion("num_kilom_dir in", values, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirNotIn(List<String> values) {
            addCriterion("num_kilom_dir not in", values, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirBetween(String value1, String value2) {
            addCriterion("num_kilom_dir between", value1, value2, "numKilomDir");
            return this;
        }

        public Criteria andNumKilomDirNotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir not between", value1, value2, "numKilomDir");
            return this;
        }

        public Criteria andNumBlockDirIsNull() {
            addCriterion("num_block_dir is null");
            return this;
        }

        public Criteria andNumBlockDirIsNotNull() {
            addCriterion("num_block_dir is not null");
            return this;
        }

        public Criteria andNumBlockDirEqualTo(String value) {
            addCriterion("num_block_dir =", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirNotEqualTo(String value) {
            addCriterion("num_block_dir <>", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirGreaterThan(String value) {
            addCriterion("num_block_dir >", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirGreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir >=", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirLessThan(String value) {
            addCriterion("num_block_dir <", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirLessThanOrEqualTo(String value) {
            addCriterion("num_block_dir <=", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirLike(String value) {
            addCriterion("num_block_dir like", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirNotLike(String value) {
            addCriterion("num_block_dir not like", value, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirIn(List<String> values) {
            addCriterion("num_block_dir in", values, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirNotIn(List<String> values) {
            addCriterion("num_block_dir not in", values, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirBetween(String value1, String value2) {
            addCriterion("num_block_dir between", value1, value2, "numBlockDir");
            return this;
        }

        public Criteria andNumBlockDirNotBetween(String value1, String value2) {
            addCriterion("num_block_dir not between", value1, value2, "numBlockDir");
            return this;
        }

        public Criteria andNumEtapaDirIsNull() {
            addCriterion("num_etapa_dir is null");
            return this;
        }

        public Criteria andNumEtapaDirIsNotNull() {
            addCriterion("num_etapa_dir is not null");
            return this;
        }

        public Criteria andNumEtapaDirEqualTo(String value) {
            addCriterion("num_etapa_dir =", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirNotEqualTo(String value) {
            addCriterion("num_etapa_dir <>", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirGreaterThan(String value) {
            addCriterion("num_etapa_dir >", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirGreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir >=", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirLessThan(String value) {
            addCriterion("num_etapa_dir <", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirLessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir <=", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirLike(String value) {
            addCriterion("num_etapa_dir like", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirNotLike(String value) {
            addCriterion("num_etapa_dir not like", value, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirIn(List<String> values) {
            addCriterion("num_etapa_dir in", values, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirNotIn(List<String> values) {
            addCriterion("num_etapa_dir not in", values, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirBetween(String value1, String value2) {
            addCriterion("num_etapa_dir between", value1, value2, "numEtapaDir");
            return this;
        }

        public Criteria andNumEtapaDirNotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir not between", value1, value2, "numEtapaDir");
            return this;
        }

        public Criteria andDesReferDirIsNull() {
            addCriterion("des_refer_dir is null");
            return this;
        }

        public Criteria andDesReferDirIsNotNull() {
            addCriterion("des_refer_dir is not null");
            return this;
        }

        public Criteria andDesReferDirEqualTo(String value) {
            addCriterion("des_refer_dir =", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirNotEqualTo(String value) {
            addCriterion("des_refer_dir <>", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirGreaterThan(String value) {
            addCriterion("des_refer_dir >", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirGreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir >=", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirLessThan(String value) {
            addCriterion("des_refer_dir <", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirLessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir <=", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirLike(String value) {
            addCriterion("des_refer_dir like", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirNotLike(String value) {
            addCriterion("des_refer_dir not like", value, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirIn(List<String> values) {
            addCriterion("des_refer_dir in", values, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirNotIn(List<String> values) {
            addCriterion("des_refer_dir not in", values, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirBetween(String value1, String value2) {
            addCriterion("des_refer_dir between", value1, value2, "desReferDir");
            return this;
        }

        public Criteria andDesReferDirNotBetween(String value1, String value2) {
            addCriterion("des_refer_dir not between", value1, value2, "desReferDir");
            return this;
        }

        public Criteria andNumArcPostulaIsNull() {
            addCriterion("num_arc_postula is null");
            return this;
        }

        public Criteria andNumArcPostulaIsNotNull() {
            addCriterion("num_arc_postula is not null");
            return this;
        }

        public Criteria andNumArcPostulaEqualTo(Integer value) {
            addCriterion("num_arc_postula =", value, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaNotEqualTo(Integer value) {
            addCriterion("num_arc_postula <>", value, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaGreaterThan(Integer value) {
            addCriterion("num_arc_postula >", value, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_arc_postula >=", value, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaLessThan(Integer value) {
            addCriterion("num_arc_postula <", value, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaLessThanOrEqualTo(Integer value) {
            addCriterion("num_arc_postula <=", value, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaIn(List<Integer> values) {
            addCriterion("num_arc_postula in", values, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaNotIn(List<Integer> values) {
            addCriterion("num_arc_postula not in", values, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_postula between", value1, value2, "numArcPostula");
            return this;
        }

        public Criteria andNumArcPostulaNotBetween(Integer value1, Integer value2) {
            addCriterion("num_arc_postula not between", value1, value2, "numArcPostula");
            return this;
        }

        public Criteria andIndFamsunatIsNull() {
            addCriterion("ind_famsunat is null");
            return this;
        }

        public Criteria andIndFamsunatIsNotNull() {
            addCriterion("ind_famsunat is not null");
            return this;
        }

        public Criteria andIndFamsunatEqualTo(String value) {
            addCriterion("ind_famsunat =", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatNotEqualTo(String value) {
            addCriterion("ind_famsunat <>", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatGreaterThan(String value) {
            addCriterion("ind_famsunat >", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatGreaterThanOrEqualTo(String value) {
            addCriterion("ind_famsunat >=", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatLessThan(String value) {
            addCriterion("ind_famsunat <", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatLessThanOrEqualTo(String value) {
            addCriterion("ind_famsunat <=", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatLike(String value) {
            addCriterion("ind_famsunat like", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatNotLike(String value) {
            addCriterion("ind_famsunat not like", value, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatIn(List<String> values) {
            addCriterion("ind_famsunat in", values, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatNotIn(List<String> values) {
            addCriterion("ind_famsunat not in", values, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatBetween(String value1, String value2) {
            addCriterion("ind_famsunat between", value1, value2, "indFamsunat");
            return this;
        }

        public Criteria andIndFamsunatNotBetween(String value1, String value2) {
            addCriterion("ind_famsunat not between", value1, value2, "indFamsunat");
            return this;
        }

        public Criteria andFecInicontratoIsNull() {
            addCriterion("fec_inicontrato is null");
            return this;
        }

        public Criteria andFecInicontratoIsNotNull() {
            addCriterion("fec_inicontrato is not null");
            return this;
        }

        public Criteria andFecInicontratoEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inicontrato =", value, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inicontrato <>", value, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_inicontrato >", value, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inicontrato >=", value, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoLessThan(Date value) {
            addCriterionForJDBCDate("fec_inicontrato <", value, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_inicontrato <=", value, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoIn(List<Date> values) {
            addCriterionForJDBCDate("fec_inicontrato in", values, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_inicontrato not in", values, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_inicontrato between", value1, value2, "fecInicontrato");
            return this;
        }

        public Criteria andFecInicontratoNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_inicontrato not between", value1, value2, "fecInicontrato");
            return this;
        }
    }
}