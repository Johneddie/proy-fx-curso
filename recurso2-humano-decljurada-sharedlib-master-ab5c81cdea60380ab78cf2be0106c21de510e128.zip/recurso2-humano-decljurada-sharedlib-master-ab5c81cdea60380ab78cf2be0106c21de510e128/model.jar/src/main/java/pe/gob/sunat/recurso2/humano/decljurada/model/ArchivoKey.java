package pe.gob.sunat.recurso2.humano.decljurada.model;

public class ArchivoKey {
    private String annDdjj;

    private String codTip;

    private Short indCorrel;

    private Integer numDdjj;

    public String getAnnDdjj() {
        return annDdjj;
    }

    public void setAnnDdjj(String annDdjj) {
        this.annDdjj = annDdjj == null ? null : annDdjj.trim();
    }

    public String getCodTip() {
        return codTip;
    }

    public void setCodTip(String codTip) {
        this.codTip = codTip == null ? null : codTip.trim();
    }

    public Short getIndCorrel() {
        return indCorrel;
    }

    public void setIndCorrel(Short indCorrel) {
        this.indCorrel = indCorrel;
    }

    public Integer getNumDdjj() {
        return numDdjj;
    }

    public void setNumDdjj(Integer numDdjj) {
        this.numDdjj = numDdjj;
    }
}