package pe.gob.sunat.recurso2.humano.decljurada.model;

import pe.gob.sunat.recurso2.humano.decljurada.bean.DeclaracionJuradaKey;

public class DeclaraDerechohabKey implements DeclaracionJuradaKey{
    private String annDdjj;

    private String indEstado;

    private Integer numDdjj;

    public String getAnnDdjj() {
        return annDdjj;
    }

    public void setAnnDdjj(String annDdjj) {
        this.annDdjj = annDdjj == null ? null : annDdjj.trim();
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado == null ? null : indEstado.trim();
    }

    public Integer getNumDdjj() {
        return numDdjj;
    }

    public void setNumDdjj(Integer numDdjj) {
        this.numDdjj = numDdjj;
    }
}