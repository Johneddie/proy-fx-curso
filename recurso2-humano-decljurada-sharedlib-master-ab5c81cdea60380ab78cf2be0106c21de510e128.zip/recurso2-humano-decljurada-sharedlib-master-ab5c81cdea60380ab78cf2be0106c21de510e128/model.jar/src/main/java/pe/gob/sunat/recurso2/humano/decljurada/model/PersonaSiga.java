package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class PersonaSiga {
    private String codiEmplPer;

    private String apePatPer;

    private String apeMatPer;

    private String nomEmpPer;

    private String nombCortPer;

    private String dirEmpPer;

    private String codiDepaDpt;

    private String codiProvTpr;

    private String codiDistTdi;

    private String numTelPer;

    private Date fecIngPer;

    private String tipoPlanTpl;

    private String estCivPer;

    private String sexEmpPer;

    private String graInsPer;

    private Date fecNacPer;

    private String paisNaciTpa;

    private String depaNaciDpt;

    private String provNaciTpr;

    private String distNaciTdi;

    private String codiDepeTde;

    private String ubicFisiTde;

    private String codiNiveTni;

    private String niveEncTni;

    private String estaTrabPer;

    private String conTraPer;

    private String regLabPer;

    private String regPenPer;

    private String codiCargTca;

    private String cargEncTca;

    private String flagAfpPer;

    private String codiAfp;

    private Date fechAfpPer;

    private String codiAfpPer;

    private String librElecPer;

    private String librMiliPer;

    private String codiIpssPer;

    private String numeBrevPer;

    private String gruSangPer;

    private String codMonSuelPer;

    private String flagSuelPer;

    private String bancSuelTbc;

    private String suelCtaPer;

    private String bancCtsTbc;

    private String ctsCtaPer;

    private String codMonCtsPer;

    private String numePlazPer;

    private Date fechRnomPer;

    private String numeRnomPer;

    private String sedeActuPer;

    private Date fingAdmPer;

    private Date fingCarrpPer;

    private String otroDocuPer;

    private String observaPer;

    private String cargoRemuPer;

    private String nivelRemuPer;

    private String plazaRemuPer;

    private String depeRemuPer;

    private String obserRemuPer;

    private String tipoCuenPer;

    private String seguMediPer;

    private String sedeRemuPer;

    private String apepSoltPer;

    private String apemSoltPer;

    private String nombSoltEr;

    private String codiProfTpr;

    private Date fechCesePer;

    private String numePasaPer;

    private String annoProgPla;

    private String codiPlazPla;

    private String codiAntePer;

    private String niveViatNvi;

    private String codiCondLab;

    private String flagMoscPer;

    private String tipoDocuPer;

    private String numeCeluPer;

    private String codiNiveNvl;

    private Integer cantAnnoExp;

    private Integer cantMeseExp;

    private String plazEncaPer;

    private Short numeDepePer;

    private String flagAfilEps;

    private String codiJefePer;

    private Date ingrEntiPer;

    private Date inicContPer;

    private Date finaContPer;

    private Date inicLaboPer;

    private String codiPlazCap;

    private String unidLocaUlo;

    private String essaludVida;

    private String domiciliado;

    private String codigoTipoVia;

    private String domicilioNombreVia;

    private String domicilioNumeroVia;

    private String domicilioInterior;

    private String codigoTipoZona;

    private String domicilioNombreZona;

    private String domicilioReferencia;

    private String codigoTipoTrabajador;

    private String codigoNivelEducativo;

    private String codigoOcupacion;

    private String discapacidad;

    private String codigoRegimenPensionario;

    private String sctrSalud;

    private String sctrPension;

    private String codigoTipoContrato;

    private String regimenAlternativo;

    private String jornadaTrabajoMaxima;

    private String horarioNocturno;

    private String otrosIngresosQuinta;

    private String sindicalizado;

    private String codigoPeriodicidad;

    private String afiliadoEps;

    private String codigoEps;

    private String codigoSituacionEps;

    private String rentaQuintaExonerada;

    private String situacionEspecialTrabajador;

    private String codigoTipoPago;

    private String modFormativaSeguroMedico;

    private String modFormativaMadreRespon;

    private String modFormativaCentroFormacion;

    private String codigoFinPeriodo;

    private String codigoModalidadFormativa;

    private String nacionalidad;

    private String categoria;

    private Date fechaInicio;

    private Date fechaFin;

    private String userCrea;

    private Date fechCrea;

    private String userModi;

    private Date fechModi;

    private String jefeAnterior;

    private String numeRegiArc;

    private String numeroRegistroAlterno;

    private Short versionFotocheck;

    private Short indicadorMigracion;

    private String numeroCarnet;

    private String gradoEfectivo;

    private String tipoEfectivo;

    private String indicadorFallecimiento;

    private String partidaDefuncion;

    private Date fechaPension;

    private Date fechaFallecimiento;

    private Short tiempoServicioAnios;

    private Short tiempoServicioMeses;

    private Integer tiempoServicioDias;

    private String codTelefCiudad;

    private String codPdtDeparta;

    private String codPdtManzana;

    private String codPdtLote;

    private String codPdtKilometro;

    private String codPdtBlock;

    private String codPdtEtapa;

    private String indAfectoAfp;

    private String indAfiliadoEps;

    private String numAnexo;

    private String nroCertArma;

    private String serieCertArma;

    private Date fecCadCertArma;

    private String indAfpCom;

    private String codofin;

    private String tarifaDefPoli;

    public String getCodiEmplPer() {
        return codiEmplPer;
    }

    public void setCodiEmplPer(String codiEmplPer) {
        this.codiEmplPer = codiEmplPer == null ? null : codiEmplPer.trim();
    }

    public String getApePatPer() {
        return apePatPer;
    }

    public void setApePatPer(String apePatPer) {
        this.apePatPer = apePatPer == null ? null : apePatPer.trim();
    }

    public String getApeMatPer() {
        return apeMatPer;
    }

    public void setApeMatPer(String apeMatPer) {
        this.apeMatPer = apeMatPer == null ? null : apeMatPer.trim();
    }

    public String getNomEmpPer() {
        return nomEmpPer;
    }

    public void setNomEmpPer(String nomEmpPer) {
        this.nomEmpPer = nomEmpPer == null ? null : nomEmpPer.trim();
    }

    public String getNombCortPer() {
        return nombCortPer;
    }

    public void setNombCortPer(String nombCortPer) {
        this.nombCortPer = nombCortPer == null ? null : nombCortPer.trim();
    }

    public String getDirEmpPer() {
        return dirEmpPer;
    }

    public void setDirEmpPer(String dirEmpPer) {
        this.dirEmpPer = dirEmpPer == null ? null : dirEmpPer.trim();
    }

    public String getCodiDepaDpt() {
        return codiDepaDpt;
    }

    public void setCodiDepaDpt(String codiDepaDpt) {
        this.codiDepaDpt = codiDepaDpt == null ? null : codiDepaDpt.trim();
    }

    public String getCodiProvTpr() {
        return codiProvTpr;
    }

    public void setCodiProvTpr(String codiProvTpr) {
        this.codiProvTpr = codiProvTpr == null ? null : codiProvTpr.trim();
    }

    public String getCodiDistTdi() {
        return codiDistTdi;
    }

    public void setCodiDistTdi(String codiDistTdi) {
        this.codiDistTdi = codiDistTdi == null ? null : codiDistTdi.trim();
    }

    public String getNumTelPer() {
        return numTelPer;
    }

    public void setNumTelPer(String numTelPer) {
        this.numTelPer = numTelPer == null ? null : numTelPer.trim();
    }

    public Date getFecIngPer() {
        return fecIngPer;
    }

    public void setFecIngPer(Date fecIngPer) {
        this.fecIngPer = fecIngPer;
    }

    public String getTipoPlanTpl() {
        return tipoPlanTpl;
    }

    public void setTipoPlanTpl(String tipoPlanTpl) {
        this.tipoPlanTpl = tipoPlanTpl == null ? null : tipoPlanTpl.trim();
    }

    public String getEstCivPer() {
        return estCivPer;
    }

    public void setEstCivPer(String estCivPer) {
        this.estCivPer = estCivPer == null ? null : estCivPer.trim();
    }

    public String getSexEmpPer() {
        return sexEmpPer;
    }

    public void setSexEmpPer(String sexEmpPer) {
        this.sexEmpPer = sexEmpPer == null ? null : sexEmpPer.trim();
    }

    public String getGraInsPer() {
        return graInsPer;
    }

    public void setGraInsPer(String graInsPer) {
        this.graInsPer = graInsPer == null ? null : graInsPer.trim();
    }

    public Date getFecNacPer() {
        return fecNacPer;
    }

    public void setFecNacPer(Date fecNacPer) {
        this.fecNacPer = fecNacPer;
    }

    public String getPaisNaciTpa() {
        return paisNaciTpa;
    }

    public void setPaisNaciTpa(String paisNaciTpa) {
        this.paisNaciTpa = paisNaciTpa == null ? null : paisNaciTpa.trim();
    }

    public String getDepaNaciDpt() {
        return depaNaciDpt;
    }

    public void setDepaNaciDpt(String depaNaciDpt) {
        this.depaNaciDpt = depaNaciDpt == null ? null : depaNaciDpt.trim();
    }

    public String getProvNaciTpr() {
        return provNaciTpr;
    }

    public void setProvNaciTpr(String provNaciTpr) {
        this.provNaciTpr = provNaciTpr == null ? null : provNaciTpr.trim();
    }

    public String getDistNaciTdi() {
        return distNaciTdi;
    }

    public void setDistNaciTdi(String distNaciTdi) {
        this.distNaciTdi = distNaciTdi == null ? null : distNaciTdi.trim();
    }

    public String getCodiDepeTde() {
        return codiDepeTde;
    }

    public void setCodiDepeTde(String codiDepeTde) {
        this.codiDepeTde = codiDepeTde == null ? null : codiDepeTde.trim();
    }

    public String getUbicFisiTde() {
        return ubicFisiTde;
    }

    public void setUbicFisiTde(String ubicFisiTde) {
        this.ubicFisiTde = ubicFisiTde == null ? null : ubicFisiTde.trim();
    }

    public String getCodiNiveTni() {
        return codiNiveTni;
    }

    public void setCodiNiveTni(String codiNiveTni) {
        this.codiNiveTni = codiNiveTni == null ? null : codiNiveTni.trim();
    }

    public String getNiveEncTni() {
        return niveEncTni;
    }

    public void setNiveEncTni(String niveEncTni) {
        this.niveEncTni = niveEncTni == null ? null : niveEncTni.trim();
    }

    public String getEstaTrabPer() {
        return estaTrabPer;
    }

    public void setEstaTrabPer(String estaTrabPer) {
        this.estaTrabPer = estaTrabPer == null ? null : estaTrabPer.trim();
    }

    public String getConTraPer() {
        return conTraPer;
    }

    public void setConTraPer(String conTraPer) {
        this.conTraPer = conTraPer == null ? null : conTraPer.trim();
    }

    public String getRegLabPer() {
        return regLabPer;
    }

    public void setRegLabPer(String regLabPer) {
        this.regLabPer = regLabPer == null ? null : regLabPer.trim();
    }

    public String getRegPenPer() {
        return regPenPer;
    }

    public void setRegPenPer(String regPenPer) {
        this.regPenPer = regPenPer == null ? null : regPenPer.trim();
    }

    public String getCodiCargTca() {
        return codiCargTca;
    }

    public void setCodiCargTca(String codiCargTca) {
        this.codiCargTca = codiCargTca == null ? null : codiCargTca.trim();
    }

    public String getCargEncTca() {
        return cargEncTca;
    }

    public void setCargEncTca(String cargEncTca) {
        this.cargEncTca = cargEncTca == null ? null : cargEncTca.trim();
    }

    public String getFlagAfpPer() {
        return flagAfpPer;
    }

    public void setFlagAfpPer(String flagAfpPer) {
        this.flagAfpPer = flagAfpPer == null ? null : flagAfpPer.trim();
    }

    public String getCodiAfp() {
        return codiAfp;
    }

    public void setCodiAfp(String codiAfp) {
        this.codiAfp = codiAfp == null ? null : codiAfp.trim();
    }

    public Date getFechAfpPer() {
        return fechAfpPer;
    }

    public void setFechAfpPer(Date fechAfpPer) {
        this.fechAfpPer = fechAfpPer;
    }

    public String getCodiAfpPer() {
        return codiAfpPer;
    }

    public void setCodiAfpPer(String codiAfpPer) {
        this.codiAfpPer = codiAfpPer == null ? null : codiAfpPer.trim();
    }

    public String getLibrElecPer() {
        return librElecPer;
    }

    public void setLibrElecPer(String librElecPer) {
        this.librElecPer = librElecPer == null ? null : librElecPer.trim();
    }

    public String getLibrMiliPer() {
        return librMiliPer;
    }

    public void setLibrMiliPer(String librMiliPer) {
        this.librMiliPer = librMiliPer == null ? null : librMiliPer.trim();
    }

    public String getCodiIpssPer() {
        return codiIpssPer;
    }

    public void setCodiIpssPer(String codiIpssPer) {
        this.codiIpssPer = codiIpssPer == null ? null : codiIpssPer.trim();
    }

    public String getNumeBrevPer() {
        return numeBrevPer;
    }

    public void setNumeBrevPer(String numeBrevPer) {
        this.numeBrevPer = numeBrevPer == null ? null : numeBrevPer.trim();
    }

    public String getGruSangPer() {
        return gruSangPer;
    }

    public void setGruSangPer(String gruSangPer) {
        this.gruSangPer = gruSangPer == null ? null : gruSangPer.trim();
    }

    public String getCodMonSuelPer() {
        return codMonSuelPer;
    }

    public void setCodMonSuelPer(String codMonSuelPer) {
        this.codMonSuelPer = codMonSuelPer == null ? null : codMonSuelPer.trim();
    }

    public String getFlagSuelPer() {
        return flagSuelPer;
    }

    public void setFlagSuelPer(String flagSuelPer) {
        this.flagSuelPer = flagSuelPer == null ? null : flagSuelPer.trim();
    }

    public String getBancSuelTbc() {
        return bancSuelTbc;
    }

    public void setBancSuelTbc(String bancSuelTbc) {
        this.bancSuelTbc = bancSuelTbc == null ? null : bancSuelTbc.trim();
    }

    public String getSuelCtaPer() {
        return suelCtaPer;
    }

    public void setSuelCtaPer(String suelCtaPer) {
        this.suelCtaPer = suelCtaPer == null ? null : suelCtaPer.trim();
    }

    public String getBancCtsTbc() {
        return bancCtsTbc;
    }

    public void setBancCtsTbc(String bancCtsTbc) {
        this.bancCtsTbc = bancCtsTbc == null ? null : bancCtsTbc.trim();
    }

    public String getCtsCtaPer() {
        return ctsCtaPer;
    }

    public void setCtsCtaPer(String ctsCtaPer) {
        this.ctsCtaPer = ctsCtaPer == null ? null : ctsCtaPer.trim();
    }

    public String getCodMonCtsPer() {
        return codMonCtsPer;
    }

    public void setCodMonCtsPer(String codMonCtsPer) {
        this.codMonCtsPer = codMonCtsPer == null ? null : codMonCtsPer.trim();
    }

    public String getNumePlazPer() {
        return numePlazPer;
    }

    public void setNumePlazPer(String numePlazPer) {
        this.numePlazPer = numePlazPer == null ? null : numePlazPer.trim();
    }

    public Date getFechRnomPer() {
        return fechRnomPer;
    }

    public void setFechRnomPer(Date fechRnomPer) {
        this.fechRnomPer = fechRnomPer;
    }

    public String getNumeRnomPer() {
        return numeRnomPer;
    }

    public void setNumeRnomPer(String numeRnomPer) {
        this.numeRnomPer = numeRnomPer == null ? null : numeRnomPer.trim();
    }

    public String getSedeActuPer() {
        return sedeActuPer;
    }

    public void setSedeActuPer(String sedeActuPer) {
        this.sedeActuPer = sedeActuPer == null ? null : sedeActuPer.trim();
    }

    public Date getFingAdmPer() {
        return fingAdmPer;
    }

    public void setFingAdmPer(Date fingAdmPer) {
        this.fingAdmPer = fingAdmPer;
    }

    public Date getFingCarrpPer() {
        return fingCarrpPer;
    }

    public void setFingCarrpPer(Date fingCarrpPer) {
        this.fingCarrpPer = fingCarrpPer;
    }

    public String getOtroDocuPer() {
        return otroDocuPer;
    }

    public void setOtroDocuPer(String otroDocuPer) {
        this.otroDocuPer = otroDocuPer == null ? null : otroDocuPer.trim();
    }

    public String getObservaPer() {
        return observaPer;
    }

    public void setObservaPer(String observaPer) {
        this.observaPer = observaPer == null ? null : observaPer.trim();
    }

    public String getCargoRemuPer() {
        return cargoRemuPer;
    }

    public void setCargoRemuPer(String cargoRemuPer) {
        this.cargoRemuPer = cargoRemuPer == null ? null : cargoRemuPer.trim();
    }

    public String getNivelRemuPer() {
        return nivelRemuPer;
    }

    public void setNivelRemuPer(String nivelRemuPer) {
        this.nivelRemuPer = nivelRemuPer == null ? null : nivelRemuPer.trim();
    }

    public String getPlazaRemuPer() {
        return plazaRemuPer;
    }

    public void setPlazaRemuPer(String plazaRemuPer) {
        this.plazaRemuPer = plazaRemuPer == null ? null : plazaRemuPer.trim();
    }

    public String getDepeRemuPer() {
        return depeRemuPer;
    }

    public void setDepeRemuPer(String depeRemuPer) {
        this.depeRemuPer = depeRemuPer == null ? null : depeRemuPer.trim();
    }

    public String getObserRemuPer() {
        return obserRemuPer;
    }

    public void setObserRemuPer(String obserRemuPer) {
        this.obserRemuPer = obserRemuPer == null ? null : obserRemuPer.trim();
    }

    public String getTipoCuenPer() {
        return tipoCuenPer;
    }

    public void setTipoCuenPer(String tipoCuenPer) {
        this.tipoCuenPer = tipoCuenPer == null ? null : tipoCuenPer.trim();
    }

    public String getSeguMediPer() {
        return seguMediPer;
    }

    public void setSeguMediPer(String seguMediPer) {
        this.seguMediPer = seguMediPer == null ? null : seguMediPer.trim();
    }

    public String getSedeRemuPer() {
        return sedeRemuPer;
    }

    public void setSedeRemuPer(String sedeRemuPer) {
        this.sedeRemuPer = sedeRemuPer == null ? null : sedeRemuPer.trim();
    }

    public String getApepSoltPer() {
        return apepSoltPer;
    }

    public void setApepSoltPer(String apepSoltPer) {
        this.apepSoltPer = apepSoltPer == null ? null : apepSoltPer.trim();
    }

    public String getApemSoltPer() {
        return apemSoltPer;
    }

    public void setApemSoltPer(String apemSoltPer) {
        this.apemSoltPer = apemSoltPer == null ? null : apemSoltPer.trim();
    }

    public String getNombSoltEr() {
        return nombSoltEr;
    }

    public void setNombSoltEr(String nombSoltEr) {
        this.nombSoltEr = nombSoltEr == null ? null : nombSoltEr.trim();
    }

    public String getCodiProfTpr() {
        return codiProfTpr;
    }

    public void setCodiProfTpr(String codiProfTpr) {
        this.codiProfTpr = codiProfTpr == null ? null : codiProfTpr.trim();
    }

    public Date getFechCesePer() {
        return fechCesePer;
    }

    public void setFechCesePer(Date fechCesePer) {
        this.fechCesePer = fechCesePer;
    }

    public String getNumePasaPer() {
        return numePasaPer;
    }

    public void setNumePasaPer(String numePasaPer) {
        this.numePasaPer = numePasaPer == null ? null : numePasaPer.trim();
    }

    public String getAnnoProgPla() {
        return annoProgPla;
    }

    public void setAnnoProgPla(String annoProgPla) {
        this.annoProgPla = annoProgPla == null ? null : annoProgPla.trim();
    }

    public String getCodiPlazPla() {
        return codiPlazPla;
    }

    public void setCodiPlazPla(String codiPlazPla) {
        this.codiPlazPla = codiPlazPla == null ? null : codiPlazPla.trim();
    }

    public String getCodiAntePer() {
        return codiAntePer;
    }

    public void setCodiAntePer(String codiAntePer) {
        this.codiAntePer = codiAntePer == null ? null : codiAntePer.trim();
    }

    public String getNiveViatNvi() {
        return niveViatNvi;
    }

    public void setNiveViatNvi(String niveViatNvi) {
        this.niveViatNvi = niveViatNvi == null ? null : niveViatNvi.trim();
    }

    public String getCodiCondLab() {
        return codiCondLab;
    }

    public void setCodiCondLab(String codiCondLab) {
        this.codiCondLab = codiCondLab == null ? null : codiCondLab.trim();
    }

    public String getFlagMoscPer() {
        return flagMoscPer;
    }

    public void setFlagMoscPer(String flagMoscPer) {
        this.flagMoscPer = flagMoscPer == null ? null : flagMoscPer.trim();
    }

    public String getTipoDocuPer() {
        return tipoDocuPer;
    }

    public void setTipoDocuPer(String tipoDocuPer) {
        this.tipoDocuPer = tipoDocuPer == null ? null : tipoDocuPer.trim();
    }

    public String getNumeCeluPer() {
        return numeCeluPer;
    }

    public void setNumeCeluPer(String numeCeluPer) {
        this.numeCeluPer = numeCeluPer == null ? null : numeCeluPer.trim();
    }

    public String getCodiNiveNvl() {
        return codiNiveNvl;
    }

    public void setCodiNiveNvl(String codiNiveNvl) {
        this.codiNiveNvl = codiNiveNvl == null ? null : codiNiveNvl.trim();
    }

    public Integer getCantAnnoExp() {
        return cantAnnoExp;
    }

    public void setCantAnnoExp(Integer cantAnnoExp) {
        this.cantAnnoExp = cantAnnoExp;
    }

    public Integer getCantMeseExp() {
        return cantMeseExp;
    }

    public void setCantMeseExp(Integer cantMeseExp) {
        this.cantMeseExp = cantMeseExp;
    }

    public String getPlazEncaPer() {
        return plazEncaPer;
    }

    public void setPlazEncaPer(String plazEncaPer) {
        this.plazEncaPer = plazEncaPer == null ? null : plazEncaPer.trim();
    }

    public Short getNumeDepePer() {
        return numeDepePer;
    }

    public void setNumeDepePer(Short numeDepePer) {
        this.numeDepePer = numeDepePer;
    }

    public String getFlagAfilEps() {
        return flagAfilEps;
    }

    public void setFlagAfilEps(String flagAfilEps) {
        this.flagAfilEps = flagAfilEps == null ? null : flagAfilEps.trim();
    }

    public String getCodiJefePer() {
        return codiJefePer;
    }

    public void setCodiJefePer(String codiJefePer) {
        this.codiJefePer = codiJefePer == null ? null : codiJefePer.trim();
    }

    public Date getIngrEntiPer() {
        return ingrEntiPer;
    }

    public void setIngrEntiPer(Date ingrEntiPer) {
        this.ingrEntiPer = ingrEntiPer;
    }

    public Date getInicContPer() {
        return inicContPer;
    }

    public void setInicContPer(Date inicContPer) {
        this.inicContPer = inicContPer;
    }

    public Date getFinaContPer() {
        return finaContPer;
    }

    public void setFinaContPer(Date finaContPer) {
        this.finaContPer = finaContPer;
    }

    public Date getInicLaboPer() {
        return inicLaboPer;
    }

    public void setInicLaboPer(Date inicLaboPer) {
        this.inicLaboPer = inicLaboPer;
    }

    public String getCodiPlazCap() {
        return codiPlazCap;
    }

    public void setCodiPlazCap(String codiPlazCap) {
        this.codiPlazCap = codiPlazCap == null ? null : codiPlazCap.trim();
    }

    public String getUnidLocaUlo() {
        return unidLocaUlo;
    }

    public void setUnidLocaUlo(String unidLocaUlo) {
        this.unidLocaUlo = unidLocaUlo == null ? null : unidLocaUlo.trim();
    }

    public String getEssaludVida() {
        return essaludVida;
    }

    public void setEssaludVida(String essaludVida) {
        this.essaludVida = essaludVida == null ? null : essaludVida.trim();
    }

    public String getDomiciliado() {
        return domiciliado;
    }

    public void setDomiciliado(String domiciliado) {
        this.domiciliado = domiciliado == null ? null : domiciliado.trim();
    }

    public String getCodigoTipoVia() {
        return codigoTipoVia;
    }

    public void setCodigoTipoVia(String codigoTipoVia) {
        this.codigoTipoVia = codigoTipoVia == null ? null : codigoTipoVia.trim();
    }

    public String getDomicilioNombreVia() {
        return domicilioNombreVia;
    }

    public void setDomicilioNombreVia(String domicilioNombreVia) {
        this.domicilioNombreVia = domicilioNombreVia == null ? null : domicilioNombreVia.trim();
    }

    public String getDomicilioNumeroVia() {
        return domicilioNumeroVia;
    }

    public void setDomicilioNumeroVia(String domicilioNumeroVia) {
        this.domicilioNumeroVia = domicilioNumeroVia == null ? null : domicilioNumeroVia.trim();
    }

    public String getDomicilioInterior() {
        return domicilioInterior;
    }

    public void setDomicilioInterior(String domicilioInterior) {
        this.domicilioInterior = domicilioInterior == null ? null : domicilioInterior.trim();
    }

    public String getCodigoTipoZona() {
        return codigoTipoZona;
    }

    public void setCodigoTipoZona(String codigoTipoZona) {
        this.codigoTipoZona = codigoTipoZona == null ? null : codigoTipoZona.trim();
    }

    public String getDomicilioNombreZona() {
        return domicilioNombreZona;
    }

    public void setDomicilioNombreZona(String domicilioNombreZona) {
        this.domicilioNombreZona = domicilioNombreZona == null ? null : domicilioNombreZona.trim();
    }

    public String getDomicilioReferencia() {
        return domicilioReferencia;
    }

    public void setDomicilioReferencia(String domicilioReferencia) {
        this.domicilioReferencia = domicilioReferencia == null ? null : domicilioReferencia.trim();
    }

    public String getCodigoTipoTrabajador() {
        return codigoTipoTrabajador;
    }

    public void setCodigoTipoTrabajador(String codigoTipoTrabajador) {
        this.codigoTipoTrabajador = codigoTipoTrabajador == null ? null : codigoTipoTrabajador.trim();
    }

    public String getCodigoNivelEducativo() {
        return codigoNivelEducativo;
    }

    public void setCodigoNivelEducativo(String codigoNivelEducativo) {
        this.codigoNivelEducativo = codigoNivelEducativo == null ? null : codigoNivelEducativo.trim();
    }

    public String getCodigoOcupacion() {
        return codigoOcupacion;
    }

    public void setCodigoOcupacion(String codigoOcupacion) {
        this.codigoOcupacion = codigoOcupacion == null ? null : codigoOcupacion.trim();
    }

    public String getDiscapacidad() {
        return discapacidad;
    }

    public void setDiscapacidad(String discapacidad) {
        this.discapacidad = discapacidad == null ? null : discapacidad.trim();
    }

    public String getCodigoRegimenPensionario() {
        return codigoRegimenPensionario;
    }

    public void setCodigoRegimenPensionario(String codigoRegimenPensionario) {
        this.codigoRegimenPensionario = codigoRegimenPensionario == null ? null : codigoRegimenPensionario.trim();
    }

    public String getSctrSalud() {
        return sctrSalud;
    }

    public void setSctrSalud(String sctrSalud) {
        this.sctrSalud = sctrSalud == null ? null : sctrSalud.trim();
    }

    public String getSctrPension() {
        return sctrPension;
    }

    public void setSctrPension(String sctrPension) {
        this.sctrPension = sctrPension == null ? null : sctrPension.trim();
    }

    public String getCodigoTipoContrato() {
        return codigoTipoContrato;
    }

    public void setCodigoTipoContrato(String codigoTipoContrato) {
        this.codigoTipoContrato = codigoTipoContrato == null ? null : codigoTipoContrato.trim();
    }

    public String getRegimenAlternativo() {
        return regimenAlternativo;
    }

    public void setRegimenAlternativo(String regimenAlternativo) {
        this.regimenAlternativo = regimenAlternativo == null ? null : regimenAlternativo.trim();
    }

    public String getJornadaTrabajoMaxima() {
        return jornadaTrabajoMaxima;
    }

    public void setJornadaTrabajoMaxima(String jornadaTrabajoMaxima) {
        this.jornadaTrabajoMaxima = jornadaTrabajoMaxima == null ? null : jornadaTrabajoMaxima.trim();
    }

    public String getHorarioNocturno() {
        return horarioNocturno;
    }

    public void setHorarioNocturno(String horarioNocturno) {
        this.horarioNocturno = horarioNocturno == null ? null : horarioNocturno.trim();
    }

    public String getOtrosIngresosQuinta() {
        return otrosIngresosQuinta;
    }

    public void setOtrosIngresosQuinta(String otrosIngresosQuinta) {
        this.otrosIngresosQuinta = otrosIngresosQuinta == null ? null : otrosIngresosQuinta.trim();
    }

    public String getSindicalizado() {
        return sindicalizado;
    }

    public void setSindicalizado(String sindicalizado) {
        this.sindicalizado = sindicalizado == null ? null : sindicalizado.trim();
    }

    public String getCodigoPeriodicidad() {
        return codigoPeriodicidad;
    }

    public void setCodigoPeriodicidad(String codigoPeriodicidad) {
        this.codigoPeriodicidad = codigoPeriodicidad == null ? null : codigoPeriodicidad.trim();
    }

    public String getAfiliadoEps() {
        return afiliadoEps;
    }

    public void setAfiliadoEps(String afiliadoEps) {
        this.afiliadoEps = afiliadoEps == null ? null : afiliadoEps.trim();
    }

    public String getCodigoEps() {
        return codigoEps;
    }

    public void setCodigoEps(String codigoEps) {
        this.codigoEps = codigoEps == null ? null : codigoEps.trim();
    }

    public String getCodigoSituacionEps() {
        return codigoSituacionEps;
    }

    public void setCodigoSituacionEps(String codigoSituacionEps) {
        this.codigoSituacionEps = codigoSituacionEps == null ? null : codigoSituacionEps.trim();
    }

    public String getRentaQuintaExonerada() {
        return rentaQuintaExonerada;
    }

    public void setRentaQuintaExonerada(String rentaQuintaExonerada) {
        this.rentaQuintaExonerada = rentaQuintaExonerada == null ? null : rentaQuintaExonerada.trim();
    }

    public String getSituacionEspecialTrabajador() {
        return situacionEspecialTrabajador;
    }

    public void setSituacionEspecialTrabajador(String situacionEspecialTrabajador) {
        this.situacionEspecialTrabajador = situacionEspecialTrabajador == null ? null : situacionEspecialTrabajador.trim();
    }

    public String getCodigoTipoPago() {
        return codigoTipoPago;
    }

    public void setCodigoTipoPago(String codigoTipoPago) {
        this.codigoTipoPago = codigoTipoPago == null ? null : codigoTipoPago.trim();
    }

    public String getModFormativaSeguroMedico() {
        return modFormativaSeguroMedico;
    }

    public void setModFormativaSeguroMedico(String modFormativaSeguroMedico) {
        this.modFormativaSeguroMedico = modFormativaSeguroMedico == null ? null : modFormativaSeguroMedico.trim();
    }

    public String getModFormativaMadreRespon() {
        return modFormativaMadreRespon;
    }

    public void setModFormativaMadreRespon(String modFormativaMadreRespon) {
        this.modFormativaMadreRespon = modFormativaMadreRespon == null ? null : modFormativaMadreRespon.trim();
    }

    public String getModFormativaCentroFormacion() {
        return modFormativaCentroFormacion;
    }

    public void setModFormativaCentroFormacion(String modFormativaCentroFormacion) {
        this.modFormativaCentroFormacion = modFormativaCentroFormacion == null ? null : modFormativaCentroFormacion.trim();
    }

    public String getCodigoFinPeriodo() {
        return codigoFinPeriodo;
    }

    public void setCodigoFinPeriodo(String codigoFinPeriodo) {
        this.codigoFinPeriodo = codigoFinPeriodo == null ? null : codigoFinPeriodo.trim();
    }

    public String getCodigoModalidadFormativa() {
        return codigoModalidadFormativa;
    }

    public void setCodigoModalidadFormativa(String codigoModalidadFormativa) {
        this.codigoModalidadFormativa = codigoModalidadFormativa == null ? null : codigoModalidadFormativa.trim();
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad == null ? null : nacionalidad.trim();
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria == null ? null : categoria.trim();
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getUserCrea() {
        return userCrea;
    }

    public void setUserCrea(String userCrea) {
        this.userCrea = userCrea == null ? null : userCrea.trim();
    }

    public Date getFechCrea() {
        return fechCrea;
    }

    public void setFechCrea(Date fechCrea) {
        this.fechCrea = fechCrea;
    }

    public String getUserModi() {
        return userModi;
    }

    public void setUserModi(String userModi) {
        this.userModi = userModi == null ? null : userModi.trim();
    }

    public Date getFechModi() {
        return fechModi;
    }

    public void setFechModi(Date fechModi) {
        this.fechModi = fechModi;
    }

    public String getJefeAnterior() {
        return jefeAnterior;
    }

    public void setJefeAnterior(String jefeAnterior) {
        this.jefeAnterior = jefeAnterior == null ? null : jefeAnterior.trim();
    }

    public String getNumeRegiArc() {
        return numeRegiArc;
    }

    public void setNumeRegiArc(String numeRegiArc) {
        this.numeRegiArc = numeRegiArc == null ? null : numeRegiArc.trim();
    }

    public String getNumeroRegistroAlterno() {
        return numeroRegistroAlterno;
    }

    public void setNumeroRegistroAlterno(String numeroRegistroAlterno) {
        this.numeroRegistroAlterno = numeroRegistroAlterno == null ? null : numeroRegistroAlterno.trim();
    }

    public Short getVersionFotocheck() {
        return versionFotocheck;
    }

    public void setVersionFotocheck(Short versionFotocheck) {
        this.versionFotocheck = versionFotocheck;
    }

    public Short getIndicadorMigracion() {
        return indicadorMigracion;
    }

    public void setIndicadorMigracion(Short indicadorMigracion) {
        this.indicadorMigracion = indicadorMigracion;
    }

    public String getNumeroCarnet() {
        return numeroCarnet;
    }

    public void setNumeroCarnet(String numeroCarnet) {
        this.numeroCarnet = numeroCarnet == null ? null : numeroCarnet.trim();
    }

    public String getGradoEfectivo() {
        return gradoEfectivo;
    }

    public void setGradoEfectivo(String gradoEfectivo) {
        this.gradoEfectivo = gradoEfectivo == null ? null : gradoEfectivo.trim();
    }

    public String getTipoEfectivo() {
        return tipoEfectivo;
    }

    public void setTipoEfectivo(String tipoEfectivo) {
        this.tipoEfectivo = tipoEfectivo == null ? null : tipoEfectivo.trim();
    }

    public String getIndicadorFallecimiento() {
        return indicadorFallecimiento;
    }

    public void setIndicadorFallecimiento(String indicadorFallecimiento) {
        this.indicadorFallecimiento = indicadorFallecimiento == null ? null : indicadorFallecimiento.trim();
    }

    public String getPartidaDefuncion() {
        return partidaDefuncion;
    }

    public void setPartidaDefuncion(String partidaDefuncion) {
        this.partidaDefuncion = partidaDefuncion == null ? null : partidaDefuncion.trim();
    }

    public Date getFechaPension() {
        return fechaPension;
    }

    public void setFechaPension(Date fechaPension) {
        this.fechaPension = fechaPension;
    }

    public Date getFechaFallecimiento() {
        return fechaFallecimiento;
    }

    public void setFechaFallecimiento(Date fechaFallecimiento) {
        this.fechaFallecimiento = fechaFallecimiento;
    }

    public Short getTiempoServicioAnios() {
        return tiempoServicioAnios;
    }

    public void setTiempoServicioAnios(Short tiempoServicioAnios) {
        this.tiempoServicioAnios = tiempoServicioAnios;
    }

    public Short getTiempoServicioMeses() {
        return tiempoServicioMeses;
    }

    public void setTiempoServicioMeses(Short tiempoServicioMeses) {
        this.tiempoServicioMeses = tiempoServicioMeses;
    }

    public Integer getTiempoServicioDias() {
        return tiempoServicioDias;
    }

    public void setTiempoServicioDias(Integer tiempoServicioDias) {
        this.tiempoServicioDias = tiempoServicioDias;
    }

    public String getCodTelefCiudad() {
        return codTelefCiudad;
    }

    public void setCodTelefCiudad(String codTelefCiudad) {
        this.codTelefCiudad = codTelefCiudad == null ? null : codTelefCiudad.trim();
    }

    public String getCodPdtDeparta() {
        return codPdtDeparta;
    }

    public void setCodPdtDeparta(String codPdtDeparta) {
        this.codPdtDeparta = codPdtDeparta == null ? null : codPdtDeparta.trim();
    }

    public String getCodPdtManzana() {
        return codPdtManzana;
    }

    public void setCodPdtManzana(String codPdtManzana) {
        this.codPdtManzana = codPdtManzana == null ? null : codPdtManzana.trim();
    }

    public String getCodPdtLote() {
        return codPdtLote;
    }

    public void setCodPdtLote(String codPdtLote) {
        this.codPdtLote = codPdtLote == null ? null : codPdtLote.trim();
    }

    public String getCodPdtKilometro() {
        return codPdtKilometro;
    }

    public void setCodPdtKilometro(String codPdtKilometro) {
        this.codPdtKilometro = codPdtKilometro == null ? null : codPdtKilometro.trim();
    }

    public String getCodPdtBlock() {
        return codPdtBlock;
    }

    public void setCodPdtBlock(String codPdtBlock) {
        this.codPdtBlock = codPdtBlock == null ? null : codPdtBlock.trim();
    }

    public String getCodPdtEtapa() {
        return codPdtEtapa;
    }

    public void setCodPdtEtapa(String codPdtEtapa) {
        this.codPdtEtapa = codPdtEtapa == null ? null : codPdtEtapa.trim();
    }

    public String getIndAfectoAfp() {
        return indAfectoAfp;
    }

    public void setIndAfectoAfp(String indAfectoAfp) {
        this.indAfectoAfp = indAfectoAfp == null ? null : indAfectoAfp.trim();
    }

    public String getIndAfiliadoEps() {
        return indAfiliadoEps;
    }

    public void setIndAfiliadoEps(String indAfiliadoEps) {
        this.indAfiliadoEps = indAfiliadoEps == null ? null : indAfiliadoEps.trim();
    }

    public String getNumAnexo() {
        return numAnexo;
    }

    public void setNumAnexo(String numAnexo) {
        this.numAnexo = numAnexo == null ? null : numAnexo.trim();
    }

    public String getNroCertArma() {
        return nroCertArma;
    }

    public void setNroCertArma(String nroCertArma) {
        this.nroCertArma = nroCertArma == null ? null : nroCertArma.trim();
    }

    public String getSerieCertArma() {
        return serieCertArma;
    }

    public void setSerieCertArma(String serieCertArma) {
        this.serieCertArma = serieCertArma == null ? null : serieCertArma.trim();
    }

    public Date getFecCadCertArma() {
        return fecCadCertArma;
    }

    public void setFecCadCertArma(Date fecCadCertArma) {
        this.fecCadCertArma = fecCadCertArma;
    }

    public String getIndAfpCom() {
        return indAfpCom;
    }

    public void setIndAfpCom(String indAfpCom) {
        this.indAfpCom = indAfpCom == null ? null : indAfpCom.trim();
    }

    public String getCodofin() {
        return codofin;
    }

    public void setCodofin(String codofin) {
        this.codofin = codofin == null ? null : codofin.trim();
    }

    public String getTarifaDefPoli() {
        return tarifaDefPoli;
    }

    public void setTarifaDefPoli(String tarifaDefPoli) {
        this.tarifaDefPoli = tarifaDefPoli == null ? null : tarifaDefPoli.trim();
    }
}