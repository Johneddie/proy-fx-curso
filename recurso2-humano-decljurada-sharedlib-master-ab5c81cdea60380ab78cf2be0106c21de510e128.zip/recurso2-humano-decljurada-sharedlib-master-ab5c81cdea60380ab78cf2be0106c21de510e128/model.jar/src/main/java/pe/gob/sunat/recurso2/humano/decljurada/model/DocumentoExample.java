package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DocumentoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public DocumentoExample() {
        oredCriteria = new ArrayList<>();
    }

    protected DocumentoExample(DocumentoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andT07codPersIsNull() {
            addCriterion("t07cod_pers is null");
            return this;
        }

        public Criteria andT07codPersIsNotNull() {
            addCriterion("t07cod_pers is not null");
            return this;
        }

        public Criteria andT07codPersEqualTo(String value) {
            addCriterion("t07cod_pers =", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersNotEqualTo(String value) {
            addCriterion("t07cod_pers <>", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersGreaterThan(String value) {
            addCriterion("t07cod_pers >", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersGreaterThanOrEqualTo(String value) {
            addCriterion("t07cod_pers >=", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersLessThan(String value) {
            addCriterion("t07cod_pers <", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersLessThanOrEqualTo(String value) {
            addCriterion("t07cod_pers <=", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersLike(String value) {
            addCriterion("t07cod_pers like", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersNotLike(String value) {
            addCriterion("t07cod_pers not like", value, "t07codPers");
            return this;
        }

        public Criteria andT07codPersIn(List<String> values) {
            addCriterion("t07cod_pers in", values, "t07codPers");
            return this;
        }

        public Criteria andT07codPersNotIn(List<String> values) {
            addCriterion("t07cod_pers not in", values, "t07codPers");
            return this;
        }

        public Criteria andT07codPersBetween(String value1, String value2) {
            addCriterion("t07cod_pers between", value1, value2, "t07codPers");
            return this;
        }

        public Criteria andT07codPersNotBetween(String value1, String value2) {
            addCriterion("t07cod_pers not between", value1, value2, "t07codPers");
            return this;
        }

        public Criteria andT07correlIsNull() {
            addCriterion("t07correl is null");
            return this;
        }

        public Criteria andT07correlIsNotNull() {
            addCriterion("t07correl is not null");
            return this;
        }

        public Criteria andT07correlEqualTo(String value) {
            addCriterion("t07correl =", value, "t07correl");
            return this;
        }

        public Criteria andT07correlNotEqualTo(String value) {
            addCriterion("t07correl <>", value, "t07correl");
            return this;
        }

        public Criteria andT07correlGreaterThan(String value) {
            addCriterion("t07correl >", value, "t07correl");
            return this;
        }

        public Criteria andT07correlGreaterThanOrEqualTo(String value) {
            addCriterion("t07correl >=", value, "t07correl");
            return this;
        }

        public Criteria andT07correlLessThan(String value) {
            addCriterion("t07correl <", value, "t07correl");
            return this;
        }

        public Criteria andT07correlLessThanOrEqualTo(String value) {
            addCriterion("t07correl <=", value, "t07correl");
            return this;
        }

        public Criteria andT07correlLike(String value) {
            addCriterion("t07correl like", value, "t07correl");
            return this;
        }

        public Criteria andT07correlNotLike(String value) {
            addCriterion("t07correl not like", value, "t07correl");
            return this;
        }

        public Criteria andT07correlIn(List<String> values) {
            addCriterion("t07correl in", values, "t07correl");
            return this;
        }

        public Criteria andT07correlNotIn(List<String> values) {
            addCriterion("t07correl not in", values, "t07correl");
            return this;
        }

        public Criteria andT07correlBetween(String value1, String value2) {
            addCriterion("t07correl between", value1, value2, "t07correl");
            return this;
        }

        public Criteria andT07correlNotBetween(String value1, String value2) {
            addCriterion("t07correl not between", value1, value2, "t07correl");
            return this;
        }

        public Criteria andT07codDctoIsNull() {
            addCriterion("t07cod_dcto is null");
            return this;
        }

        public Criteria andT07codDctoIsNotNull() {
            addCriterion("t07cod_dcto is not null");
            return this;
        }

        public Criteria andT07codDctoEqualTo(String value) {
            addCriterion("t07cod_dcto =", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoNotEqualTo(String value) {
            addCriterion("t07cod_dcto <>", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoGreaterThan(String value) {
            addCriterion("t07cod_dcto >", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoGreaterThanOrEqualTo(String value) {
            addCriterion("t07cod_dcto >=", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoLessThan(String value) {
            addCriterion("t07cod_dcto <", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoLessThanOrEqualTo(String value) {
            addCriterion("t07cod_dcto <=", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoLike(String value) {
            addCriterion("t07cod_dcto like", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoNotLike(String value) {
            addCriterion("t07cod_dcto not like", value, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoIn(List<String> values) {
            addCriterion("t07cod_dcto in", values, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoNotIn(List<String> values) {
            addCriterion("t07cod_dcto not in", values, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoBetween(String value1, String value2) {
            addCriterion("t07cod_dcto between", value1, value2, "t07codDcto");
            return this;
        }

        public Criteria andT07codDctoNotBetween(String value1, String value2) {
            addCriterion("t07cod_dcto not between", value1, value2, "t07codDcto");
            return this;
        }

        public Criteria andT07nroDctoIsNull() {
            addCriterion("t07nro_dcto is null");
            return this;
        }

        public Criteria andT07nroDctoIsNotNull() {
            addCriterion("t07nro_dcto is not null");
            return this;
        }

        public Criteria andT07nroDctoEqualTo(String value) {
            addCriterion("t07nro_dcto =", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoNotEqualTo(String value) {
            addCriterion("t07nro_dcto <>", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoGreaterThan(String value) {
            addCriterion("t07nro_dcto >", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoGreaterThanOrEqualTo(String value) {
            addCriterion("t07nro_dcto >=", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoLessThan(String value) {
            addCriterion("t07nro_dcto <", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoLessThanOrEqualTo(String value) {
            addCriterion("t07nro_dcto <=", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoLike(String value) {
            addCriterion("t07nro_dcto like", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoNotLike(String value) {
            addCriterion("t07nro_dcto not like", value, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoIn(List<String> values) {
            addCriterion("t07nro_dcto in", values, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoNotIn(List<String> values) {
            addCriterion("t07nro_dcto not in", values, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoBetween(String value1, String value2) {
            addCriterion("t07nro_dcto between", value1, value2, "t07nroDcto");
            return this;
        }

        public Criteria andT07nroDctoNotBetween(String value1, String value2) {
            addCriterion("t07nro_dcto not between", value1, value2, "t07nroDcto");
            return this;
        }

        public Criteria andT07fGrabaIsNull() {
            addCriterion("t07f_graba is null");
            return this;
        }

        public Criteria andT07fGrabaIsNotNull() {
            addCriterion("t07f_graba is not null");
            return this;
        }

        public Criteria andT07fGrabaEqualTo(Date value) {
            addCriterion("t07f_graba =", value, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaNotEqualTo(Date value) {
            addCriterion("t07f_graba <>", value, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaGreaterThan(Date value) {
            addCriterion("t07f_graba >", value, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaGreaterThanOrEqualTo(Date value) {
            addCriterion("t07f_graba >=", value, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaLessThan(Date value) {
            addCriterion("t07f_graba <", value, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaLessThanOrEqualTo(Date value) {
            addCriterion("t07f_graba <=", value, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaIn(List<Date> values) {
            addCriterion("t07f_graba in", values, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaNotIn(List<Date> values) {
            addCriterion("t07f_graba not in", values, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaBetween(Date value1, Date value2) {
            addCriterion("t07f_graba between", value1, value2, "t07fGraba");
            return this;
        }

        public Criteria andT07fGrabaNotBetween(Date value1, Date value2) {
            addCriterion("t07f_graba not between", value1, value2, "t07fGraba");
            return this;
        }

        public Criteria andT07codUserIsNull() {
            addCriterion("t07cod_user is null");
            return this;
        }

        public Criteria andT07codUserIsNotNull() {
            addCriterion("t07cod_user is not null");
            return this;
        }

        public Criteria andT07codUserEqualTo(String value) {
            addCriterion("t07cod_user =", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserNotEqualTo(String value) {
            addCriterion("t07cod_user <>", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserGreaterThan(String value) {
            addCriterion("t07cod_user >", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserGreaterThanOrEqualTo(String value) {
            addCriterion("t07cod_user >=", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserLessThan(String value) {
            addCriterion("t07cod_user <", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserLessThanOrEqualTo(String value) {
            addCriterion("t07cod_user <=", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserLike(String value) {
            addCriterion("t07cod_user like", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserNotLike(String value) {
            addCriterion("t07cod_user not like", value, "t07codUser");
            return this;
        }

        public Criteria andT07codUserIn(List<String> values) {
            addCriterion("t07cod_user in", values, "t07codUser");
            return this;
        }

        public Criteria andT07codUserNotIn(List<String> values) {
            addCriterion("t07cod_user not in", values, "t07codUser");
            return this;
        }

        public Criteria andT07codUserBetween(String value1, String value2) {
            addCriterion("t07cod_user between", value1, value2, "t07codUser");
            return this;
        }

        public Criteria andT07codUserNotBetween(String value1, String value2) {
            addCriterion("t07cod_user not between", value1, value2, "t07codUser");
            return this;
        }
    }
}