package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Estructura04Example {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public Estructura04Example() {
        oredCriteria = new ArrayList<>();
    }

    protected Estructura04Example(Estructura04Example example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andFecProcesoIsNull() {
            addCriterion("fec_proceso is null");
            return this;
        }

        public Criteria andFecProcesoIsNotNull() {
            addCriterion("fec_proceso is not null");
            return this;
        }

        public Criteria andFecProcesoEqualTo(Date value) {
            addCriterion("fec_proceso =", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotEqualTo(Date value) {
            addCriterion("fec_proceso <>", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThan(Date value) {
            addCriterion("fec_proceso >", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_proceso >=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThan(Date value) {
            addCriterion("fec_proceso <", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThanOrEqualTo(Date value) {
            addCriterion("fec_proceso <=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoIn(List<Date> values) {
            addCriterion("fec_proceso in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotIn(List<Date> values) {
            addCriterion("fec_proceso not in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoBetween(Date value1, Date value2) {
            addCriterion("fec_proceso between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotBetween(Date value1, Date value2) {
            addCriterion("fec_proceso not between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andFecNacimientoIsNull() {
            addCriterion("fec_nacimiento is null");
            return this;
        }

        public Criteria andFecNacimientoIsNotNull() {
            addCriterion("fec_nacimiento is not null");
            return this;
        }

        public Criteria andFecNacimientoEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento =", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento <>", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento >", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento >=", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoLessThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento <", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento <=", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento in", values, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento not in", values, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento between", value1, value2, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento not between", value1, value2, "fecNacimiento");
            return this;
        }

        public Criteria andApePatIsNull() {
            addCriterion("ape_pat is null");
            return this;
        }

        public Criteria andApePatIsNotNull() {
            addCriterion("ape_pat is not null");
            return this;
        }

        public Criteria andApePatEqualTo(String value) {
            addCriterion("ape_pat =", value, "apePat");
            return this;
        }

        public Criteria andApePatNotEqualTo(String value) {
            addCriterion("ape_pat <>", value, "apePat");
            return this;
        }

        public Criteria andApePatGreaterThan(String value) {
            addCriterion("ape_pat >", value, "apePat");
            return this;
        }

        public Criteria andApePatGreaterThanOrEqualTo(String value) {
            addCriterion("ape_pat >=", value, "apePat");
            return this;
        }

        public Criteria andApePatLessThan(String value) {
            addCriterion("ape_pat <", value, "apePat");
            return this;
        }

        public Criteria andApePatLessThanOrEqualTo(String value) {
            addCriterion("ape_pat <=", value, "apePat");
            return this;
        }

        public Criteria andApePatLike(String value) {
            addCriterion("ape_pat like", value, "apePat");
            return this;
        }

        public Criteria andApePatNotLike(String value) {
            addCriterion("ape_pat not like", value, "apePat");
            return this;
        }

        public Criteria andApePatIn(List<String> values) {
            addCriterion("ape_pat in", values, "apePat");
            return this;
        }

        public Criteria andApePatNotIn(List<String> values) {
            addCriterion("ape_pat not in", values, "apePat");
            return this;
        }

        public Criteria andApePatBetween(String value1, String value2) {
            addCriterion("ape_pat between", value1, value2, "apePat");
            return this;
        }

        public Criteria andApePatNotBetween(String value1, String value2) {
            addCriterion("ape_pat not between", value1, value2, "apePat");
            return this;
        }

        public Criteria andApeMatIsNull() {
            addCriterion("ape_mat is null");
            return this;
        }

        public Criteria andApeMatIsNotNull() {
            addCriterion("ape_mat is not null");
            return this;
        }

        public Criteria andApeMatEqualTo(String value) {
            addCriterion("ape_mat =", value, "apeMat");
            return this;
        }

        public Criteria andApeMatNotEqualTo(String value) {
            addCriterion("ape_mat <>", value, "apeMat");
            return this;
        }

        public Criteria andApeMatGreaterThan(String value) {
            addCriterion("ape_mat >", value, "apeMat");
            return this;
        }

        public Criteria andApeMatGreaterThanOrEqualTo(String value) {
            addCriterion("ape_mat >=", value, "apeMat");
            return this;
        }

        public Criteria andApeMatLessThan(String value) {
            addCriterion("ape_mat <", value, "apeMat");
            return this;
        }

        public Criteria andApeMatLessThanOrEqualTo(String value) {
            addCriterion("ape_mat <=", value, "apeMat");
            return this;
        }

        public Criteria andApeMatLike(String value) {
            addCriterion("ape_mat like", value, "apeMat");
            return this;
        }

        public Criteria andApeMatNotLike(String value) {
            addCriterion("ape_mat not like", value, "apeMat");
            return this;
        }

        public Criteria andApeMatIn(List<String> values) {
            addCriterion("ape_mat in", values, "apeMat");
            return this;
        }

        public Criteria andApeMatNotIn(List<String> values) {
            addCriterion("ape_mat not in", values, "apeMat");
            return this;
        }

        public Criteria andApeMatBetween(String value1, String value2) {
            addCriterion("ape_mat between", value1, value2, "apeMat");
            return this;
        }

        public Criteria andApeMatNotBetween(String value1, String value2) {
            addCriterion("ape_mat not between", value1, value2, "apeMat");
            return this;
        }

        public Criteria andNomPersonalIsNull() {
            addCriterion("nom_personal is null");
            return this;
        }

        public Criteria andNomPersonalIsNotNull() {
            addCriterion("nom_personal is not null");
            return this;
        }

        public Criteria andNomPersonalEqualTo(String value) {
            addCriterion("nom_personal =", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotEqualTo(String value) {
            addCriterion("nom_personal <>", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalGreaterThan(String value) {
            addCriterion("nom_personal >", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalGreaterThanOrEqualTo(String value) {
            addCriterion("nom_personal >=", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalLessThan(String value) {
            addCriterion("nom_personal <", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalLessThanOrEqualTo(String value) {
            addCriterion("nom_personal <=", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalLike(String value) {
            addCriterion("nom_personal like", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotLike(String value) {
            addCriterion("nom_personal not like", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalIn(List<String> values) {
            addCriterion("nom_personal in", values, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotIn(List<String> values) {
            addCriterion("nom_personal not in", values, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalBetween(String value1, String value2) {
            addCriterion("nom_personal between", value1, value2, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotBetween(String value1, String value2) {
            addCriterion("nom_personal not between", value1, value2, "nomPersonal");
            return this;
        }

        public Criteria andIndSexoIsNull() {
            addCriterion("ind_sexo is null");
            return this;
        }

        public Criteria andIndSexoIsNotNull() {
            addCriterion("ind_sexo is not null");
            return this;
        }

        public Criteria andIndSexoEqualTo(String value) {
            addCriterion("ind_sexo =", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotEqualTo(String value) {
            addCriterion("ind_sexo <>", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoGreaterThan(String value) {
            addCriterion("ind_sexo >", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sexo >=", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLessThan(String value) {
            addCriterion("ind_sexo <", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLessThanOrEqualTo(String value) {
            addCriterion("ind_sexo <=", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLike(String value) {
            addCriterion("ind_sexo like", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotLike(String value) {
            addCriterion("ind_sexo not like", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoIn(List<String> values) {
            addCriterion("ind_sexo in", values, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotIn(List<String> values) {
            addCriterion("ind_sexo not in", values, "indSexo");
            return this;
        }

        public Criteria andIndSexoBetween(String value1, String value2) {
            addCriterion("ind_sexo between", value1, value2, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotBetween(String value1, String value2) {
            addCriterion("ind_sexo not between", value1, value2, "indSexo");
            return this;
        }

        public Criteria andCodNacionalidadIsNull() {
            addCriterion("cod_nacionalidad is null");
            return this;
        }

        public Criteria andCodNacionalidadIsNotNull() {
            addCriterion("cod_nacionalidad is not null");
            return this;
        }

        public Criteria andCodNacionalidadEqualTo(String value) {
            addCriterion("cod_nacionalidad =", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotEqualTo(String value) {
            addCriterion("cod_nacionalidad <>", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadGreaterThan(String value) {
            addCriterion("cod_nacionalidad >", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadGreaterThanOrEqualTo(String value) {
            addCriterion("cod_nacionalidad >=", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadLessThan(String value) {
            addCriterion("cod_nacionalidad <", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadLessThanOrEqualTo(String value) {
            addCriterion("cod_nacionalidad <=", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadLike(String value) {
            addCriterion("cod_nacionalidad like", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotLike(String value) {
            addCriterion("cod_nacionalidad not like", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadIn(List<String> values) {
            addCriterion("cod_nacionalidad in", values, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotIn(List<String> values) {
            addCriterion("cod_nacionalidad not in", values, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadBetween(String value1, String value2) {
            addCriterion("cod_nacionalidad between", value1, value2, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotBetween(String value1, String value2) {
            addCriterion("cod_nacionalidad not between", value1, value2, "codNacionalidad");
            return this;
        }

        public Criteria andCodTelefLarDisIsNull() {
            addCriterion("cod_telef_lar_dis is null");
            return this;
        }

        public Criteria andCodTelefLarDisIsNotNull() {
            addCriterion("cod_telef_lar_dis is not null");
            return this;
        }

        public Criteria andCodTelefLarDisEqualTo(String value) {
            addCriterion("cod_telef_lar_dis =", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotEqualTo(String value) {
            addCriterion("cod_telef_lar_dis <>", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisGreaterThan(String value) {
            addCriterion("cod_telef_lar_dis >", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_telef_lar_dis >=", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLessThan(String value) {
            addCriterion("cod_telef_lar_dis <", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLessThanOrEqualTo(String value) {
            addCriterion("cod_telef_lar_dis <=", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLike(String value) {
            addCriterion("cod_telef_lar_dis like", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotLike(String value) {
            addCriterion("cod_telef_lar_dis not like", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisIn(List<String> values) {
            addCriterion("cod_telef_lar_dis in", values, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotIn(List<String> values) {
            addCriterion("cod_telef_lar_dis not in", values, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisBetween(String value1, String value2) {
            addCriterion("cod_telef_lar_dis between", value1, value2, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotBetween(String value1, String value2) {
            addCriterion("cod_telef_lar_dis not between", value1, value2, "codTelefLarDis");
            return this;
        }

        public Criteria andNumTelefIsNull() {
            addCriterion("num_telef is null");
            return this;
        }

        public Criteria andNumTelefIsNotNull() {
            addCriterion("num_telef is not null");
            return this;
        }

        public Criteria andNumTelefEqualTo(String value) {
            addCriterion("num_telef =", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotEqualTo(String value) {
            addCriterion("num_telef <>", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThan(String value) {
            addCriterion("num_telef >", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThanOrEqualTo(String value) {
            addCriterion("num_telef >=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThan(String value) {
            addCriterion("num_telef <", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThanOrEqualTo(String value) {
            addCriterion("num_telef <=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLike(String value) {
            addCriterion("num_telef like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotLike(String value) {
            addCriterion("num_telef not like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefIn(List<String> values) {
            addCriterion("num_telef in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotIn(List<String> values) {
            addCriterion("num_telef not in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefBetween(String value1, String value2) {
            addCriterion("num_telef between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotBetween(String value1, String value2) {
            addCriterion("num_telef not between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andDesCorreoIsNull() {
            addCriterion("des_correo is null");
            return this;
        }

        public Criteria andDesCorreoIsNotNull() {
            addCriterion("des_correo is not null");
            return this;
        }

        public Criteria andDesCorreoEqualTo(String value) {
            addCriterion("des_correo =", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotEqualTo(String value) {
            addCriterion("des_correo <>", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThan(String value) {
            addCriterion("des_correo >", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThanOrEqualTo(String value) {
            addCriterion("des_correo >=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThan(String value) {
            addCriterion("des_correo <", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThanOrEqualTo(String value) {
            addCriterion("des_correo <=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLike(String value) {
            addCriterion("des_correo like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotLike(String value) {
            addCriterion("des_correo not like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoIn(List<String> values) {
            addCriterion("des_correo in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotIn(List<String> values) {
            addCriterion("des_correo not in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoBetween(String value1, String value2) {
            addCriterion("des_correo between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotBetween(String value1, String value2) {
            addCriterion("des_correo not between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andCodViaDir1IsNull() {
            addCriterion("cod_via_dir1 is null");
            return this;
        }

        public Criteria andCodViaDir1IsNotNull() {
            addCriterion("cod_via_dir1 is not null");
            return this;
        }

        public Criteria andCodViaDir1EqualTo(String value) {
            addCriterion("cod_via_dir1 =", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotEqualTo(String value) {
            addCriterion("cod_via_dir1 <>", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThan(String value) {
            addCriterion("cod_via_dir1 >", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 >=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThan(String value) {
            addCriterion("cod_via_dir1 <", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 <=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Like(String value) {
            addCriterion("cod_via_dir1 like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotLike(String value) {
            addCriterion("cod_via_dir1 not like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1In(List<String> values) {
            addCriterion("cod_via_dir1 in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotIn(List<String> values) {
            addCriterion("cod_via_dir1 not in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Between(String value1, String value2) {
            addCriterion("cod_via_dir1 between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir1 not between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andNomViaDir1IsNull() {
            addCriterion("nom_via_dir1 is null");
            return this;
        }

        public Criteria andNomViaDir1IsNotNull() {
            addCriterion("nom_via_dir1 is not null");
            return this;
        }

        public Criteria andNomViaDir1EqualTo(String value) {
            addCriterion("nom_via_dir1 =", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotEqualTo(String value) {
            addCriterion("nom_via_dir1 <>", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThan(String value) {
            addCriterion("nom_via_dir1 >", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 >=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThan(String value) {
            addCriterion("nom_via_dir1 <", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 <=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Like(String value) {
            addCriterion("nom_via_dir1 like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotLike(String value) {
            addCriterion("nom_via_dir1 not like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1In(List<String> values) {
            addCriterion("nom_via_dir1 in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotIn(List<String> values) {
            addCriterion("nom_via_dir1 not in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Between(String value1, String value2) {
            addCriterion("nom_via_dir1 between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir1 not between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNumViaDir1IsNull() {
            addCriterion("num_via_dir1 is null");
            return this;
        }

        public Criteria andNumViaDir1IsNotNull() {
            addCriterion("num_via_dir1 is not null");
            return this;
        }

        public Criteria andNumViaDir1EqualTo(String value) {
            addCriterion("num_via_dir1 =", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotEqualTo(String value) {
            addCriterion("num_via_dir1 <>", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThan(String value) {
            addCriterion("num_via_dir1 >", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 >=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThan(String value) {
            addCriterion("num_via_dir1 <", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 <=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Like(String value) {
            addCriterion("num_via_dir1 like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotLike(String value) {
            addCriterion("num_via_dir1 not like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1In(List<String> values) {
            addCriterion("num_via_dir1 in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotIn(List<String> values) {
            addCriterion("num_via_dir1 not in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Between(String value1, String value2) {
            addCriterion("num_via_dir1 between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotBetween(String value1, String value2) {
            addCriterion("num_via_dir1 not between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumDepaDir1IsNull() {
            addCriterion("num_depa_dir1 is null");
            return this;
        }

        public Criteria andNumDepaDir1IsNotNull() {
            addCriterion("num_depa_dir1 is not null");
            return this;
        }

        public Criteria andNumDepaDir1EqualTo(String value) {
            addCriterion("num_depa_dir1 =", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotEqualTo(String value) {
            addCriterion("num_depa_dir1 <>", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThan(String value) {
            addCriterion("num_depa_dir1 >", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 >=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThan(String value) {
            addCriterion("num_depa_dir1 <", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 <=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Like(String value) {
            addCriterion("num_depa_dir1 like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotLike(String value) {
            addCriterion("num_depa_dir1 not like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1In(List<String> values) {
            addCriterion("num_depa_dir1 in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotIn(List<String> values) {
            addCriterion("num_depa_dir1 not in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Between(String value1, String value2) {
            addCriterion("num_depa_dir1 between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir1 not between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumInteriorDir1IsNull() {
            addCriterion("num_interior_dir1 is null");
            return this;
        }

        public Criteria andNumInteriorDir1IsNotNull() {
            addCriterion("num_interior_dir1 is not null");
            return this;
        }

        public Criteria andNumInteriorDir1EqualTo(String value) {
            addCriterion("num_interior_dir1 =", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotEqualTo(String value) {
            addCriterion("num_interior_dir1 <>", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThan(String value) {
            addCriterion("num_interior_dir1 >", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 >=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThan(String value) {
            addCriterion("num_interior_dir1 <", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 <=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Like(String value) {
            addCriterion("num_interior_dir1 like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotLike(String value) {
            addCriterion("num_interior_dir1 not like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1In(List<String> values) {
            addCriterion("num_interior_dir1 in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotIn(List<String> values) {
            addCriterion("num_interior_dir1 not in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Between(String value1, String value2) {
            addCriterion("num_interior_dir1 between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir1 not between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumManzDir1IsNull() {
            addCriterion("num_manz_dir1 is null");
            return this;
        }

        public Criteria andNumManzDir1IsNotNull() {
            addCriterion("num_manz_dir1 is not null");
            return this;
        }

        public Criteria andNumManzDir1EqualTo(String value) {
            addCriterion("num_manz_dir1 =", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotEqualTo(String value) {
            addCriterion("num_manz_dir1 <>", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThan(String value) {
            addCriterion("num_manz_dir1 >", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 >=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThan(String value) {
            addCriterion("num_manz_dir1 <", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 <=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Like(String value) {
            addCriterion("num_manz_dir1 like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotLike(String value) {
            addCriterion("num_manz_dir1 not like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1In(List<String> values) {
            addCriterion("num_manz_dir1 in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotIn(List<String> values) {
            addCriterion("num_manz_dir1 not in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Between(String value1, String value2) {
            addCriterion("num_manz_dir1 between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir1 not between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumLoteDir1IsNull() {
            addCriterion("num_lote_dir1 is null");
            return this;
        }

        public Criteria andNumLoteDir1IsNotNull() {
            addCriterion("num_lote_dir1 is not null");
            return this;
        }

        public Criteria andNumLoteDir1EqualTo(String value) {
            addCriterion("num_lote_dir1 =", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotEqualTo(String value) {
            addCriterion("num_lote_dir1 <>", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThan(String value) {
            addCriterion("num_lote_dir1 >", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 >=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThan(String value) {
            addCriterion("num_lote_dir1 <", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 <=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Like(String value) {
            addCriterion("num_lote_dir1 like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotLike(String value) {
            addCriterion("num_lote_dir1 not like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1In(List<String> values) {
            addCriterion("num_lote_dir1 in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotIn(List<String> values) {
            addCriterion("num_lote_dir1 not in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Between(String value1, String value2) {
            addCriterion("num_lote_dir1 between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir1 not between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumKilomDir1IsNull() {
            addCriterion("num_kilom_dir1 is null");
            return this;
        }

        public Criteria andNumKilomDir1IsNotNull() {
            addCriterion("num_kilom_dir1 is not null");
            return this;
        }

        public Criteria andNumKilomDir1EqualTo(String value) {
            addCriterion("num_kilom_dir1 =", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotEqualTo(String value) {
            addCriterion("num_kilom_dir1 <>", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThan(String value) {
            addCriterion("num_kilom_dir1 >", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 >=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThan(String value) {
            addCriterion("num_kilom_dir1 <", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 <=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Like(String value) {
            addCriterion("num_kilom_dir1 like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotLike(String value) {
            addCriterion("num_kilom_dir1 not like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1In(List<String> values) {
            addCriterion("num_kilom_dir1 in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotIn(List<String> values) {
            addCriterion("num_kilom_dir1 not in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Between(String value1, String value2) {
            addCriterion("num_kilom_dir1 between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir1 not between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumBlockDir1IsNull() {
            addCriterion("num_block_dir1 is null");
            return this;
        }

        public Criteria andNumBlockDir1IsNotNull() {
            addCriterion("num_block_dir1 is not null");
            return this;
        }

        public Criteria andNumBlockDir1EqualTo(String value) {
            addCriterion("num_block_dir1 =", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotEqualTo(String value) {
            addCriterion("num_block_dir1 <>", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThan(String value) {
            addCriterion("num_block_dir1 >", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 >=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThan(String value) {
            addCriterion("num_block_dir1 <", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 <=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Like(String value) {
            addCriterion("num_block_dir1 like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotLike(String value) {
            addCriterion("num_block_dir1 not like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1In(List<String> values) {
            addCriterion("num_block_dir1 in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotIn(List<String> values) {
            addCriterion("num_block_dir1 not in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Between(String value1, String value2) {
            addCriterion("num_block_dir1 between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotBetween(String value1, String value2) {
            addCriterion("num_block_dir1 not between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumEtapaDir1IsNull() {
            addCriterion("num_etapa_dir1 is null");
            return this;
        }

        public Criteria andNumEtapaDir1IsNotNull() {
            addCriterion("num_etapa_dir1 is not null");
            return this;
        }

        public Criteria andNumEtapaDir1EqualTo(String value) {
            addCriterion("num_etapa_dir1 =", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotEqualTo(String value) {
            addCriterion("num_etapa_dir1 <>", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThan(String value) {
            addCriterion("num_etapa_dir1 >", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 >=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThan(String value) {
            addCriterion("num_etapa_dir1 <", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 <=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Like(String value) {
            addCriterion("num_etapa_dir1 like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotLike(String value) {
            addCriterion("num_etapa_dir1 not like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1In(List<String> values) {
            addCriterion("num_etapa_dir1 in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotIn(List<String> values) {
            addCriterion("num_etapa_dir1 not in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Between(String value1, String value2) {
            addCriterion("num_etapa_dir1 between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir1 not between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andCodZonaDir1IsNull() {
            addCriterion("cod_zona_dir1 is null");
            return this;
        }

        public Criteria andCodZonaDir1IsNotNull() {
            addCriterion("cod_zona_dir1 is not null");
            return this;
        }

        public Criteria andCodZonaDir1EqualTo(String value) {
            addCriterion("cod_zona_dir1 =", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotEqualTo(String value) {
            addCriterion("cod_zona_dir1 <>", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThan(String value) {
            addCriterion("cod_zona_dir1 >", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 >=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThan(String value) {
            addCriterion("cod_zona_dir1 <", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 <=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Like(String value) {
            addCriterion("cod_zona_dir1 like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotLike(String value) {
            addCriterion("cod_zona_dir1 not like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1In(List<String> values) {
            addCriterion("cod_zona_dir1 in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotIn(List<String> values) {
            addCriterion("cod_zona_dir1 not in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Between(String value1, String value2) {
            addCriterion("cod_zona_dir1 between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir1 not between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1IsNull() {
            addCriterion("nom_zona_dir1 is null");
            return this;
        }

        public Criteria andNomZonaDir1IsNotNull() {
            addCriterion("nom_zona_dir1 is not null");
            return this;
        }

        public Criteria andNomZonaDir1EqualTo(String value) {
            addCriterion("nom_zona_dir1 =", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotEqualTo(String value) {
            addCriterion("nom_zona_dir1 <>", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThan(String value) {
            addCriterion("nom_zona_dir1 >", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 >=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThan(String value) {
            addCriterion("nom_zona_dir1 <", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 <=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Like(String value) {
            addCriterion("nom_zona_dir1 like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotLike(String value) {
            addCriterion("nom_zona_dir1 not like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1In(List<String> values) {
            addCriterion("nom_zona_dir1 in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotIn(List<String> values) {
            addCriterion("nom_zona_dir1 not in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Between(String value1, String value2) {
            addCriterion("nom_zona_dir1 between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir1 not between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andDesReferDir1IsNull() {
            addCriterion("des_refer_dir1 is null");
            return this;
        }

        public Criteria andDesReferDir1IsNotNull() {
            addCriterion("des_refer_dir1 is not null");
            return this;
        }

        public Criteria andDesReferDir1EqualTo(String value) {
            addCriterion("des_refer_dir1 =", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotEqualTo(String value) {
            addCriterion("des_refer_dir1 <>", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThan(String value) {
            addCriterion("des_refer_dir1 >", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 >=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThan(String value) {
            addCriterion("des_refer_dir1 <", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 <=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Like(String value) {
            addCriterion("des_refer_dir1 like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotLike(String value) {
            addCriterion("des_refer_dir1 not like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1In(List<String> values) {
            addCriterion("des_refer_dir1 in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotIn(List<String> values) {
            addCriterion("des_refer_dir1 not in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Between(String value1, String value2) {
            addCriterion("des_refer_dir1 between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotBetween(String value1, String value2) {
            addCriterion("des_refer_dir1 not between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNull() {
            addCriterion("cod_ubigeo_dir1 is null");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNotNull() {
            addCriterion("cod_ubigeo_dir1 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir1EqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 =", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <>", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir1 >", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 >=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThan(String value) {
            addCriterion("cod_ubigeo_dir1 <", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Like(String value) {
            addCriterion("cod_ubigeo_dir1 like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotLike(String value) {
            addCriterion("cod_ubigeo_dir1 not like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1In(List<String> values) {
            addCriterion("cod_ubigeo_dir1 in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir1 not in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 not between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodViaDir2IsNull() {
            addCriterion("cod_via_dir2 is null");
            return this;
        }

        public Criteria andCodViaDir2IsNotNull() {
            addCriterion("cod_via_dir2 is not null");
            return this;
        }

        public Criteria andCodViaDir2EqualTo(String value) {
            addCriterion("cod_via_dir2 =", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotEqualTo(String value) {
            addCriterion("cod_via_dir2 <>", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThan(String value) {
            addCriterion("cod_via_dir2 >", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 >=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThan(String value) {
            addCriterion("cod_via_dir2 <", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 <=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Like(String value) {
            addCriterion("cod_via_dir2 like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotLike(String value) {
            addCriterion("cod_via_dir2 not like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2In(List<String> values) {
            addCriterion("cod_via_dir2 in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotIn(List<String> values) {
            addCriterion("cod_via_dir2 not in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Between(String value1, String value2) {
            addCriterion("cod_via_dir2 between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir2 not between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andNomViaDir2IsNull() {
            addCriterion("nom_via_dir2 is null");
            return this;
        }

        public Criteria andNomViaDir2IsNotNull() {
            addCriterion("nom_via_dir2 is not null");
            return this;
        }

        public Criteria andNomViaDir2EqualTo(String value) {
            addCriterion("nom_via_dir2 =", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotEqualTo(String value) {
            addCriterion("nom_via_dir2 <>", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThan(String value) {
            addCriterion("nom_via_dir2 >", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 >=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThan(String value) {
            addCriterion("nom_via_dir2 <", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 <=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Like(String value) {
            addCriterion("nom_via_dir2 like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotLike(String value) {
            addCriterion("nom_via_dir2 not like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2In(List<String> values) {
            addCriterion("nom_via_dir2 in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotIn(List<String> values) {
            addCriterion("nom_via_dir2 not in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Between(String value1, String value2) {
            addCriterion("nom_via_dir2 between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir2 not between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNumViaDir2IsNull() {
            addCriterion("num_via_dir2 is null");
            return this;
        }

        public Criteria andNumViaDir2IsNotNull() {
            addCriterion("num_via_dir2 is not null");
            return this;
        }

        public Criteria andNumViaDir2EqualTo(String value) {
            addCriterion("num_via_dir2 =", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotEqualTo(String value) {
            addCriterion("num_via_dir2 <>", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThan(String value) {
            addCriterion("num_via_dir2 >", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 >=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThan(String value) {
            addCriterion("num_via_dir2 <", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 <=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Like(String value) {
            addCriterion("num_via_dir2 like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotLike(String value) {
            addCriterion("num_via_dir2 not like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2In(List<String> values) {
            addCriterion("num_via_dir2 in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotIn(List<String> values) {
            addCriterion("num_via_dir2 not in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Between(String value1, String value2) {
            addCriterion("num_via_dir2 between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotBetween(String value1, String value2) {
            addCriterion("num_via_dir2 not between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumDepaDir2IsNull() {
            addCriterion("num_depa_dir2 is null");
            return this;
        }

        public Criteria andNumDepaDir2IsNotNull() {
            addCriterion("num_depa_dir2 is not null");
            return this;
        }

        public Criteria andNumDepaDir2EqualTo(String value) {
            addCriterion("num_depa_dir2 =", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotEqualTo(String value) {
            addCriterion("num_depa_dir2 <>", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThan(String value) {
            addCriterion("num_depa_dir2 >", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 >=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThan(String value) {
            addCriterion("num_depa_dir2 <", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 <=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Like(String value) {
            addCriterion("num_depa_dir2 like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotLike(String value) {
            addCriterion("num_depa_dir2 not like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2In(List<String> values) {
            addCriterion("num_depa_dir2 in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotIn(List<String> values) {
            addCriterion("num_depa_dir2 not in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Between(String value1, String value2) {
            addCriterion("num_depa_dir2 between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir2 not between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumInteriorDir2IsNull() {
            addCriterion("num_interior_dir2 is null");
            return this;
        }

        public Criteria andNumInteriorDir2IsNotNull() {
            addCriterion("num_interior_dir2 is not null");
            return this;
        }

        public Criteria andNumInteriorDir2EqualTo(String value) {
            addCriterion("num_interior_dir2 =", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotEqualTo(String value) {
            addCriterion("num_interior_dir2 <>", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThan(String value) {
            addCriterion("num_interior_dir2 >", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 >=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThan(String value) {
            addCriterion("num_interior_dir2 <", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 <=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Like(String value) {
            addCriterion("num_interior_dir2 like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotLike(String value) {
            addCriterion("num_interior_dir2 not like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2In(List<String> values) {
            addCriterion("num_interior_dir2 in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotIn(List<String> values) {
            addCriterion("num_interior_dir2 not in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Between(String value1, String value2) {
            addCriterion("num_interior_dir2 between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir2 not between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumManzDir2IsNull() {
            addCriterion("num_manz_dir2 is null");
            return this;
        }

        public Criteria andNumManzDir2IsNotNull() {
            addCriterion("num_manz_dir2 is not null");
            return this;
        }

        public Criteria andNumManzDir2EqualTo(String value) {
            addCriterion("num_manz_dir2 =", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotEqualTo(String value) {
            addCriterion("num_manz_dir2 <>", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThan(String value) {
            addCriterion("num_manz_dir2 >", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 >=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThan(String value) {
            addCriterion("num_manz_dir2 <", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 <=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Like(String value) {
            addCriterion("num_manz_dir2 like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotLike(String value) {
            addCriterion("num_manz_dir2 not like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2In(List<String> values) {
            addCriterion("num_manz_dir2 in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotIn(List<String> values) {
            addCriterion("num_manz_dir2 not in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Between(String value1, String value2) {
            addCriterion("num_manz_dir2 between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir2 not between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumLoteDir2IsNull() {
            addCriterion("num_lote_dir2 is null");
            return this;
        }

        public Criteria andNumLoteDir2IsNotNull() {
            addCriterion("num_lote_dir2 is not null");
            return this;
        }

        public Criteria andNumLoteDir2EqualTo(String value) {
            addCriterion("num_lote_dir2 =", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotEqualTo(String value) {
            addCriterion("num_lote_dir2 <>", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThan(String value) {
            addCriterion("num_lote_dir2 >", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 >=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThan(String value) {
            addCriterion("num_lote_dir2 <", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 <=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Like(String value) {
            addCriterion("num_lote_dir2 like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotLike(String value) {
            addCriterion("num_lote_dir2 not like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2In(List<String> values) {
            addCriterion("num_lote_dir2 in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotIn(List<String> values) {
            addCriterion("num_lote_dir2 not in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Between(String value1, String value2) {
            addCriterion("num_lote_dir2 between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir2 not between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumKilomDir2IsNull() {
            addCriterion("num_kilom_dir2 is null");
            return this;
        }

        public Criteria andNumKilomDir2IsNotNull() {
            addCriterion("num_kilom_dir2 is not null");
            return this;
        }

        public Criteria andNumKilomDir2EqualTo(String value) {
            addCriterion("num_kilom_dir2 =", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotEqualTo(String value) {
            addCriterion("num_kilom_dir2 <>", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThan(String value) {
            addCriterion("num_kilom_dir2 >", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 >=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThan(String value) {
            addCriterion("num_kilom_dir2 <", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 <=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Like(String value) {
            addCriterion("num_kilom_dir2 like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotLike(String value) {
            addCriterion("num_kilom_dir2 not like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2In(List<String> values) {
            addCriterion("num_kilom_dir2 in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotIn(List<String> values) {
            addCriterion("num_kilom_dir2 not in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Between(String value1, String value2) {
            addCriterion("num_kilom_dir2 between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir2 not between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumBlockDir2IsNull() {
            addCriterion("num_block_dir2 is null");
            return this;
        }

        public Criteria andNumBlockDir2IsNotNull() {
            addCriterion("num_block_dir2 is not null");
            return this;
        }

        public Criteria andNumBlockDir2EqualTo(String value) {
            addCriterion("num_block_dir2 =", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotEqualTo(String value) {
            addCriterion("num_block_dir2 <>", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThan(String value) {
            addCriterion("num_block_dir2 >", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 >=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThan(String value) {
            addCriterion("num_block_dir2 <", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 <=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Like(String value) {
            addCriterion("num_block_dir2 like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotLike(String value) {
            addCriterion("num_block_dir2 not like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2In(List<String> values) {
            addCriterion("num_block_dir2 in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotIn(List<String> values) {
            addCriterion("num_block_dir2 not in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Between(String value1, String value2) {
            addCriterion("num_block_dir2 between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotBetween(String value1, String value2) {
            addCriterion("num_block_dir2 not between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumEtapaDir2IsNull() {
            addCriterion("num_etapa_dir2 is null");
            return this;
        }

        public Criteria andNumEtapaDir2IsNotNull() {
            addCriterion("num_etapa_dir2 is not null");
            return this;
        }

        public Criteria andNumEtapaDir2EqualTo(String value) {
            addCriterion("num_etapa_dir2 =", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotEqualTo(String value) {
            addCriterion("num_etapa_dir2 <>", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThan(String value) {
            addCriterion("num_etapa_dir2 >", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 >=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThan(String value) {
            addCriterion("num_etapa_dir2 <", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 <=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Like(String value) {
            addCriterion("num_etapa_dir2 like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotLike(String value) {
            addCriterion("num_etapa_dir2 not like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2In(List<String> values) {
            addCriterion("num_etapa_dir2 in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotIn(List<String> values) {
            addCriterion("num_etapa_dir2 not in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Between(String value1, String value2) {
            addCriterion("num_etapa_dir2 between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir2 not between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andCodZonaDir2IsNull() {
            addCriterion("cod_zona_dir2 is null");
            return this;
        }

        public Criteria andCodZonaDir2IsNotNull() {
            addCriterion("cod_zona_dir2 is not null");
            return this;
        }

        public Criteria andCodZonaDir2EqualTo(String value) {
            addCriterion("cod_zona_dir2 =", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotEqualTo(String value) {
            addCriterion("cod_zona_dir2 <>", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThan(String value) {
            addCriterion("cod_zona_dir2 >", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 >=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThan(String value) {
            addCriterion("cod_zona_dir2 <", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 <=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Like(String value) {
            addCriterion("cod_zona_dir2 like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotLike(String value) {
            addCriterion("cod_zona_dir2 not like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2In(List<String> values) {
            addCriterion("cod_zona_dir2 in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotIn(List<String> values) {
            addCriterion("cod_zona_dir2 not in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Between(String value1, String value2) {
            addCriterion("cod_zona_dir2 between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir2 not between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2IsNull() {
            addCriterion("nom_zona_dir2 is null");
            return this;
        }

        public Criteria andNomZonaDir2IsNotNull() {
            addCriterion("nom_zona_dir2 is not null");
            return this;
        }

        public Criteria andNomZonaDir2EqualTo(String value) {
            addCriterion("nom_zona_dir2 =", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotEqualTo(String value) {
            addCriterion("nom_zona_dir2 <>", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThan(String value) {
            addCriterion("nom_zona_dir2 >", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 >=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThan(String value) {
            addCriterion("nom_zona_dir2 <", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 <=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Like(String value) {
            addCriterion("nom_zona_dir2 like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotLike(String value) {
            addCriterion("nom_zona_dir2 not like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2In(List<String> values) {
            addCriterion("nom_zona_dir2 in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotIn(List<String> values) {
            addCriterion("nom_zona_dir2 not in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Between(String value1, String value2) {
            addCriterion("nom_zona_dir2 between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir2 not between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andDesReferDir2IsNull() {
            addCriterion("des_refer_dir2 is null");
            return this;
        }

        public Criteria andDesReferDir2IsNotNull() {
            addCriterion("des_refer_dir2 is not null");
            return this;
        }

        public Criteria andDesReferDir2EqualTo(String value) {
            addCriterion("des_refer_dir2 =", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotEqualTo(String value) {
            addCriterion("des_refer_dir2 <>", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2GreaterThan(String value) {
            addCriterion("des_refer_dir2 >", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2GreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir2 >=", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2LessThan(String value) {
            addCriterion("des_refer_dir2 <", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2LessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir2 <=", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2Like(String value) {
            addCriterion("des_refer_dir2 like", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotLike(String value) {
            addCriterion("des_refer_dir2 not like", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2In(List<String> values) {
            addCriterion("des_refer_dir2 in", values, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotIn(List<String> values) {
            addCriterion("des_refer_dir2 not in", values, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2Between(String value1, String value2) {
            addCriterion("des_refer_dir2 between", value1, value2, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotBetween(String value1, String value2) {
            addCriterion("des_refer_dir2 not between", value1, value2, "desReferDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNull() {
            addCriterion("cod_ubigeo_dir2 is null");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNotNull() {
            addCriterion("cod_ubigeo_dir2 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir2EqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 =", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <>", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir2 >", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 >=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThan(String value) {
            addCriterion("cod_ubigeo_dir2 <", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Like(String value) {
            addCriterion("cod_ubigeo_dir2 like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotLike(String value) {
            addCriterion("cod_ubigeo_dir2 not like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2In(List<String> values) {
            addCriterion("cod_ubigeo_dir2 in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir2 not in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 not between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andIndCentAsisIsNull() {
            addCriterion("ind_cent_asis is null");
            return this;
        }

        public Criteria andIndCentAsisIsNotNull() {
            addCriterion("ind_cent_asis is not null");
            return this;
        }

        public Criteria andIndCentAsisEqualTo(String value) {
            addCriterion("ind_cent_asis =", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotEqualTo(String value) {
            addCriterion("ind_cent_asis <>", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThan(String value) {
            addCriterion("ind_cent_asis >", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis >=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThan(String value) {
            addCriterion("ind_cent_asis <", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis <=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLike(String value) {
            addCriterion("ind_cent_asis like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotLike(String value) {
            addCriterion("ind_cent_asis not like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisIn(List<String> values) {
            addCriterion("ind_cent_asis in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotIn(List<String> values) {
            addCriterion("ind_cent_asis not in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisBetween(String value1, String value2) {
            addCriterion("ind_cent_asis between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotBetween(String value1, String value2) {
            addCriterion("ind_cent_asis not between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andEstProcesoIsNull() {
            addCriterion("est_proceso is null");
            return this;
        }

        public Criteria andEstProcesoIsNotNull() {
            addCriterion("est_proceso is not null");
            return this;
        }

        public Criteria andEstProcesoEqualTo(String value) {
            addCriterion("est_proceso =", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotEqualTo(String value) {
            addCriterion("est_proceso <>", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThan(String value) {
            addCriterion("est_proceso >", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThanOrEqualTo(String value) {
            addCriterion("est_proceso >=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThan(String value) {
            addCriterion("est_proceso <", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThanOrEqualTo(String value) {
            addCriterion("est_proceso <=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLike(String value) {
            addCriterion("est_proceso like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotLike(String value) {
            addCriterion("est_proceso not like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoIn(List<String> values) {
            addCriterion("est_proceso in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotIn(List<String> values) {
            addCriterion("est_proceso not in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoBetween(String value1, String value2) {
            addCriterion("est_proceso between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotBetween(String value1, String value2) {
            addCriterion("est_proceso not between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andAccCreacionIsNull() {
            addCriterion("acc_creacion is null");
            return this;
        }

        public Criteria andAccCreacionIsNotNull() {
            addCriterion("acc_creacion is not null");
            return this;
        }

        public Criteria andAccCreacionEqualTo(String value) {
            addCriterion("acc_creacion =", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotEqualTo(String value) {
            addCriterion("acc_creacion <>", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThan(String value) {
            addCriterion("acc_creacion >", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionGreaterThanOrEqualTo(String value) {
            addCriterion("acc_creacion >=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThan(String value) {
            addCriterion("acc_creacion <", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLessThanOrEqualTo(String value) {
            addCriterion("acc_creacion <=", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionLike(String value) {
            addCriterion("acc_creacion like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotLike(String value) {
            addCriterion("acc_creacion not like", value, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionIn(List<String> values) {
            addCriterion("acc_creacion in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotIn(List<String> values) {
            addCriterion("acc_creacion not in", values, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionBetween(String value1, String value2) {
            addCriterion("acc_creacion between", value1, value2, "accCreacion");
            return this;
        }

        public Criteria andAccCreacionNotBetween(String value1, String value2) {
            addCriterion("acc_creacion not between", value1, value2, "accCreacion");
            return this;
        }
    }
}