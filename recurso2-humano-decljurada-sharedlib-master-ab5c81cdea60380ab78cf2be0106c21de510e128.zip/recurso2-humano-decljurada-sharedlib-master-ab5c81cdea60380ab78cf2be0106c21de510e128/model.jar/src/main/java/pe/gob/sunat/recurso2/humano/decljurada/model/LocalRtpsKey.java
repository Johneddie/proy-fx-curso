package pe.gob.sunat.recurso2.humano.decljurada.model;

public class LocalRtpsKey {
    private Short sprCorrel;

    private String sprNumruc;

    public Short getSprCorrel() {
        return sprCorrel;
    }

    public void setSprCorrel(Short sprCorrel) {
        this.sprCorrel = sprCorrel;
    }

    public String getSprNumruc() {
        return sprNumruc;
    }

    public void setSprNumruc(String sprNumruc) {
        this.sprNumruc = sprNumruc == null ? null : sprNumruc.trim();
    }
}