package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Estructura24Example {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public Estructura24Example() {
        oredCriteria = new ArrayList<>();
    }

    protected Estructura24Example(Estructura24Example example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andFecProcesoIsNull() {
            addCriterion("fec_proceso is null");
            return this;
        }

        public Criteria andFecProcesoIsNotNull() {
            addCriterion("fec_proceso is not null");
            return this;
        }

        public Criteria andFecProcesoEqualTo(Date value) {
            addCriterion("fec_proceso =", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotEqualTo(Date value) {
            addCriterion("fec_proceso <>", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThan(Date value) {
            addCriterion("fec_proceso >", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_proceso >=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThan(Date value) {
            addCriterion("fec_proceso <", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoLessThanOrEqualTo(Date value) {
            addCriterion("fec_proceso <=", value, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoIn(List<Date> values) {
            addCriterion("fec_proceso in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotIn(List<Date> values) {
            addCriterion("fec_proceso not in", values, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoBetween(Date value1, Date value2) {
            addCriterion("fec_proceso between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andFecProcesoNotBetween(Date value1, Date value2) {
            addCriterion("fec_proceso not between", value1, value2, "fecProceso");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodDocumDerIsNull() {
            addCriterion("cod_docum_der is null");
            return this;
        }

        public Criteria andCodDocumDerIsNotNull() {
            addCriterion("cod_docum_der is not null");
            return this;
        }

        public Criteria andCodDocumDerEqualTo(String value) {
            addCriterion("cod_docum_der =", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotEqualTo(String value) {
            addCriterion("cod_docum_der <>", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerGreaterThan(String value) {
            addCriterion("cod_docum_der >", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum_der >=", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLessThan(String value) {
            addCriterion("cod_docum_der <", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLessThanOrEqualTo(String value) {
            addCriterion("cod_docum_der <=", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerLike(String value) {
            addCriterion("cod_docum_der like", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotLike(String value) {
            addCriterion("cod_docum_der not like", value, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerIn(List<String> values) {
            addCriterion("cod_docum_der in", values, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotIn(List<String> values) {
            addCriterion("cod_docum_der not in", values, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerBetween(String value1, String value2) {
            addCriterion("cod_docum_der between", value1, value2, "codDocumDer");
            return this;
        }

        public Criteria andCodDocumDerNotBetween(String value1, String value2) {
            addCriterion("cod_docum_der not between", value1, value2, "codDocumDer");
            return this;
        }

        public Criteria andNumDocumDerIsNull() {
            addCriterion("num_docum_der is null");
            return this;
        }

        public Criteria andNumDocumDerIsNotNull() {
            addCriterion("num_docum_der is not null");
            return this;
        }

        public Criteria andNumDocumDerEqualTo(String value) {
            addCriterion("num_docum_der =", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotEqualTo(String value) {
            addCriterion("num_docum_der <>", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerGreaterThan(String value) {
            addCriterion("num_docum_der >", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum_der >=", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLessThan(String value) {
            addCriterion("num_docum_der <", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLessThanOrEqualTo(String value) {
            addCriterion("num_docum_der <=", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerLike(String value) {
            addCriterion("num_docum_der like", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotLike(String value) {
            addCriterion("num_docum_der not like", value, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerIn(List<String> values) {
            addCriterion("num_docum_der in", values, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotIn(List<String> values) {
            addCriterion("num_docum_der not in", values, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerBetween(String value1, String value2) {
            addCriterion("num_docum_der between", value1, value2, "numDocumDer");
            return this;
        }

        public Criteria andNumDocumDerNotBetween(String value1, String value2) {
            addCriterion("num_docum_der not between", value1, value2, "numDocumDer");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andFecNacimientoDerIsNull() {
            addCriterion("fec_nacimiento_der is null");
            return this;
        }

        public Criteria andFecNacimientoDerIsNotNull() {
            addCriterion("fec_nacimiento_der is not null");
            return this;
        }

        public Criteria andFecNacimientoDerEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der =", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der <>", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der >", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der >=", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerLessThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der <", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento_der <=", value, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento_der in", values, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento_der not in", values, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento_der between", value1, value2, "fecNacimientoDer");
            return this;
        }

        public Criteria andFecNacimientoDerNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento_der not between", value1, value2, "fecNacimientoDer");
            return this;
        }

        public Criteria andApePatDerIsNull() {
            addCriterion("ape_pat_der is null");
            return this;
        }

        public Criteria andApePatDerIsNotNull() {
            addCriterion("ape_pat_der is not null");
            return this;
        }

        public Criteria andApePatDerEqualTo(String value) {
            addCriterion("ape_pat_der =", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotEqualTo(String value) {
            addCriterion("ape_pat_der <>", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerGreaterThan(String value) {
            addCriterion("ape_pat_der >", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerGreaterThanOrEqualTo(String value) {
            addCriterion("ape_pat_der >=", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLessThan(String value) {
            addCriterion("ape_pat_der <", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLessThanOrEqualTo(String value) {
            addCriterion("ape_pat_der <=", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerLike(String value) {
            addCriterion("ape_pat_der like", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotLike(String value) {
            addCriterion("ape_pat_der not like", value, "apePatDer");
            return this;
        }

        public Criteria andApePatDerIn(List<String> values) {
            addCriterion("ape_pat_der in", values, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotIn(List<String> values) {
            addCriterion("ape_pat_der not in", values, "apePatDer");
            return this;
        }

        public Criteria andApePatDerBetween(String value1, String value2) {
            addCriterion("ape_pat_der between", value1, value2, "apePatDer");
            return this;
        }

        public Criteria andApePatDerNotBetween(String value1, String value2) {
            addCriterion("ape_pat_der not between", value1, value2, "apePatDer");
            return this;
        }

        public Criteria andApeMatDerIsNull() {
            addCriterion("ape_mat_der is null");
            return this;
        }

        public Criteria andApeMatDerIsNotNull() {
            addCriterion("ape_mat_der is not null");
            return this;
        }

        public Criteria andApeMatDerEqualTo(String value) {
            addCriterion("ape_mat_der =", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotEqualTo(String value) {
            addCriterion("ape_mat_der <>", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerGreaterThan(String value) {
            addCriterion("ape_mat_der >", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerGreaterThanOrEqualTo(String value) {
            addCriterion("ape_mat_der >=", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLessThan(String value) {
            addCriterion("ape_mat_der <", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLessThanOrEqualTo(String value) {
            addCriterion("ape_mat_der <=", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerLike(String value) {
            addCriterion("ape_mat_der like", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotLike(String value) {
            addCriterion("ape_mat_der not like", value, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerIn(List<String> values) {
            addCriterion("ape_mat_der in", values, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotIn(List<String> values) {
            addCriterion("ape_mat_der not in", values, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerBetween(String value1, String value2) {
            addCriterion("ape_mat_der between", value1, value2, "apeMatDer");
            return this;
        }

        public Criteria andApeMatDerNotBetween(String value1, String value2) {
            addCriterion("ape_mat_der not between", value1, value2, "apeMatDer");
            return this;
        }

        public Criteria andNomDerIsNull() {
            addCriterion("nom_der is null");
            return this;
        }

        public Criteria andNomDerIsNotNull() {
            addCriterion("nom_der is not null");
            return this;
        }

        public Criteria andNomDerEqualTo(String value) {
            addCriterion("nom_der =", value, "nomDer");
            return this;
        }

        public Criteria andNomDerNotEqualTo(String value) {
            addCriterion("nom_der <>", value, "nomDer");
            return this;
        }

        public Criteria andNomDerGreaterThan(String value) {
            addCriterion("nom_der >", value, "nomDer");
            return this;
        }

        public Criteria andNomDerGreaterThanOrEqualTo(String value) {
            addCriterion("nom_der >=", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLessThan(String value) {
            addCriterion("nom_der <", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLessThanOrEqualTo(String value) {
            addCriterion("nom_der <=", value, "nomDer");
            return this;
        }

        public Criteria andNomDerLike(String value) {
            addCriterion("nom_der like", value, "nomDer");
            return this;
        }

        public Criteria andNomDerNotLike(String value) {
            addCriterion("nom_der not like", value, "nomDer");
            return this;
        }

        public Criteria andNomDerIn(List<String> values) {
            addCriterion("nom_der in", values, "nomDer");
            return this;
        }

        public Criteria andNomDerNotIn(List<String> values) {
            addCriterion("nom_der not in", values, "nomDer");
            return this;
        }

        public Criteria andNomDerBetween(String value1, String value2) {
            addCriterion("nom_der between", value1, value2, "nomDer");
            return this;
        }

        public Criteria andNomDerNotBetween(String value1, String value2) {
            addCriterion("nom_der not between", value1, value2, "nomDer");
            return this;
        }

        public Criteria andCodVinFamIsNull() {
            addCriterion("cod_vin_fam is null");
            return this;
        }

        public Criteria andCodVinFamIsNotNull() {
            addCriterion("cod_vin_fam is not null");
            return this;
        }

        public Criteria andCodVinFamEqualTo(String value) {
            addCriterion("cod_vin_fam =", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotEqualTo(String value) {
            addCriterion("cod_vin_fam <>", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamGreaterThan(String value) {
            addCriterion("cod_vin_fam >", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamGreaterThanOrEqualTo(String value) {
            addCriterion("cod_vin_fam >=", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLessThan(String value) {
            addCriterion("cod_vin_fam <", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLessThanOrEqualTo(String value) {
            addCriterion("cod_vin_fam <=", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamLike(String value) {
            addCriterion("cod_vin_fam like", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotLike(String value) {
            addCriterion("cod_vin_fam not like", value, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamIn(List<String> values) {
            addCriterion("cod_vin_fam in", values, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotIn(List<String> values) {
            addCriterion("cod_vin_fam not in", values, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamBetween(String value1, String value2) {
            addCriterion("cod_vin_fam between", value1, value2, "codVinFam");
            return this;
        }

        public Criteria andCodVinFamNotBetween(String value1, String value2) {
            addCriterion("cod_vin_fam not between", value1, value2, "codVinFam");
            return this;
        }

        public Criteria andFecBajaIsNull() {
            addCriterion("fec_baja is null");
            return this;
        }

        public Criteria andFecBajaIsNotNull() {
            addCriterion("fec_baja is not null");
            return this;
        }

        public Criteria andFecBajaEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja =", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja <>", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_baja >", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja >=", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaLessThan(Date value) {
            addCriterionForJDBCDate("fec_baja <", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_baja <=", value, "fecBaja");
            return this;
        }

        public Criteria andFecBajaIn(List<Date> values) {
            addCriterionForJDBCDate("fec_baja in", values, "fecBaja");
            return this;
        }

        public Criteria andFecBajaNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_baja not in", values, "fecBaja");
            return this;
        }

        public Criteria andFecBajaBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_baja between", value1, value2, "fecBaja");
            return this;
        }

        public Criteria andFecBajaNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_baja not between", value1, value2, "fecBaja");
            return this;
        }

        public Criteria andCodBajaIsNull() {
            addCriterion("cod_baja is null");
            return this;
        }

        public Criteria andCodBajaIsNotNull() {
            addCriterion("cod_baja is not null");
            return this;
        }

        public Criteria andCodBajaEqualTo(String value) {
            addCriterion("cod_baja =", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotEqualTo(String value) {
            addCriterion("cod_baja <>", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaGreaterThan(String value) {
            addCriterion("cod_baja >", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_baja >=", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaLessThan(String value) {
            addCriterion("cod_baja <", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaLessThanOrEqualTo(String value) {
            addCriterion("cod_baja <=", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaLike(String value) {
            addCriterion("cod_baja like", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotLike(String value) {
            addCriterion("cod_baja not like", value, "codBaja");
            return this;
        }

        public Criteria andCodBajaIn(List<String> values) {
            addCriterion("cod_baja in", values, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotIn(List<String> values) {
            addCriterion("cod_baja not in", values, "codBaja");
            return this;
        }

        public Criteria andCodBajaBetween(String value1, String value2) {
            addCriterion("cod_baja between", value1, value2, "codBaja");
            return this;
        }

        public Criteria andCodBajaNotBetween(String value1, String value2) {
            addCriterion("cod_baja not between", value1, value2, "codBaja");
            return this;
        }

        public Criteria andEstProcesoIsNull() {
            addCriterion("est_proceso is null");
            return this;
        }

        public Criteria andEstProcesoIsNotNull() {
            addCriterion("est_proceso is not null");
            return this;
        }

        public Criteria andEstProcesoEqualTo(String value) {
            addCriterion("est_proceso =", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotEqualTo(String value) {
            addCriterion("est_proceso <>", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThan(String value) {
            addCriterion("est_proceso >", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoGreaterThanOrEqualTo(String value) {
            addCriterion("est_proceso >=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThan(String value) {
            addCriterion("est_proceso <", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLessThanOrEqualTo(String value) {
            addCriterion("est_proceso <=", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoLike(String value) {
            addCriterion("est_proceso like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotLike(String value) {
            addCriterion("est_proceso not like", value, "estProceso");
            return this;
        }

        public Criteria andEstProcesoIn(List<String> values) {
            addCriterion("est_proceso in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotIn(List<String> values) {
            addCriterion("est_proceso not in", values, "estProceso");
            return this;
        }

        public Criteria andEstProcesoBetween(String value1, String value2) {
            addCriterion("est_proceso between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andEstProcesoNotBetween(String value1, String value2) {
            addCriterion("est_proceso not between", value1, value2, "estProceso");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }
    }
}