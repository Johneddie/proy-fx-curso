package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Estructura24 {
    private Date fecProceso;

    private String codDocum;

    private String numDocum;

    private String codDocumDer;

    private String numDocumDer;

    private String codPaisEmiDoc;

    private Date fecNacimientoDer;

    private String apePatDer;

    private String apeMatDer;

    private String nomDer;

    private String codVinFam;

    private Date fecBaja;

    private String codBaja;

    private String estProceso;

    private Date fecCreacion;

    public Date getFecProceso() {
        return fecProceso;
    }

    public void setFecProceso(Date fecProceso) {
        this.fecProceso = fecProceso;
    }

    public String getCodDocum() {
        return codDocum;
    }

    public void setCodDocum(String codDocum) {
        this.codDocum = codDocum == null ? null : codDocum.trim();
    }

    public String getNumDocum() {
        return numDocum;
    }

    public void setNumDocum(String numDocum) {
        this.numDocum = numDocum == null ? null : numDocum.trim();
    }

    public String getCodDocumDer() {
        return codDocumDer;
    }

    public void setCodDocumDer(String codDocumDer) {
        this.codDocumDer = codDocumDer == null ? null : codDocumDer.trim();
    }

    public String getNumDocumDer() {
        return numDocumDer;
    }

    public void setNumDocumDer(String numDocumDer) {
        this.numDocumDer = numDocumDer == null ? null : numDocumDer.trim();
    }

    public String getCodPaisEmiDoc() {
        return codPaisEmiDoc;
    }

    public void setCodPaisEmiDoc(String codPaisEmiDoc) {
        this.codPaisEmiDoc = codPaisEmiDoc == null ? null : codPaisEmiDoc.trim();
    }

    public Date getFecNacimientoDer() {
        return fecNacimientoDer;
    }

    public void setFecNacimientoDer(Date fecNacimientoDer) {
        this.fecNacimientoDer = fecNacimientoDer;
    }

    public String getApePatDer() {
        return apePatDer;
    }

    public void setApePatDer(String apePatDer) {
        this.apePatDer = apePatDer == null ? null : apePatDer.trim();
    }

    public String getApeMatDer() {
        return apeMatDer;
    }

    public void setApeMatDer(String apeMatDer) {
        this.apeMatDer = apeMatDer == null ? null : apeMatDer.trim();
    }

    public String getNomDer() {
        return nomDer;
    }

    public void setNomDer(String nomDer) {
        this.nomDer = nomDer == null ? null : nomDer.trim();
    }

    public String getCodVinFam() {
        return codVinFam;
    }

    public void setCodVinFam(String codVinFam) {
        this.codVinFam = codVinFam == null ? null : codVinFam.trim();
    }

    public Date getFecBaja() {
        return fecBaja;
    }

    public void setFecBaja(Date fecBaja) {
        this.fecBaja = fecBaja;
    }

    public String getCodBaja() {
        return codBaja;
    }

    public void setCodBaja(String codBaja) {
        this.codBaja = codBaja == null ? null : codBaja.trim();
    }

    public String getEstProceso() {
        return estProceso;
    }

    public void setEstProceso(String estProceso) {
        this.estProceso = estProceso == null ? null : estProceso.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }
}