package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class PersonaRtps extends PersonaRtpsKey {
    private String desApepatPnat;

    private String desApematPnat;

    private String desNombrePnat;

    private Date fecNacPnat;

    private String tipEstcivPnat;

    private String tipSexoPnat;

    private String desDomiciPnat;

    private Date fecFallPnat;

    private String codUbigeoPnat;

    private String numTelefoPnat;

    private String indProcedPnat;

    private Date fecActPnat;

    private String claNombre1;

    private String claNombre2;

    private String claNombre3;

    private String claNombre4;

    private String claDirec1;

    private String claDirec2;

    private String claDirec3;

    private String numPaqActualiza;

    private String indNovedad;

    private String codUserna;

    private Date fecAct;

    private String indVerifica;

    private String desApeCasada;

    private String indInstruccion;

    private String codUbigeoDom;

    private String codUbigeoNac;

    private String codDocidePadre;

    private String numDocidePadre;

    private String desNombrePadre;

    private String codDocideMadre;

    private String numDocideMadre;

    private String desNombreMadre;

    private Date fecInscripcion;

    private Date fecExpedicion;

    private String indVotacion;

    private String indRestriccion;

    private Date fecCaducidad;

    private String codVia;

    private String desVia;

    private String numVia;

    private String numBlock;

    private String numInterior;

    private String desZona;

    private String numEtapa;

    private String numManzana;

    private String numLote;

    private String codBlock;

    private String codInterior;

    private String codZona;

    public String getDesApepatPnat() {
        return desApepatPnat;
    }

    public void setDesApepatPnat(String desApepatPnat) {
        this.desApepatPnat = desApepatPnat == null ? null : desApepatPnat.trim();
    }

    public String getDesApematPnat() {
        return desApematPnat;
    }

    public void setDesApematPnat(String desApematPnat) {
        this.desApematPnat = desApematPnat == null ? null : desApematPnat.trim();
    }

    public String getDesNombrePnat() {
        return desNombrePnat;
    }

    public void setDesNombrePnat(String desNombrePnat) {
        this.desNombrePnat = desNombrePnat == null ? null : desNombrePnat.trim();
    }

    public Date getFecNacPnat() {
        return fecNacPnat;
    }

    public void setFecNacPnat(Date fecNacPnat) {
        this.fecNacPnat = fecNacPnat;
    }

    public String getTipEstcivPnat() {
        return tipEstcivPnat;
    }

    public void setTipEstcivPnat(String tipEstcivPnat) {
        this.tipEstcivPnat = tipEstcivPnat == null ? null : tipEstcivPnat.trim();
    }

    public String getTipSexoPnat() {
        return tipSexoPnat;
    }

    public void setTipSexoPnat(String tipSexoPnat) {
        this.tipSexoPnat = tipSexoPnat == null ? null : tipSexoPnat.trim();
    }

    public String getDesDomiciPnat() {
        return desDomiciPnat;
    }

    public void setDesDomiciPnat(String desDomiciPnat) {
        this.desDomiciPnat = desDomiciPnat == null ? null : desDomiciPnat.trim();
    }

    public Date getFecFallPnat() {
        return fecFallPnat;
    }

    public void setFecFallPnat(Date fecFallPnat) {
        this.fecFallPnat = fecFallPnat;
    }

    public String getCodUbigeoPnat() {
        return codUbigeoPnat;
    }

    public void setCodUbigeoPnat(String codUbigeoPnat) {
        this.codUbigeoPnat = codUbigeoPnat == null ? null : codUbigeoPnat.trim();
    }

    public String getNumTelefoPnat() {
        return numTelefoPnat;
    }

    public void setNumTelefoPnat(String numTelefoPnat) {
        this.numTelefoPnat = numTelefoPnat == null ? null : numTelefoPnat.trim();
    }

    public String getIndProcedPnat() {
        return indProcedPnat;
    }

    public void setIndProcedPnat(String indProcedPnat) {
        this.indProcedPnat = indProcedPnat == null ? null : indProcedPnat.trim();
    }

    public Date getFecActPnat() {
        return fecActPnat;
    }

    public void setFecActPnat(Date fecActPnat) {
        this.fecActPnat = fecActPnat;
    }

    public String getClaNombre1() {
        return claNombre1;
    }

    public void setClaNombre1(String claNombre1) {
        this.claNombre1 = claNombre1 == null ? null : claNombre1.trim();
    }

    public String getClaNombre2() {
        return claNombre2;
    }

    public void setClaNombre2(String claNombre2) {
        this.claNombre2 = claNombre2 == null ? null : claNombre2.trim();
    }

    public String getClaNombre3() {
        return claNombre3;
    }

    public void setClaNombre3(String claNombre3) {
        this.claNombre3 = claNombre3 == null ? null : claNombre3.trim();
    }

    public String getClaNombre4() {
        return claNombre4;
    }

    public void setClaNombre4(String claNombre4) {
        this.claNombre4 = claNombre4 == null ? null : claNombre4.trim();
    }

    public String getClaDirec1() {
        return claDirec1;
    }

    public void setClaDirec1(String claDirec1) {
        this.claDirec1 = claDirec1 == null ? null : claDirec1.trim();
    }

    public String getClaDirec2() {
        return claDirec2;
    }

    public void setClaDirec2(String claDirec2) {
        this.claDirec2 = claDirec2 == null ? null : claDirec2.trim();
    }

    public String getClaDirec3() {
        return claDirec3;
    }

    public void setClaDirec3(String claDirec3) {
        this.claDirec3 = claDirec3 == null ? null : claDirec3.trim();
    }

    public String getNumPaqActualiza() {
        return numPaqActualiza;
    }

    public void setNumPaqActualiza(String numPaqActualiza) {
        this.numPaqActualiza = numPaqActualiza == null ? null : numPaqActualiza.trim();
    }

    public String getIndNovedad() {
        return indNovedad;
    }

    public void setIndNovedad(String indNovedad) {
        this.indNovedad = indNovedad == null ? null : indNovedad.trim();
    }

    public String getCodUserna() {
        return codUserna;
    }

    public void setCodUserna(String codUserna) {
        this.codUserna = codUserna == null ? null : codUserna.trim();
    }

    public Date getFecAct() {
        return fecAct;
    }

    public void setFecAct(Date fecAct) {
        this.fecAct = fecAct;
    }

    public String getIndVerifica() {
        return indVerifica;
    }

    public void setIndVerifica(String indVerifica) {
        this.indVerifica = indVerifica == null ? null : indVerifica.trim();
    }

    public String getDesApeCasada() {
        return desApeCasada;
    }

    public void setDesApeCasada(String desApeCasada) {
        this.desApeCasada = desApeCasada == null ? null : desApeCasada.trim();
    }

    public String getIndInstruccion() {
        return indInstruccion;
    }

    public void setIndInstruccion(String indInstruccion) {
        this.indInstruccion = indInstruccion == null ? null : indInstruccion.trim();
    }

    public String getCodUbigeoDom() {
        return codUbigeoDom;
    }

    public void setCodUbigeoDom(String codUbigeoDom) {
        this.codUbigeoDom = codUbigeoDom == null ? null : codUbigeoDom.trim();
    }

    public String getCodUbigeoNac() {
        return codUbigeoNac;
    }

    public void setCodUbigeoNac(String codUbigeoNac) {
        this.codUbigeoNac = codUbigeoNac == null ? null : codUbigeoNac.trim();
    }

    public String getCodDocidePadre() {
        return codDocidePadre;
    }

    public void setCodDocidePadre(String codDocidePadre) {
        this.codDocidePadre = codDocidePadre == null ? null : codDocidePadre.trim();
    }

    public String getNumDocidePadre() {
        return numDocidePadre;
    }

    public void setNumDocidePadre(String numDocidePadre) {
        this.numDocidePadre = numDocidePadre == null ? null : numDocidePadre.trim();
    }

    public String getDesNombrePadre() {
        return desNombrePadre;
    }

    public void setDesNombrePadre(String desNombrePadre) {
        this.desNombrePadre = desNombrePadre == null ? null : desNombrePadre.trim();
    }

    public String getCodDocideMadre() {
        return codDocideMadre;
    }

    public void setCodDocideMadre(String codDocideMadre) {
        this.codDocideMadre = codDocideMadre == null ? null : codDocideMadre.trim();
    }

    public String getNumDocideMadre() {
        return numDocideMadre;
    }

    public void setNumDocideMadre(String numDocideMadre) {
        this.numDocideMadre = numDocideMadre == null ? null : numDocideMadre.trim();
    }

    public String getDesNombreMadre() {
        return desNombreMadre;
    }

    public void setDesNombreMadre(String desNombreMadre) {
        this.desNombreMadre = desNombreMadre == null ? null : desNombreMadre.trim();
    }

    public Date getFecInscripcion() {
        return fecInscripcion;
    }

    public void setFecInscripcion(Date fecInscripcion) {
        this.fecInscripcion = fecInscripcion;
    }

    public Date getFecExpedicion() {
        return fecExpedicion;
    }

    public void setFecExpedicion(Date fecExpedicion) {
        this.fecExpedicion = fecExpedicion;
    }

    public String getIndVotacion() {
        return indVotacion;
    }

    public void setIndVotacion(String indVotacion) {
        this.indVotacion = indVotacion == null ? null : indVotacion.trim();
    }

    public String getIndRestriccion() {
        return indRestriccion;
    }

    public void setIndRestriccion(String indRestriccion) {
        this.indRestriccion = indRestriccion == null ? null : indRestriccion.trim();
    }

    public Date getFecCaducidad() {
        return fecCaducidad;
    }

    public void setFecCaducidad(Date fecCaducidad) {
        this.fecCaducidad = fecCaducidad;
    }

    public String getCodVia() {
        return codVia;
    }

    public void setCodVia(String codVia) {
        this.codVia = codVia == null ? null : codVia.trim();
    }

    public String getDesVia() {
        return desVia;
    }

    public void setDesVia(String desVia) {
        this.desVia = desVia == null ? null : desVia.trim();
    }

    public String getNumVia() {
        return numVia;
    }

    public void setNumVia(String numVia) {
        this.numVia = numVia == null ? null : numVia.trim();
    }

    public String getNumBlock() {
        return numBlock;
    }

    public void setNumBlock(String numBlock) {
        this.numBlock = numBlock == null ? null : numBlock.trim();
    }

    public String getNumInterior() {
        return numInterior;
    }

    public void setNumInterior(String numInterior) {
        this.numInterior = numInterior == null ? null : numInterior.trim();
    }

    public String getDesZona() {
        return desZona;
    }

    public void setDesZona(String desZona) {
        this.desZona = desZona == null ? null : desZona.trim();
    }

    public String getNumEtapa() {
        return numEtapa;
    }

    public void setNumEtapa(String numEtapa) {
        this.numEtapa = numEtapa == null ? null : numEtapa.trim();
    }

    public String getNumManzana() {
        return numManzana;
    }

    public void setNumManzana(String numManzana) {
        this.numManzana = numManzana == null ? null : numManzana.trim();
    }

    public String getNumLote() {
        return numLote;
    }

    public void setNumLote(String numLote) {
        this.numLote = numLote == null ? null : numLote.trim();
    }

    public String getCodBlock() {
        return codBlock;
    }

    public void setCodBlock(String codBlock) {
        this.codBlock = codBlock == null ? null : codBlock.trim();
    }

    public String getCodInterior() {
        return codInterior;
    }

    public void setCodInterior(String codInterior) {
        this.codInterior = codInterior == null ? null : codInterior.trim();
    }

    public String getCodZona() {
        return codZona;
    }

    public void setCodZona(String codZona) {
        this.codZona = codZona == null ? null : codZona.trim();
    }
}