package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Telefono {
    private String t28codPers;

    private String t28tipTel;

    private String t28numDdn;

    private String t28numTel;

    private String t28numAne;

    private Date t28fGraba;

    private String t28codUser;

    public String getT28codPers() {
        return t28codPers;
    }

    public void setT28codPers(String t28codPers) {
        this.t28codPers = t28codPers == null ? null : t28codPers.trim();
    }

    public String getT28tipTel() {
        return t28tipTel;
    }

    public void setT28tipTel(String t28tipTel) {
        this.t28tipTel = t28tipTel == null ? null : t28tipTel.trim();
    }

    public String getT28numDdn() {
        return t28numDdn;
    }

    public void setT28numDdn(String t28numDdn) {
        this.t28numDdn = t28numDdn == null ? null : t28numDdn.trim();
    }

    public String getT28numTel() {
        return t28numTel;
    }

    public void setT28numTel(String t28numTel) {
        this.t28numTel = t28numTel == null ? null : t28numTel.trim();
    }

    public String getT28numAne() {
        return t28numAne;
    }

    public void setT28numAne(String t28numAne) {
        this.t28numAne = t28numAne == null ? null : t28numAne.trim();
    }

    public Date getT28fGraba() {
        return t28fGraba;
    }

    public void setT28fGraba(Date t28fGraba) {
        this.t28fGraba = t28fGraba;
    }

    public String getT28codUser() {
        return t28codUser;
    }

    public void setT28codUser(String t28codUser) {
        this.t28codUser = t28codUser == null ? null : t28codUser.trim();
    }
}