package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Temporal extends TemporalKey {
    private Integer numDdjjAnt;

    private String codUsucrea;

    private Date fecCreacion;

    private String codUsumodif;

    private Date fecModif;

    public Integer getNumDdjjAnt() {
        return numDdjjAnt;
    }

    public void setNumDdjjAnt(Integer numDdjjAnt) {
        this.numDdjjAnt = numDdjjAnt;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }
}