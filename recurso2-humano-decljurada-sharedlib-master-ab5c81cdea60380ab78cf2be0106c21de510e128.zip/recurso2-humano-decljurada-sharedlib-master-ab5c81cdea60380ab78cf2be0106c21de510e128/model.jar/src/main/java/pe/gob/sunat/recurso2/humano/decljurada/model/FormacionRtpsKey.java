package pe.gob.sunat.recurso2.humano.decljurada.model;

public class FormacionRtpsKey {
    private String annDdjj;

    private Short numCorrel;

    private Integer numDdjj;

    public String getAnnDdjj() {
        return annDdjj;
    }

    public void setAnnDdjj(String annDdjj) {
        this.annDdjj = annDdjj == null ? null : annDdjj.trim();
    }

    public Short getNumCorrel() {
        return numCorrel;
    }

    public void setNumCorrel(Short numCorrel) {
        this.numCorrel = numCorrel;
    }

    public Integer getNumDdjj() {
        return numDdjj;
    }

    public void setNumDdjj(Integer numDdjj) {
        this.numDdjj = numDdjj;
    }
}