package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelefonoEmplExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public TelefonoEmplExample() {
        oredCriteria = new ArrayList<>();
    }

    protected TelefonoEmplExample(TelefonoEmplExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodPersIsNull() {
            addCriterion("cod_pers is null");
            return this;
        }

        public Criteria andCodPersIsNotNull() {
            addCriterion("cod_pers is not null");
            return this;
        }

        public Criteria andCodPersEqualTo(String value) {
            addCriterion("cod_pers =", value, "codPers");
            return this;
        }

        public Criteria andCodPersNotEqualTo(String value) {
            addCriterion("cod_pers <>", value, "codPers");
            return this;
        }

        public Criteria andCodPersGreaterThan(String value) {
            addCriterion("cod_pers >", value, "codPers");
            return this;
        }

        public Criteria andCodPersGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pers >=", value, "codPers");
            return this;
        }

        public Criteria andCodPersLessThan(String value) {
            addCriterion("cod_pers <", value, "codPers");
            return this;
        }

        public Criteria andCodPersLessThanOrEqualTo(String value) {
            addCriterion("cod_pers <=", value, "codPers");
            return this;
        }

        public Criteria andCodPersLike(String value) {
            addCriterion("cod_pers like", value, "codPers");
            return this;
        }

        public Criteria andCodPersNotLike(String value) {
            addCriterion("cod_pers not like", value, "codPers");
            return this;
        }

        public Criteria andCodPersIn(List<String> values) {
            addCriterion("cod_pers in", values, "codPers");
            return this;
        }

        public Criteria andCodPersNotIn(List<String> values) {
            addCriterion("cod_pers not in", values, "codPers");
            return this;
        }

        public Criteria andCodPersBetween(String value1, String value2) {
            addCriterion("cod_pers between", value1, value2, "codPers");
            return this;
        }

        public Criteria andCodPersNotBetween(String value1, String value2) {
            addCriterion("cod_pers not between", value1, value2, "codPers");
            return this;
        }

        public Criteria andNumeroIsNull() {
            addCriterion("numero is null");
            return this;
        }

        public Criteria andNumeroIsNotNull() {
            addCriterion("numero is not null");
            return this;
        }

        public Criteria andNumeroEqualTo(String value) {
            addCriterion("numero =", value, "numero");
            return this;
        }

        public Criteria andNumeroNotEqualTo(String value) {
            addCriterion("numero <>", value, "numero");
            return this;
        }

        public Criteria andNumeroGreaterThan(String value) {
            addCriterion("numero >", value, "numero");
            return this;
        }

        public Criteria andNumeroGreaterThanOrEqualTo(String value) {
            addCriterion("numero >=", value, "numero");
            return this;
        }

        public Criteria andNumeroLessThan(String value) {
            addCriterion("numero <", value, "numero");
            return this;
        }

        public Criteria andNumeroLessThanOrEqualTo(String value) {
            addCriterion("numero <=", value, "numero");
            return this;
        }

        public Criteria andNumeroLike(String value) {
            addCriterion("numero like", value, "numero");
            return this;
        }

        public Criteria andNumeroNotLike(String value) {
            addCriterion("numero not like", value, "numero");
            return this;
        }

        public Criteria andNumeroIn(List<String> values) {
            addCriterion("numero in", values, "numero");
            return this;
        }

        public Criteria andNumeroNotIn(List<String> values) {
            addCriterion("numero not in", values, "numero");
            return this;
        }

        public Criteria andNumeroBetween(String value1, String value2) {
            addCriterion("numero between", value1, value2, "numero");
            return this;
        }

        public Criteria andNumeroNotBetween(String value1, String value2) {
            addCriterion("numero not between", value1, value2, "numero");
            return this;
        }

        public Criteria andTipLineaIsNull() {
            addCriterion("tip_linea is null");
            return this;
        }

        public Criteria andTipLineaIsNotNull() {
            addCriterion("tip_linea is not null");
            return this;
        }

        public Criteria andTipLineaEqualTo(String value) {
            addCriterion("tip_linea =", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaNotEqualTo(String value) {
            addCriterion("tip_linea <>", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaGreaterThan(String value) {
            addCriterion("tip_linea >", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaGreaterThanOrEqualTo(String value) {
            addCriterion("tip_linea >=", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaLessThan(String value) {
            addCriterion("tip_linea <", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaLessThanOrEqualTo(String value) {
            addCriterion("tip_linea <=", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaLike(String value) {
            addCriterion("tip_linea like", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaNotLike(String value) {
            addCriterion("tip_linea not like", value, "tipLinea");
            return this;
        }

        public Criteria andTipLineaIn(List<String> values) {
            addCriterion("tip_linea in", values, "tipLinea");
            return this;
        }

        public Criteria andTipLineaNotIn(List<String> values) {
            addCriterion("tip_linea not in", values, "tipLinea");
            return this;
        }

        public Criteria andTipLineaBetween(String value1, String value2) {
            addCriterion("tip_linea between", value1, value2, "tipLinea");
            return this;
        }

        public Criteria andTipLineaNotBetween(String value1, String value2) {
            addCriterion("tip_linea not between", value1, value2, "tipLinea");
            return this;
        }

        public Criteria andCodUorganIsNull() {
            addCriterion("cod_uorgan is null");
            return this;
        }

        public Criteria andCodUorganIsNotNull() {
            addCriterion("cod_uorgan is not null");
            return this;
        }

        public Criteria andCodUorganEqualTo(String value) {
            addCriterion("cod_uorgan =", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotEqualTo(String value) {
            addCriterion("cod_uorgan <>", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThan(String value) {
            addCriterion("cod_uorgan >", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThanOrEqualTo(String value) {
            addCriterion("cod_uorgan >=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThan(String value) {
            addCriterion("cod_uorgan <", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThanOrEqualTo(String value) {
            addCriterion("cod_uorgan <=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLike(String value) {
            addCriterion("cod_uorgan like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotLike(String value) {
            addCriterion("cod_uorgan not like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganIn(List<String> values) {
            addCriterion("cod_uorgan in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotIn(List<String> values) {
            addCriterion("cod_uorgan not in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganBetween(String value1, String value2) {
            addCriterion("cod_uorgan between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotBetween(String value1, String value2) {
            addCriterion("cod_uorgan not between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andCodLocalIsNull() {
            addCriterion("cod_local is null");
            return this;
        }

        public Criteria andCodLocalIsNotNull() {
            addCriterion("cod_local is not null");
            return this;
        }

        public Criteria andCodLocalEqualTo(String value) {
            addCriterion("cod_local =", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalNotEqualTo(String value) {
            addCriterion("cod_local <>", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalGreaterThan(String value) {
            addCriterion("cod_local >", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalGreaterThanOrEqualTo(String value) {
            addCriterion("cod_local >=", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalLessThan(String value) {
            addCriterion("cod_local <", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalLessThanOrEqualTo(String value) {
            addCriterion("cod_local <=", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalLike(String value) {
            addCriterion("cod_local like", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalNotLike(String value) {
            addCriterion("cod_local not like", value, "codLocal");
            return this;
        }

        public Criteria andCodLocalIn(List<String> values) {
            addCriterion("cod_local in", values, "codLocal");
            return this;
        }

        public Criteria andCodLocalNotIn(List<String> values) {
            addCriterion("cod_local not in", values, "codLocal");
            return this;
        }

        public Criteria andCodLocalBetween(String value1, String value2) {
            addCriterion("cod_local between", value1, value2, "codLocal");
            return this;
        }

        public Criteria andCodLocalNotBetween(String value1, String value2) {
            addCriterion("cod_local not between", value1, value2, "codLocal");
            return this;
        }

        public Criteria andPisoIsNull() {
            addCriterion("piso is null");
            return this;
        }

        public Criteria andPisoIsNotNull() {
            addCriterion("piso is not null");
            return this;
        }

        public Criteria andPisoEqualTo(String value) {
            addCriterion("piso =", value, "piso");
            return this;
        }

        public Criteria andPisoNotEqualTo(String value) {
            addCriterion("piso <>", value, "piso");
            return this;
        }

        public Criteria andPisoGreaterThan(String value) {
            addCriterion("piso >", value, "piso");
            return this;
        }

        public Criteria andPisoGreaterThanOrEqualTo(String value) {
            addCriterion("piso >=", value, "piso");
            return this;
        }

        public Criteria andPisoLessThan(String value) {
            addCriterion("piso <", value, "piso");
            return this;
        }

        public Criteria andPisoLessThanOrEqualTo(String value) {
            addCriterion("piso <=", value, "piso");
            return this;
        }

        public Criteria andPisoLike(String value) {
            addCriterion("piso like", value, "piso");
            return this;
        }

        public Criteria andPisoNotLike(String value) {
            addCriterion("piso not like", value, "piso");
            return this;
        }

        public Criteria andPisoIn(List<String> values) {
            addCriterion("piso in", values, "piso");
            return this;
        }

        public Criteria andPisoNotIn(List<String> values) {
            addCriterion("piso not in", values, "piso");
            return this;
        }

        public Criteria andPisoBetween(String value1, String value2) {
            addCriterion("piso between", value1, value2, "piso");
            return this;
        }

        public Criteria andPisoNotBetween(String value1, String value2) {
            addCriterion("piso not between", value1, value2, "piso");
            return this;
        }
    }
}