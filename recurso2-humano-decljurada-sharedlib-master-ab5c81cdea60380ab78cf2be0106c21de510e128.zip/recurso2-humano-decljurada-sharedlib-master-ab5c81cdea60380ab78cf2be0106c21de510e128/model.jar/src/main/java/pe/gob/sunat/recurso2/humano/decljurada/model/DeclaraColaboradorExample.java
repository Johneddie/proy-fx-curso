package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DeclaraColaboradorExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public DeclaraColaboradorExample() {
        oredCriteria = new ArrayList<>();
    }

    protected DeclaraColaboradorExample(DeclaraColaboradorExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.isEmpty()) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
    	return new Criteria();
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<>();
            criteriaWithSingleValue = new ArrayList<>();
            criteriaWithListValue = new ArrayList<>();
            criteriaWithBetweenValue = new ArrayList<>();
        }

        public boolean isValid() {
            return !criteriaWithoutValue.isEmpty()
                || !criteriaWithSingleValue.isEmpty()
                || !criteriaWithListValue.isEmpty()
                || !criteriaWithBetweenValue.isEmpty();
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new IllegalArgumentException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new IllegalArgumentException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.isEmpty()) {
                throw new IllegalArgumentException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new IllegalArgumentException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andAnnDdjjIsNull() {
            addCriterion("ann_ddjj is null");
            return this;
        }

        public Criteria andAnnDdjjIsNotNull() {
            addCriterion("ann_ddjj is not null");
            return this;
        }

        public Criteria andAnnDdjjEqualTo(String value) {
            addCriterion("ann_ddjj =", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotEqualTo(String value) {
            addCriterion("ann_ddjj <>", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThan(String value) {
            addCriterion("ann_ddjj >", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjGreaterThanOrEqualTo(String value) {
            addCriterion("ann_ddjj >=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThan(String value) {
            addCriterion("ann_ddjj <", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLessThanOrEqualTo(String value) {
            addCriterion("ann_ddjj <=", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjLike(String value) {
            addCriterion("ann_ddjj like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotLike(String value) {
            addCriterion("ann_ddjj not like", value, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjIn(List<String> values) {
            addCriterion("ann_ddjj in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotIn(List<String> values) {
            addCriterion("ann_ddjj not in", values, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjBetween(String value1, String value2) {
            addCriterion("ann_ddjj between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andAnnDdjjNotBetween(String value1, String value2) {
            addCriterion("ann_ddjj not between", value1, value2, "annDdjj");
            return this;
        }

        public Criteria andIndEstadoIsNull() {
            addCriterion("ind_estado is null");
            return this;
        }

        public Criteria andIndEstadoIsNotNull() {
            addCriterion("ind_estado is not null");
            return this;
        }

        public Criteria andIndEstadoEqualTo(String value) {
            addCriterion("ind_estado =", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotEqualTo(String value) {
            addCriterion("ind_estado <>", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoGreaterThan(String value) {
            addCriterion("ind_estado >", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_estado >=", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLessThan(String value) {
            addCriterion("ind_estado <", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLessThanOrEqualTo(String value) {
            addCriterion("ind_estado <=", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoLike(String value) {
            addCriterion("ind_estado like", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotLike(String value) {
            addCriterion("ind_estado not like", value, "indEstado");
            return this;
        }

        public Criteria andIndEstadoIn(List<String> values) {
            addCriterion("ind_estado in", values, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotIn(List<String> values) {
            addCriterion("ind_estado not in", values, "indEstado");
            return this;
        }

        public Criteria andIndEstadoBetween(String value1, String value2) {
            addCriterion("ind_estado between", value1, value2, "indEstado");
            return this;
        }

        public Criteria andIndEstadoNotBetween(String value1, String value2) {
            addCriterion("ind_estado not between", value1, value2, "indEstado");
            return this;
        }

        public Criteria andNumDdjjIsNull() {
            addCriterion("num_ddjj is null");
            return this;
        }

        public Criteria andNumDdjjIsNotNull() {
            addCriterion("num_ddjj is not null");
            return this;
        }

        public Criteria andNumDdjjEqualTo(Integer value) {
            addCriterion("num_ddjj =", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotEqualTo(Integer value) {
            addCriterion("num_ddjj <>", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThan(Integer value) {
            addCriterion("num_ddjj >", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj >=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThan(Integer value) {
            addCriterion("num_ddjj <", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjLessThanOrEqualTo(Integer value) {
            addCriterion("num_ddjj <=", value, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjIn(List<Integer> values) {
            addCriterion("num_ddjj in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotIn(List<Integer> values) {
            addCriterion("num_ddjj not in", values, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andNumDdjjNotBetween(Integer value1, Integer value2) {
            addCriterion("num_ddjj not between", value1, value2, "numDdjj");
            return this;
        }

        public Criteria andCodPersonalIsNull() {
            addCriterion("cod_personal is null");
            return this;
        }

        public Criteria andCodPersonalIsNotNull() {
            addCriterion("cod_personal is not null");
            return this;
        }

        public Criteria andCodPersonalEqualTo(String value) {
            addCriterion("cod_personal =", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotEqualTo(String value) {
            addCriterion("cod_personal <>", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThan(String value) {
            addCriterion("cod_personal >", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThanOrEqualTo(String value) {
            addCriterion("cod_personal >=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThan(String value) {
            addCriterion("cod_personal <", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThanOrEqualTo(String value) {
            addCriterion("cod_personal <=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLike(String value) {
            addCriterion("cod_personal like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotLike(String value) {
            addCriterion("cod_personal not like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalIn(List<String> values) {
            addCriterion("cod_personal in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotIn(List<String> values) {
            addCriterion("cod_personal not in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalBetween(String value1, String value2) {
            addCriterion("cod_personal between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotBetween(String value1, String value2) {
            addCriterion("cod_personal not between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andCodUorganIsNull() {
            addCriterion("cod_uorgan is null");
            return this;
        }

        public Criteria andCodUorganIsNotNull() {
            addCriterion("cod_uorgan is not null");
            return this;
        }

        public Criteria andCodUorganEqualTo(String value) {
            addCriterion("cod_uorgan =", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotEqualTo(String value) {
            addCriterion("cod_uorgan <>", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThan(String value) {
            addCriterion("cod_uorgan >", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganGreaterThanOrEqualTo(String value) {
            addCriterion("cod_uorgan >=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThan(String value) {
            addCriterion("cod_uorgan <", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLessThanOrEqualTo(String value) {
            addCriterion("cod_uorgan <=", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganLike(String value) {
            addCriterion("cod_uorgan like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotLike(String value) {
            addCriterion("cod_uorgan not like", value, "codUorgan");
            return this;
        }

        public Criteria andCodUorganIn(List<String> values) {
            addCriterion("cod_uorgan in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotIn(List<String> values) {
            addCriterion("cod_uorgan not in", values, "codUorgan");
            return this;
        }

        public Criteria andCodUorganBetween(String value1, String value2) {
            addCriterion("cod_uorgan between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andCodUorganNotBetween(String value1, String value2) {
            addCriterion("cod_uorgan not between", value1, value2, "codUorgan");
            return this;
        }

        public Criteria andCodDocumIsNull() {
            addCriterion("cod_docum is null");
            return this;
        }

        public Criteria andCodDocumIsNotNull() {
            addCriterion("cod_docum is not null");
            return this;
        }

        public Criteria andCodDocumEqualTo(String value) {
            addCriterion("cod_docum =", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotEqualTo(String value) {
            addCriterion("cod_docum <>", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThan(String value) {
            addCriterion("cod_docum >", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumGreaterThanOrEqualTo(String value) {
            addCriterion("cod_docum >=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThan(String value) {
            addCriterion("cod_docum <", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLessThanOrEqualTo(String value) {
            addCriterion("cod_docum <=", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumLike(String value) {
            addCriterion("cod_docum like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotLike(String value) {
            addCriterion("cod_docum not like", value, "codDocum");
            return this;
        }

        public Criteria andCodDocumIn(List<String> values) {
            addCriterion("cod_docum in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotIn(List<String> values) {
            addCriterion("cod_docum not in", values, "codDocum");
            return this;
        }

        public Criteria andCodDocumBetween(String value1, String value2) {
            addCriterion("cod_docum between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andCodDocumNotBetween(String value1, String value2) {
            addCriterion("cod_docum not between", value1, value2, "codDocum");
            return this;
        }

        public Criteria andNumDocumIsNull() {
            addCriterion("num_docum is null");
            return this;
        }

        public Criteria andNumDocumIsNotNull() {
            addCriterion("num_docum is not null");
            return this;
        }

        public Criteria andNumDocumEqualTo(String value) {
            addCriterion("num_docum =", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotEqualTo(String value) {
            addCriterion("num_docum <>", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThan(String value) {
            addCriterion("num_docum >", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumGreaterThanOrEqualTo(String value) {
            addCriterion("num_docum >=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThan(String value) {
            addCriterion("num_docum <", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLessThanOrEqualTo(String value) {
            addCriterion("num_docum <=", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumLike(String value) {
            addCriterion("num_docum like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotLike(String value) {
            addCriterion("num_docum not like", value, "numDocum");
            return this;
        }

        public Criteria andNumDocumIn(List<String> values) {
            addCriterion("num_docum in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotIn(List<String> values) {
            addCriterion("num_docum not in", values, "numDocum");
            return this;
        }

        public Criteria andNumDocumBetween(String value1, String value2) {
            addCriterion("num_docum between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andNumDocumNotBetween(String value1, String value2) {
            addCriterion("num_docum not between", value1, value2, "numDocum");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNull() {
            addCriterion("cod_pais_emi_doc is null");
            return this;
        }

        public Criteria andCodPaisEmiDocIsNotNull() {
            addCriterion("cod_pais_emi_doc is not null");
            return this;
        }

        public Criteria andCodPaisEmiDocEqualTo(String value) {
            addCriterion("cod_pais_emi_doc =", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <>", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThan(String value) {
            addCriterion("cod_pais_emi_doc >", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc >=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThan(String value) {
            addCriterion("cod_pais_emi_doc <", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_emi_doc <=", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocLike(String value) {
            addCriterion("cod_pais_emi_doc like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotLike(String value) {
            addCriterion("cod_pais_emi_doc not like", value, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocIn(List<String> values) {
            addCriterion("cod_pais_emi_doc in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotIn(List<String> values) {
            addCriterion("cod_pais_emi_doc not in", values, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andCodPaisEmiDocNotBetween(String value1, String value2) {
            addCriterion("cod_pais_emi_doc not between", value1, value2, "codPaisEmiDoc");
            return this;
        }

        public Criteria andFecNacimientoIsNull() {
            addCriterion("fec_nacimiento is null");
            return this;
        }

        public Criteria andFecNacimientoIsNotNull() {
            addCriterion("fec_nacimiento is not null");
            return this;
        }

        public Criteria andFecNacimientoEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento =", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento <>", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoGreaterThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento >", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento >=", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoLessThan(Date value) {
            addCriterionForJDBCDate("fec_nacimiento <", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("fec_nacimiento <=", value, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento in", values, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotIn(List<Date> values) {
            addCriterionForJDBCDate("fec_nacimiento not in", values, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento between", value1, value2, "fecNacimiento");
            return this;
        }

        public Criteria andFecNacimientoNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("fec_nacimiento not between", value1, value2, "fecNacimiento");
            return this;
        }

        public Criteria andApePatIsNull() {
            addCriterion("ape_pat is null");
            return this;
        }

        public Criteria andApePatIsNotNull() {
            addCriterion("ape_pat is not null");
            return this;
        }

        public Criteria andApePatEqualTo(String value) {
            addCriterion("ape_pat =", value, "apePat");
            return this;
        }

        public Criteria andApePatNotEqualTo(String value) {
            addCriterion("ape_pat <>", value, "apePat");
            return this;
        }

        public Criteria andApePatGreaterThan(String value) {
            addCriterion("ape_pat >", value, "apePat");
            return this;
        }

        public Criteria andApePatGreaterThanOrEqualTo(String value) {
            addCriterion("ape_pat >=", value, "apePat");
            return this;
        }

        public Criteria andApePatLessThan(String value) {
            addCriterion("ape_pat <", value, "apePat");
            return this;
        }

        public Criteria andApePatLessThanOrEqualTo(String value) {
            addCriterion("ape_pat <=", value, "apePat");
            return this;
        }

        public Criteria andApePatLike(String value) {
            addCriterion("ape_pat like", value, "apePat");
            return this;
        }

        public Criteria andApePatNotLike(String value) {
            addCriterion("ape_pat not like", value, "apePat");
            return this;
        }

        public Criteria andApePatIn(List<String> values) {
            addCriterion("ape_pat in", values, "apePat");
            return this;
        }

        public Criteria andApePatNotIn(List<String> values) {
            addCriterion("ape_pat not in", values, "apePat");
            return this;
        }

        public Criteria andApePatBetween(String value1, String value2) {
            addCriterion("ape_pat between", value1, value2, "apePat");
            return this;
        }

        public Criteria andApePatNotBetween(String value1, String value2) {
            addCriterion("ape_pat not between", value1, value2, "apePat");
            return this;
        }

        public Criteria andApeMatIsNull() {
            addCriterion("ape_mat is null");
            return this;
        }

        public Criteria andApeMatIsNotNull() {
            addCriterion("ape_mat is not null");
            return this;
        }

        public Criteria andApeMatEqualTo(String value) {
            addCriterion("ape_mat =", value, "apeMat");
            return this;
        }

        public Criteria andApeMatNotEqualTo(String value) {
            addCriterion("ape_mat <>", value, "apeMat");
            return this;
        }

        public Criteria andApeMatGreaterThan(String value) {
            addCriterion("ape_mat >", value, "apeMat");
            return this;
        }

        public Criteria andApeMatGreaterThanOrEqualTo(String value) {
            addCriterion("ape_mat >=", value, "apeMat");
            return this;
        }

        public Criteria andApeMatLessThan(String value) {
            addCriterion("ape_mat <", value, "apeMat");
            return this;
        }

        public Criteria andApeMatLessThanOrEqualTo(String value) {
            addCriterion("ape_mat <=", value, "apeMat");
            return this;
        }

        public Criteria andApeMatLike(String value) {
            addCriterion("ape_mat like", value, "apeMat");
            return this;
        }

        public Criteria andApeMatNotLike(String value) {
            addCriterion("ape_mat not like", value, "apeMat");
            return this;
        }

        public Criteria andApeMatIn(List<String> values) {
            addCriterion("ape_mat in", values, "apeMat");
            return this;
        }

        public Criteria andApeMatNotIn(List<String> values) {
            addCriterion("ape_mat not in", values, "apeMat");
            return this;
        }

        public Criteria andApeMatBetween(String value1, String value2) {
            addCriterion("ape_mat between", value1, value2, "apeMat");
            return this;
        }

        public Criteria andApeMatNotBetween(String value1, String value2) {
            addCriterion("ape_mat not between", value1, value2, "apeMat");
            return this;
        }

        public Criteria andNomPersonalIsNull() {
            addCriterion("nom_personal is null");
            return this;
        }

        public Criteria andNomPersonalIsNotNull() {
            addCriterion("nom_personal is not null");
            return this;
        }

        public Criteria andNomPersonalEqualTo(String value) {
            addCriterion("nom_personal =", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotEqualTo(String value) {
            addCriterion("nom_personal <>", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalGreaterThan(String value) {
            addCriterion("nom_personal >", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalGreaterThanOrEqualTo(String value) {
            addCriterion("nom_personal >=", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalLessThan(String value) {
            addCriterion("nom_personal <", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalLessThanOrEqualTo(String value) {
            addCriterion("nom_personal <=", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalLike(String value) {
            addCriterion("nom_personal like", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotLike(String value) {
            addCriterion("nom_personal not like", value, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalIn(List<String> values) {
            addCriterion("nom_personal in", values, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotIn(List<String> values) {
            addCriterion("nom_personal not in", values, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalBetween(String value1, String value2) {
            addCriterion("nom_personal between", value1, value2, "nomPersonal");
            return this;
        }

        public Criteria andNomPersonalNotBetween(String value1, String value2) {
            addCriterion("nom_personal not between", value1, value2, "nomPersonal");
            return this;
        }

        public Criteria andIndSexoIsNull() {
            addCriterion("ind_sexo is null");
            return this;
        }

        public Criteria andIndSexoIsNotNull() {
            addCriterion("ind_sexo is not null");
            return this;
        }

        public Criteria andIndSexoEqualTo(String value) {
            addCriterion("ind_sexo =", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotEqualTo(String value) {
            addCriterion("ind_sexo <>", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoGreaterThan(String value) {
            addCriterion("ind_sexo >", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoGreaterThanOrEqualTo(String value) {
            addCriterion("ind_sexo >=", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLessThan(String value) {
            addCriterion("ind_sexo <", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLessThanOrEqualTo(String value) {
            addCriterion("ind_sexo <=", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoLike(String value) {
            addCriterion("ind_sexo like", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotLike(String value) {
            addCriterion("ind_sexo not like", value, "indSexo");
            return this;
        }

        public Criteria andIndSexoIn(List<String> values) {
            addCriterion("ind_sexo in", values, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotIn(List<String> values) {
            addCriterion("ind_sexo not in", values, "indSexo");
            return this;
        }

        public Criteria andIndSexoBetween(String value1, String value2) {
            addCriterion("ind_sexo between", value1, value2, "indSexo");
            return this;
        }

        public Criteria andIndSexoNotBetween(String value1, String value2) {
            addCriterion("ind_sexo not between", value1, value2, "indSexo");
            return this;
        }

        public Criteria andCodNacionalidadIsNull() {
            addCriterion("cod_nacionalidad is null");
            return this;
        }

        public Criteria andCodNacionalidadIsNotNull() {
            addCriterion("cod_nacionalidad is not null");
            return this;
        }

        public Criteria andCodNacionalidadEqualTo(String value) {
            addCriterion("cod_nacionalidad =", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotEqualTo(String value) {
            addCriterion("cod_nacionalidad <>", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadGreaterThan(String value) {
            addCriterion("cod_nacionalidad >", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadGreaterThanOrEqualTo(String value) {
            addCriterion("cod_nacionalidad >=", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadLessThan(String value) {
            addCriterion("cod_nacionalidad <", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadLessThanOrEqualTo(String value) {
            addCriterion("cod_nacionalidad <=", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadLike(String value) {
            addCriterion("cod_nacionalidad like", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotLike(String value) {
            addCriterion("cod_nacionalidad not like", value, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadIn(List<String> values) {
            addCriterion("cod_nacionalidad in", values, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotIn(List<String> values) {
            addCriterion("cod_nacionalidad not in", values, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadBetween(String value1, String value2) {
            addCriterion("cod_nacionalidad between", value1, value2, "codNacionalidad");
            return this;
        }

        public Criteria andCodNacionalidadNotBetween(String value1, String value2) {
            addCriterion("cod_nacionalidad not between", value1, value2, "codNacionalidad");
            return this;
        }

        public Criteria andCodUbigeoNacIsNull() {
            addCriterion("cod_ubigeo_nac is null");
            return this;
        }

        public Criteria andCodUbigeoNacIsNotNull() {
            addCriterion("cod_ubigeo_nac is not null");
            return this;
        }

        public Criteria andCodUbigeoNacEqualTo(String value) {
            addCriterion("cod_ubigeo_nac =", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotEqualTo(String value) {
            addCriterion("cod_ubigeo_nac <>", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacGreaterThan(String value) {
            addCriterion("cod_ubigeo_nac >", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_nac >=", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacLessThan(String value) {
            addCriterion("cod_ubigeo_nac <", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacLessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_nac <=", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacLike(String value) {
            addCriterion("cod_ubigeo_nac like", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotLike(String value) {
            addCriterion("cod_ubigeo_nac not like", value, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacIn(List<String> values) {
            addCriterion("cod_ubigeo_nac in", values, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotIn(List<String> values) {
            addCriterion("cod_ubigeo_nac not in", values, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_nac between", value1, value2, "codUbigeoNac");
            return this;
        }

        public Criteria andCodUbigeoNacNotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_nac not between", value1, value2, "codUbigeoNac");
            return this;
        }

        public Criteria andIndEstCivilIsNull() {
            addCriterion("ind_est_civil is null");
            return this;
        }

        public Criteria andIndEstCivilIsNotNull() {
            addCriterion("ind_est_civil is not null");
            return this;
        }

        public Criteria andIndEstCivilEqualTo(String value) {
            addCriterion("ind_est_civil =", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilNotEqualTo(String value) {
            addCriterion("ind_est_civil <>", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilGreaterThan(String value) {
            addCriterion("ind_est_civil >", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilGreaterThanOrEqualTo(String value) {
            addCriterion("ind_est_civil >=", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilLessThan(String value) {
            addCriterion("ind_est_civil <", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilLessThanOrEqualTo(String value) {
            addCriterion("ind_est_civil <=", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilLike(String value) {
            addCriterion("ind_est_civil like", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilNotLike(String value) {
            addCriterion("ind_est_civil not like", value, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilIn(List<String> values) {
            addCriterion("ind_est_civil in", values, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilNotIn(List<String> values) {
            addCriterion("ind_est_civil not in", values, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilBetween(String value1, String value2) {
            addCriterion("ind_est_civil between", value1, value2, "indEstCivil");
            return this;
        }

        public Criteria andIndEstCivilNotBetween(String value1, String value2) {
            addCriterion("ind_est_civil not between", value1, value2, "indEstCivil");
            return this;
        }

        public Criteria andCodSedeLabIsNull() {
            addCriterion("cod_sede_lab is null");
            return this;
        }

        public Criteria andCodSedeLabIsNotNull() {
            addCriterion("cod_sede_lab is not null");
            return this;
        }

        public Criteria andCodSedeLabEqualTo(String value) {
            addCriterion("cod_sede_lab =", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabNotEqualTo(String value) {
            addCriterion("cod_sede_lab <>", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabGreaterThan(String value) {
            addCriterion("cod_sede_lab >", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabGreaterThanOrEqualTo(String value) {
            addCriterion("cod_sede_lab >=", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabLessThan(String value) {
            addCriterion("cod_sede_lab <", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabLessThanOrEqualTo(String value) {
            addCriterion("cod_sede_lab <=", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabLike(String value) {
            addCriterion("cod_sede_lab like", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabNotLike(String value) {
            addCriterion("cod_sede_lab not like", value, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabIn(List<String> values) {
            addCriterion("cod_sede_lab in", values, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabNotIn(List<String> values) {
            addCriterion("cod_sede_lab not in", values, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabBetween(String value1, String value2) {
            addCriterion("cod_sede_lab between", value1, value2, "codSedeLab");
            return this;
        }

        public Criteria andCodSedeLabNotBetween(String value1, String value2) {
            addCriterion("cod_sede_lab not between", value1, value2, "codSedeLab");
            return this;
        }

        public Criteria andCodTelefLarDisIsNull() {
            addCriterion("cod_telef_lar_dis is null");
            return this;
        }

        public Criteria andCodTelefLarDisIsNotNull() {
            addCriterion("cod_telef_lar_dis is not null");
            return this;
        }

        public Criteria andCodTelefLarDisEqualTo(String value) {
            addCriterion("cod_telef_lar_dis =", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotEqualTo(String value) {
            addCriterion("cod_telef_lar_dis <>", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisGreaterThan(String value) {
            addCriterion("cod_telef_lar_dis >", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_telef_lar_dis >=", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLessThan(String value) {
            addCriterion("cod_telef_lar_dis <", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLessThanOrEqualTo(String value) {
            addCriterion("cod_telef_lar_dis <=", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisLike(String value) {
            addCriterion("cod_telef_lar_dis like", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotLike(String value) {
            addCriterion("cod_telef_lar_dis not like", value, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisIn(List<String> values) {
            addCriterion("cod_telef_lar_dis in", values, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotIn(List<String> values) {
            addCriterion("cod_telef_lar_dis not in", values, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisBetween(String value1, String value2) {
            addCriterion("cod_telef_lar_dis between", value1, value2, "codTelefLarDis");
            return this;
        }

        public Criteria andCodTelefLarDisNotBetween(String value1, String value2) {
            addCriterion("cod_telef_lar_dis not between", value1, value2, "codTelefLarDis");
            return this;
        }

        public Criteria andNumTelefIsNull() {
            addCriterion("num_telef is null");
            return this;
        }

        public Criteria andNumTelefIsNotNull() {
            addCriterion("num_telef is not null");
            return this;
        }

        public Criteria andNumTelefEqualTo(String value) {
            addCriterion("num_telef =", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotEqualTo(String value) {
            addCriterion("num_telef <>", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThan(String value) {
            addCriterion("num_telef >", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThanOrEqualTo(String value) {
            addCriterion("num_telef >=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThan(String value) {
            addCriterion("num_telef <", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThanOrEqualTo(String value) {
            addCriterion("num_telef <=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLike(String value) {
            addCriterion("num_telef like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotLike(String value) {
            addCriterion("num_telef not like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefIn(List<String> values) {
            addCriterion("num_telef in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotIn(List<String> values) {
            addCriterion("num_telef not in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefBetween(String value1, String value2) {
            addCriterion("num_telef between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotBetween(String value1, String value2) {
            addCriterion("num_telef not between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andCodCelLarDisIsNull() {
            addCriterion("cod_cel_lar_dis is null");
            return this;
        }

        public Criteria andCodCelLarDisIsNotNull() {
            addCriterion("cod_cel_lar_dis is not null");
            return this;
        }

        public Criteria andCodCelLarDisEqualTo(String value) {
            addCriterion("cod_cel_lar_dis =", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotEqualTo(String value) {
            addCriterion("cod_cel_lar_dis <>", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisGreaterThan(String value) {
            addCriterion("cod_cel_lar_dis >", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_cel_lar_dis >=", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisLessThan(String value) {
            addCriterion("cod_cel_lar_dis <", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisLessThanOrEqualTo(String value) {
            addCriterion("cod_cel_lar_dis <=", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisLike(String value) {
            addCriterion("cod_cel_lar_dis like", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotLike(String value) {
            addCriterion("cod_cel_lar_dis not like", value, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisIn(List<String> values) {
            addCriterion("cod_cel_lar_dis in", values, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotIn(List<String> values) {
            addCriterion("cod_cel_lar_dis not in", values, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisBetween(String value1, String value2) {
            addCriterion("cod_cel_lar_dis between", value1, value2, "codCelLarDis");
            return this;
        }

        public Criteria andCodCelLarDisNotBetween(String value1, String value2) {
            addCriterion("cod_cel_lar_dis not between", value1, value2, "codCelLarDis");
            return this;
        }

        public Criteria andNumCelularIsNull() {
            addCriterion("num_celular is null");
            return this;
        }

        public Criteria andNumCelularIsNotNull() {
            addCriterion("num_celular is not null");
            return this;
        }

        public Criteria andNumCelularEqualTo(String value) {
            addCriterion("num_celular =", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotEqualTo(String value) {
            addCriterion("num_celular <>", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularGreaterThan(String value) {
            addCriterion("num_celular >", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularGreaterThanOrEqualTo(String value) {
            addCriterion("num_celular >=", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLessThan(String value) {
            addCriterion("num_celular <", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLessThanOrEqualTo(String value) {
            addCriterion("num_celular <=", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularLike(String value) {
            addCriterion("num_celular like", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotLike(String value) {
            addCriterion("num_celular not like", value, "numCelular");
            return this;
        }

        public Criteria andNumCelularIn(List<String> values) {
            addCriterion("num_celular in", values, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotIn(List<String> values) {
            addCriterion("num_celular not in", values, "numCelular");
            return this;
        }

        public Criteria andNumCelularBetween(String value1, String value2) {
            addCriterion("num_celular between", value1, value2, "numCelular");
            return this;
        }

        public Criteria andNumCelularNotBetween(String value1, String value2) {
            addCriterion("num_celular not between", value1, value2, "numCelular");
            return this;
        }

        public Criteria andDesCorreoIsNull() {
            addCriterion("des_correo is null");
            return this;
        }

        public Criteria andDesCorreoIsNotNull() {
            addCriterion("des_correo is not null");
            return this;
        }

        public Criteria andDesCorreoEqualTo(String value) {
            addCriterion("des_correo =", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotEqualTo(String value) {
            addCriterion("des_correo <>", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThan(String value) {
            addCriterion("des_correo >", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThanOrEqualTo(String value) {
            addCriterion("des_correo >=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThan(String value) {
            addCriterion("des_correo <", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThanOrEqualTo(String value) {
            addCriterion("des_correo <=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLike(String value) {
            addCriterion("des_correo like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotLike(String value) {
            addCriterion("des_correo not like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoIn(List<String> values) {
            addCriterion("des_correo in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotIn(List<String> values) {
            addCriterion("des_correo not in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoBetween(String value1, String value2) {
            addCriterion("des_correo between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotBetween(String value1, String value2) {
            addCriterion("des_correo not between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andCodViaDir1IsNull() {
            addCriterion("cod_via_dir1 is null");
            return this;
        }

        public Criteria andCodViaDir1IsNotNull() {
            addCriterion("cod_via_dir1 is not null");
            return this;
        }

        public Criteria andCodViaDir1EqualTo(String value) {
            addCriterion("cod_via_dir1 =", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotEqualTo(String value) {
            addCriterion("cod_via_dir1 <>", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThan(String value) {
            addCriterion("cod_via_dir1 >", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 >=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThan(String value) {
            addCriterion("cod_via_dir1 <", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir1 <=", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Like(String value) {
            addCriterion("cod_via_dir1 like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotLike(String value) {
            addCriterion("cod_via_dir1 not like", value, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1In(List<String> values) {
            addCriterion("cod_via_dir1 in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotIn(List<String> values) {
            addCriterion("cod_via_dir1 not in", values, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1Between(String value1, String value2) {
            addCriterion("cod_via_dir1 between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andCodViaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir1 not between", value1, value2, "codViaDir1");
            return this;
        }

        public Criteria andNomViaDir1IsNull() {
            addCriterion("nom_via_dir1 is null");
            return this;
        }

        public Criteria andNomViaDir1IsNotNull() {
            addCriterion("nom_via_dir1 is not null");
            return this;
        }

        public Criteria andNomViaDir1EqualTo(String value) {
            addCriterion("nom_via_dir1 =", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotEqualTo(String value) {
            addCriterion("nom_via_dir1 <>", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThan(String value) {
            addCriterion("nom_via_dir1 >", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 >=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThan(String value) {
            addCriterion("nom_via_dir1 <", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir1 <=", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Like(String value) {
            addCriterion("nom_via_dir1 like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotLike(String value) {
            addCriterion("nom_via_dir1 not like", value, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1In(List<String> values) {
            addCriterion("nom_via_dir1 in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotIn(List<String> values) {
            addCriterion("nom_via_dir1 not in", values, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1Between(String value1, String value2) {
            addCriterion("nom_via_dir1 between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNomViaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir1 not between", value1, value2, "nomViaDir1");
            return this;
        }

        public Criteria andNumViaDir1IsNull() {
            addCriterion("num_via_dir1 is null");
            return this;
        }

        public Criteria andNumViaDir1IsNotNull() {
            addCriterion("num_via_dir1 is not null");
            return this;
        }

        public Criteria andNumViaDir1EqualTo(String value) {
            addCriterion("num_via_dir1 =", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotEqualTo(String value) {
            addCriterion("num_via_dir1 <>", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThan(String value) {
            addCriterion("num_via_dir1 >", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 >=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThan(String value) {
            addCriterion("num_via_dir1 <", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir1 <=", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Like(String value) {
            addCriterion("num_via_dir1 like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotLike(String value) {
            addCriterion("num_via_dir1 not like", value, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1In(List<String> values) {
            addCriterion("num_via_dir1 in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotIn(List<String> values) {
            addCriterion("num_via_dir1 not in", values, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1Between(String value1, String value2) {
            addCriterion("num_via_dir1 between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumViaDir1NotBetween(String value1, String value2) {
            addCriterion("num_via_dir1 not between", value1, value2, "numViaDir1");
            return this;
        }

        public Criteria andNumDepaDir1IsNull() {
            addCriterion("num_depa_dir1 is null");
            return this;
        }

        public Criteria andNumDepaDir1IsNotNull() {
            addCriterion("num_depa_dir1 is not null");
            return this;
        }

        public Criteria andNumDepaDir1EqualTo(String value) {
            addCriterion("num_depa_dir1 =", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotEqualTo(String value) {
            addCriterion("num_depa_dir1 <>", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThan(String value) {
            addCriterion("num_depa_dir1 >", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 >=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThan(String value) {
            addCriterion("num_depa_dir1 <", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir1 <=", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Like(String value) {
            addCriterion("num_depa_dir1 like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotLike(String value) {
            addCriterion("num_depa_dir1 not like", value, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1In(List<String> values) {
            addCriterion("num_depa_dir1 in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotIn(List<String> values) {
            addCriterion("num_depa_dir1 not in", values, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1Between(String value1, String value2) {
            addCriterion("num_depa_dir1 between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumDepaDir1NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir1 not between", value1, value2, "numDepaDir1");
            return this;
        }

        public Criteria andNumInteriorDir1IsNull() {
            addCriterion("num_interior_dir1 is null");
            return this;
        }

        public Criteria andNumInteriorDir1IsNotNull() {
            addCriterion("num_interior_dir1 is not null");
            return this;
        }

        public Criteria andNumInteriorDir1EqualTo(String value) {
            addCriterion("num_interior_dir1 =", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotEqualTo(String value) {
            addCriterion("num_interior_dir1 <>", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThan(String value) {
            addCriterion("num_interior_dir1 >", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 >=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThan(String value) {
            addCriterion("num_interior_dir1 <", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir1 <=", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Like(String value) {
            addCriterion("num_interior_dir1 like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotLike(String value) {
            addCriterion("num_interior_dir1 not like", value, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1In(List<String> values) {
            addCriterion("num_interior_dir1 in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotIn(List<String> values) {
            addCriterion("num_interior_dir1 not in", values, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1Between(String value1, String value2) {
            addCriterion("num_interior_dir1 between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumInteriorDir1NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir1 not between", value1, value2, "numInteriorDir1");
            return this;
        }

        public Criteria andNumManzDir1IsNull() {
            addCriterion("num_manz_dir1 is null");
            return this;
        }

        public Criteria andNumManzDir1IsNotNull() {
            addCriterion("num_manz_dir1 is not null");
            return this;
        }

        public Criteria andNumManzDir1EqualTo(String value) {
            addCriterion("num_manz_dir1 =", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotEqualTo(String value) {
            addCriterion("num_manz_dir1 <>", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThan(String value) {
            addCriterion("num_manz_dir1 >", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 >=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThan(String value) {
            addCriterion("num_manz_dir1 <", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir1 <=", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Like(String value) {
            addCriterion("num_manz_dir1 like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotLike(String value) {
            addCriterion("num_manz_dir1 not like", value, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1In(List<String> values) {
            addCriterion("num_manz_dir1 in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotIn(List<String> values) {
            addCriterion("num_manz_dir1 not in", values, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1Between(String value1, String value2) {
            addCriterion("num_manz_dir1 between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumManzDir1NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir1 not between", value1, value2, "numManzDir1");
            return this;
        }

        public Criteria andNumLoteDir1IsNull() {
            addCriterion("num_lote_dir1 is null");
            return this;
        }

        public Criteria andNumLoteDir1IsNotNull() {
            addCriterion("num_lote_dir1 is not null");
            return this;
        }

        public Criteria andNumLoteDir1EqualTo(String value) {
            addCriterion("num_lote_dir1 =", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotEqualTo(String value) {
            addCriterion("num_lote_dir1 <>", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThan(String value) {
            addCriterion("num_lote_dir1 >", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 >=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThan(String value) {
            addCriterion("num_lote_dir1 <", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir1 <=", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Like(String value) {
            addCriterion("num_lote_dir1 like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotLike(String value) {
            addCriterion("num_lote_dir1 not like", value, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1In(List<String> values) {
            addCriterion("num_lote_dir1 in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotIn(List<String> values) {
            addCriterion("num_lote_dir1 not in", values, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1Between(String value1, String value2) {
            addCriterion("num_lote_dir1 between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumLoteDir1NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir1 not between", value1, value2, "numLoteDir1");
            return this;
        }

        public Criteria andNumKilomDir1IsNull() {
            addCriterion("num_kilom_dir1 is null");
            return this;
        }

        public Criteria andNumKilomDir1IsNotNull() {
            addCriterion("num_kilom_dir1 is not null");
            return this;
        }

        public Criteria andNumKilomDir1EqualTo(String value) {
            addCriterion("num_kilom_dir1 =", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotEqualTo(String value) {
            addCriterion("num_kilom_dir1 <>", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThan(String value) {
            addCriterion("num_kilom_dir1 >", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 >=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThan(String value) {
            addCriterion("num_kilom_dir1 <", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir1 <=", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Like(String value) {
            addCriterion("num_kilom_dir1 like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotLike(String value) {
            addCriterion("num_kilom_dir1 not like", value, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1In(List<String> values) {
            addCriterion("num_kilom_dir1 in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotIn(List<String> values) {
            addCriterion("num_kilom_dir1 not in", values, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1Between(String value1, String value2) {
            addCriterion("num_kilom_dir1 between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumKilomDir1NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir1 not between", value1, value2, "numKilomDir1");
            return this;
        }

        public Criteria andNumBlockDir1IsNull() {
            addCriterion("num_block_dir1 is null");
            return this;
        }

        public Criteria andNumBlockDir1IsNotNull() {
            addCriterion("num_block_dir1 is not null");
            return this;
        }

        public Criteria andNumBlockDir1EqualTo(String value) {
            addCriterion("num_block_dir1 =", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotEqualTo(String value) {
            addCriterion("num_block_dir1 <>", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThan(String value) {
            addCriterion("num_block_dir1 >", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 >=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThan(String value) {
            addCriterion("num_block_dir1 <", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir1 <=", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Like(String value) {
            addCriterion("num_block_dir1 like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotLike(String value) {
            addCriterion("num_block_dir1 not like", value, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1In(List<String> values) {
            addCriterion("num_block_dir1 in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotIn(List<String> values) {
            addCriterion("num_block_dir1 not in", values, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1Between(String value1, String value2) {
            addCriterion("num_block_dir1 between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumBlockDir1NotBetween(String value1, String value2) {
            addCriterion("num_block_dir1 not between", value1, value2, "numBlockDir1");
            return this;
        }

        public Criteria andNumEtapaDir1IsNull() {
            addCriterion("num_etapa_dir1 is null");
            return this;
        }

        public Criteria andNumEtapaDir1IsNotNull() {
            addCriterion("num_etapa_dir1 is not null");
            return this;
        }

        public Criteria andNumEtapaDir1EqualTo(String value) {
            addCriterion("num_etapa_dir1 =", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotEqualTo(String value) {
            addCriterion("num_etapa_dir1 <>", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThan(String value) {
            addCriterion("num_etapa_dir1 >", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 >=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThan(String value) {
            addCriterion("num_etapa_dir1 <", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir1 <=", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Like(String value) {
            addCriterion("num_etapa_dir1 like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotLike(String value) {
            addCriterion("num_etapa_dir1 not like", value, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1In(List<String> values) {
            addCriterion("num_etapa_dir1 in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotIn(List<String> values) {
            addCriterion("num_etapa_dir1 not in", values, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1Between(String value1, String value2) {
            addCriterion("num_etapa_dir1 between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andNumEtapaDir1NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir1 not between", value1, value2, "numEtapaDir1");
            return this;
        }

        public Criteria andCodZonaDir1IsNull() {
            addCriterion("cod_zona_dir1 is null");
            return this;
        }

        public Criteria andCodZonaDir1IsNotNull() {
            addCriterion("cod_zona_dir1 is not null");
            return this;
        }

        public Criteria andCodZonaDir1EqualTo(String value) {
            addCriterion("cod_zona_dir1 =", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotEqualTo(String value) {
            addCriterion("cod_zona_dir1 <>", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThan(String value) {
            addCriterion("cod_zona_dir1 >", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 >=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThan(String value) {
            addCriterion("cod_zona_dir1 <", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir1 <=", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Like(String value) {
            addCriterion("cod_zona_dir1 like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotLike(String value) {
            addCriterion("cod_zona_dir1 not like", value, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1In(List<String> values) {
            addCriterion("cod_zona_dir1 in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotIn(List<String> values) {
            addCriterion("cod_zona_dir1 not in", values, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1Between(String value1, String value2) {
            addCriterion("cod_zona_dir1 between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andCodZonaDir1NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir1 not between", value1, value2, "codZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1IsNull() {
            addCriterion("nom_zona_dir1 is null");
            return this;
        }

        public Criteria andNomZonaDir1IsNotNull() {
            addCriterion("nom_zona_dir1 is not null");
            return this;
        }

        public Criteria andNomZonaDir1EqualTo(String value) {
            addCriterion("nom_zona_dir1 =", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotEqualTo(String value) {
            addCriterion("nom_zona_dir1 <>", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThan(String value) {
            addCriterion("nom_zona_dir1 >", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 >=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThan(String value) {
            addCriterion("nom_zona_dir1 <", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir1 <=", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Like(String value) {
            addCriterion("nom_zona_dir1 like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotLike(String value) {
            addCriterion("nom_zona_dir1 not like", value, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1In(List<String> values) {
            addCriterion("nom_zona_dir1 in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotIn(List<String> values) {
            addCriterion("nom_zona_dir1 not in", values, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1Between(String value1, String value2) {
            addCriterion("nom_zona_dir1 between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andNomZonaDir1NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir1 not between", value1, value2, "nomZonaDir1");
            return this;
        }

        public Criteria andDesReferDir1IsNull() {
            addCriterion("des_refer_dir1 is null");
            return this;
        }

        public Criteria andDesReferDir1IsNotNull() {
            addCriterion("des_refer_dir1 is not null");
            return this;
        }

        public Criteria andDesReferDir1EqualTo(String value) {
            addCriterion("des_refer_dir1 =", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotEqualTo(String value) {
            addCriterion("des_refer_dir1 <>", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThan(String value) {
            addCriterion("des_refer_dir1 >", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 >=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThan(String value) {
            addCriterion("des_refer_dir1 <", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1LessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir1 <=", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Like(String value) {
            addCriterion("des_refer_dir1 like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotLike(String value) {
            addCriterion("des_refer_dir1 not like", value, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1In(List<String> values) {
            addCriterion("des_refer_dir1 in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotIn(List<String> values) {
            addCriterion("des_refer_dir1 not in", values, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1Between(String value1, String value2) {
            addCriterion("des_refer_dir1 between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andDesReferDir1NotBetween(String value1, String value2) {
            addCriterion("des_refer_dir1 not between", value1, value2, "desReferDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNull() {
            addCriterion("cod_ubigeo_dir1 is null");
            return this;
        }

        public Criteria andCodUbigeoDir1IsNotNull() {
            addCriterion("cod_ubigeo_dir1 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir1EqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 =", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <>", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir1 >", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 >=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThan(String value) {
            addCriterion("cod_ubigeo_dir1 <", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir1 <=", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Like(String value) {
            addCriterion("cod_ubigeo_dir1 like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotLike(String value) {
            addCriterion("cod_ubigeo_dir1 not like", value, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1In(List<String> values) {
            addCriterion("cod_ubigeo_dir1 in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir1 not in", values, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodUbigeoDir1NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir1 not between", value1, value2, "codUbigeoDir1");
            return this;
        }

        public Criteria andCodViaDir2IsNull() {
            addCriterion("cod_via_dir2 is null");
            return this;
        }

        public Criteria andCodViaDir2IsNotNull() {
            addCriterion("cod_via_dir2 is not null");
            return this;
        }

        public Criteria andCodViaDir2EqualTo(String value) {
            addCriterion("cod_via_dir2 =", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotEqualTo(String value) {
            addCriterion("cod_via_dir2 <>", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThan(String value) {
            addCriterion("cod_via_dir2 >", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 >=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThan(String value) {
            addCriterion("cod_via_dir2 <", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_via_dir2 <=", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Like(String value) {
            addCriterion("cod_via_dir2 like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotLike(String value) {
            addCriterion("cod_via_dir2 not like", value, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2In(List<String> values) {
            addCriterion("cod_via_dir2 in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotIn(List<String> values) {
            addCriterion("cod_via_dir2 not in", values, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2Between(String value1, String value2) {
            addCriterion("cod_via_dir2 between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andCodViaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_via_dir2 not between", value1, value2, "codViaDir2");
            return this;
        }

        public Criteria andNomViaDir2IsNull() {
            addCriterion("nom_via_dir2 is null");
            return this;
        }

        public Criteria andNomViaDir2IsNotNull() {
            addCriterion("nom_via_dir2 is not null");
            return this;
        }

        public Criteria andNomViaDir2EqualTo(String value) {
            addCriterion("nom_via_dir2 =", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotEqualTo(String value) {
            addCriterion("nom_via_dir2 <>", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThan(String value) {
            addCriterion("nom_via_dir2 >", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 >=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThan(String value) {
            addCriterion("nom_via_dir2 <", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_via_dir2 <=", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Like(String value) {
            addCriterion("nom_via_dir2 like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotLike(String value) {
            addCriterion("nom_via_dir2 not like", value, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2In(List<String> values) {
            addCriterion("nom_via_dir2 in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotIn(List<String> values) {
            addCriterion("nom_via_dir2 not in", values, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2Between(String value1, String value2) {
            addCriterion("nom_via_dir2 between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNomViaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_via_dir2 not between", value1, value2, "nomViaDir2");
            return this;
        }

        public Criteria andNumViaDir2IsNull() {
            addCriterion("num_via_dir2 is null");
            return this;
        }

        public Criteria andNumViaDir2IsNotNull() {
            addCriterion("num_via_dir2 is not null");
            return this;
        }

        public Criteria andNumViaDir2EqualTo(String value) {
            addCriterion("num_via_dir2 =", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotEqualTo(String value) {
            addCriterion("num_via_dir2 <>", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThan(String value) {
            addCriterion("num_via_dir2 >", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 >=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThan(String value) {
            addCriterion("num_via_dir2 <", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_via_dir2 <=", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Like(String value) {
            addCriterion("num_via_dir2 like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotLike(String value) {
            addCriterion("num_via_dir2 not like", value, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2In(List<String> values) {
            addCriterion("num_via_dir2 in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotIn(List<String> values) {
            addCriterion("num_via_dir2 not in", values, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2Between(String value1, String value2) {
            addCriterion("num_via_dir2 between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumViaDir2NotBetween(String value1, String value2) {
            addCriterion("num_via_dir2 not between", value1, value2, "numViaDir2");
            return this;
        }

        public Criteria andNumDepaDir2IsNull() {
            addCriterion("num_depa_dir2 is null");
            return this;
        }

        public Criteria andNumDepaDir2IsNotNull() {
            addCriterion("num_depa_dir2 is not null");
            return this;
        }

        public Criteria andNumDepaDir2EqualTo(String value) {
            addCriterion("num_depa_dir2 =", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotEqualTo(String value) {
            addCriterion("num_depa_dir2 <>", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThan(String value) {
            addCriterion("num_depa_dir2 >", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 >=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThan(String value) {
            addCriterion("num_depa_dir2 <", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_depa_dir2 <=", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Like(String value) {
            addCriterion("num_depa_dir2 like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotLike(String value) {
            addCriterion("num_depa_dir2 not like", value, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2In(List<String> values) {
            addCriterion("num_depa_dir2 in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotIn(List<String> values) {
            addCriterion("num_depa_dir2 not in", values, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2Between(String value1, String value2) {
            addCriterion("num_depa_dir2 between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumDepaDir2NotBetween(String value1, String value2) {
            addCriterion("num_depa_dir2 not between", value1, value2, "numDepaDir2");
            return this;
        }

        public Criteria andNumInteriorDir2IsNull() {
            addCriterion("num_interior_dir2 is null");
            return this;
        }

        public Criteria andNumInteriorDir2IsNotNull() {
            addCriterion("num_interior_dir2 is not null");
            return this;
        }

        public Criteria andNumInteriorDir2EqualTo(String value) {
            addCriterion("num_interior_dir2 =", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotEqualTo(String value) {
            addCriterion("num_interior_dir2 <>", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThan(String value) {
            addCriterion("num_interior_dir2 >", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 >=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThan(String value) {
            addCriterion("num_interior_dir2 <", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2LessThanOrEqualTo(String value) {
            addCriterion("num_interior_dir2 <=", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Like(String value) {
            addCriterion("num_interior_dir2 like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotLike(String value) {
            addCriterion("num_interior_dir2 not like", value, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2In(List<String> values) {
            addCriterion("num_interior_dir2 in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotIn(List<String> values) {
            addCriterion("num_interior_dir2 not in", values, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2Between(String value1, String value2) {
            addCriterion("num_interior_dir2 between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumInteriorDir2NotBetween(String value1, String value2) {
            addCriterion("num_interior_dir2 not between", value1, value2, "numInteriorDir2");
            return this;
        }

        public Criteria andNumManzDir2IsNull() {
            addCriterion("num_manz_dir2 is null");
            return this;
        }

        public Criteria andNumManzDir2IsNotNull() {
            addCriterion("num_manz_dir2 is not null");
            return this;
        }

        public Criteria andNumManzDir2EqualTo(String value) {
            addCriterion("num_manz_dir2 =", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotEqualTo(String value) {
            addCriterion("num_manz_dir2 <>", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThan(String value) {
            addCriterion("num_manz_dir2 >", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 >=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThan(String value) {
            addCriterion("num_manz_dir2 <", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2LessThanOrEqualTo(String value) {
            addCriterion("num_manz_dir2 <=", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Like(String value) {
            addCriterion("num_manz_dir2 like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotLike(String value) {
            addCriterion("num_manz_dir2 not like", value, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2In(List<String> values) {
            addCriterion("num_manz_dir2 in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotIn(List<String> values) {
            addCriterion("num_manz_dir2 not in", values, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2Between(String value1, String value2) {
            addCriterion("num_manz_dir2 between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumManzDir2NotBetween(String value1, String value2) {
            addCriterion("num_manz_dir2 not between", value1, value2, "numManzDir2");
            return this;
        }

        public Criteria andNumLoteDir2IsNull() {
            addCriterion("num_lote_dir2 is null");
            return this;
        }

        public Criteria andNumLoteDir2IsNotNull() {
            addCriterion("num_lote_dir2 is not null");
            return this;
        }

        public Criteria andNumLoteDir2EqualTo(String value) {
            addCriterion("num_lote_dir2 =", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotEqualTo(String value) {
            addCriterion("num_lote_dir2 <>", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThan(String value) {
            addCriterion("num_lote_dir2 >", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 >=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThan(String value) {
            addCriterion("num_lote_dir2 <", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2LessThanOrEqualTo(String value) {
            addCriterion("num_lote_dir2 <=", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Like(String value) {
            addCriterion("num_lote_dir2 like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotLike(String value) {
            addCriterion("num_lote_dir2 not like", value, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2In(List<String> values) {
            addCriterion("num_lote_dir2 in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotIn(List<String> values) {
            addCriterion("num_lote_dir2 not in", values, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2Between(String value1, String value2) {
            addCriterion("num_lote_dir2 between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumLoteDir2NotBetween(String value1, String value2) {
            addCriterion("num_lote_dir2 not between", value1, value2, "numLoteDir2");
            return this;
        }

        public Criteria andNumKilomDir2IsNull() {
            addCriterion("num_kilom_dir2 is null");
            return this;
        }

        public Criteria andNumKilomDir2IsNotNull() {
            addCriterion("num_kilom_dir2 is not null");
            return this;
        }

        public Criteria andNumKilomDir2EqualTo(String value) {
            addCriterion("num_kilom_dir2 =", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotEqualTo(String value) {
            addCriterion("num_kilom_dir2 <>", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThan(String value) {
            addCriterion("num_kilom_dir2 >", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 >=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThan(String value) {
            addCriterion("num_kilom_dir2 <", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2LessThanOrEqualTo(String value) {
            addCriterion("num_kilom_dir2 <=", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Like(String value) {
            addCriterion("num_kilom_dir2 like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotLike(String value) {
            addCriterion("num_kilom_dir2 not like", value, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2In(List<String> values) {
            addCriterion("num_kilom_dir2 in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotIn(List<String> values) {
            addCriterion("num_kilom_dir2 not in", values, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2Between(String value1, String value2) {
            addCriterion("num_kilom_dir2 between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumKilomDir2NotBetween(String value1, String value2) {
            addCriterion("num_kilom_dir2 not between", value1, value2, "numKilomDir2");
            return this;
        }

        public Criteria andNumBlockDir2IsNull() {
            addCriterion("num_block_dir2 is null");
            return this;
        }

        public Criteria andNumBlockDir2IsNotNull() {
            addCriterion("num_block_dir2 is not null");
            return this;
        }

        public Criteria andNumBlockDir2EqualTo(String value) {
            addCriterion("num_block_dir2 =", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotEqualTo(String value) {
            addCriterion("num_block_dir2 <>", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThan(String value) {
            addCriterion("num_block_dir2 >", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 >=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThan(String value) {
            addCriterion("num_block_dir2 <", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2LessThanOrEqualTo(String value) {
            addCriterion("num_block_dir2 <=", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Like(String value) {
            addCriterion("num_block_dir2 like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotLike(String value) {
            addCriterion("num_block_dir2 not like", value, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2In(List<String> values) {
            addCriterion("num_block_dir2 in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotIn(List<String> values) {
            addCriterion("num_block_dir2 not in", values, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2Between(String value1, String value2) {
            addCriterion("num_block_dir2 between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumBlockDir2NotBetween(String value1, String value2) {
            addCriterion("num_block_dir2 not between", value1, value2, "numBlockDir2");
            return this;
        }

        public Criteria andNumEtapaDir2IsNull() {
            addCriterion("num_etapa_dir2 is null");
            return this;
        }

        public Criteria andNumEtapaDir2IsNotNull() {
            addCriterion("num_etapa_dir2 is not null");
            return this;
        }

        public Criteria andNumEtapaDir2EqualTo(String value) {
            addCriterion("num_etapa_dir2 =", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotEqualTo(String value) {
            addCriterion("num_etapa_dir2 <>", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThan(String value) {
            addCriterion("num_etapa_dir2 >", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 >=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThan(String value) {
            addCriterion("num_etapa_dir2 <", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2LessThanOrEqualTo(String value) {
            addCriterion("num_etapa_dir2 <=", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Like(String value) {
            addCriterion("num_etapa_dir2 like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotLike(String value) {
            addCriterion("num_etapa_dir2 not like", value, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2In(List<String> values) {
            addCriterion("num_etapa_dir2 in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotIn(List<String> values) {
            addCriterion("num_etapa_dir2 not in", values, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2Between(String value1, String value2) {
            addCriterion("num_etapa_dir2 between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andNumEtapaDir2NotBetween(String value1, String value2) {
            addCriterion("num_etapa_dir2 not between", value1, value2, "numEtapaDir2");
            return this;
        }

        public Criteria andCodZonaDir2IsNull() {
            addCriterion("cod_zona_dir2 is null");
            return this;
        }

        public Criteria andCodZonaDir2IsNotNull() {
            addCriterion("cod_zona_dir2 is not null");
            return this;
        }

        public Criteria andCodZonaDir2EqualTo(String value) {
            addCriterion("cod_zona_dir2 =", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotEqualTo(String value) {
            addCriterion("cod_zona_dir2 <>", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThan(String value) {
            addCriterion("cod_zona_dir2 >", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 >=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThan(String value) {
            addCriterion("cod_zona_dir2 <", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_zona_dir2 <=", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Like(String value) {
            addCriterion("cod_zona_dir2 like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotLike(String value) {
            addCriterion("cod_zona_dir2 not like", value, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2In(List<String> values) {
            addCriterion("cod_zona_dir2 in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotIn(List<String> values) {
            addCriterion("cod_zona_dir2 not in", values, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2Between(String value1, String value2) {
            addCriterion("cod_zona_dir2 between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andCodZonaDir2NotBetween(String value1, String value2) {
            addCriterion("cod_zona_dir2 not between", value1, value2, "codZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2IsNull() {
            addCriterion("nom_zona_dir2 is null");
            return this;
        }

        public Criteria andNomZonaDir2IsNotNull() {
            addCriterion("nom_zona_dir2 is not null");
            return this;
        }

        public Criteria andNomZonaDir2EqualTo(String value) {
            addCriterion("nom_zona_dir2 =", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotEqualTo(String value) {
            addCriterion("nom_zona_dir2 <>", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThan(String value) {
            addCriterion("nom_zona_dir2 >", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2GreaterThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 >=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThan(String value) {
            addCriterion("nom_zona_dir2 <", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2LessThanOrEqualTo(String value) {
            addCriterion("nom_zona_dir2 <=", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Like(String value) {
            addCriterion("nom_zona_dir2 like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotLike(String value) {
            addCriterion("nom_zona_dir2 not like", value, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2In(List<String> values) {
            addCriterion("nom_zona_dir2 in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotIn(List<String> values) {
            addCriterion("nom_zona_dir2 not in", values, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2Between(String value1, String value2) {
            addCriterion("nom_zona_dir2 between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andNomZonaDir2NotBetween(String value1, String value2) {
            addCriterion("nom_zona_dir2 not between", value1, value2, "nomZonaDir2");
            return this;
        }

        public Criteria andDesReferDir2IsNull() {
            addCriterion("des_refer_dir2 is null");
            return this;
        }

        public Criteria andDesReferDir2IsNotNull() {
            addCriterion("des_refer_dir2 is not null");
            return this;
        }

        public Criteria andDesReferDir2EqualTo(String value) {
            addCriterion("des_refer_dir2 =", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotEqualTo(String value) {
            addCriterion("des_refer_dir2 <>", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2GreaterThan(String value) {
            addCriterion("des_refer_dir2 >", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2GreaterThanOrEqualTo(String value) {
            addCriterion("des_refer_dir2 >=", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2LessThan(String value) {
            addCriterion("des_refer_dir2 <", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2LessThanOrEqualTo(String value) {
            addCriterion("des_refer_dir2 <=", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2Like(String value) {
            addCriterion("des_refer_dir2 like", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotLike(String value) {
            addCriterion("des_refer_dir2 not like", value, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2In(List<String> values) {
            addCriterion("des_refer_dir2 in", values, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotIn(List<String> values) {
            addCriterion("des_refer_dir2 not in", values, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2Between(String value1, String value2) {
            addCriterion("des_refer_dir2 between", value1, value2, "desReferDir2");
            return this;
        }

        public Criteria andDesReferDir2NotBetween(String value1, String value2) {
            addCriterion("des_refer_dir2 not between", value1, value2, "desReferDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNull() {
            addCriterion("cod_ubigeo_dir2 is null");
            return this;
        }

        public Criteria andCodUbigeoDir2IsNotNull() {
            addCriterion("cod_ubigeo_dir2 is not null");
            return this;
        }

        public Criteria andCodUbigeoDir2EqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 =", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <>", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThan(String value) {
            addCriterion("cod_ubigeo_dir2 >", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2GreaterThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 >=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThan(String value) {
            addCriterion("cod_ubigeo_dir2 <", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2LessThanOrEqualTo(String value) {
            addCriterion("cod_ubigeo_dir2 <=", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Like(String value) {
            addCriterion("cod_ubigeo_dir2 like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotLike(String value) {
            addCriterion("cod_ubigeo_dir2 not like", value, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2In(List<String> values) {
            addCriterion("cod_ubigeo_dir2 in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotIn(List<String> values) {
            addCriterion("cod_ubigeo_dir2 not in", values, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2Between(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andCodUbigeoDir2NotBetween(String value1, String value2) {
            addCriterion("cod_ubigeo_dir2 not between", value1, value2, "codUbigeoDir2");
            return this;
        }

        public Criteria andIndCentAsisIsNull() {
            addCriterion("ind_cent_asis is null");
            return this;
        }

        public Criteria andIndCentAsisIsNotNull() {
            addCriterion("ind_cent_asis is not null");
            return this;
        }

        public Criteria andIndCentAsisEqualTo(String value) {
            addCriterion("ind_cent_asis =", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotEqualTo(String value) {
            addCriterion("ind_cent_asis <>", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThan(String value) {
            addCriterion("ind_cent_asis >", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisGreaterThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis >=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThan(String value) {
            addCriterion("ind_cent_asis <", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLessThanOrEqualTo(String value) {
            addCriterion("ind_cent_asis <=", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisLike(String value) {
            addCriterion("ind_cent_asis like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotLike(String value) {
            addCriterion("ind_cent_asis not like", value, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisIn(List<String> values) {
            addCriterion("ind_cent_asis in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotIn(List<String> values) {
            addCriterion("ind_cent_asis not in", values, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisBetween(String value1, String value2) {
            addCriterion("ind_cent_asis between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andIndCentAsisNotBetween(String value1, String value2) {
            addCriterion("ind_cent_asis not between", value1, value2, "indCentAsis");
            return this;
        }

        public Criteria andDesCtaHaberesIsNull() {
            addCriterion("des_cta_haberes is null");
            return this;
        }

        public Criteria andDesCtaHaberesIsNotNull() {
            addCriterion("des_cta_haberes is not null");
            return this;
        }

        public Criteria andDesCtaHaberesEqualTo(String value) {
            addCriterion("des_cta_haberes =", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesNotEqualTo(String value) {
            addCriterion("des_cta_haberes <>", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesGreaterThan(String value) {
            addCriterion("des_cta_haberes >", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesGreaterThanOrEqualTo(String value) {
            addCriterion("des_cta_haberes >=", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesLessThan(String value) {
            addCriterion("des_cta_haberes <", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesLessThanOrEqualTo(String value) {
            addCriterion("des_cta_haberes <=", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesLike(String value) {
            addCriterion("des_cta_haberes like", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesNotLike(String value) {
            addCriterion("des_cta_haberes not like", value, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesIn(List<String> values) {
            addCriterion("des_cta_haberes in", values, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesNotIn(List<String> values) {
            addCriterion("des_cta_haberes not in", values, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesBetween(String value1, String value2) {
            addCriterion("des_cta_haberes between", value1, value2, "desCtaHaberes");
            return this;
        }

        public Criteria andDesCtaHaberesNotBetween(String value1, String value2) {
            addCriterion("des_cta_haberes not between", value1, value2, "desCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesIsNull() {
            addCriterion("num_cta_haberes is null");
            return this;
        }

        public Criteria andNumCtaHaberesIsNotNull() {
            addCriterion("num_cta_haberes is not null");
            return this;
        }

        public Criteria andNumCtaHaberesEqualTo(String value) {
            addCriterion("num_cta_haberes =", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesNotEqualTo(String value) {
            addCriterion("num_cta_haberes <>", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesGreaterThan(String value) {
            addCriterion("num_cta_haberes >", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesGreaterThanOrEqualTo(String value) {
            addCriterion("num_cta_haberes >=", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesLessThan(String value) {
            addCriterion("num_cta_haberes <", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesLessThanOrEqualTo(String value) {
            addCriterion("num_cta_haberes <=", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesLike(String value) {
            addCriterion("num_cta_haberes like", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesNotLike(String value) {
            addCriterion("num_cta_haberes not like", value, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesIn(List<String> values) {
            addCriterion("num_cta_haberes in", values, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesNotIn(List<String> values) {
            addCriterion("num_cta_haberes not in", values, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesBetween(String value1, String value2) {
            addCriterion("num_cta_haberes between", value1, value2, "numCtaHaberes");
            return this;
        }

        public Criteria andNumCtaHaberesNotBetween(String value1, String value2) {
            addCriterion("num_cta_haberes not between", value1, value2, "numCtaHaberes");
            return this;
        }

        public Criteria andCodGrupoSanIsNull() {
            addCriterion("cod_grupo_san is null");
            return this;
        }

        public Criteria andCodGrupoSanIsNotNull() {
            addCriterion("cod_grupo_san is not null");
            return this;
        }

        public Criteria andCodGrupoSanEqualTo(String value) {
            addCriterion("cod_grupo_san =", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanNotEqualTo(String value) {
            addCriterion("cod_grupo_san <>", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanGreaterThan(String value) {
            addCriterion("cod_grupo_san >", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanGreaterThanOrEqualTo(String value) {
            addCriterion("cod_grupo_san >=", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanLessThan(String value) {
            addCriterion("cod_grupo_san <", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanLessThanOrEqualTo(String value) {
            addCriterion("cod_grupo_san <=", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanLike(String value) {
            addCriterion("cod_grupo_san like", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanNotLike(String value) {
            addCriterion("cod_grupo_san not like", value, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanIn(List<String> values) {
            addCriterion("cod_grupo_san in", values, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanNotIn(List<String> values) {
            addCriterion("cod_grupo_san not in", values, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanBetween(String value1, String value2) {
            addCriterion("cod_grupo_san between", value1, value2, "codGrupoSan");
            return this;
        }

        public Criteria andCodGrupoSanNotBetween(String value1, String value2) {
            addCriterion("cod_grupo_san not between", value1, value2, "codGrupoSan");
            return this;
        }

        public Criteria andIndDiscapacidadIsNull() {
            addCriterion("ind_discapacidad is null");
            return this;
        }

        public Criteria andIndDiscapacidadIsNotNull() {
            addCriterion("ind_discapacidad is not null");
            return this;
        }

        public Criteria andIndDiscapacidadEqualTo(String value) {
            addCriterion("ind_discapacidad =", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotEqualTo(String value) {
            addCriterion("ind_discapacidad <>", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadGreaterThan(String value) {
            addCriterion("ind_discapacidad >", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadGreaterThanOrEqualTo(String value) {
            addCriterion("ind_discapacidad >=", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLessThan(String value) {
            addCriterion("ind_discapacidad <", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLessThanOrEqualTo(String value) {
            addCriterion("ind_discapacidad <=", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadLike(String value) {
            addCriterion("ind_discapacidad like", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotLike(String value) {
            addCriterion("ind_discapacidad not like", value, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadIn(List<String> values) {
            addCriterion("ind_discapacidad in", values, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotIn(List<String> values) {
            addCriterion("ind_discapacidad not in", values, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadBetween(String value1, String value2) {
            addCriterion("ind_discapacidad between", value1, value2, "indDiscapacidad");
            return this;
        }

        public Criteria andIndDiscapacidadNotBetween(String value1, String value2) {
            addCriterion("ind_discapacidad not between", value1, value2, "indDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadIsNull() {
            addCriterion("cod_discapacidad is null");
            return this;
        }

        public Criteria andCodDiscapacidadIsNotNull() {
            addCriterion("cod_discapacidad is not null");
            return this;
        }

        public Criteria andCodDiscapacidadEqualTo(String value) {
            addCriterion("cod_discapacidad =", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadNotEqualTo(String value) {
            addCriterion("cod_discapacidad <>", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadGreaterThan(String value) {
            addCriterion("cod_discapacidad >", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadGreaterThanOrEqualTo(String value) {
            addCriterion("cod_discapacidad >=", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadLessThan(String value) {
            addCriterion("cod_discapacidad <", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadLessThanOrEqualTo(String value) {
            addCriterion("cod_discapacidad <=", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadLike(String value) {
            addCriterion("cod_discapacidad like", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadNotLike(String value) {
            addCriterion("cod_discapacidad not like", value, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadIn(List<String> values) {
            addCriterion("cod_discapacidad in", values, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadNotIn(List<String> values) {
            addCriterion("cod_discapacidad not in", values, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadBetween(String value1, String value2) {
            addCriterion("cod_discapacidad between", value1, value2, "codDiscapacidad");
            return this;
        }

        public Criteria andCodDiscapacidadNotBetween(String value1, String value2) {
            addCriterion("cod_discapacidad not between", value1, value2, "codDiscapacidad");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecCreacionIsNull() {
            addCriterion("fec_creacion is null");
            return this;
        }

        public Criteria andFecCreacionIsNotNull() {
            addCriterion("fec_creacion is not null");
            return this;
        }

        public Criteria andFecCreacionEqualTo(Date value) {
            addCriterion("fec_creacion =", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotEqualTo(Date value) {
            addCriterion("fec_creacion <>", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThan(Date value) {
            addCriterion("fec_creacion >", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_creacion >=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThan(Date value) {
            addCriterion("fec_creacion <", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionLessThanOrEqualTo(Date value) {
            addCriterion("fec_creacion <=", value, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionIn(List<Date> values) {
            addCriterion("fec_creacion in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotIn(List<Date> values) {
            addCriterion("fec_creacion not in", values, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionBetween(Date value1, Date value2) {
            addCriterion("fec_creacion between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andFecCreacionNotBetween(Date value1, Date value2) {
            addCriterion("fec_creacion not between", value1, value2, "fecCreacion");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andIndNivEducIsNull() {
            addCriterion("ind_niv_educ is null");
            return this;
        }

        public Criteria andIndNivEducIsNotNull() {
            addCriterion("ind_niv_educ is not null");
            return this;
        }

        public Criteria andIndNivEducEqualTo(String value) {
            addCriterion("ind_niv_educ =", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducNotEqualTo(String value) {
            addCriterion("ind_niv_educ <>", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducGreaterThan(String value) {
            addCriterion("ind_niv_educ >", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducGreaterThanOrEqualTo(String value) {
            addCriterion("ind_niv_educ >=", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducLessThan(String value) {
            addCriterion("ind_niv_educ <", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducLessThanOrEqualTo(String value) {
            addCriterion("ind_niv_educ <=", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducLike(String value) {
            addCriterion("ind_niv_educ like", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducNotLike(String value) {
            addCriterion("ind_niv_educ not like", value, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducIn(List<String> values) {
            addCriterion("ind_niv_educ in", values, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducNotIn(List<String> values) {
            addCriterion("ind_niv_educ not in", values, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducBetween(String value1, String value2) {
            addCriterion("ind_niv_educ between", value1, value2, "indNivEduc");
            return this;
        }

        public Criteria andIndNivEducNotBetween(String value1, String value2) {
            addCriterion("ind_niv_educ not between", value1, value2, "indNivEduc");
            return this;
        }

        public Criteria andNumCusppIsNull() {
            addCriterion("num_cuspp is null");
            return this;
        }

        public Criteria andNumCusppIsNotNull() {
            addCriterion("num_cuspp is not null");
            return this;
        }

        public Criteria andNumCusppEqualTo(String value) {
            addCriterion("num_cuspp =", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppNotEqualTo(String value) {
            addCriterion("num_cuspp <>", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppGreaterThan(String value) {
            addCriterion("num_cuspp >", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppGreaterThanOrEqualTo(String value) {
            addCriterion("num_cuspp >=", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppLessThan(String value) {
            addCriterion("num_cuspp <", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppLessThanOrEqualTo(String value) {
            addCriterion("num_cuspp <=", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppLike(String value) {
            addCriterion("num_cuspp like", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppNotLike(String value) {
            addCriterion("num_cuspp not like", value, "numCuspp");
            return this;
        }

        public Criteria andNumCusppIn(List<String> values) {
            addCriterion("num_cuspp in", values, "numCuspp");
            return this;
        }

        public Criteria andNumCusppNotIn(List<String> values) {
            addCriterion("num_cuspp not in", values, "numCuspp");
            return this;
        }

        public Criteria andNumCusppBetween(String value1, String value2) {
            addCriterion("num_cuspp between", value1, value2, "numCuspp");
            return this;
        }

        public Criteria andNumCusppNotBetween(String value1, String value2) {
            addCriterion("num_cuspp not between", value1, value2, "numCuspp");
            return this;
        }

        public Criteria andDesDomiciDir1IsNull() {
            addCriterion("des_domici_dir1 is null");
            return this;
        }

        public Criteria andDesDomiciDir1IsNotNull() {
            addCriterion("des_domici_dir1 is not null");
            return this;
        }

        public Criteria andDesDomiciDir1EqualTo(String value) {
            addCriterion("des_domici_dir1 =", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotEqualTo(String value) {
            addCriterion("des_domici_dir1 <>", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1GreaterThan(String value) {
            addCriterion("des_domici_dir1 >", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_domici_dir1 >=", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1LessThan(String value) {
            addCriterion("des_domici_dir1 <", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1LessThanOrEqualTo(String value) {
            addCriterion("des_domici_dir1 <=", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1Like(String value) {
            addCriterion("des_domici_dir1 like", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotLike(String value) {
            addCriterion("des_domici_dir1 not like", value, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1In(List<String> values) {
            addCriterion("des_domici_dir1 in", values, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotIn(List<String> values) {
            addCriterion("des_domici_dir1 not in", values, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1Between(String value1, String value2) {
            addCriterion("des_domici_dir1 between", value1, value2, "desDomiciDir1");
            return this;
        }

        public Criteria andDesDomiciDir1NotBetween(String value1, String value2) {
            addCriterion("des_domici_dir1 not between", value1, value2, "desDomiciDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1IsNull() {
            addCriterion("des_ubigeo_dir1 is null");
            return this;
        }

        public Criteria andDesUbigeoDir1IsNotNull() {
            addCriterion("des_ubigeo_dir1 is not null");
            return this;
        }

        public Criteria andDesUbigeoDir1EqualTo(String value) {
            addCriterion("des_ubigeo_dir1 =", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 <>", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1GreaterThan(String value) {
            addCriterion("des_ubigeo_dir1 >", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1GreaterThanOrEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 >=", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1LessThan(String value) {
            addCriterion("des_ubigeo_dir1 <", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1LessThanOrEqualTo(String value) {
            addCriterion("des_ubigeo_dir1 <=", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1Like(String value) {
            addCriterion("des_ubigeo_dir1 like", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotLike(String value) {
            addCriterion("des_ubigeo_dir1 not like", value, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1In(List<String> values) {
            addCriterion("des_ubigeo_dir1 in", values, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotIn(List<String> values) {
            addCriterion("des_ubigeo_dir1 not in", values, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1Between(String value1, String value2) {
            addCriterion("des_ubigeo_dir1 between", value1, value2, "desUbigeoDir1");
            return this;
        }

        public Criteria andDesUbigeoDir1NotBetween(String value1, String value2) {
            addCriterion("des_ubigeo_dir1 not between", value1, value2, "desUbigeoDir1");
            return this;
        }

        public Criteria andIndReniecIsNull() {
            addCriterion("ind_reniec is null");
            return this;
        }

        public Criteria andIndReniecIsNotNull() {
            addCriterion("ind_reniec is not null");
            return this;
        }

        public Criteria andIndReniecEqualTo(String value) {
            addCriterion("ind_reniec =", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotEqualTo(String value) {
            addCriterion("ind_reniec <>", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecGreaterThan(String value) {
            addCriterion("ind_reniec >", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecGreaterThanOrEqualTo(String value) {
            addCriterion("ind_reniec >=", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLessThan(String value) {
            addCriterion("ind_reniec <", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLessThanOrEqualTo(String value) {
            addCriterion("ind_reniec <=", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecLike(String value) {
            addCriterion("ind_reniec like", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotLike(String value) {
            addCriterion("ind_reniec not like", value, "indReniec");
            return this;
        }

        public Criteria andIndReniecIn(List<String> values) {
            addCriterion("ind_reniec in", values, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotIn(List<String> values) {
            addCriterion("ind_reniec not in", values, "indReniec");
            return this;
        }

        public Criteria andIndReniecBetween(String value1, String value2) {
            addCriterion("ind_reniec between", value1, value2, "indReniec");
            return this;
        }

        public Criteria andIndReniecNotBetween(String value1, String value2) {
            addCriterion("ind_reniec not between", value1, value2, "indReniec");
            return this;
        }

        public Criteria andCodPaisUbiNacIsNull() {
            addCriterion("cod_pais_ubi_nac is null");
            return this;
        }

        public Criteria andCodPaisUbiNacIsNotNull() {
            addCriterion("cod_pais_ubi_nac is not null");
            return this;
        }

        public Criteria andCodPaisUbiNacEqualTo(String value) {
            addCriterion("cod_pais_ubi_nac =", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacNotEqualTo(String value) {
            addCriterion("cod_pais_ubi_nac <>", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacGreaterThan(String value) {
            addCriterion("cod_pais_ubi_nac >", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacGreaterThanOrEqualTo(String value) {
            addCriterion("cod_pais_ubi_nac >=", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacLessThan(String value) {
            addCriterion("cod_pais_ubi_nac <", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacLessThanOrEqualTo(String value) {
            addCriterion("cod_pais_ubi_nac <=", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacLike(String value) {
            addCriterion("cod_pais_ubi_nac like", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacNotLike(String value) {
            addCriterion("cod_pais_ubi_nac not like", value, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacIn(List<String> values) {
            addCriterion("cod_pais_ubi_nac in", values, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacNotIn(List<String> values) {
            addCriterion("cod_pais_ubi_nac not in", values, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacBetween(String value1, String value2) {
            addCriterion("cod_pais_ubi_nac between", value1, value2, "codPaisUbiNac");
            return this;
        }

        public Criteria andCodPaisUbiNacNotBetween(String value1, String value2) {
            addCriterion("cod_pais_ubi_nac not between", value1, value2, "codPaisUbiNac");
            return this;
        }
    }
}