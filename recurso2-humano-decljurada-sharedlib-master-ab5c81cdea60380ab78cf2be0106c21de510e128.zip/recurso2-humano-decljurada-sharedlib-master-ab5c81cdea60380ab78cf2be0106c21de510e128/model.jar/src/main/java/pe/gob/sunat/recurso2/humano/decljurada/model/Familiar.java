package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class Familiar {
    private String t09codPers;

    private String t09codFami;

    private String t09correl;

    private String t09apPfami;

    private String t09apMfami;

    private String t09nombFa;

    private String t09codDcto;

    private String t09nroDcto;

    private String t09estado;

    private Date t09fNacfa;

    private Date t09fMatri;

    private String t09trabFami;

    private String t09telfFami;

    private String t09pamf;

    private String t09enSunat;

    private String t09codPersf;

    private String t09direccion;

    private String t09refer;

    private Date t09fGraba;

    private String t09codUser;

    private String t09indDel;

    public String getT09codPers() {
        return t09codPers;
    }

    public void setT09codPers(String t09codPers) {
        this.t09codPers = t09codPers == null ? null : t09codPers.trim();
    }

    public String getT09codFami() {
        return t09codFami;
    }

    public void setT09codFami(String t09codFami) {
        this.t09codFami = t09codFami == null ? null : t09codFami.trim();
    }

    public String getT09correl() {
        return t09correl;
    }

    public void setT09correl(String t09correl) {
        this.t09correl = t09correl == null ? null : t09correl.trim();
    }

    public String getT09apPfami() {
        return t09apPfami;
    }

    public void setT09apPfami(String t09apPfami) {
        this.t09apPfami = t09apPfami == null ? null : t09apPfami.trim();
    }

    public String getT09apMfami() {
        return t09apMfami;
    }

    public void setT09apMfami(String t09apMfami) {
        this.t09apMfami = t09apMfami == null ? null : t09apMfami.trim();
    }

    public String getT09nombFa() {
        return t09nombFa;
    }

    public void setT09nombFa(String t09nombFa) {
        this.t09nombFa = t09nombFa == null ? null : t09nombFa.trim();
    }

    public String getT09codDcto() {
        return t09codDcto;
    }

    public void setT09codDcto(String t09codDcto) {
        this.t09codDcto = t09codDcto == null ? null : t09codDcto.trim();
    }

    public String getT09nroDcto() {
        return t09nroDcto;
    }

    public void setT09nroDcto(String t09nroDcto) {
        this.t09nroDcto = t09nroDcto == null ? null : t09nroDcto.trim();
    }

    public String getT09estado() {
        return t09estado;
    }

    public void setT09estado(String t09estado) {
        this.t09estado = t09estado == null ? null : t09estado.trim();
    }

    public Date getT09fNacfa() {
        return t09fNacfa;
    }

    public void setT09fNacfa(Date t09fNacfa) {
        this.t09fNacfa = t09fNacfa;
    }

    public Date getT09fMatri() {
        return t09fMatri;
    }

    public void setT09fMatri(Date t09fMatri) {
        this.t09fMatri = t09fMatri;
    }

    public String getT09trabFami() {
        return t09trabFami;
    }

    public void setT09trabFami(String t09trabFami) {
        this.t09trabFami = t09trabFami == null ? null : t09trabFami.trim();
    }

    public String getT09telfFami() {
        return t09telfFami;
    }

    public void setT09telfFami(String t09telfFami) {
        this.t09telfFami = t09telfFami == null ? null : t09telfFami.trim();
    }

    public String getT09pamf() {
        return t09pamf;
    }

    public void setT09pamf(String t09pamf) {
        this.t09pamf = t09pamf == null ? null : t09pamf.trim();
    }

    public String getT09enSunat() {
        return t09enSunat;
    }

    public void setT09enSunat(String t09enSunat) {
        this.t09enSunat = t09enSunat == null ? null : t09enSunat.trim();
    }

    public String getT09codPersf() {
        return t09codPersf;
    }

    public void setT09codPersf(String t09codPersf) {
        this.t09codPersf = t09codPersf == null ? null : t09codPersf.trim();
    }

    public String getT09direccion() {
        return t09direccion;
    }

    public void setT09direccion(String t09direccion) {
        this.t09direccion = t09direccion == null ? null : t09direccion.trim();
    }

    public String getT09refer() {
        return t09refer;
    }

    public void setT09refer(String t09refer) {
        this.t09refer = t09refer == null ? null : t09refer.trim();
    }

    public Date getT09fGraba() {
        return t09fGraba;
    }

    public void setT09fGraba(Date t09fGraba) {
        this.t09fGraba = t09fGraba;
    }

    public String getT09codUser() {
        return t09codUser;
    }

    public void setT09codUser(String t09codUser) {
        this.t09codUser = t09codUser == null ? null : t09codUser.trim();
    }

    public String getT09indDel() {
        return t09indDel;
    }

    public void setT09indDel(String t09indDel) {
        this.t09indDel = t09indDel == null ? null : t09indDel.trim();
    }
}