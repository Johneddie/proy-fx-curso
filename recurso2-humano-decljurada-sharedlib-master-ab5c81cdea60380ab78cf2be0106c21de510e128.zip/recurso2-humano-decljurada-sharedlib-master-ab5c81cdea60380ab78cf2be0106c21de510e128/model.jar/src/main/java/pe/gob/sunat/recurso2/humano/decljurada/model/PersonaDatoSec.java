package pe.gob.sunat.recurso2.humano.decljurada.model;

import java.util.Date;

public class PersonaDatoSec {
    private String t03codPers;

    private String t03grpSang;

    private String t03sexo;

    private String t03codUbin;

    private String t03estCiv;

    private String t03pamf;

    private Short t03nFotoch;

    private String t03observa;

    private String t03correo;

    private Date t03fGraba;

    private String t03codUser;

    public String getT03codPers() {
        return t03codPers;
    }

    public void setT03codPers(String t03codPers) {
        this.t03codPers = t03codPers == null ? null : t03codPers.trim();
    }

    public String getT03grpSang() {
        return t03grpSang;
    }

    public void setT03grpSang(String t03grpSang) {
        this.t03grpSang = t03grpSang == null ? null : t03grpSang.trim();
    }

    public String getT03sexo() {
        return t03sexo;
    }

    public void setT03sexo(String t03sexo) {
        this.t03sexo = t03sexo == null ? null : t03sexo.trim();
    }

    public String getT03codUbin() {
        return t03codUbin;
    }

    public void setT03codUbin(String t03codUbin) {
        this.t03codUbin = t03codUbin == null ? null : t03codUbin.trim();
    }

    public String getT03estCiv() {
        return t03estCiv;
    }

    public void setT03estCiv(String t03estCiv) {
        this.t03estCiv = t03estCiv == null ? null : t03estCiv.trim();
    }

    public String getT03pamf() {
        return t03pamf;
    }

    public void setT03pamf(String t03pamf) {
        this.t03pamf = t03pamf == null ? null : t03pamf.trim();
    }

    public Short getT03nFotoch() {
        return t03nFotoch;
    }

    public void setT03nFotoch(Short t03nFotoch) {
        this.t03nFotoch = t03nFotoch;
    }

    public String getT03observa() {
        return t03observa;
    }

    public void setT03observa(String t03observa) {
        this.t03observa = t03observa == null ? null : t03observa.trim();
    }

    public String getT03correo() {
        return t03correo;
    }

    public void setT03correo(String t03correo) {
        this.t03correo = t03correo == null ? null : t03correo.trim();
    }

    public Date getT03fGraba() {
        return t03fGraba;
    }

    public void setT03fGraba(Date t03fGraba) {
        this.t03fGraba = t03fGraba;
    }

    public String getT03codUser() {
        return t03codUser;
    }

    public void setT03codUser(String t03codUser) {
        this.t03codUser = t03codUser == null ? null : t03codUser.trim();
    }
}