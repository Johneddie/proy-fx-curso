package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Archivo;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ArchivoDAO;

@SuppressWarnings("deprecation")
public class SqlMapArchivoDAO extends SqlMapDAOBase implements ArchivoDAO {

    public SqlMapArchivoDAO() {
        super();
    }

    @Override
    public int countByExample(ArchivoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4877ddjjarchivo.countByExample", example);
    }

    @Override
    public int deleteByExample(ArchivoExample example) {
    	return getSqlMapClientTemplate().delete("t4877ddjjarchivo.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(ArchivoKey key) {
    	return getSqlMapClientTemplate().delete("t4877ddjjarchivo.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(Archivo record) {
        getSqlMapClientTemplate().insert("t4877ddjjarchivo.insert", record);
    }

    @Override
    public void insertSelective(Archivo record) {
        getSqlMapClientTemplate().insert("t4877ddjjarchivo.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Archivo> selectByExampleWithBLOBs(ArchivoExample example) {
    	return getSqlMapClientTemplate().queryForList("t4877ddjjarchivo.selectByExampleWithBLOBs", example);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Archivo> selectByExampleWithoutBLOBs(ArchivoExample example) {
    	return getSqlMapClientTemplate().queryForList("t4877ddjjarchivo.selectByExample", example);
    }

    @Override
    public Archivo selectByPrimaryKey(ArchivoKey key) {
    	return (Archivo) getSqlMapClientTemplate().queryForObject("t4877ddjjarchivo.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4877ddjjarchivo.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExampleWithBLOBs(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4877ddjjarchivo.updateByExampleWithBLOBs", parms);
    }

    @Override
    public int updateByExampleWithoutBLOBs(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4877ddjjarchivo.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(Archivo record) {
    	return getSqlMapClientTemplate().update("t4877ddjjarchivo.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKeyWithBLOBs(Archivo record) {
    	return getSqlMapClientTemplate().update("t4877ddjjarchivo.updateByPrimaryKeyWithBLOBs", record);
    }

    @Override
    public int updateByPrimaryKeyWithoutBLOBs(Archivo record) {
    	return getSqlMapClientTemplate().update("t4877ddjjarchivo.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends ArchivoExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Archivo> listarArchivosByTipo(String annDdjj, Integer numDdjj, String codTip) {
    	ArchivoExample ae = new ArchivoExample();
    	ArchivoExample.Criteria ac = ae.createCriteria();
    	ac.andAnnDdjjEqualTo(annDdjj);
    	ac.andNumDdjjEqualTo(numDdjj);
    	ac.andCodTipEqualTo(codTip);
    	return getSqlMapClientTemplate().queryForList("t4877ddjjarchivo.selectByExample", ae);
    }
}