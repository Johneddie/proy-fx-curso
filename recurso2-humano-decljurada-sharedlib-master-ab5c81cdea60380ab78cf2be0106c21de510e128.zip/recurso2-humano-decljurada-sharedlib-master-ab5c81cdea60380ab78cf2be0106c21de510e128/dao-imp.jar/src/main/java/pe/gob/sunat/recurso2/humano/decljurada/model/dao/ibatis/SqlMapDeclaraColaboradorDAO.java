package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaborador;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraColaboradorDAO;

@SuppressWarnings("deprecation")
public class SqlMapDeclaraColaboradorDAO extends SqlMapDAOBase implements DeclaraColaboradorDAO {

    public SqlMapDeclaraColaboradorDAO() {
        super();
    }
    
    @Override
    public int countByExample(DeclaraColaboradorExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4876datoscolabora.countByExample", example);
    }
    
    @Override
    public int deleteByExample(DeclaraColaboradorExample example) {
    	return getSqlMapClientTemplate().delete("t4876datoscolabora.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(DeclaraColaboradorKey key) {
    	return getSqlMapClientTemplate().delete("t4876datoscolabora.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(DeclaraColaborador record) {
        getSqlMapClientTemplate().insert("t4876datoscolabora.insert", record);
    }
    
    @Override
    public void insertSelective(DeclaraColaborador record) {
        getSqlMapClientTemplate().insert("t4876datoscolabora.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<DeclaraColaborador> selectByExample(DeclaraColaboradorExample example) {
    	return getSqlMapClientTemplate().queryForList("t4876datoscolabora.selectByExample", example);
    }
    
    @Override
    public DeclaraColaborador selectByPrimaryKey(DeclaraColaboradorKey key) {
    	return (DeclaraColaborador) getSqlMapClientTemplate().queryForObject("t4876datoscolabora.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(DeclaraColaborador record, DeclaraColaboradorExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4876datoscolabora.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(DeclaraColaborador record, DeclaraColaboradorExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4876datoscolabora.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(DeclaraColaborador record) {
    	return getSqlMapClientTemplate().update("t4876datoscolabora.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(DeclaraColaborador record) {
    	return getSqlMapClientTemplate().update("t4876datoscolabora.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends DeclaraColaboradorExample {
        private Object record;

        public UpdateByExampleParms(Object record, DeclaraColaboradorExample example) {
            super(example);
            this.record = record;
        }
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
    public DeclaraColaborador obtenerUltimaDeclaracion(DeclaraColaborador example) {
    	return (DeclaraColaborador)getSqlMapClientTemplate().queryForObject("t4876datoscolabora.obtenerUltimaDeclaracion", example);
    }
}