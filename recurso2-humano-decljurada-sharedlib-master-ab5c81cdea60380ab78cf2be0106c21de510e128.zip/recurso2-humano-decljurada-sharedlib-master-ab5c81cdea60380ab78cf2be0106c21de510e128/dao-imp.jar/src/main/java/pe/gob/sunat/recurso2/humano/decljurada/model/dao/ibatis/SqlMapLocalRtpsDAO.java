package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.LocalRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.LocalRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.LocalRtpsKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.LocalRtpsDAO;

@SuppressWarnings("deprecation")
public class SqlMapLocalRtpsDAO extends SqlMapDAOBase implements LocalRtpsDAO {

    public SqlMapLocalRtpsDAO() {
        super();
    }
    
    @Override
    public int countByExample(LocalRtpsExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("spr.countByExample", example);
    }
    
    @Override
    public int deleteByExample(LocalRtpsExample example) {
    	return getSqlMapClientTemplate().delete("spr.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(LocalRtpsKey key) {
    	return getSqlMapClientTemplate().delete("spr.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(LocalRtps record) {
        getSqlMapClientTemplate().insert("spr.insert", record);
    }
    
    @Override
    public void insertSelective(LocalRtps record) {
        getSqlMapClientTemplate().insert("spr.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<LocalRtps> selectByExample(LocalRtpsExample example) {
    	return getSqlMapClientTemplate().queryForList("spr.selectByExample", example);
    }
    
    @Override
    public LocalRtps selectByPrimaryKey(LocalRtpsKey key) {
    	return (LocalRtps) getSqlMapClientTemplate().queryForObject("spr.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(LocalRtps record, LocalRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("spr.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(LocalRtps record, LocalRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("spr.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(LocalRtps record) {
    	return getSqlMapClientTemplate().update("spr.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(LocalRtps record) {
    	return getSqlMapClientTemplate().update("spr.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends LocalRtpsExample {
        private Object record;

        public UpdateByExampleParms(Object record, LocalRtpsExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}