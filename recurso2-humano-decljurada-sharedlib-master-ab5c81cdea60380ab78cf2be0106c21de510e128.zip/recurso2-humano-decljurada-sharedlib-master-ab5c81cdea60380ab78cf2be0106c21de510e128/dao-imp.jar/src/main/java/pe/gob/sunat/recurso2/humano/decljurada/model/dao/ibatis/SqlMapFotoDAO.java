package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Foto;
import pe.gob.sunat.recurso2.humano.decljurada.model.FotoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.FotoDAO;

@SuppressWarnings("deprecation")
public class SqlMapFotoDAO extends SqlMapDAOBase implements FotoDAO {

    public SqlMapFotoDAO() {
        super();
    }
    
    @Override
    public int countByExample(FotoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t02fotos.countByExample", example);
    }
    
    @Override
    public int deleteByExample(FotoExample example) {
    	return getSqlMapClientTemplate().delete("t02fotos.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(String t02codPers) {
        Foto key = new Foto();
        key.setT02codPers(t02codPers);
        return getSqlMapClientTemplate().delete("t02fotos.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(Foto record) {
        getSqlMapClientTemplate().insert("t02fotos.insert", record);
    }
    
    @Override
    public void insertSelective(Foto record) {
        getSqlMapClientTemplate().insert("t02fotos.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Foto> selectByExampleWithBLOBs(FotoExample example) {
    	return getSqlMapClientTemplate().queryForList("t02fotos.selectByExampleWithBLOBs", example);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Foto> selectByExampleWithoutBLOBs(FotoExample example) {
    	return getSqlMapClientTemplate().queryForList("t02fotos.selectByExample", example);
    }
    
    @Override
    public Foto selectByPrimaryKey(String t02codPers) {
        Foto key = new Foto();
        key.setT02codPers(t02codPers);
        return (Foto) getSqlMapClientTemplate().queryForObject("t02fotos.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(Foto record, FotoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t02fotos.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExampleWithBLOBs(Foto record, FotoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t02fotos.updateByExampleWithBLOBs", parms);
    }
    
    @Override
    public int updateByExampleWithoutBLOBs(Foto record, FotoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t02fotos.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(Foto record) {
    	return getSqlMapClientTemplate().update("t02fotos.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKeyWithBLOBs(Foto record) {
    	return getSqlMapClientTemplate().update("t02fotos.updateByPrimaryKeyWithBLOBs", record);
    }
    
    @Override
    public int updateByPrimaryKeyWithoutBLOBs(Foto record) {
    	return getSqlMapClientTemplate().update("t02fotos.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends FotoExample {
        private Object record;

        public UpdateByExampleParms(Object record, FotoExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}