package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura05;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura05Example;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.Estructura05DAO;

@SuppressWarnings("deprecation")
public class SqlMapEstructura05DAO extends SqlMapDAOBase implements Estructura05DAO {

    public SqlMapEstructura05DAO() {
        super();
    }
    
    @Override
    public int countByExample(Estructura05Example example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4946tregisimp05.countByExample", example);
    }

    @Override
    public int deleteByExample(Estructura05Example example) {
    	return getSqlMapClientTemplate().delete("t4946tregisimp05.deleteByExample", example);
    }
    
    @Override
    public void insert(Estructura05 record) {
        getSqlMapClientTemplate().insert("t4946tregisimp05.insert", record);
    }
    
    @Override
    public void insertSelective(Estructura05 record) {
        getSqlMapClientTemplate().insert("t4946tregisimp05.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Estructura05> selectByExample(Estructura05Example example) {
    	return getSqlMapClientTemplate().queryForList("t4946tregisimp05.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(Estructura05 record, Estructura05Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4946tregisimp05.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Estructura05 record, Estructura05Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4946tregisimp05.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends Estructura05Example {
        private Object record;

        public UpdateByExampleParms(Object record, Estructura05Example example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}