package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Temporal;
import pe.gob.sunat.recurso2.humano.decljurada.model.TemporalExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.TemporalKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.TemporalDAO;

@SuppressWarnings("deprecation")
public class SqlMapTemporalDAO extends SqlMapDAOBase implements TemporalDAO {

    public SqlMapTemporalDAO() {
        super();
    }
    
    @Override
    public int countByExample(TemporalExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4879ddjjtemp.countByExample", example);
    }	

    @Override
    public int deleteByExample(TemporalExample example) {
    	return getSqlMapClientTemplate().delete("t4879ddjjtemp.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(TemporalKey key) {
    	return getSqlMapClientTemplate().delete("t4879ddjjtemp.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(Temporal record) {
        getSqlMapClientTemplate().insert("t4879ddjjtemp.insert", record);
    }

    @Override
    public void insertSelective(Temporal record) {
        getSqlMapClientTemplate().insert("t4879ddjjtemp.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Temporal> selectByExample(TemporalExample example) {
    	return getSqlMapClientTemplate().queryForList("t4879ddjjtemp.selectByExample", example);
    }
 
    @Override
    public Temporal selectByPrimaryKey(TemporalKey key) {
    	return (Temporal) getSqlMapClientTemplate().queryForObject("t4879ddjjtemp.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(Temporal record, TemporalExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4879ddjjtemp.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(Temporal record, TemporalExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4879ddjjtemp.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(Temporal record) {
    	return getSqlMapClientTemplate().update("t4879ddjjtemp.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKey(Temporal record) {
    	return getSqlMapClientTemplate().update("t4879ddjjtemp.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends TemporalExample {
        private Object record;

        public UpdateByExampleParms(Object record, TemporalExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}