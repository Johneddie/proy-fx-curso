package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura24;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura24Example;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.Estructura24DAO;

@SuppressWarnings("deprecation")
public class SqlMapEstructura24DAO extends SqlMapDAOBase implements Estructura24DAO {

    public SqlMapEstructura24DAO() {
        super();
    }
    
    @Override
    public int countByExample(Estructura24Example example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4950tregisimp24.countByExample", example);
    }

    @Override
    public int deleteByExample(Estructura24Example example) {
    	return getSqlMapClientTemplate().delete("t4950tregisimp24.deleteByExample", example);
    }
    
    @Override
    public void insert(Estructura24 record) {
        getSqlMapClientTemplate().insert("t4950tregisimp24.insert", record);
    }
    
    @Override
    public void insertSelective(Estructura24 record) {
        getSqlMapClientTemplate().insert("t4950tregisimp24.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Estructura24> selectByExample(Estructura24Example example) {
    	return getSqlMapClientTemplate().queryForList("t4950tregisimp24.selectByExample", example);
    }	
    
    @Override
    public int updateByExampleSelective(Estructura24 record, Estructura24Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4950tregisimp24.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Estructura24 record, Estructura24Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4950tregisimp24.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends Estructura24Example {
        private Object record;

        public UpdateByExampleParms(Object record, Estructura24Example example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}