package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamContribuyenteDAO;

@SuppressWarnings({"deprecation","unchecked"})
public class SqlMapParamContribuyenteDAO extends SqlMapDAOBase implements ParamContribuyenteDAO{

	
	public SqlMapParamContribuyenteDAO() {
        super();
    }
	
	@Override
	public List<Parametro> listarDepartamentos() {
		return getSqlMapClientTemplate().queryForList("t01param.listarDepartamentos");
	}

	@Override
	public List<Parametro> listarProvincias(String codDepartamento) {
		Parametro param = new Parametro();
		param.setCodParametro(codDepartamento);
		return getSqlMapClientTemplate().queryForList("t01param.listarProvincias",param);
	}

	@Override
	public List<Parametro> listarDistritos(String codProvincia) {
		Parametro param = new Parametro();
		param.setCodParametro(codProvincia);
		return getSqlMapClientTemplate().queryForList("t01param.listarDistritos",param);
	}

	@Override
	public List<Parametro> listarCodigosLDN() {
		return getSqlMapClientTemplate().queryForList("t01param.listarCodigosLDN");
	}	
	
	@Override
	public List<Parametro> listarTiposDocumento() {
		return getSqlMapClientTemplate().queryForList("t01param.listarTiposDocumento");
	}
	
	@Override
	public List<Parametro> listarNacionalidades() {
		return getSqlMapClientTemplate().queryForList("t01param.listarNacionalidades");
	}

	@Override
	public List<Parametro> listarTiposVia() {
		return getSqlMapClientTemplate().queryForList("t01param.listarTiposVia");
	}

	@Override
	public List<Parametro> listarTiposZona() {
		return getSqlMapClientTemplate().queryForList("t01param.listarTiposZona");
	}

	@Override
	public String obtenerUbigeoReniec(String ubigeoSunat) {
		return (String)getSqlMapClientTemplate().queryForObject("t01param.obtenerUbigeoReniec", ubigeoSunat);
	}
	@Override
	public String obtenerUbigeoSunat(String ubigeoReniec) {
		return (String)getSqlMapClientTemplate().queryForObject("t01param.obtenerUbigeoSunat", ubigeoReniec);
	}

	@Override
	public List<Parametro> listarPaisesEmisor() {
		return getSqlMapClientTemplate().queryForList("t01param.listarPaisesEmisor");
	}	
	
}









