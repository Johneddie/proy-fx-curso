package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.TipoDocumSiga;
import pe.gob.sunat.recurso2.humano.decljurada.model.TipoDocumSigaExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.TipoDocumSigaDAO;

@SuppressWarnings("deprecation")
public class SqlMapTipoDocumSigaDAO extends SqlMapDAOBase implements TipoDocumSigaDAO {

    public SqlMapTipoDocumSigaDAO() {
        super();
    }

    @Override
    public int countByExample(TipoDocumSigaExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("TIPOS_DOCUMENTOS_IDENTIDAD.countByExample", example);
    }

    @Override
    public int deleteByExample(TipoDocumSigaExample example) {
    	return getSqlMapClientTemplate().delete("TIPOS_DOCUMENTOS_IDENTIDAD.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(String tipoDocuIde) {
        TipoDocumSiga key = new TipoDocumSiga();
        key.setTipoDocuIde(tipoDocuIde);
        return getSqlMapClientTemplate().delete("TIPOS_DOCUMENTOS_IDENTIDAD.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(TipoDocumSiga record) {
        getSqlMapClientTemplate().insert("TIPOS_DOCUMENTOS_IDENTIDAD.insert", record);
    }

    @Override
    public void insertSelective(TipoDocumSiga record) {
        getSqlMapClientTemplate().insert("TIPOS_DOCUMENTOS_IDENTIDAD.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<TipoDocumSiga> selectByExample(TipoDocumSigaExample example) {
    	return getSqlMapClientTemplate().queryForList("TIPOS_DOCUMENTOS_IDENTIDAD.selectByExample", example);
    }

    @Override
    public TipoDocumSiga selectByPrimaryKey(String tipoDocuIde) {
        TipoDocumSiga key = new TipoDocumSiga();
        key.setTipoDocuIde(tipoDocuIde);
        return (TipoDocumSiga) getSqlMapClientTemplate().queryForObject("TIPOS_DOCUMENTOS_IDENTIDAD.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(TipoDocumSiga record, TipoDocumSigaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("TIPOS_DOCUMENTOS_IDENTIDAD.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(TipoDocumSiga record, TipoDocumSigaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("TIPOS_DOCUMENTOS_IDENTIDAD.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(TipoDocumSiga record) {
    	return getSqlMapClientTemplate().update("TIPOS_DOCUMENTOS_IDENTIDAD.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKey(TipoDocumSiga record) {
    	return getSqlMapClientTemplate().update("TIPOS_DOCUMENTOS_IDENTIDAD.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends TipoDocumSigaExample {
        private Object record;

        public UpdateByExampleParms(Object record, TipoDocumSigaExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
}