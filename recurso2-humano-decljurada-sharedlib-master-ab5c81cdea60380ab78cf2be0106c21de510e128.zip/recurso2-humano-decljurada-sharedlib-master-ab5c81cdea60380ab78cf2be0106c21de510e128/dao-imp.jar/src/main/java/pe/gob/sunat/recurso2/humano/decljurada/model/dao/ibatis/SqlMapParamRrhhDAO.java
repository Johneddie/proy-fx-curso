package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;


import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ParamRrhhDAO;

public class SqlMapParamRrhhDAO extends SqlMapDAOBase implements ParamRrhhDAO{

	@SuppressWarnings("deprecation")
	@Override
	public String obtenerDesUbigeoSunat(String codigo) {
		return (String)getSqlMapClientTemplate().queryForObject("t01paramsp.obtenerDesUbigeoSunat", codigo);
	}
	
}
