package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Familiar;
import pe.gob.sunat.recurso2.humano.decljurada.model.FamiliarExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.FamiliarDAO;

@SuppressWarnings("deprecation")
public class SqlMapFamiliarDAO extends SqlMapDAOBase implements FamiliarDAO {

    public SqlMapFamiliarDAO() {
        super();
    }
    
    @Override
    public int countByExample(FamiliarExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t09famil.countByExample", example);
    }

    @Override
    public int deleteByExample(FamiliarExample example) {
    	return getSqlMapClientTemplate().delete("t09famil.deleteByExample", example);
    }

    @Override
    public void insert(Familiar record) {
        getSqlMapClientTemplate().insert("t09famil.insert", record);
    }

    @Override
    public void insertSelective(Familiar record) {
        getSqlMapClientTemplate().insert("t09famil.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Familiar> selectByExample(FamiliarExample example) {
    	return getSqlMapClientTemplate().queryForList("t09famil.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(Familiar record, FamiliarExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t09famil.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Familiar record, FamiliarExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t09famil.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends FamiliarExample {
        private Object record;

        public UpdateByExampleParms(Object record, FamiliarExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}