package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura04;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura04Example;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.Estructura04DAO;

@SuppressWarnings("deprecation")
public class SqlMapEstructura04DAO extends SqlMapDAOBase implements Estructura04DAO {

    public SqlMapEstructura04DAO() {
        super();
    }
    
    @Override
    public int countByExample(Estructura04Example example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4945tregisimp04.countByExample", example);
    }
    
    @Override
    public int deleteByExample(Estructura04Example example) {
    	return getSqlMapClientTemplate().delete("t4945tregisimp04.deleteByExample", example);
    }
    
    @Override
    public void insert(Estructura04 record) {
        getSqlMapClientTemplate().insert("t4945tregisimp04.insert", record);
    }
    
    @Override
    public void insertSelective(Estructura04 record) {
        getSqlMapClientTemplate().insert("t4945tregisimp04.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Estructura04> selectByExample(Estructura04Example example) {
    	return getSqlMapClientTemplate().queryForList("t4945tregisimp04.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(Estructura04 record, Estructura04Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4945tregisimp04.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Estructura04 record, Estructura04Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4945tregisimp04.updateByExample", parms);
    }
    
    
    private static class UpdateByExampleParms extends Estructura04Example {
        private Object record;

        public UpdateByExampleParms(Object record, Estructura04Example example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}