package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Delegacion;
import pe.gob.sunat.recurso2.humano.decljurada.model.DelegacionExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DelegacionKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DelegacionDAO;

@SuppressWarnings("deprecation")
public class SqlMapDelegacionDAO extends SqlMapDAOBase implements DelegacionDAO {

    public SqlMapDelegacionDAO() {
        super();
    }
    
    @Override
    public int countByExample(DelegacionExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t1595delega.countByExample", example);
    }
    
    @Override
    public int deleteByExample(DelegacionExample example) {
    	return getSqlMapClientTemplate().delete("t1595delega.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(DelegacionKey key) {
    	return getSqlMapClientTemplate().delete("t1595delega.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(Delegacion record) {
        getSqlMapClientTemplate().insert("t1595delega.insert", record);
    }
    
    @Override
    public void insertSelective(Delegacion record) {
        getSqlMapClientTemplate().insert("t1595delega.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Delegacion> selectByExample(DelegacionExample example) {
    	return getSqlMapClientTemplate().queryForList("t1595delega.selectByExample", example);
    }
    
    @Override
    public Delegacion selectByPrimaryKey(DelegacionKey key) {
    	return (Delegacion) getSqlMapClientTemplate().queryForObject("t1595delega.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(Delegacion record, DelegacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t1595delega.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Delegacion record, DelegacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t1595delega.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(Delegacion record) {
    	return getSqlMapClientTemplate().update("t1595delega.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(Delegacion record) {
    	return getSqlMapClientTemplate().update("t1595delega.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends DelegacionExample {
        private Object record;

        public UpdateByExampleParms(Object record, DelegacionExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}