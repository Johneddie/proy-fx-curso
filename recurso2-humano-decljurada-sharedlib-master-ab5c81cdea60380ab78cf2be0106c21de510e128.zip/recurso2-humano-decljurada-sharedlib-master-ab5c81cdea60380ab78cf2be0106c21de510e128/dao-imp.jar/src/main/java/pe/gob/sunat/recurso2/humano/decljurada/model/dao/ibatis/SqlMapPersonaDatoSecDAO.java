package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaDatoSec;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaDatoSecExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaDatoSecDAO;

@SuppressWarnings("deprecation")
public class SqlMapPersonaDatoSecDAO extends SqlMapDAOBase implements PersonaDatoSecDAO {

    public SqlMapPersonaDatoSecDAO() {
        super();
    }
    
    @Override
    public int countByExample(PersonaDatoSecExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t03perds.countByExample", example);
    }
    
    @Override
    public int deleteByExample(PersonaDatoSecExample example) {
    	return getSqlMapClientTemplate().delete("t03perds.deleteByExample", example);
    }
    
    @Override
    public void insert(PersonaDatoSec record) {
        getSqlMapClientTemplate().insert("t03perds.insert", record);
    }
    
    @Override
    public void insertSelective(PersonaDatoSec record) {
        getSqlMapClientTemplate().insert("t03perds.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<PersonaDatoSec> selectByExample(PersonaDatoSecExample example) {
    	return getSqlMapClientTemplate().queryForList("t03perds.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(PersonaDatoSec record, PersonaDatoSecExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t03perds.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(PersonaDatoSec record, PersonaDatoSecExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t03perds.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends PersonaDatoSecExample {
        private Object record;

        public UpdateByExampleParms(Object record, PersonaDatoSecExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}