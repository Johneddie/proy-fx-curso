package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Formacion;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.FormacionDAO;

@SuppressWarnings("deprecation")
public class SqlMapFormacionDAO extends SqlMapDAOBase implements FormacionDAO {

    public SqlMapFormacionDAO() {
        super();
    }
    
    @Override
    public int countByExample(FormacionExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t29perac.countByExample", example);
    }
    
    @Override
    public int deleteByExample(FormacionExample example) {
    	return getSqlMapClientTemplate().delete("t29perac.deleteByExample", example);
    }
    
    @Override
    public void insert(Formacion record) {
        getSqlMapClientTemplate().insert("t29perac.insert", record);
    }
    
    @Override
    public void insertSelective(Formacion record) {
        getSqlMapClientTemplate().insert("t29perac.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Formacion> selectByExample(FormacionExample example) {
    	return getSqlMapClientTemplate().queryForList("t29perac.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(Formacion record, FormacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t29perac.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Formacion record, FormacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t29perac.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends FormacionExample {
        private Object record;

        public UpdateByExampleParms(Object record, FormacionExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}