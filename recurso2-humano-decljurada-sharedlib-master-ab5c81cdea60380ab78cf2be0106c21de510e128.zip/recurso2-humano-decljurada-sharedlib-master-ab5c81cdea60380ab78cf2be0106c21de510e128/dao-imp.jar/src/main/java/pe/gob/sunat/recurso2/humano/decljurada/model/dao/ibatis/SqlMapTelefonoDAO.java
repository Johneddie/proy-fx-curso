package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Telefono;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.TelefonoDAO;

@SuppressWarnings("deprecation")
public class SqlMapTelefonoDAO extends SqlMapDAOBase implements TelefonoDAO {

    public SqlMapTelefonoDAO() {
        super();
    }
    
    @Override
    public int countByExample(TelefonoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t28perte.countByExample", example);
    }
    
    @Override
    public int deleteByExample(TelefonoExample example) {
    	return getSqlMapClientTemplate().delete("t28perte.deleteByExample", example);
    }

    @Override
    public void insert(Telefono record) {
        getSqlMapClientTemplate().insert("t28perte.insert", record);
    }

    @Override
    public void insertSelective(Telefono record) {
        getSqlMapClientTemplate().insert("t28perte.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Telefono> selectByExample(TelefonoExample example) {
    	return getSqlMapClientTemplate().queryForList("t28perte.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(Telefono record, TelefonoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t28perte.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Telefono record, TelefonoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t28perte.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends TelefonoExample {
        private Object record;

        public UpdateByExampleParms(Object record, TelefonoExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}