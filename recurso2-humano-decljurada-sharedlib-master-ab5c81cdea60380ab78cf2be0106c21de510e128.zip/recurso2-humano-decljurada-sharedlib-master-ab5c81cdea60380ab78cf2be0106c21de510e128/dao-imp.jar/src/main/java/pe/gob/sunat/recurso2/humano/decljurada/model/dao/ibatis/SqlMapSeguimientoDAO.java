package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Seguimiento;
import pe.gob.sunat.recurso2.humano.decljurada.model.SeguimientoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.SeguimientoKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.SeguimientoDAO;

@SuppressWarnings("deprecation")
public class SqlMapSeguimientoDAO extends SqlMapDAOBase implements SeguimientoDAO {

    public SqlMapSeguimientoDAO() {
        super();
    }
    
    @Override
    public int countByExample(SeguimientoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4878ddjjsegui.countByExample", example);
    }	
    
    @Override
    public int deleteByExample(SeguimientoExample example) {
    	return getSqlMapClientTemplate().delete("t4878ddjjsegui.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(SeguimientoKey key) {
    	return getSqlMapClientTemplate().delete("t4878ddjjsegui.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(Seguimiento record) {
        getSqlMapClientTemplate().insert("t4878ddjjsegui.insert", record);
    }
    
    @Override
    public void insertSelective(Seguimiento record) {
        getSqlMapClientTemplate().insert("t4878ddjjsegui.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Seguimiento> selectByExample(SeguimientoExample example) {
    	return getSqlMapClientTemplate().queryForList("t4878ddjjsegui.selectByExample", example);
    }
    
    @Override
    public Seguimiento selectByPrimaryKey(SeguimientoKey key) {
    	return (Seguimiento) getSqlMapClientTemplate().queryForObject("t4878ddjjsegui.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(Seguimiento record, SeguimientoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4878ddjjsegui.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Seguimiento record, SeguimientoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4878ddjjsegui.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(Seguimiento record) {
    	return getSqlMapClientTemplate().update("t4878ddjjsegui.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(Seguimiento record) {
    	return getSqlMapClientTemplate().update("t4878ddjjsegui.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends SeguimientoExample {
        private Object record;

        public UpdateByExampleParms(Object record, SeguimientoExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
    @Override
    public Seguimiento selectByExampleFirst(SeguimientoExample example) {
    	return (Seguimiento)getSqlMapClientTemplate().queryForObject("t4878ddjjsegui.selectByExampleFirst", example);
    }
    
    @SuppressWarnings("unchecked")
	@Override
    public List<Seguimiento> listarSeguimientos(Map<String, Object> params) {
    	return getSqlMapClientTemplate().queryForList("t4878ddjjsegui.listarSeguimientos", params);
    }
}