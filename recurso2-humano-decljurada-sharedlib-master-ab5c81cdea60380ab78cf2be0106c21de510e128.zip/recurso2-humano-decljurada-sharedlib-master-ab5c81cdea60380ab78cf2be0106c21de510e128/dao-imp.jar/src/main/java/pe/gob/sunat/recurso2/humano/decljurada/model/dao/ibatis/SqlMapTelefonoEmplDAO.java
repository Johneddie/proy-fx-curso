package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoEmpl;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoEmplExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoEmplKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.TelefonoEmplDAO;

@SuppressWarnings("deprecation")
public class SqlMapTelefonoEmplDAO extends SqlMapDAOBase implements TelefonoEmplDAO {

    public SqlMapTelefonoEmplDAO() {
        super();
    }
    
    @Override
    public int countByExample(TelefonoEmplExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("telefonos.countByExample", example);
    }
    
    @Override
    public int deleteByExample(TelefonoEmplExample example) {
    	return getSqlMapClientTemplate().delete("telefonos.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(TelefonoEmplKey key) {
    	return getSqlMapClientTemplate().delete("telefonos.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(TelefonoEmpl record) {
        getSqlMapClientTemplate().insert("telefonos.insert", record);
    }
    
    @Override
    public void insertSelective(TelefonoEmpl record) {
        getSqlMapClientTemplate().insert("telefonos.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<TelefonoEmpl> selectByExample(TelefonoEmplExample example) {
    	return getSqlMapClientTemplate().queryForList("telefonos.selectByExample", example);
    }
    
    @Override
    public TelefonoEmpl selectByPrimaryKey(TelefonoEmplKey key) {
    	return (TelefonoEmpl) getSqlMapClientTemplate().queryForObject("telefonos.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(TelefonoEmpl record, TelefonoEmplExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("telefonos.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(TelefonoEmpl record, TelefonoEmplExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("telefonos.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(TelefonoEmpl record) {
    	return getSqlMapClientTemplate().update("telefonos.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(TelefonoEmpl record) {
    	return getSqlMapClientTemplate().update("telefonos.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends TelefonoEmplExample {
        private Object record;

        public UpdateByExampleParms(Object record, TelefonoEmplExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}