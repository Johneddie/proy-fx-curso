package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Correo;
import pe.gob.sunat.recurso2.humano.decljurada.model.CorreoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.CorreoDAO;

@SuppressWarnings("deprecation")
public class SqlMapCorreoDAO extends SqlMapDAOBase implements CorreoDAO {

    public SqlMapCorreoDAO() {
        super();
    }
    
    @Override
    public int countByExample(CorreoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("correos.countByExample", example);
    }
    
    @Override
    public int deleteByExample(CorreoExample example) {
    	return getSqlMapClientTemplate().delete("correos.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(String codPers) {
        Correo key = new Correo();
        key.setCodPers(codPers);
        return getSqlMapClientTemplate().delete("correos.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(Correo record) {
        getSqlMapClientTemplate().insert("correos.insert", record);
    }
    
    @Override
    public void insertSelective(Correo record) {
        getSqlMapClientTemplate().insert("correos.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Correo> selectByExample(CorreoExample example) {
    	return getSqlMapClientTemplate().queryForList("correos.selectByExample", example);
    }
    
    @Override
    public Correo selectByPrimaryKey(String codPers) {
        Correo key = new Correo();
        key.setCodPers(codPers);
        return (Correo) getSqlMapClientTemplate().queryForObject("correos.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(Correo record, CorreoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("correos.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Correo record, CorreoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("correos.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(Correo record) {
    	return getSqlMapClientTemplate().update("correos.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(Correo record) {
    	return getSqlMapClientTemplate().update("correos.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends CorreoExample {
        private Object record;

        public UpdateByExampleParms(Object record, CorreoExample example) {
            super(example);
            this.record = record;
        }
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}