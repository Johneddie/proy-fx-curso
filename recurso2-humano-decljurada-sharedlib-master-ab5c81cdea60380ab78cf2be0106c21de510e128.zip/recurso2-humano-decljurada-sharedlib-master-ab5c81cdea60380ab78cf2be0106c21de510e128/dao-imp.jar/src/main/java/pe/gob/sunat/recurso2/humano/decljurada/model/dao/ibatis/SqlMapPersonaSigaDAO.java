package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaSiga;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaSigaExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaSigaDAO;

@SuppressWarnings("deprecation")
public class SqlMapPersonaSigaDAO extends SqlMapDAOBase implements PersonaSigaDAO {

    public SqlMapPersonaSigaDAO() {
        super();
    }
    
    @Override
    public int countByExample(PersonaSigaExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("MAESTRO_PERSONAL.countByExample", example);
    }
    
    @Override
    public int deleteByExample(PersonaSigaExample example) {
    	return getSqlMapClientTemplate().delete("MAESTRO_PERSONAL.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(String codiEmplPer) {
        PersonaSiga key = new PersonaSiga();
        key.setCodiEmplPer(codiEmplPer);
        return getSqlMapClientTemplate().delete("MAESTRO_PERSONAL.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(PersonaSiga record) {
        getSqlMapClientTemplate().insert("MAESTRO_PERSONAL.insert", record);
    }
    
    @Override
    public void insertSelective(PersonaSiga record) {
        getSqlMapClientTemplate().insert("MAESTRO_PERSONAL.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<PersonaSiga> selectByExample(PersonaSigaExample example) {
    	return getSqlMapClientTemplate().queryForList("MAESTRO_PERSONAL.selectByExample", example);
    }
    
    @Override
    public PersonaSiga selectByPrimaryKey(String codiEmplPer) {
        PersonaSiga key = new PersonaSiga();
        key.setCodiEmplPer(codiEmplPer);
        return (PersonaSiga) getSqlMapClientTemplate().queryForObject("MAESTRO_PERSONAL.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(PersonaSiga record, PersonaSigaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("MAESTRO_PERSONAL.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(PersonaSiga record, PersonaSigaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("MAESTRO_PERSONAL.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(PersonaSiga record) {
    	return getSqlMapClientTemplate().update("MAESTRO_PERSONAL.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(PersonaSiga record) {
    	return getSqlMapClientTemplate().update("MAESTRO_PERSONAL.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends PersonaSigaExample {
        private Object record;

        public UpdateByExampleParms(Object record, PersonaSigaExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}