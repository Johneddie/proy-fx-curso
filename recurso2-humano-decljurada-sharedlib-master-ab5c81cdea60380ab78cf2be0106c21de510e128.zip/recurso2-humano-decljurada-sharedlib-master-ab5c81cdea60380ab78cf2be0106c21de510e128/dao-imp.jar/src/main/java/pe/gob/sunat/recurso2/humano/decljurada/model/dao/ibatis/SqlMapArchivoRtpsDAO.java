package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.Date;
import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoRtpsWithBLOBs;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.ArchivoRtpsDAO;

@SuppressWarnings("deprecation")
public class SqlMapArchivoRtpsDAO extends SqlMapDAOBase implements ArchivoRtpsDAO {

    public SqlMapArchivoRtpsDAO() {
        super();
    }

    @Override
    public int countByExample(ArchivoRtpsExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4882archtregistro.countByExample", example);
    }

    @Override
    public int deleteByExample(ArchivoRtpsExample example) {
    	return getSqlMapClientTemplate().delete("t4882archtregistro.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(Date fecProceso) {
        ArchivoRtps key = new ArchivoRtps();
        key.setFecProceso(fecProceso);
        return getSqlMapClientTemplate().delete("t4882archtregistro.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(ArchivoRtpsWithBLOBs record) {
        getSqlMapClientTemplate().insert("t4882archtregistro.insert", record);
    }

    @Override
    public void insertSelective(ArchivoRtpsWithBLOBs record) {
        getSqlMapClientTemplate().insert("t4882archtregistro.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ArchivoRtpsWithBLOBs> selectByExampleWithBLOBs(ArchivoRtpsExample example) {
    	return getSqlMapClientTemplate().queryForList("t4882archtregistro.selectByExampleWithBLOBs", example);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ArchivoRtps> selectByExampleWithoutBLOBs(ArchivoRtpsExample example) {
    	return getSqlMapClientTemplate().queryForList("t4882archtregistro.selectByExample", example);
    }

    @Override
    public ArchivoRtpsWithBLOBs selectByPrimaryKey(Date fecProceso) {
        ArchivoRtps key = new ArchivoRtps();
        key.setFecProceso(fecProceso);
        return (ArchivoRtpsWithBLOBs) getSqlMapClientTemplate().queryForObject("t4882archtregistro.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(ArchivoRtpsWithBLOBs record, ArchivoRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4882archtregistro.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(ArchivoRtpsWithBLOBs record, ArchivoRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4882archtregistro.updateByExampleWithBLOBs", parms);
    }

    @Override
    public int updateByExample(ArchivoRtps record, ArchivoRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4882archtregistro.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(ArchivoRtpsWithBLOBs record) {
    	return getSqlMapClientTemplate().update("t4882archtregistro.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKey(ArchivoRtpsWithBLOBs record) {
    	return getSqlMapClientTemplate().update("t4882archtregistro.updateByPrimaryKeyWithBLOBs", record);
    }

    @Override
    public int updateByPrimaryKey(ArchivoRtps record) {
    	return getSqlMapClientTemplate().update("t4882archtregistro.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends ArchivoRtpsExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoRtpsExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
}