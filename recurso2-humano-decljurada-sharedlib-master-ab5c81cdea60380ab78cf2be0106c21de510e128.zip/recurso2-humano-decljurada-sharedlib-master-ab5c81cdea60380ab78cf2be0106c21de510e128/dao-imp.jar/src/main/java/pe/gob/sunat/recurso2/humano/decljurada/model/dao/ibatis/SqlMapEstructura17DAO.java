package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura17;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura17Example;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.Estructura17DAO;

@SuppressWarnings("deprecation")
public class SqlMapEstructura17DAO extends SqlMapDAOBase implements Estructura17DAO {

    public SqlMapEstructura17DAO() {
        super();
    }
    
    @Override
    public int countByExample(Estructura17Example example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4949tregisimp17.countByExample", example);
    }
    
    @Override
    public int deleteByExample(Estructura17Example example) {
    	return getSqlMapClientTemplate().delete("t4949tregisimp17.deleteByExample", example);
    }
    
    @Override
    public void insert(Estructura17 record) {
        getSqlMapClientTemplate().insert("t4949tregisimp17.insert", record);
    }
    
    @Override
    public void insertSelective(Estructura17 record) {
        getSqlMapClientTemplate().insert("t4949tregisimp17.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Estructura17> selectByExample(Estructura17Example example) {
    	return getSqlMapClientTemplate().queryForList("t4949tregisimp17.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(Estructura17 record, Estructura17Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4949tregisimp17.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Estructura17 record, Estructura17Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4949tregisimp17.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends Estructura17Example {
        private Object record;

        public UpdateByExampleParms(Object record, Estructura17Example example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}