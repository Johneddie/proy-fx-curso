package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.FichaHistorico;
import pe.gob.sunat.recurso2.humano.decljurada.model.FichaHistoricoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.FichaHistoricoKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.FichaHistoricoDAO;

@SuppressWarnings("deprecation")
public class SqlMapFichaHistoricoDAO extends SqlMapDAOBase implements FichaHistoricoDAO {

    public SqlMapFichaHistoricoDAO() {
        super();
    }

    @Override
    public int countByExample(FichaHistoricoExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t8334fichadatosh.countByExample", example);
    }

    @Override
    public int deleteByExample(FichaHistoricoExample example) {
    	return getSqlMapClientTemplate().delete("t8334fichadatosh.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(FichaHistoricoKey key) {
    	return getSqlMapClientTemplate().delete("t8334fichadatosh.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(FichaHistorico record) {
        getSqlMapClientTemplate().insert("t8334fichadatosh.insert", record);
    }

    @Override
    public void insertSelective(FichaHistorico record) {
        getSqlMapClientTemplate().insert("t8334fichadatosh.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<FichaHistorico> selectByExample(FichaHistoricoExample example) {
    	return getSqlMapClientTemplate().queryForList("t8334fichadatosh.selectByExample", example);
    }

    @Override
    public FichaHistorico selectByPrimaryKey(FichaHistoricoKey key) {
    	return (FichaHistorico) getSqlMapClientTemplate().queryForObject("t8334fichadatosh.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(FichaHistorico record, FichaHistoricoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8334fichadatosh.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(FichaHistorico record, FichaHistoricoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8334fichadatosh.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(FichaHistorico record) {
    	return getSqlMapClientTemplate().update("t8334fichadatosh.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKey(FichaHistorico record) {
    	return getSqlMapClientTemplate().update("t8334fichadatosh.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends FichaHistoricoExample {
        private Object record;

        public UpdateByExampleParms(Object record, FichaHistoricoExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
    @Override
    public FichaHistorico obtenerFichaHistoricoByDocumento(FichaHistorico documento) {
    	return (FichaHistorico)getSqlMapClientTemplate().queryForObject("t8334fichadatosh.obtenerFichaHistoricoByDocumento", documento);
    }
}