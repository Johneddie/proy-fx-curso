package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura11;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura11Example;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.Estructura11DAO;

@SuppressWarnings("deprecation")
public class SqlMapEstructura11DAO extends SqlMapDAOBase implements Estructura11DAO {

    public SqlMapEstructura11DAO() {
        super();
    }
    
    @Override
    public int countByExample(Estructura11Example example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4947tregisimp11.countByExample", example);
    }
    
    @Override
    public int deleteByExample(Estructura11Example example) {
    	return getSqlMapClientTemplate().delete("t4947tregisimp11.deleteByExample", example);
    }
    
    @Override
    public void insert(Estructura11 record) {
        getSqlMapClientTemplate().insert("t4947tregisimp11.insert", record);
    }
    
    @Override
    public void insertSelective(Estructura11 record) {
        getSqlMapClientTemplate().insert("t4947tregisimp11.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Estructura11> selectByExample(Estructura11Example example) {
    	return getSqlMapClientTemplate().queryForList("t4947tregisimp11.selectByExample", example);
    }
    
    @Override
    public int updateByExampleSelective(Estructura11 record, Estructura11Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4947tregisimp11.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Estructura11 record, Estructura11Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4947tregisimp11.updateByExample", parms);
    }

    private static class UpdateByExampleParms extends Estructura11Example {
        private Object record;

        public UpdateByExampleParms(Object record, Estructura11Example example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}