package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtpsKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtpsWithBLOBs;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.PersonaRtpsDAO;

@SuppressWarnings("deprecation")
public class SqlMapPersonaRtpsDAO extends SqlMapDAOBase implements PersonaRtpsDAO {

    public SqlMapPersonaRtpsDAO() {
        super();
    }
    
    @Override
    public int countByExample(PersonaRtpsExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t733pernat.countByExample", example);
    }

    @Override
    public int deleteByExample(PersonaRtpsExample example) {
    	return getSqlMapClientTemplate().delete("t733pernat.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(PersonaRtpsKey key) {
    	return getSqlMapClientTemplate().delete("t733pernat.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(PersonaRtpsWithBLOBs record) {
        getSqlMapClientTemplate().insert("t733pernat.insert", record);
    }

    @Override
    public void insertSelective(PersonaRtpsWithBLOBs record) {
        getSqlMapClientTemplate().insert("t733pernat.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<PersonaRtpsWithBLOBs> selectByExampleWithBLOBs(PersonaRtpsExample example) {
    	return getSqlMapClientTemplate().queryForList("t733pernat.selectByExampleWithBLOBs", example);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<PersonaRtps> selectByExampleWithoutBLOBs(PersonaRtpsExample example) {
    	return getSqlMapClientTemplate().queryForList("t733pernat.selectByExample", example);
    }

    @Override
    public PersonaRtpsWithBLOBs selectByPrimaryKey(PersonaRtpsKey key) {
    	return (PersonaRtpsWithBLOBs) getSqlMapClientTemplate().queryForObject("t733pernat.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(PersonaRtpsWithBLOBs record, PersonaRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t733pernat.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(PersonaRtpsWithBLOBs record, PersonaRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t733pernat.updateByExampleWithBLOBs", parms);
    }

    @Override
    public int updateByExample(PersonaRtps record, PersonaRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t733pernat.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(PersonaRtpsWithBLOBs record) {
    	return getSqlMapClientTemplate().update("t733pernat.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKey(PersonaRtpsWithBLOBs record) {
    	return getSqlMapClientTemplate().update("t733pernat.updateByPrimaryKeyWithBLOBs", record);
    }

    @Override
    public int updateByPrimaryKey(PersonaRtps record) {
    	return getSqlMapClientTemplate().update("t733pernat.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends PersonaRtpsExample {
        private Object record;

        public UpdateByExampleParms(Object record, PersonaRtpsExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}