package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura13;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura13Example;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.Estructura13DAO;

@SuppressWarnings("deprecation")
public class SqlMapEstructura13DAO extends SqlMapDAOBase implements Estructura13DAO {

    public SqlMapEstructura13DAO() {
        super();
    }
    
    @Override
    public int countByExample(Estructura13Example example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4948tregisimp13.countByExample", example);
    }
    
    @Override
    public int deleteByExample(Estructura13Example example) {
    	return getSqlMapClientTemplate().delete("t4948tregisimp13.deleteByExample", example);
    }
    
    @Override
    public void insert(Estructura13 record) {
        getSqlMapClientTemplate().insert("t4948tregisimp13.insert", record);
    }
    
    @Override
    public void insertSelective(Estructura13 record) {
        getSqlMapClientTemplate().insert("t4948tregisimp13.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Estructura13> selectByExample(Estructura13Example example) {
    	return getSqlMapClientTemplate().queryForList("t4948tregisimp13.selectByExample", example);
    }	
    
    @Override
    public int updateByExampleSelective(Estructura13 record, Estructura13Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4948tregisimp13.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(Estructura13 record, Estructura13Example example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4948tregisimp13.updateByExample", parms);
    }
    
    private static class UpdateByExampleParms extends Estructura13Example {
        private Object record;

        public UpdateByExampleParms(Object record, Estructura13Example example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}