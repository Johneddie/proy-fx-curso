package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohab;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DeclaraDerechohabDAO;

@SuppressWarnings("deprecation")
public class SqlMapDeclaraDerechohabDAO extends SqlMapDAOBase implements DeclaraDerechohabDAO {

    public SqlMapDeclaraDerechohabDAO() {
        super();
    }
    
    @Override
    public int countByExample(DeclaraDerechohabExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4880derechohab.countByExample", example);
    }
    
    @Override
    public int deleteByExample(DeclaraDerechohabExample example) {
    	return getSqlMapClientTemplate().delete("t4880derechohab.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(DeclaraDerechohabKey key) {
    	return getSqlMapClientTemplate().delete("t4880derechohab.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(DeclaraDerechohab record) {
        getSqlMapClientTemplate().insert("t4880derechohab.insert", record);
    }
    
    @Override
    public void insertSelective(DeclaraDerechohab record) {
        getSqlMapClientTemplate().insert("t4880derechohab.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<DeclaraDerechohab> selectByExample(DeclaraDerechohabExample example) {
    	return getSqlMapClientTemplate().queryForList("t4880derechohab.selectByExample", example);
    }
    
    @Override
    public DeclaraDerechohab selectByPrimaryKey(DeclaraDerechohabKey key) {
    	return (DeclaraDerechohab) getSqlMapClientTemplate().queryForObject("t4880derechohab.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(DeclaraDerechohab record, DeclaraDerechohabExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4880derechohab.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(DeclaraDerechohab record, DeclaraDerechohabExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4880derechohab.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(DeclaraDerechohab record) {
    	return getSqlMapClientTemplate().update("t4880derechohab.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(DeclaraDerechohab record) {
    	return getSqlMapClientTemplate().update("t4880derechohab.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends DeclaraDerechohabExample {
        private Object record;

        public UpdateByExampleParms(Object record, DeclaraDerechohabExample example) {
            super(example);
            this.record = record;
        }
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
    
    //personalizado
    
    @SuppressWarnings("unchecked")
	@Override
    public List<DeclaraDerechohab> listarUltimasDeclaraciones(DeclaraDerechohab params) {
    	List<DeclaraDerechohab> lstDeclaracionesRpt = new ArrayList<>();
    	List<DeclaraDerechohab> lstDeclaraciones = getSqlMapClientTemplate().queryForList("t4880derechohab.listarUltimasDeclaraciones", params);
    	if(!lstDeclaraciones.isEmpty()){
    		String numDocumDer = lstDeclaraciones.get(0).getNumDocumDer();
    		lstDeclaracionesRpt.add(lstDeclaraciones.get(0));
    		for(DeclaraDerechohab d:lstDeclaraciones){
    			if(!numDocumDer.equals(d.getNumDocumDer())){
    				lstDeclaracionesRpt.add(d);
    				numDocumDer = d.getNumDocumDer();
    			}
	    	}
    	}
    	return lstDeclaracionesRpt;
    }
}