package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSel;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSelExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSelKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.DerechohabSelDAO;

@SuppressWarnings("deprecation")
public class SqlMapDerechohabSelDAO extends SqlMapDAOBase implements DerechohabSelDAO {

    public SqlMapDerechohabSelDAO() {
        super();
    }

    @Override
    public int countByExample(DerechohabSelExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t9491derechohab.countByExample", example);
    }

    @Override
    public int deleteByExample(DerechohabSelExample example) {
    	return getSqlMapClientTemplate().delete("t9491derechohab.deleteByExample", example);
    }

    @Override
    public int deleteByPrimaryKey(DerechohabSelKey key) {
    	return getSqlMapClientTemplate().delete("t9491derechohab.deleteByPrimaryKey", key);
    }

    @Override
    public void insert(DerechohabSel record) {
        getSqlMapClientTemplate().insert("t9491derechohab.insert", record);
    }

    @Override
    public void insertSelective(DerechohabSel record) {
        getSqlMapClientTemplate().insert("t9491derechohab.insertSelective", record);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<DerechohabSel> selectByExample(DerechohabSelExample example) {
    	return getSqlMapClientTemplate().queryForList("t9491derechohab.selectByExample", example);
    }

    @Override
    public DerechohabSel selectByPrimaryKey(DerechohabSelKey key) {
    	return (DerechohabSel) getSqlMapClientTemplate().queryForObject("t9491derechohab.selectByPrimaryKey", key);
    }

    @Override
    public int updateByExampleSelective(DerechohabSel record, DerechohabSelExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t9491derechohab.updateByExampleSelective", parms);
    }

    @Override
    public int updateByExample(DerechohabSel record, DerechohabSelExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t9491derechohab.updateByExample", parms);
    }

    @Override
    public int updateByPrimaryKeySelective(DerechohabSel record) {
    	return getSqlMapClientTemplate().update("t9491derechohab.updateByPrimaryKeySelective", record);
    }

    @Override
    public int updateByPrimaryKey(DerechohabSel record) {
    	return getSqlMapClientTemplate().update("t9491derechohab.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends DerechohabSelExample {
        private Object record;

        public UpdateByExampleParms(Object record, DerechohabSelExample example) {
            super(example);
            this.record = record;
        }

        @SuppressWarnings("unused")
		public Object getRecord() {
            return record;
        }
    }
}