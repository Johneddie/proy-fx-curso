package pe.gob.sunat.recurso2.humano.decljurada.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionRtpsKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.dao.FormacionRtpsDAO;

@SuppressWarnings("deprecation")
public class SqlMapFormacionRtpsDAO extends SqlMapDAOBase implements FormacionRtpsDAO {

    public SqlMapFormacionRtpsDAO() {
        super();
    }

    @Override
    public int countByExample(FormacionRtpsExample example) {
    	return (Integer)  getSqlMapClientTemplate().queryForObject("t4881formacad.countByExample", example);
    }
    
    @Override
    public int deleteByExample(FormacionRtpsExample example) {
    	return getSqlMapClientTemplate().delete("t4881formacad.deleteByExample", example);
    }
    
    @Override
    public int deleteByPrimaryKey(FormacionRtpsKey key) {
    	return getSqlMapClientTemplate().delete("t4881formacad.deleteByPrimaryKey", key);
    }
    
    @Override
    public void insert(FormacionRtps record) {
        getSqlMapClientTemplate().insert("t4881formacad.insert", record);
    }
    
    @Override
    public void insertSelective(FormacionRtps record) {
        getSqlMapClientTemplate().insert("t4881formacad.insertSelective", record);
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<FormacionRtps> selectByExample(FormacionRtpsExample example) {
    	return getSqlMapClientTemplate().queryForList("t4881formacad.selectByExample", example);
    }
    
    @Override
    public FormacionRtps selectByPrimaryKey(FormacionRtpsKey key) {
    	return (FormacionRtps) getSqlMapClientTemplate().queryForObject("t4881formacad.selectByPrimaryKey", key);
    }
    
    @Override
    public int updateByExampleSelective(FormacionRtps record, FormacionRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4881formacad.updateByExampleSelective", parms);
    }
    
    @Override
    public int updateByExample(FormacionRtps record, FormacionRtpsExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t4881formacad.updateByExample", parms);
    }
    
    @Override
    public int updateByPrimaryKeySelective(FormacionRtps record) {
    	return getSqlMapClientTemplate().update("t4881formacad.updateByPrimaryKeySelective", record);
    }
    
    @Override
    public int updateByPrimaryKey(FormacionRtps record) {
    	return getSqlMapClientTemplate().update("t4881formacad.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends FormacionRtpsExample {
        private Object record;

        public UpdateByExampleParms(Object record, FormacionRtpsExample example) {
            super(example);
            this.record = record;
        }
        
        @SuppressWarnings("unused")
        public Object getRecord() {
            return record;
        }
    }
}