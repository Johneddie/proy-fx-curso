package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoEmpl;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoEmplExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoEmplKey;

public interface TelefonoEmplDAO {
    int countByExample(TelefonoEmplExample example);

    int deleteByExample(TelefonoEmplExample example);

    int deleteByPrimaryKey(TelefonoEmplKey key);

    void insert(TelefonoEmpl record);

    void insertSelective(TelefonoEmpl record);

    List<TelefonoEmpl> selectByExample(TelefonoEmplExample example);

    TelefonoEmpl selectByPrimaryKey(TelefonoEmplKey key);

    int updateByExampleSelective(TelefonoEmpl record, TelefonoEmplExample example);

    int updateByExample(TelefonoEmpl record, TelefonoEmplExample example);

    int updateByPrimaryKeySelective(TelefonoEmpl record);

    int updateByPrimaryKey(TelefonoEmpl record);
}