package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.Date;
import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoRtpsWithBLOBs;

public interface ArchivoRtpsDAO {
    int countByExample(ArchivoRtpsExample example);

    int deleteByExample(ArchivoRtpsExample example);

    int deleteByPrimaryKey(Date fecProceso);

    void insert(ArchivoRtpsWithBLOBs record);

    void insertSelective(ArchivoRtpsWithBLOBs record);

    List<ArchivoRtpsWithBLOBs> selectByExampleWithBLOBs(ArchivoRtpsExample example);

    List<ArchivoRtps> selectByExampleWithoutBLOBs(ArchivoRtpsExample example);

    ArchivoRtpsWithBLOBs selectByPrimaryKey(Date fecProceso);

    int updateByExampleSelective(ArchivoRtpsWithBLOBs record, ArchivoRtpsExample example);

    int updateByExample(ArchivoRtpsWithBLOBs record, ArchivoRtpsExample example);

    int updateByExample(ArchivoRtps record, ArchivoRtpsExample example);

    int updateByPrimaryKeySelective(ArchivoRtpsWithBLOBs record);

    int updateByPrimaryKey(ArchivoRtpsWithBLOBs record);

    int updateByPrimaryKey(ArchivoRtps record);
}