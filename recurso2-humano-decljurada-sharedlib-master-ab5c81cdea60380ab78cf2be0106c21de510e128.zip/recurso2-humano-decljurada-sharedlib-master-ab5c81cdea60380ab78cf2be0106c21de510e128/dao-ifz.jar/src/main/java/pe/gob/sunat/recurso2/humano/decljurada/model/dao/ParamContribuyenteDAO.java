package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;

public interface ParamContribuyenteDAO {

	List<Parametro> listarDepartamentos();
	List<Parametro> listarProvincias(String codDepartamento);
	List<Parametro> listarDistritos(String codProvincia);
	List<Parametro> listarCodigosLDN();
	List<Parametro> listarTiposDocumento();
	List<Parametro> listarNacionalidades();
	List<Parametro> listarTiposVia();
	List<Parametro> listarTiposZona();
	String obtenerUbigeoReniec(String ubigeoSunat);
	String obtenerUbigeoSunat(String ubigeoReniec);
	List<Parametro> listarPaisesEmisor();
	
}
