package pe.gob.sunat.recurso2.humano.decljurada.model.dao;


public interface ParamRrhhDAO {

	public String obtenerDesUbigeoSunat(String codigo);

}
