package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Persona;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaExample;

public interface PersonaDAO {
    int countByExample(PersonaExample example);

    int deleteByExample(PersonaExample example);

    int deleteByPrimaryKey(String t02codPers);

    void insert(Persona record);

    void insertSelective(Persona record);

    List<Persona> selectByExample(PersonaExample example);

    Persona selectByPrimaryKey(String t02codPers);

    int updateByExampleSelective(Persona record, PersonaExample example);

    int updateByExample(Persona record, PersonaExample example);

    int updateByPrimaryKeySelective(Persona record);

    int updateByPrimaryKey(Persona record);
}