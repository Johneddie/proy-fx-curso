package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura24;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura24Example;

public interface Estructura24DAO {
    int countByExample(Estructura24Example example);

    int deleteByExample(Estructura24Example example);

    void insert(Estructura24 record);

    void insertSelective(Estructura24 record);

    List<Estructura24> selectByExample(Estructura24Example example);

    int updateByExampleSelective(Estructura24 record, Estructura24Example example);

    int updateByExample(Estructura24 record, Estructura24Example example);
}