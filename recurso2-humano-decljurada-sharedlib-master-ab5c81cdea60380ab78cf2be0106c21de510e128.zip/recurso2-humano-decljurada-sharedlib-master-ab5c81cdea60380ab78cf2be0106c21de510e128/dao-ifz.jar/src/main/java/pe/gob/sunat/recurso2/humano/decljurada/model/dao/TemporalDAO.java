package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Temporal;
import pe.gob.sunat.recurso2.humano.decljurada.model.TemporalExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.TemporalKey;

public interface TemporalDAO {
    int countByExample(TemporalExample example);

    int deleteByExample(TemporalExample example);

    int deleteByPrimaryKey(TemporalKey key);

    void insert(Temporal record);

    void insertSelective(Temporal record);

    List<Temporal> selectByExample(TemporalExample example);

    Temporal selectByPrimaryKey(TemporalKey key);

    int updateByExampleSelective(Temporal record, TemporalExample example);

    int updateByExample(Temporal record, TemporalExample example);

    int updateByPrimaryKeySelective(Temporal record);

    int updateByPrimaryKey(Temporal record);
}