package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.TipoDocumSiga;
import pe.gob.sunat.recurso2.humano.decljurada.model.TipoDocumSigaExample;

public interface TipoDocumSigaDAO {
    int countByExample(TipoDocumSigaExample example);

    int deleteByExample(TipoDocumSigaExample example);

    int deleteByPrimaryKey(String tipoDocuIde);

    void insert(TipoDocumSiga record);

    void insertSelective(TipoDocumSiga record);

    List<TipoDocumSiga> selectByExample(TipoDocumSigaExample example);

    TipoDocumSiga selectByPrimaryKey(String tipoDocuIde);

    int updateByExampleSelective(TipoDocumSiga record, TipoDocumSigaExample example);

    int updateByExample(TipoDocumSiga record, TipoDocumSigaExample example);

    int updateByPrimaryKeySelective(TipoDocumSiga record);

    int updateByPrimaryKey(TipoDocumSiga record);
}