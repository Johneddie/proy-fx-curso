package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaborador;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraColaboradorKey;

public interface DeclaraColaboradorDAO {
    int countByExample(DeclaraColaboradorExample example);

    int deleteByExample(DeclaraColaboradorExample example);

    int deleteByPrimaryKey(DeclaraColaboradorKey key);

    void insert(DeclaraColaborador record);

    void insertSelective(DeclaraColaborador record);

    List<DeclaraColaborador> selectByExample(DeclaraColaboradorExample example);

    DeclaraColaborador selectByPrimaryKey(DeclaraColaboradorKey key);

    int updateByExampleSelective(DeclaraColaborador record, DeclaraColaboradorExample example);

    int updateByExample(DeclaraColaborador record, DeclaraColaboradorExample example);

    int updateByPrimaryKeySelective(DeclaraColaborador record);

    int updateByPrimaryKey(DeclaraColaborador record);
    
    public DeclaraColaborador obtenerUltimaDeclaracion(DeclaraColaborador example);
}