package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSel;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSelExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DerechohabSelKey;

public interface DerechohabSelDAO {
    int countByExample(DerechohabSelExample example);

    int deleteByExample(DerechohabSelExample example);

    int deleteByPrimaryKey(DerechohabSelKey key);

    void insert(DerechohabSel record);

    void insertSelective(DerechohabSel record);

    List<DerechohabSel> selectByExample(DerechohabSelExample example);

    DerechohabSel selectByPrimaryKey(DerechohabSelKey key);

    int updateByExampleSelective(DerechohabSel record, DerechohabSelExample example);

    int updateByExample(DerechohabSel record, DerechohabSelExample example);

    int updateByPrimaryKeySelective(DerechohabSel record);

    int updateByPrimaryKey(DerechohabSel record);
}