package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Familiar;
import pe.gob.sunat.recurso2.humano.decljurada.model.FamiliarExample;

public interface FamiliarDAO {
    int countByExample(FamiliarExample example);

    int deleteByExample(FamiliarExample example);

    void insert(Familiar record);

    void insertSelective(Familiar record);

    List<Familiar> selectByExample(FamiliarExample example);

    int updateByExampleSelective(Familiar record, FamiliarExample example);

    int updateByExample(Familiar record, FamiliarExample example);
}