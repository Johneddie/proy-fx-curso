package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura17;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura17Example;

public interface Estructura17DAO {
    int countByExample(Estructura17Example example);

    int deleteByExample(Estructura17Example example);

    void insert(Estructura17 record);

    void insertSelective(Estructura17 record);

    List<Estructura17> selectByExample(Estructura17Example example);

    int updateByExampleSelective(Estructura17 record, Estructura17Example example);

    int updateByExample(Estructura17 record, Estructura17Example example);
}