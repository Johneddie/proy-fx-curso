package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Documento;
import pe.gob.sunat.recurso2.humano.decljurada.model.DocumentoExample;

public interface DocumentoDAO {
    int countByExample(DocumentoExample example);

    int deleteByExample(DocumentoExample example);

    void insert(Documento record);

    void insertSelective(Documento record);

    List<Documento> selectByExample(DocumentoExample example);

    int updateByExampleSelective(Documento record, DocumentoExample example);

    int updateByExample(Documento record, DocumentoExample example);
    
    public Documento obtenerDocumento(String codPersonal);
}