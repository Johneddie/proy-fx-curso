package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.LocalRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.LocalRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.LocalRtpsKey;

public interface LocalRtpsDAO {
    int countByExample(LocalRtpsExample example);

    int deleteByExample(LocalRtpsExample example);

    int deleteByPrimaryKey(LocalRtpsKey key);

    void insert(LocalRtps record);

    void insertSelective(LocalRtps record);

    List<LocalRtps> selectByExample(LocalRtpsExample example);

    LocalRtps selectByPrimaryKey(LocalRtpsKey key);

    int updateByExampleSelective(LocalRtps record, LocalRtpsExample example);

    int updateByExample(LocalRtps record, LocalRtpsExample example);

    int updateByPrimaryKeySelective(LocalRtps record);

    int updateByPrimaryKey(LocalRtps record);
}