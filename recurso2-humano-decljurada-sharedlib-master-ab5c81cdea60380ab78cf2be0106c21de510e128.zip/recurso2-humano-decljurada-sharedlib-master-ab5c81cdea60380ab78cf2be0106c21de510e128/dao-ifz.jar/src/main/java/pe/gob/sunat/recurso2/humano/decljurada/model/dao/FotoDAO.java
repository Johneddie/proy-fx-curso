package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Foto;
import pe.gob.sunat.recurso2.humano.decljurada.model.FotoExample;

public interface FotoDAO {
    int countByExample(FotoExample example);

    int deleteByExample(FotoExample example);

    int deleteByPrimaryKey(String t02codPers);

    void insert(Foto record);

    void insertSelective(Foto record);

    List<Foto> selectByExampleWithBLOBs(FotoExample example);

    List<Foto> selectByExampleWithoutBLOBs(FotoExample example);

    Foto selectByPrimaryKey(String t02codPers);

    int updateByExampleSelective(Foto record, FotoExample example);

    int updateByExampleWithBLOBs(Foto record, FotoExample example);

    int updateByExampleWithoutBLOBs(Foto record, FotoExample example);

    int updateByPrimaryKeySelective(Foto record);

    int updateByPrimaryKeyWithBLOBs(Foto record);

    int updateByPrimaryKeyWithoutBLOBs(Foto record);
}