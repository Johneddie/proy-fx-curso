package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtpsKey;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaRtpsWithBLOBs;

public interface PersonaRtpsDAO {
    int countByExample(PersonaRtpsExample example);

    int deleteByExample(PersonaRtpsExample example);

    int deleteByPrimaryKey(PersonaRtpsKey key);

    void insert(PersonaRtpsWithBLOBs record);

    void insertSelective(PersonaRtpsWithBLOBs record);

    List<PersonaRtpsWithBLOBs> selectByExampleWithBLOBs(PersonaRtpsExample example);

    List<PersonaRtps> selectByExampleWithoutBLOBs(PersonaRtpsExample example);

    PersonaRtpsWithBLOBs selectByPrimaryKey(PersonaRtpsKey key);

    int updateByExampleSelective(PersonaRtpsWithBLOBs record, PersonaRtpsExample example);

    int updateByExample(PersonaRtpsWithBLOBs record, PersonaRtpsExample example);

    int updateByExample(PersonaRtps record, PersonaRtpsExample example);

    int updateByPrimaryKeySelective(PersonaRtpsWithBLOBs record);

    int updateByPrimaryKey(PersonaRtpsWithBLOBs record);

    int updateByPrimaryKey(PersonaRtps record);
}