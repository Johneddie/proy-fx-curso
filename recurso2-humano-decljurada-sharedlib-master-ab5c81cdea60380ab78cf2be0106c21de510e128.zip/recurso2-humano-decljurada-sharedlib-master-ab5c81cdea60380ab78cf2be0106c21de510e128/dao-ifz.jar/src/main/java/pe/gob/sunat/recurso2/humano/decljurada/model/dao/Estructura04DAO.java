package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura04;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura04Example;

public interface Estructura04DAO {
    int countByExample(Estructura04Example example);

    int deleteByExample(Estructura04Example example);

    void insert(Estructura04 record);

    void insertSelective(Estructura04 record);

    List<Estructura04> selectByExample(Estructura04Example example);

    int updateByExampleSelective(Estructura04 record, Estructura04Example example);

    int updateByExample(Estructura04 record, Estructura04Example example);
}