package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.UnidadOrg;
import pe.gob.sunat.recurso2.humano.decljurada.model.UnidadOrgExample;

public interface UnidadOrgDAO {
    int countByExample(UnidadOrgExample example);

    int deleteByExample(UnidadOrgExample example);

    int deleteByPrimaryKey(String t12codUorga);

    void insert(UnidadOrg record);

    void insertSelective(UnidadOrg record);

    List<UnidadOrg> selectByExample(UnidadOrgExample example);

    UnidadOrg selectByPrimaryKey(String t12codUorga);

    int updateByExampleSelective(UnidadOrg record, UnidadOrgExample example);

    int updateByExample(UnidadOrg record, UnidadOrgExample example);

    int updateByPrimaryKeySelective(UnidadOrg record);

    int updateByPrimaryKey(UnidadOrg record);
}