package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaSiga;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaSigaExample;

public interface PersonaSigaDAO {
    int countByExample(PersonaSigaExample example);

    int deleteByExample(PersonaSigaExample example);

    int deleteByPrimaryKey(String codiEmplPer);

    void insert(PersonaSiga record);

    void insertSelective(PersonaSiga record);

    List<PersonaSiga> selectByExample(PersonaSigaExample example);

    PersonaSiga selectByPrimaryKey(String codiEmplPer);

    int updateByExampleSelective(PersonaSiga record, PersonaSigaExample example);

    int updateByExample(PersonaSiga record, PersonaSigaExample example);

    int updateByPrimaryKeySelective(PersonaSiga record);

    int updateByPrimaryKey(PersonaSiga record);
}