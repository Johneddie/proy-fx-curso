package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionRtps;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionRtpsExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionRtpsKey;

public interface FormacionRtpsDAO {
    int countByExample(FormacionRtpsExample example);

    int deleteByExample(FormacionRtpsExample example);

    int deleteByPrimaryKey(FormacionRtpsKey key);

    void insert(FormacionRtps record);

    void insertSelective(FormacionRtps record);

    List<FormacionRtps> selectByExample(FormacionRtpsExample example);

    FormacionRtps selectByPrimaryKey(FormacionRtpsKey key);

    int updateByExampleSelective(FormacionRtps record, FormacionRtpsExample example);

    int updateByExample(FormacionRtps record, FormacionRtpsExample example);

    int updateByPrimaryKeySelective(FormacionRtps record);

    int updateByPrimaryKey(FormacionRtps record);
}