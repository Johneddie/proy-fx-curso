package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura13;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura13Example;

public interface Estructura13DAO {
    int countByExample(Estructura13Example example);

    int deleteByExample(Estructura13Example example);

    void insert(Estructura13 record);

    void insertSelective(Estructura13 record);

    List<Estructura13> selectByExample(Estructura13Example example);

    int updateByExampleSelective(Estructura13 record, Estructura13Example example);

    int updateByExample(Estructura13 record, Estructura13Example example);
}