package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.FichaHistorico;
import pe.gob.sunat.recurso2.humano.decljurada.model.FichaHistoricoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.FichaHistoricoKey;

public interface FichaHistoricoDAO {
    int countByExample(FichaHistoricoExample example);

    int deleteByExample(FichaHistoricoExample example);

    int deleteByPrimaryKey(FichaHistoricoKey key);

    void insert(FichaHistorico record);

    void insertSelective(FichaHistorico record);

    List<FichaHistorico> selectByExample(FichaHistoricoExample example);

    FichaHistorico selectByPrimaryKey(FichaHistoricoKey key);

    int updateByExampleSelective(FichaHistorico record, FichaHistoricoExample example);

    int updateByExample(FichaHistorico record, FichaHistoricoExample example);

    int updateByPrimaryKeySelective(FichaHistorico record);

    int updateByPrimaryKey(FichaHistorico record);
    
    public FichaHistorico obtenerFichaHistoricoByDocumento(FichaHistorico documento);
}