package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Formacion;
import pe.gob.sunat.recurso2.humano.decljurada.model.FormacionExample;

public interface FormacionDAO {
    int countByExample(FormacionExample example);

    int deleteByExample(FormacionExample example);

    void insert(Formacion record);

    void insertSelective(Formacion record);

    List<Formacion> selectByExample(FormacionExample example);

    int updateByExampleSelective(Formacion record, FormacionExample example);

    int updateByExample(Formacion record, FormacionExample example);
}