package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.decljurada.model.Seguimiento;
import pe.gob.sunat.recurso2.humano.decljurada.model.SeguimientoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.SeguimientoKey;

public interface SeguimientoDAO {
    int countByExample(SeguimientoExample example);

    int deleteByExample(SeguimientoExample example);

    int deleteByPrimaryKey(SeguimientoKey key);

    void insert(Seguimiento record);

    void insertSelective(Seguimiento record);

    List<Seguimiento> selectByExample(SeguimientoExample example);

    Seguimiento selectByPrimaryKey(SeguimientoKey key);

    int updateByExampleSelective(Seguimiento record, SeguimientoExample example);

    int updateByExample(Seguimiento record, SeguimientoExample example);

    int updateByPrimaryKeySelective(Seguimiento record);

    int updateByPrimaryKey(Seguimiento record);
    
    public Seguimiento selectByExampleFirst(SeguimientoExample example);
    
    public List<Seguimiento> listarSeguimientos(Map<String, Object> params);
}