package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Telefono;
import pe.gob.sunat.recurso2.humano.decljurada.model.TelefonoExample;

public interface TelefonoDAO {
    int countByExample(TelefonoExample example);

    int deleteByExample(TelefonoExample example);

    void insert(Telefono record);

    void insertSelective(Telefono record);

    List<Telefono> selectByExample(TelefonoExample example);

    int updateByExampleSelective(Telefono record, TelefonoExample example);

    int updateByExample(Telefono record, TelefonoExample example);
}