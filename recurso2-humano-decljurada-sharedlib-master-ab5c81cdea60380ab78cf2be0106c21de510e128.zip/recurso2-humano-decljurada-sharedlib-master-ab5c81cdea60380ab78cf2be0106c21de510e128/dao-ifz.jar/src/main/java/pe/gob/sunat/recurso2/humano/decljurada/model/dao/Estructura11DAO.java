package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura11;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura11Example;

public interface Estructura11DAO {
    int countByExample(Estructura11Example example);

    int deleteByExample(Estructura11Example example);

    void insert(Estructura11 record);

    void insertSelective(Estructura11 record);

    List<Estructura11> selectByExample(Estructura11Example example);

    int updateByExampleSelective(Estructura11 record, Estructura11Example example);

    int updateByExample(Estructura11 record, Estructura11Example example);
}