package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Delegacion;
import pe.gob.sunat.recurso2.humano.decljurada.model.DelegacionExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DelegacionKey;

public interface DelegacionDAO {
    int countByExample(DelegacionExample example);

    int deleteByExample(DelegacionExample example);

    int deleteByPrimaryKey(DelegacionKey key);

    void insert(Delegacion record);

    void insertSelective(Delegacion record);

    List<Delegacion> selectByExample(DelegacionExample example);

    Delegacion selectByPrimaryKey(DelegacionKey key);

    int updateByExampleSelective(Delegacion record, DelegacionExample example);

    int updateByExample(Delegacion record, DelegacionExample example);

    int updateByPrimaryKeySelective(Delegacion record);

    int updateByPrimaryKey(Delegacion record);
}