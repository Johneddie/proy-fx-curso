package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.decljurada.bean.Parametro;
import pe.gob.sunat.recurso2.humano.decljurada.model.Codigo;
import pe.gob.sunat.recurso2.humano.decljurada.model.CodigoExample;

public interface CodigoDAO {
    int countByExample(CodigoExample example);

    int deleteByExample(CodigoExample example);

    void insert(Codigo record);

    void insertSelective(Codigo record);

    List<Codigo> selectByExample(CodigoExample example);

    int updateByExampleSelective(Codigo record, CodigoExample example);

    int updateByExample(Codigo record, CodigoExample example);
    
    public List<Parametro> selectByExampleBasic(CodigoExample example);
    
    public Codigo obtenerParametro(String codTabla, String codParametro);
    
    public String obtenerDescripcion(String codTabla, String codParametro);
    
    public Codigo obtenerParametroBySigla(String codTabla, String codSigla);
}