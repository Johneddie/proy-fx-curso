package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohab;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.DeclaraDerechohabKey;

public interface DeclaraDerechohabDAO {
    int countByExample(DeclaraDerechohabExample example);

    int deleteByExample(DeclaraDerechohabExample example);

    int deleteByPrimaryKey(DeclaraDerechohabKey key);

    void insert(DeclaraDerechohab record);

    void insertSelective(DeclaraDerechohab record);

    List<DeclaraDerechohab> selectByExample(DeclaraDerechohabExample example);

    DeclaraDerechohab selectByPrimaryKey(DeclaraDerechohabKey key);

    int updateByExampleSelective(DeclaraDerechohab record, DeclaraDerechohabExample example);

    int updateByExample(DeclaraDerechohab record, DeclaraDerechohabExample example);

    int updateByPrimaryKeySelective(DeclaraDerechohab record);

    int updateByPrimaryKey(DeclaraDerechohab record);
    
    public List<DeclaraDerechohab> listarUltimasDeclaraciones(DeclaraDerechohab params);
}