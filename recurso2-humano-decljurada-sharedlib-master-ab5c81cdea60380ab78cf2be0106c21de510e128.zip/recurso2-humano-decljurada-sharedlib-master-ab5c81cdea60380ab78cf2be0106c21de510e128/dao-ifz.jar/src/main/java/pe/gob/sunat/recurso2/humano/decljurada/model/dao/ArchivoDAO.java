package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Archivo;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoExample;
import pe.gob.sunat.recurso2.humano.decljurada.model.ArchivoKey;

public interface ArchivoDAO {
    int countByExample(ArchivoExample example);

    int deleteByExample(ArchivoExample example);

    int deleteByPrimaryKey(ArchivoKey key);

    void insert(Archivo record);

    void insertSelective(Archivo record);

    List<Archivo> selectByExampleWithBLOBs(ArchivoExample example);

    List<Archivo> selectByExampleWithoutBLOBs(ArchivoExample example);

    Archivo selectByPrimaryKey(ArchivoKey key);

    int updateByExampleSelective(Archivo record, ArchivoExample example);

    int updateByExampleWithBLOBs(Archivo record, ArchivoExample example);

    int updateByExampleWithoutBLOBs(Archivo record, ArchivoExample example);

    int updateByPrimaryKeySelective(Archivo record);

    int updateByPrimaryKeyWithBLOBs(Archivo record);

    int updateByPrimaryKeyWithoutBLOBs(Archivo record);
    
    //personalizado
    
    public List<Archivo> listarArchivosByTipo(String annDdjj, Integer numDdjj, String codTip);
}