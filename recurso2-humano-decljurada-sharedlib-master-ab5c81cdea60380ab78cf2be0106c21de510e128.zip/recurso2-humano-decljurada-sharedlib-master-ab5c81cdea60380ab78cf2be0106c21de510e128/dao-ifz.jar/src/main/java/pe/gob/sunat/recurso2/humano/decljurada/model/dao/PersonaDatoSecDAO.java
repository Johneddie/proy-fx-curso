package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaDatoSec;
import pe.gob.sunat.recurso2.humano.decljurada.model.PersonaDatoSecExample;

public interface PersonaDatoSecDAO {
    int countByExample(PersonaDatoSecExample example);

    int deleteByExample(PersonaDatoSecExample example);

    void insert(PersonaDatoSec record);

    void insertSelective(PersonaDatoSec record);

    List<PersonaDatoSec> selectByExample(PersonaDatoSecExample example);

    int updateByExampleSelective(PersonaDatoSec record, PersonaDatoSecExample example);

    int updateByExample(PersonaDatoSec record, PersonaDatoSecExample example);
}