package pe.gob.sunat.recurso2.humano.decljurada.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura05;
import pe.gob.sunat.recurso2.humano.decljurada.model.Estructura05Example;

public interface Estructura05DAO {
    int countByExample(Estructura05Example example);

    int deleteByExample(Estructura05Example example);

    void insert(Estructura05 record);

    void insertSelective(Estructura05 record);

    List<Estructura05> selectByExample(Estructura05Example example);

    int updateByExampleSelective(Estructura05 record, Estructura05Example example);

    int updateByExample(Estructura05 record, Estructura05Example example);
}